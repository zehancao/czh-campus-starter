from flask import Flask, render_template, request, jsonify
import json
from datetime import datetime

app = Flask(__name__)

# 存储最新数据
latest_data = {
    'voltage': 0.0,
    'status': 'Normal',
    'time': ''
}

# 存储历史数据（最多50条）
history_data = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    global latest_data, history_data
    try:
        # 接收 Hi3861 发送的数据
        data = request.get_json()
        if data:
            voltage = float(data.get('voltage', 0))
            # 判断烟雾状态
            status = 'Alarm!' if voltage > 2.5 else 'Normal'
            now = datetime.now().strftime('%H:%M:%S')
            
            latest_data = {
                'voltage': voltage,
                'status': status,
                'time': now
            }
            
            # 保存历史
            history_data.append({
                'time': now,
                'voltage': voltage
            })
            if len(history_data) > 50:
                history_data.pop(0)
            
            print(f"[{now}] Voltage: {voltage:.3f}V, Status: {status}")
            return jsonify({'status': 'ok'})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'status': 'error'}), 500

@app.route('/data')
def get_data():
    return jsonify({
        'latest': latest_data,
        'history': history_data
    })

if __name__ == '__main__':
    # 让 Flask 监听所有网络接口，开发板可以访问
    app.run(host='0.0.0.0', port=5000, debug=True)