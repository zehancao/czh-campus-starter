#include <stdio.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"


void Thread1(void)
{
    int sum = 0;
    while (1)
    {
        printf("This is thread1----%d\r\n", sum++);
        usleep(1000000);
    }
}

static void ThreadDeleteSample(void)
{
    osThreadAttr_t attr;

    attr.name = "thread1";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 1024 * 4;
    attr.priority = 25;

    osThreadId_t threadID1 = osThreadNew((osThreadFunc_t)Thread1, NULL, &attr);
    if (threadID1 == NULL)
    {
        printf("Falied to create thread1!\n");
    }

    int sum = 0;
    for (int i = 0; i < 5; i++)
    {
        printf("This is main thread----%d\r\n", sum++);
        usleep(1000000);
    }
    
    osStatus_t status = osThreadTerminate(threadID1);
    printf("This is main thread: terminate thread1, result:%d\r\n", status);
    
    while (1)
    {
        printf("This is main thread----%d\r\n", sum++);
        usleep(1000000);
    }
}

APP_FEATURE_INIT(ThreadDeleteSample);
