#ifndef __FINGERPRINT_UART_TASK_H__
#define __FINGERPRINT_UART_TASK_H__

#include <hi_types_base.h>
#include <hi_early_debug.h>
#include <hi_task.h>
#include <hi_uart.h>

#define WRITE_BY_INT
#define UART_DEMO_TASK_STAK_SIZE 2048
#define UART_DEMO_TASK_PRIORITY  20
#define DEMO_UART_NUM            HI_UART_IDX_1

//max onece readLen is 16
//#define UART_BUFF_SIZE           32
#define UART_BUFF_SIZE           600

hi_void fingerprint_uart_demo(hi_void);
#endif 
