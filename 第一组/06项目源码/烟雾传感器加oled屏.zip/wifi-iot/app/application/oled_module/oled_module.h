#ifndef __OLED_MODULE_H__
#define __OLED_MODULE_H__

#include <hi_types_base.h>
#include <hi_io.h>
#include <hi_early_debug.h>
#include <hi_gpio.h>
#include <hi_task.h>

// 声明 WiFi 状态变量（由 wifi_module 更新）
extern int g_wifi_connected;

hi_void oled_demo(hi_void);
hi_void oled_gpio_io_init(hi_void);

#endif