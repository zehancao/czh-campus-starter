#include <stdio.h>
#include <string.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "hi_gpio.h"
#include "hi_io.h"
#include "hi_spi.h"
#include "oled.h"
#include "gui.h"
#include "oled_module.h"
#include "smoke_adc.h"
#include "spi_screen.h"

// 使用 wifi_module.c 中定义的全局变量
extern int g_wifi_connected;

void oled_gpio_io_init(void)
{
    hi_u32 ret;
    
    ret = hi_io_set_func(HI_IO_NAME_GPIO_8, HI_IO_FUNC_GPIO_8_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO8 set func failed:%d\r\n", ret);
        return;
    }
    ret = hi_gpio_set_dir(HI_GPIO_IDX_8, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO8 set dir failed:%d\r\n", ret);
        return;
    }
    
    ret = hi_io_set_func(HI_IO_NAME_GPIO_11, HI_IO_FUNC_GPIO_11_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO11 set func failed:%d\r\n", ret);
        return;
    }
    ret = hi_gpio_set_dir(HI_GPIO_IDX_11, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO11 set dir failed:%d\r\n", ret);
        return;
    }
    
    ret = hi_io_set_func(HI_IO_NAME_GPIO_12, HI_IO_FUNC_GPIO_12_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO12 set func failed:%d\r\n", ret);
        return;
    }
    ret = hi_gpio_set_dir(HI_GPIO_IDX_12, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO12 set dir failed:%d\r\n", ret);
        return;
    }
    
    printf("OLED GPIO init success!\r\n");
}

static void OledDisplayTask(void *arg)
{
    (void)arg;
    char buf[32];
    int count = 0;
    
    oled_gpio_io_init();
    hi_spi_deinit(HI_SPI_ID_0);
    screen_spi_master_init(0);
    
    OLED_Init();
    OLED_Clear(0);
    printf("========== OLED Display Started ==========\r\n");
    
    while (1) {
        OLED_Clear(0);
        
        if (g_wifi_connected) {
            GUI_ShowString(0, 0, "WiFi: Connected  ", 16, 1);
        } else {
            GUI_ShowString(0, 0, "WiFi: Disconnected", 16, 1);
        }
        
        float voltage = g_smoke_voltage;
        snprintf(buf, sizeof(buf), "Smoke: %.2fV     ", voltage);
        GUI_ShowString(0, 20, buf, 16, 1);
        
        if (voltage > 2.5) {
            GUI_ShowString(0, 40, "!!! ALARM !!!    ", 16, 1);
        } else {
            GUI_ShowString(0, 40, "Status: Normal   ", 16, 1);
        }
        
        snprintf(buf, sizeof(buf), "Run: %ds         ", count++);
        GUI_ShowString(0, 56, buf, 8, 1);
        
        OLED_Display();
        osDelay(500);
    }
}

static void OledEntry(void)
{
    printf("============== OLED Module Started ==============\r\n");
    
    osThreadAttr_t attr = {
        .name = "OledDisplay",
        .stack_size = 4096,
        .priority = osPriorityNormal,
    };
    osThreadNew(OledDisplayTask, NULL, &attr);
}

SYS_RUN(OledEntry);