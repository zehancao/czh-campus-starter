#ifndef WIFI_STA_H
#define WIFI_STA_H

extern int g_wifi_connected;  // 添加这行

void sta_demo(void);

#endif