#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "hi_wifi_api.h"
#include "lwip/ip_addr.h"
#include "lwip/netifapi.h"
#include "lwip/sockets.h"
#include "hi_watchdog.h"
#include "smoke_adc.h"

#define WIFI_SSID "lzy"
#define WIFI_PSK  "98765432"
#define SERVER_IP   "10.231.155.162"
#define SERVER_PORT 5000

static struct netif *g_lwip_netif = NULL;
int g_wifi_connected = 0;

void hi_sta_reset_addr(struct netif *pst_lwip_netif)
{
    ip4_addr_t st_gw;
    ip4_addr_t st_ipaddr;
    ip4_addr_t st_netmask;
    if (pst_lwip_netif == NULL) {
        printf("hisi_reset_addr::Null param of netdev\r\n");
        return;
    }
    IP4_ADDR(&st_gw, 0, 0, 0, 0);
    IP4_ADDR(&st_ipaddr, 0, 0, 0, 0);
    IP4_ADDR(&st_netmask, 0, 0, 0, 0);
    netifapi_netif_set_addr(pst_lwip_netif, &st_ipaddr, &st_netmask, &st_gw);
}

void wifi_wpa_event_cb(const hi_wifi_event *hisi_event)
{
    if (hisi_event == NULL) return;

    switch (hisi_event->event) {
        case HI_WIFI_EVT_SCAN_DONE:
            printf("WiFi: Scan results available\n");
            break;
        case HI_WIFI_EVT_CONNECTED:
            g_wifi_connected = 1;
            printf("WiFi: Connected\n");
            netifapi_dhcp_start(g_lwip_netif);
            break;
        case HI_WIFI_EVT_DISCONNECTED:
            g_wifi_connected = 0;
            printf("WiFi: Disconnected\n");
            netifapi_dhcp_stop(g_lwip_netif);
            hi_sta_reset_addr(g_lwip_netif);
            break;
        case HI_WIFI_EVT_WPS_TIMEOUT:
            printf("WiFi: wps is timeout\n");
            break;
        default:
            break;
    }
}

int hi_wifi_start_connect(void)
{
    int ret;
    hi_wifi_assoc_request assoc_req = {0};

    strcpy(assoc_req.ssid, WIFI_SSID);
    assoc_req.auth = HI_WIFI_SECURITY_WPA2PSK;
    strcpy(assoc_req.key, WIFI_PSK);

    ret = hi_wifi_sta_connect(&assoc_req);
    if (ret != HISI_OK) {
        printf("hi_wifi_sta_connect failed: %d\r\n", ret);
        return -1;
    }
    printf("WiFi connecting...\r\n");
    return 0;
}

void http_post_voltage(float voltage)
{
    int sock;
    struct sockaddr_in server_addr;
    char request[512];
    char response[128];
    int ret;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        printf("socket create failed\r\n");
        return;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    ret = connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (ret < 0) {
        printf("connect failed, ret: %d\r\n", ret);
        close(sock);
        return;
    }

    char json_data[64];
    snprintf(json_data, sizeof(json_data), "{\"voltage\":%.3f}", voltage);

    snprintf(request, sizeof(request),
        "POST /upload HTTP/1.1\r\n"
        "Host: %s:%d\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: %d\r\n"
        "\r\n"
        "%s",
        SERVER_IP, SERVER_PORT, (int)strlen(json_data), json_data
    );

    ret = send(sock, request, strlen(request), 0);
    if (ret < 0) {
        printf("send failed, ret: %d\r\n", ret);
        close(sock);
        return;
    }

    ret = recv(sock, response, sizeof(response) - 1, 0);
    if (ret > 0) {
        response[ret] = '\0';
        printf("Server response: %s\r\n", response);
    }

    close(sock);
}

static void wifi_demo(void)
{
    int ret;
    char ifname[WIFI_IFNAME_MAX_SIZE + 1] = {0};
    int len = sizeof(ifname);

    printf("\r\n========== WiFi STA Demo Started ==========\r\n");

    ret = hi_wifi_sta_start(ifname, &len);
    if (ret != HISI_OK) {
        printf("hi_wifi_sta_start failed: %d\r\n", ret);
        return;
    }
    printf("hi_wifi_sta_start success, ifname: %s\r\n", ifname);

    ret = hi_wifi_register_event_callback(wifi_wpa_event_cb);
    if (ret != HISI_OK) {
        printf("register wifi event callback failed: %d\n", ret);
    }

    g_lwip_netif = netifapi_netif_find(ifname);
    if (g_lwip_netif == NULL) {
        printf("netifapi_netif_find failed\n");
        return;
    }

    ret = hi_wifi_sta_scan();
    if (ret != HISI_OK) {
        printf("hi_wifi_sta_scan failed: %d\r\n", ret);
        return;
    }
    printf("WiFi scan started...\r\n");

    sleep(5);

    unsigned int num = WIFI_SCAN_AP_LIMIT;
    hi_wifi_ap_info *pst_results = malloc(sizeof(hi_wifi_ap_info) * WIFI_SCAN_AP_LIMIT);
    if (pst_results != NULL) {
        ret = hi_wifi_sta_scan_results(pst_results, &num);
        if (ret == HISI_OK) {
            for (unsigned int loop = 0; loop < num && loop < WIFI_SCAN_AP_LIMIT; loop++) {
                printf("SSID: %s\n", pst_results[loop].ssid);
            }
        }
        free(pst_results);
    }

    ret = hi_wifi_start_connect();
    if (ret != 0) {
        printf("hi_wifi_start_connect failed: %d\r\n", ret);
        return;
    }

    int wait_cnt = 0;
    while (wait_cnt < 30) {
        osDelay(500);
        wait_cnt++;
        hi_wifi_status status = {0};
        if (hi_wifi_sta_get_connect_info(&status) == HISI_OK && status.status == 1) {
            break;
        }
    }

    printf("========== WiFi STA Demo Started Success ==========\r\n");

    while (1) {
        float voltage = g_smoke_voltage;
        printf("Smoke voltage: %.3f, sending to server...\r\n", voltage);
        http_post_voltage(voltage);
        osDelay(2000);
        hi_watchdog_feed();
    }
}

void WiFiEntry(void)
{
    printf("===== WiFiEntry() CALLED =====\r\n");
    osDelay(2000);
    printf("===== Calling wifi_demo() =====\r\n");
    wifi_demo();
}

SYS_RUN(WiFiEntry);