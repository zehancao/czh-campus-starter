#ifndef __SHT3X_I2C_H__
#define __SHT3X_I2C_H__

#include <hi_types_base.h>
#include <hi_i2c.h>
#include <hi_early_debug.h>
#include <hi_stdlib.h>

#define POLYNOMIAL 0x131

typedef enum{
    NO_ERROR = 0x00,
    ACK_ERROR = 0x01,
    CHECKSUM_ERROR = 0x02,
    TIMEOUT_ERROR = 0x04,
    PARM_ERROR = 0x80,
} etError;

typedef enum{
    CMD_READ_SERIALNBR = 0x3780,
    CMD_READ_STATUS = 0xF32D,
    CMD_CLEAR_STATUS = 0x3041,
    CMD_SOFT_RESET = 0x30A2,
    CMD_MEAS_PERI_2_M = 0x2220,
    CMD_FETCH_DATA = 0xE000,
} etCommands;

#define SHT3X_DEV_ADDR 0x80

// 外部变量
extern float Temperature;
extern float Humidity;

// 函数声明
void SHT3X_SoftReset(void);
void SHT3X_init(void);
void SHT3X_ReadSerialNumber(void);
void SHT3X_StartPeriodicMeasurment(void);
void SHT3X_ReadMeasurementBuffer(float* temperature, float* humidity);

#endif