#include <stdio.h>
#include <unistd.h>
#include "hi_timer.h"
#include "hi_gpio.h"
#include "hi_io.h"
#include "dbg.h"
#include "sht3x_i2c.h"

float Temperature = 0;
float Humidity = 0;

void dump_buf(unsigned char *buf, unsigned int len)
{
    if(buf == NULL)
        return;

    DBG("in buf : \r\n");
    for(int i = 0; i < len; i++){
        printf("%#x ", *buf++); 
    }
    printf(" \r\n");
}

static unsigned char SHT3X_CalcCrc(unsigned char data[], unsigned int nbrOfBytes) 
{
    unsigned char bit;
    unsigned char crc = 0xFF;
    unsigned char byteCtr;

    for(byteCtr = 0; byteCtr < nbrOfBytes; byteCtr++)
    {
        crc ^= (data[byteCtr]);
        for(bit = 8; bit > 0; --bit)
        {
            if(crc & 0x80) 
                crc = (crc << 1) ^ POLYNOMIAL;
            else 
                crc = (crc << 1);
        }
    }
    return crc; 
}

static etError SHT3X_CheckCrc(unsigned char data[], unsigned int nbrOfBytes, unsigned char checksum) 
{
    unsigned char crc = SHT3X_CalcCrc(data, nbrOfBytes);
    if(crc != checksum) 
        return CHECKSUM_ERROR;
    else 
        return NO_ERROR; 
}

int SHT3x_WriteCMD(unsigned short cmd)
{
    int ret = -1;
    unsigned char sendbuf[2] = {0};
    
    hi_i2c_data sht3x_i2c_data = { 0 };
    sht3x_i2c_data.send_buf = sendbuf;
    sht3x_i2c_data.send_len = sizeof(sendbuf);
    sht3x_i2c_data.receive_buf = NULL;
    sht3x_i2c_data.receive_len = 0;
    
    sendbuf[0] = (cmd & 0xff00) >> 8;
    sendbuf[1] = cmd & 0xff;
    dump_buf(sendbuf, 2); 
    ret = hi_i2c_write(0, SHT3X_DEV_ADDR, &sht3x_i2c_data);
    if(ret != 0){
        DBG("hi_i2c_write failed ret :%#x \r\n", ret);
        return ret;
    }
    return 0;        
}

int SHT3x_Read4BytesDataAndCrc(unsigned short *data)
{
    int ret = -1;
    unsigned char rcvbuf[6] = {0};
    
    hi_i2c_data sht3x_i2c_data = { 0 };
    sht3x_i2c_data.send_buf = NULL;
    sht3x_i2c_data.send_len = 0;
    sht3x_i2c_data.receive_buf = rcvbuf;
    sht3x_i2c_data.receive_len = sizeof(rcvbuf);

    if(data == NULL){
        DBG("invalid para \r\n");
        return ret;
    }

    ret = hi_i2c_read(0, SHT3X_DEV_ADDR | 0x01, &sht3x_i2c_data);
    if(ret != 0){
        DBG("hi_i2c_read failed ret :%#x \r\n", ret);
        return ret;
    }
    
    ret = SHT3X_CheckCrc(rcvbuf, 2, rcvbuf[2]);
    if(ret != NO_ERROR){
        DBG("read crc check failed \r\n"); 
        return ret;
    }
    
    ret = SHT3X_CheckCrc(&rcvbuf[3], 2, rcvbuf[5]);
    if(ret != NO_ERROR){
        DBG("read crc check failed \r\n"); 
        return ret;
    }

    data[0] = rcvbuf[0] << 8 | rcvbuf[1];
    data[1] = rcvbuf[3] << 8 | rcvbuf[4];

    return 0;        
}

void SHT3X_SoftReset(void)
{
    SHT3x_WriteCMD(CMD_SOFT_RESET);
}

void SHT3X_ReadSerialNumber(void) 
{
    unsigned short data[2] = {0};
    SHT3X_SoftReset();
    SHT3x_WriteCMD(CMD_READ_SERIALNBR);
    SHT3x_Read4BytesDataAndCrc(data);
    printf("Serial Number: 0x%04X 0x%04X\r\n", data[0], data[1]);
}

void SHT3X_StartPeriodicMeasurment(void)
{
    SHT3x_WriteCMD(CMD_MEAS_PERI_2_M);
}

static float SHT3X_CalcTemperature(unsigned short rawValue) 
{
    return 175.0f * (float)rawValue / 65535.0f - 45.0f; 
}

static float SHT3X_CalcHumidity(unsigned short rawValue) 
{
    return 100.0f * (float)rawValue / 65535.0f; 
}

void SHT3X_init(void)
{
    printf("===== SHT3X_init: I2C pins GPIO9(SCL), GPIO10(SDA) =====\r\n");
    
    // I2C0 引脚初始化
    hi_io_set_func(HI_IO_NAME_GPIO_9, HI_IO_FUNC_GPIO_9_I2C0_SCL);
    hi_io_set_func(HI_IO_NAME_GPIO_10, HI_IO_FUNC_GPIO_10_I2C0_SDA);

    SHT3X_SoftReset();
    hi_sleep(100);
    SHT3X_StartPeriodicMeasurment();
    hi_sleep(100);
    printf("SHT3X init done\r\n");
}

void SHT3X_ReadMeasurementBuffer(float* temperature, float* humidity) 
{
    unsigned int rawValueTemp = 0; 
    
    SHT3x_WriteCMD(CMD_FETCH_DATA);
    SHT3x_Read4BytesDataAndCrc((unsigned short *)&rawValueTemp);

    *temperature = SHT3X_CalcTemperature(rawValueTemp);
    *humidity = SHT3X_CalcHumidity(*((unsigned short *)(&rawValueTemp)+1));
    Temperature = *temperature;
    Humidity = *humidity;
    DBG("temp :%.2f, hum :%.2f \r\n", Temperature, Humidity);
}