#include <stdio.h>
#include <unistd.h>
#include "hi_timer.h"
#include "hi_gpio.h"
#include "hi_pwm.h"
#include "dbg.h"
#include "motor_module.h"
#include "hi_spi.h"
#include "ohos_init.h"
#include "oled.h"
#include "gui.h"
#include "spi_screen.h"
#include "sht3x_i2c.h"

#define PWM_CLK_FREQ 160000000 
#define freq 2442

static unsigned int g_MonitorOledTask;
static unsigned int g_MonitorMotorTask;
static unsigned int g_MonitorShtTask;

const hi_task_attr MonitorTaskAttr = {
    .task_prio = 20,
    .stack_size = 4096,
    .task_name = "FanMonitorTask",
};

int g_fan_speed = 0;
int g_ir_triggered = 0;

void *MonitorOledTask(void * para)
{
    char buf[32];
    
    while(1){
        OLED_Clear(0);
        
        GUI_ShowString(0, 0, (u8 *)"Smart Fan", 16, 1);
        
        switch(g_fan_speed) {
            case 0: GUI_ShowString(0, 20, (u8 *)"Speed: OFF     ", 16, 1); break;
            case 1: GUI_ShowString(0, 20, (u8 *)"Speed: Level 1 ", 16, 1); break;
            case 2: GUI_ShowString(0, 20, (u8 *)"Speed: Level 2 ", 16, 1); break;
            case 3: GUI_ShowString(0, 20, (u8 *)"Speed: Level 3 ", 16, 1); break;
            default: GUI_ShowString(0, 20, (u8 *)"Speed: UNKNOWN ", 16, 1);
        }
        
        if(g_ir_triggered) {
            GUI_ShowString(0, 40, (u8 *)"IR: DETECTED   ", 16, 1);
        } else {
            GUI_ShowString(0, 40, (u8 *)"IR: Normal     ", 16, 1);
        }
        
        snprintf(buf, sizeof(buf), "T:%.1fC H:%.1f%%", Temperature, Humidity);
        GUI_ShowString(0, 56, (u8 *)buf, 8, 1);
        
        OLED_Display();
        hi_sleep(500);
    }
    return NULL;
}

void *MonitorMotorTask(void * para)
{
    while(1){
        gpio_getval();
        infrared_ctrl();
        hi_sleep(50);
    }
    return NULL;
}

void *MonitorShtTask(void * para)
{
    float temp, hum;
    
    while(1){
        SHT3X_ReadMeasurementBuffer(&temp, &hum);
        printf("===== SHT3x Sensor =====\r\n");
        printf("Temperature: %.2f C\r\n", temp);
        printf("Humidity: %.2f %%\r\n", hum);
        printf("========================\r\n");
        hi_sleep(2000);
    }
    return NULL;
}

hi_void motor_gpio_io_init(void)
{
    hi_u32 ret;

    /* gpio5 按键控制电机速度 */
    ret = hi_io_set_func(HI_IO_NAME_GPIO_5, HI_IO_FUNC_GPIO_5_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO5 set func failed:%d\r\n", ret);
        return;
    }
    printf("----- gpio5 fan set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_5, HI_GPIO_DIR_IN);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO5 set dir failed:%d\r\n", ret);
        return;
    }
    printf("----- gpio set dir success! -----\r\n");

    /* gpio6 电机模块 LED */
    ret = hi_io_set_func(HI_IO_NAME_GPIO_6, HI_IO_FUNC_GPIO_6_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO6 set func failed:%d\r\n", ret);
        return;
    }
    printf("----- io set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_6, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO6 set dir failed:%d\r\n", ret);
        return;
    }
    
    /* gpio7 电机模块红外传感 */
    ret = hi_io_set_func(HI_IO_NAME_GPIO_7, HI_IO_FUNC_GPIO_7_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO7 set func failed:%d\r\n", ret);
        return;
    }
    printf("----- io set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_7, HI_GPIO_DIR_IN);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO7 set dir failed:%d\r\n", ret);
        return;
    }
    printf("----- gpio set dir success! -----\r\n");

    /* OLED GPIO 初始化 */
    ret = hi_io_set_func(HI_IO_NAME_GPIO_8, HI_IO_FUNC_GPIO_8_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO8 set func failed:%d\r\n", ret);
        return;
    }
    ret = hi_gpio_set_dir(HI_GPIO_IDX_8, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO8 set dir failed:%d\r\n", ret);
        return;
    }

    ret = hi_io_set_func(HI_IO_NAME_GPIO_11, HI_IO_FUNC_GPIO_11_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO11 set func failed:%d\r\n", ret);
        return;
    }
    ret = hi_gpio_set_dir(HI_GPIO_IDX_11, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO11 set dir failed:%d\r\n", ret);
        return;
    }

    ret = hi_io_set_func(HI_IO_NAME_GPIO_12, HI_IO_FUNC_GPIO_12_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO12 set func failed:%d\r\n", ret);
        return;
    }
    ret = hi_gpio_set_dir(HI_GPIO_IDX_12, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO12 set dir failed:%d\r\n", ret);
        return;
    }
    printf("OLED GPIO init success!\r\n");
}

hi_void motor_pwm_init(hi_void)
{
    int ret = -1;
    ret = hi_pwm_deinit(HI_PWM_PORT_PWM2);
    if(ret != 0){ 
        printf("hi_pwm_deinit failed :%#x \r\n",ret); 
    }

    ret = hi_pwm_init(HI_PWM_PORT_PWM2);
    if(ret != 0){ 
        printf("hi_pwm_init failed :%#x \r\n",ret); 
    }

    ret = hi_pwm_set_clock(PWM_CLK_160M);
    if(ret != 0){ 
        printf("hi_pwm_set_clock failed ret : %#x \r\n",ret); 
    }
}

hi_void motor_pwm_start(unsigned int duty)
{
    int ret = 0;  
    DBG("motor start \r\n");

    if(duty == 0){
        ret = hi_pwm_stop(HI_PWM_PORT_PWM2); 
        if(ret != 0){ 
            printf("hi_pwm_stop failed ret : %#x \r\n",ret); 
        }
        return;
    }

    ret = hi_pwm_start(HI_PWM_PORT_PWM2, duty*(PWM_CLK_FREQ/freq)/100, PWM_CLK_FREQ/freq); 
    if(ret != 0){ 
        printf("hi_pwm_start failed ret : %#x \r\n",ret); 
    }
}

int infrared_ctrl(hi_void)
{
    hi_u32 ret;
    int temp = 0;
    hi_gpio_value gpio_val_7 = HI_GPIO_VALUE0;

    ret = hi_gpio_get_input_val(HI_GPIO_IDX_7, &gpio_val_7);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO7 get input failed:%d\r\n", ret);
        return 0;
    }

    if(gpio_val_7 == 1){
        hi_gpio_set_ouput_val(HI_GPIO_IDX_6, HI_GPIO_VALUE1);
        ret = hi_pwm_stop(HI_PWM_PORT_PWM2);
        if(ret != 0){ 
            printf("hi_pwm_stop failed ret : %#x \r\n",ret); 
        }
        g_ir_triggered = 1;
        temp = 1;
    }else{
        hi_gpio_set_ouput_val(HI_GPIO_IDX_6, HI_GPIO_VALUE0);
        g_ir_triggered = 0;
    }
    return temp;
}

hi_void gpio_getval(hi_void)
{
    hi_u32 ret;
    int temp;
    hi_gpio_value gpio_val_1 = HI_GPIO_VALUE1;
 
    temp = infrared_ctrl();
    ret = hi_gpio_get_input_val(HI_GPIO_IDX_5, &gpio_val_1);
    if (ret != HI_ERR_SUCCESS) {
        printf("GPIO5 get input failed:%d\r\n", ret);
        return;
    }

    if(gpio_val_1 == 0){
        hi_sleep(50);
        ret = hi_gpio_get_input_val(HI_GPIO_IDX_5, &gpio_val_1);
        if(ret != HI_ERR_SUCCESS){
            return;
        }
        if(gpio_val_1 == 0){
            g_fan_speed++;
        }

        switch(g_fan_speed){
        case 0:
            break;
        case 1:
            motor_pwm_start(1);
            printf("Fan speed: Level 1\r\n");
            break;
        case 2:
            motor_pwm_start(2);
            printf("Fan speed: Level 2\r\n");
            break;
        case 3:
            motor_pwm_start(3);
            printf("Fan speed: Level 3\r\n");
            break;
        default:
            printf("invalid mode \r\n");
        }

        if(g_fan_speed >= 4 || temp == 1){
            g_fan_speed = 0;
            ret = hi_pwm_stop(HI_PWM_PORT_PWM2);
            if(ret != 0){
                printf("hi_pwm_stop failed \r\n");
            }
            printf("Fan speed: OFF\r\n");
        }
    }
}

hi_void motor_demo(hi_void)
{    
    int ret;
    
    motor_gpio_io_init();
    SHT3X_init();
    motor_pwm_init();

    hi_spi_deinit(HI_SPI_ID_0);
    screen_spi_master_init(0);

    ret = hi_task_create(&g_MonitorOledTask,
        &MonitorTaskAttr,
        MonitorOledTask,
        NULL);
    if (ret < 0) {
        printf("Create monitor oled task failed [%d]\r\n", ret);
    }
   
    ret = hi_task_create(&g_MonitorMotorTask,
        &MonitorTaskAttr,
        MonitorMotorTask,
        NULL);
    if (ret < 0) {
        printf("Create monitor motor task failed [%d]\r\n", ret);
    }   
    
    ret = hi_task_create(&g_MonitorShtTask,
        &MonitorTaskAttr,
        MonitorShtTask,
        NULL);
    if (ret < 0) {
        printf("Create monitor sht task failed [%d]\r\n", ret);
    }
}

static void FanEntry(void)
{
    printf("============== smart fan module ==============\r\n");
    motor_demo();
}

SYS_RUN(FanEntry);