#ifndef __MOTOR_MODULE_H__
#define __MOTOR_MODULE_H__

#include <hi_types_base.h>
#include <hi_io.h>
#include <hi_early_debug.h>
#include <hi_gpio.h>
#include <hi_task.h>
#include <hi_i2c.h>
#include <hi_spi.h>
#include <hi_pwm.h>

// 全局变量声明
extern int g_fan_speed;
extern int g_ir_triggered;

// 函数声明
void motor_gpio_io_init(void);
void motor_pwm_init(void);
void motor_pwm_start(unsigned int duty);
int infrared_ctrl(void);
void gpio_getval(void);
void motor_demo(void);

#endif