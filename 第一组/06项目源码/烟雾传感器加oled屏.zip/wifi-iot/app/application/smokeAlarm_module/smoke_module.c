#include <stdio.h>
#include "hi_timer.h"
#include "hi_gpio.h"
#include "hi_pwm.h"
#include "dbg.h"
#include "smoke_module.h"
#include "smoke_adc.h"
#include "ohos_init.h"

#define PWM_CLK_FREQ 160000000 
#define freq 2442

static unsigned int g_MonitorTask;
static const hi_task_attr MonitorTaskAttr = {
    .task_prio = 20,
    .stack_size = 4096,
    .task_name = "smoke_alarm_task",
};

void *MonitorTask_smoke(void * para)
{
    while(1){
        smoke_adc_gather();
        printf("smoke monitor task \r\n");
        hi_sleep(500);
    }
    return NULL;
}

hi_void smoke_gpio_io_init(void)
{
    hi_u32 ret;
    
    ret = hi_io_set_func(HI_IO_NAME_GPIO_5, HI_IO_FUNC_GPIO_5_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio5 smoke set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_5, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_set_dir1 ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio set dir success! -----\r\n");
}

hi_void smoke_pwm_init(hi_void)
{
    int ret = -1;
    ret = hi_pwm_deinit(HI_PWM_PORT_PWM2);
    if(ret != 0){ 
        printf("hi_pwm_deinit failed :%#x \r\n",ret); 
    }

    ret = hi_pwm_init(HI_PWM_PORT_PWM2);
    if(ret != 0){ 
        printf("hi_pwm_init failed :%#x \r\n",ret); 
    }

    ret = hi_pwm_set_clock(PWM_CLK_160M);
    if(ret != 0){ 
        printf("hi_pwm_set_clock failed ret : %#x \r\n",ret); 
    }
}

hi_void smoke_led_ctrl(unsigned int state)
{  
    if(state == 1){
        printf("----- smoke alarm led turn on -----\r\n");
        hi_gpio_set_ouput_val(HI_GPIO_IDX_5,HI_GPIO_VALUE1);
    }else{
        printf("----- smoke alarm led turn off -----\r\n");
        hi_gpio_set_ouput_val(HI_GPIO_IDX_5,HI_GPIO_VALUE0);
    }
}

hi_void smoke_pwm_start(unsigned int duty)
{
    int ret = 0;  
    DBG("motor start \r\n");

    if(duty == 0){
        smoke_led_ctrl(0);
        ret = hi_pwm_stop(HI_PWM_PORT_PWM2); 
        if(ret != 0){ 
            printf("hi_pwm_start failed ret : %#x \r\n",ret); 
        }
    }else{
        smoke_led_ctrl(1);
        ret = hi_pwm_start(HI_PWM_PORT_PWM2, duty*(PWM_CLK_FREQ/freq)/100, PWM_CLK_FREQ/freq); 
        if(ret != 0){ 
            printf("hi_pwm_start failed ret : %#x \r\n",ret); 
        }
    }
}
 
hi_void smoke_adc_demo(hi_void)
{   
    int ret;

    smoke_gpio_io_init();
    smoke_pwm_init();
    
    ret = hi_task_create(&g_MonitorTask,
        &MonitorTaskAttr,
        MonitorTask_smoke,
        NULL);
}

static void SmokeEntry(void)
{
    printf("============== smoke alarm module ==============\r\n");
    smoke_adc_demo();
}

SYS_RUN(SmokeEntry);