ALL_LIBS := wifiiot_app
wifiiot_app_srcs := init src

CCFLAGS += -DCONFIG_I2C_SUPPORT
CCFLAGS += -D_PRE_WLAN_FEATURE_CSI -D_PRE_WLAN_FEATURE_P2P -DLWIP_ENABLE_DIAG_CMD=0
CCFLAGS += -DCONFIG_PWM_SUPPORT -DCONFIG_SPI_SUPPORT
CCFLAGS += -I$(MAIN_TOPDIR)/components/iperf2/include \
           -I$(MAIN_TOPDIR)/app/wifiiot_app/include \
           -I$(MAIN_TOPDIR)/app/wifiiot_app/init \
           -I$(MAIN_TOPDIR)/app/wifiiot_app/src \
           -I$(MAIN_TOPDIR)/app/wifiiot_app/application/motor_module \
           -I$(MAIN_TOPDIR)/config/app \
           -I$(MAIN_TOPDIR)/config/diag \
           -I$(MAIN_TOPDIR)/platform/os/Huawei_LiteOS/net/ripple/exports \
           -I$(MAIN_TOPDIR)/components/ripple/exports