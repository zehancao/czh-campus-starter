#include <stdio.h>
#include <unistd.h>
#include "hi_timer.h"
#include "hi_gpio.h"
#include "hi_pwm.h"
#include "dbg.h"
#include "motor_module.h"
#include "hi_spi.h"

#define PWM_CLK_FREQ 160000000 
#define freq 2442  //min


static unsigned int g_MonitorTask;
const hi_task_attr MonitorTaskAttr = {
    .task_prio = 20,
    .stack_size = 4096,
    .task_name = "BuggyNetworkMonitorTask",
};

void *MonitorOledTask(void * para) /* OLEDtask处理函数 */
{
    while(1){
        test_led_screen();
        printf("OLED task \r\n");
    }
    return NULL;
}

void *MonitorMotorTask(void * para) /* 电机task处理函数 */
{
    while(1){
        gpio_getval();
        infrared_ctrl(); 
        //printf("fan task \r\n");
    }
    return NULL;
}

void *MonitorShtTask(void * para) /* 温湿度传感器处理函数 */
{
    while(1){
        sleep(2);
        SHT3X_ReadMeasurementVal(0);
        printf("sth task \r\n");
    }
    return NULL;
}

hi_void motor_gpio_io_init(void)
{
    hi_u32 ret;

    /*gpio5按键控制电机速度*/
    ret = hi_io_set_func(HI_IO_NAME_GPIO_5, HI_IO_FUNC_GPIO_5_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio5 fan set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_5, HI_GPIO_DIR_IN);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_set_dir1 ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio set dir success! -----\r\n");

    /*gpio6电机模块led*/
    ret = hi_io_set_func(HI_IO_NAME_GPIO_6, HI_IO_FUNC_GPIO_6_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }
    printf("----- io set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_6, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_set_dir1 ret:%d\r\n", ret);
        return;
    }
    
    /*gpio7 电机模块红外传感*/
    ret = hi_io_set_func(HI_IO_NAME_GPIO_7, HI_IO_FUNC_GPIO_7_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }
    printf("----- io set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_7, HI_GPIO_DIR_IN);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_set_dir1 ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio set dir success! -----\r\n");

    /*
    ret = hi_io_set_func(HI_IO_NAME_GPIO_11, HI_IO_FUNC_GPIO_11_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }
    printf("----- io set func success-----\r\n");
    */
    ret = hi_io_set_func(HI_IO_NAME_GPIO_8, HI_IO_FUNC_GPIO_8_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }
    printf("----- io set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_8, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_set_dir1 ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio set dir success! -----\r\n");

    ret = hi_io_set_func(HI_IO_NAME_GPIO_11, HI_IO_FUNC_GPIO_11_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }
    printf("----- io set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_11, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_set_dir1 ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio set dir success! -----\r\n");

    ret = hi_io_set_func(HI_IO_NAME_GPIO_12, HI_IO_FUNC_GPIO_12_GPIO);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_io_set_func ret:%d\r\n", ret);
        return;
    }
    printf("----- io set func success-----\r\n");

    ret = hi_gpio_set_dir(HI_GPIO_IDX_12, HI_GPIO_DIR_OUT);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_set_dir1 ret:%d\r\n", ret);
        return;
    }
    printf("----- gpio set dir success! -----\r\n");
}

void motor_pwm_init(hi_void)
{
    // 将 GPIO2 设置为输出模式（用于电机控制）
    hi_io_set_func(HI_IO_NAME_GPIO_2, HI_IO_FUNC_GPIO_2_GPIO);
    hi_gpio_set_dir(HI_GPIO_IDX_2, HI_GPIO_DIR_OUT);
    hi_gpio_set_ouput_val(HI_GPIO_IDX_2, HI_GPIO_VALUE0);
    printf("motor_pwm_init: GPIO2 set as output (GPIO PWM simulation)\r\n");
}

// 替换原来的 motor_pwm_start 函数
void motor_pwm_start(unsigned int duty)
{
    // duty: 0~100，表示占空比百分比
    // 通过 GPIO 模拟 PWM
    static int pwm_running = 0;
    
    if (duty == 0) {
        // 停止电机
        hi_gpio_set_ouput_val(HI_GPIO_IDX_2, HI_GPIO_VALUE0);
        pwm_running = 0;
        printf("Motor stopped\r\n");
        return;
    }
    
    // 启动电机，使用 GPIO 模拟 PWM
    // 这里简单实现：直接输出高电平（100% 占空比，全速）
    // 如果需要调速，可以在定时器中断中实现精确 PWM
    hi_gpio_set_ouput_val(HI_GPIO_IDX_2, HI_GPIO_VALUE1);
    pwm_running = 1;
    printf("Motor running with duty: %d%% (GPIO simulated)\r\n", duty);
}

int infrared_ctrl(hi_void)
{
    hi_u32 ret;
    int temp = 0;
    hi_gpio_value gpio_val_7 = HI_GPIO_VALUE0;

    ret = hi_gpio_get_input_val(HI_GPIO_IDX_7, &gpio_val_7);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_get_input_val ret:%d\r\n", ret);
        return 0;
    }

    //printf("----- gpio input val is:%d. -----\r\n", gpio_val_7);

    if(gpio_val_7 == 1){
        hi_gpio_set_ouput_val(HI_GPIO_IDX_6,HI_GPIO_VALUE1);
        ret = hi_pwm_stop(HI_PWM_PORT_PWM2);
        if(ret != 0){ 
            printf("hi_pwm_start failed ret : %#x \r\n",ret); 
        }
        temp = 1;
    }else{
        hi_gpio_set_ouput_val(HI_GPIO_IDX_6,HI_GPIO_VALUE0);
    }
    return temp;
}

hi_void gpio_getval(hi_void)
{
    hi_u32 ret;
    int temp;
    static int key = 0;
    hi_gpio_value gpio_val_1 = HI_GPIO_VALUE1;
 
    temp = infrared_ctrl();
    ret = hi_gpio_get_input_val(HI_GPIO_IDX_5, &gpio_val_1);
    if (ret != HI_ERR_SUCCESS) {
        printf("===== ERROR ===== gpio -> hi_gpio_get_input_val ret:%d\r\n", ret);
        return;
    }

    //printf("----- gpio input val is:%d. -----\r\n", gpio_val_1);

    if(gpio_val_1 == 0){
        sleep(1);
        if(gpio_val_1 == 0){
            key++;
        }

        switch(key){
        case 0:
            break;

        case 1:
            motor_pwm_start(1);
            break;

        case 2:
            motor_pwm_start(2);
            break;

        case 3:
            motor_pwm_start(3);
            break;

        default:
            printf("invalid mode \r\n");
        }

        if(key >= 4 || key == 0 || temp == 1){
            key = 0;
            ret = hi_pwm_stop(HI_PWM_PORT_PWM2);
            if(ret != 0){
                printf("hi_pwm_stop failed \r\n");
            }
        }
    }
    //printf("key : %d \r\n",key);


}

hi_void motor_demo(hi_void)
{
    int ret;
    motor_gpio_io_init();
    SHT3X_init();
    motor_pwm_init();
    // hi_spi_deinit(HI_SPI_ID_0);
    // screen_spi_master_init(0);
    // ... 后续代码
}