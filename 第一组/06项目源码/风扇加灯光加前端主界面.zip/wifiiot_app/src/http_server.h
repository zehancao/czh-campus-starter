#ifndef HTTP_SERVER_H
#define HTTP_SERVER_H

#include <hi_types.h>

void wifi_ap_init(hi_void);
hi_void *http_server_task(hi_void *arg);
void wifi_sta_init(hi_void);

extern float Temperature;
extern float Humidity;

#endif