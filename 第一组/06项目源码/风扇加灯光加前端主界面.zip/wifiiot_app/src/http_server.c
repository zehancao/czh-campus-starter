#include "http_server.h"
#include <hi_wifi_api.h>
//#include <hi_wifi_sta.h>
#include <lwip/sockets.h>
#include <lwip/netdb.h>
#include <hi_gpio.h>
#include <hi_io.h>
#include <hi_pwm.h>
#include <hi_task.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <lwip/netif.h>
#include <lwip/ip4_addr.h>
#include <lwip/dhcp.h>
#include <lwip/netifapi.h>
#include <hi_watchdog.h>
#include <arpa/inet.h>

// ===== 临时空实现（让编译通过） =====
//void motor_pwm_start(unsigned int duty)
//{
//   printf("motor_pwm_start called with duty: %d (placeholder)\r\n", duty);
//}
// ====================================

#define STA_SSID "lzy"      // 改成你的手机热点名称
#define STA_PWD  "98765432"        // 改成你的手机热点密码
#define HTTP_PORT 80

extern float Temperature;
extern float Humidity;

//float Temperature = 25.0;
//float Humidity = 60.0;

// -------------------- WiFi STA 初始化 --------------------
void wifi_sta_init(hi_void)
{
    hi_u32 ret;
    char ifname[16] = {0};
    int len = sizeof(ifname);
    hi_wifi_assoc_request req = {0};

    // 启动 STA 模式
    ret = hi_wifi_sta_start(ifname, &len);
    if (ret != HI_ERR_SUCCESS) {
        printf("sta start failed: 0x%x\r\n", ret);
        return;
    }
    printf("STA started, ifname=%s\r\n", ifname);

    // 配置连接参数
    strcpy((char *)req.ssid, "lzy");
    strcpy((char *)req.key, "98765432");
    req.auth = HI_WIFI_SECURITY_WPA2PSK;

    // 连接热点
    ret = hi_wifi_sta_connect(&req);
    if (ret != HI_ERR_SUCCESS) {
        printf("sta connect failed: 0x%x\r\n", ret);
        return;
    }

    printf("Connecting to SSID: %s\r\n", req.ssid);
    hi_sleep(3000);  // 等待连接完成

    // ===== 手动启动 DHCP 客户端 =====
    struct netif *netif = netif_find("wlan0");
    if (netif == NULL) {
        netif = netif_find("sta0");
    }
    if (netif != NULL) {
        // 启动 DHCP 客户端
        err_t err = netifapi_dhcp_start(netif);
        if (err == ERR_OK) {
            printf("DHCP client started\r\n");
        } else {
            printf("DHCP client start failed: %d\r\n", err);
        }
        hi_sleep(2000);  // 等待 DHCP 获取 IP
        printf("Connected! IP: %s\r\n", ip4addr_ntoa(netif_ip_addr4(netif)));
    } else {
        printf("Failed to find network interface\r\n");
    }
}

// -------------------- 响应函数 --------------------
static void send_html_page(int client_fd)
{
    const char *html =
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Connection: close\r\n\r\n"
        "<!DOCTYPE html>"
        "<html>"
        "<head><title>Harmony IoT Control</title>"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        "<style>"
        "body { font-family: Arial; text-align: center; margin-top: 50px; "
        "background: #f5f5f5; }"
        ".container { max-width: 400px; margin: auto; background: white; "
        "padding: 30px; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }"
        "h1 { color: #333; }"
        ".btn { display: inline-block; padding: 14px 28px; margin: 8px; "
        "font-size: 18px; border: none; border-radius: 30px; color: white; "
        "cursor: pointer; text-decoration: none; min-width: 120px; }"
        ".btn-green { background: linear-gradient(135deg, #4CAF50, #66BB6A); }"
        ".btn-red { background: linear-gradient(135deg, #f44336, #ef5350); }"
        ".btn-blue { background: linear-gradient(135deg, #2196F3, #42A5F5); }"
        ".btn-orange { background: linear-gradient(135deg, #FF9800, #FFA726); }"
        ".btn-gray { background: #9E9E9E; }"
        ".sensor-box { background: #e3f2fd; padding: 15px; border-radius: 12px; "
        "margin: 20px 0; font-size: 20px; }"
        ".footer { margin-top: 20px; color: #888; font-size: 14px; }"
        "</style>"
        "</head>"
        "<body>"
        "<div class=\"container\">"
        "<h1>🌟 IoT 控制面板</h1>"
        "<h2>💡 LED 控制</h2>"
        "<a href=\"/led_on\" class=\"btn btn-green\">开灯</a>"
        "<a href=\"/led_off\" class=\"btn btn-red\">关灯</a>"
        "<h2>🌀 风扇控制</h2>"
        "<a href=\"/fan_on\" class=\"btn btn-blue\">开风扇</a>"
        "<a href=\"/fan_off\" class=\"btn btn-orange\">关风扇</a>"
        "<div class=\"sensor-box\">"
        "<p>🌡️ 温度: <span id=\"temp\">--</span> °C</p>"
        "<p>💧 湿度: <span id=\"humi\">--</span> %</p>"
        "</div>"
        "<a href=\"/data\" class=\"btn btn-gray\">🔄 刷新数据</a>"
        "<p class=\"footer\">开发板已连接手机热点</p>"
        "</div>"
        "</body>"
        "</html>\r\n";

    send(client_fd, html, strlen(html), 0);
}

static void send_html_response(int client_fd, const char *message)
{
    char response[512];
    snprintf(response, sizeof(response),
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Connection: close\r\n\r\n"
        "<!DOCTYPE html><html><body style=\"text-align:center;margin-top:50px;font-family:Arial;\">"
        "<h1>✅ %s</h1>"
        "<a href=\"/\" style=\"display:inline-block;padding:12px 24px;"
        "background:#2196F3;color:white;text-decoration:none;border-radius:8px;\">"
        "⬅ 返回控制面板</a>"
        "</body></html>\r\n", message);
    send(client_fd, response, strlen(response), 0);
}

static void send_json_response(int client_fd, const char *json)
{
    char response[512];
    snprintf(response, sizeof(response),
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: application/json\r\n"
        "Connection: close\r\n\r\n"
        "%s\r\n", json);
    send(client_fd, response, strlen(response), 0);
}

// -------------------- 请求处理 --------------------
static void handle_http_request(int client_fd, char *request)
{
    char method[8], path[64], version[16];

    sscanf(request, "%s %s %s", method, path, version);
    printf("Method: %s, Path: %s\r\n", method, path);

    if (strcmp(path, "/led_on") == 0) {
        hi_gpio_set_ouput_val(HI_GPIO_IDX_8, HI_GPIO_VALUE1);
        send_html_response(client_fd, "LED 已开启");
    } else if (strcmp(path, "/led_off") == 0) {
        hi_gpio_set_ouput_val(HI_GPIO_IDX_8, HI_GPIO_VALUE0);
        send_html_response(client_fd, "LED 已关闭");
    } else if (strcmp(path, "/fan_on") == 0) {
        motor_pwm_start(2);
        send_html_response(client_fd, "风扇已开启（2档）");
    } else if (strcmp(path, "/fan_off") == 0) {
        motor_pwm_start(0);
        send_html_response(client_fd, "风扇已关闭");
    } else if (strcmp(path, "/data") == 0) {
        char json[128];
        snprintf(json, sizeof(json),
            "{\"temperature\": %.1f, \"humidity\": %.1f}",
            Temperature, Humidity);
        send_json_response(client_fd, json);
    } else {
        send_html_page(client_fd);
    }
}

// -------------------- HTTP 服务器任务 --------------------
hi_void *http_server_task(hi_void *arg)
{
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    char recv_buf[512];
    int recv_len;

    printf("===== http_server_task ENTER =====\r\n");

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        printf("socket create failed! errno=%d\r\n", errno);
        return HI_NULL;
    }
    printf("socket created, fd=%d\r\n", server_fd);

    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(HTTP_PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    int reuse = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));

    // 等待网络接口准备好
    hi_sleep(1000);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        printf("bind failed! errno=%d\r\n", errno);
        close(server_fd);
        return HI_NULL;
    }
    printf("bind success!\r\n");

    if (listen(server_fd, 5) < 0) {
        printf("listen failed! errno=%d\r\n", errno);
        close(server_fd);
        return HI_NULL;
    }
    printf("listen success!\r\n");

    printf("HTTP server started on port %d\r\n", HTTP_PORT);

    while (1) {
        client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len);
        if (client_fd < 0) {
            printf("accept failed! errno=%d\r\n", errno);
            continue;
        }
        printf("Client connected! IP: %s, port: %d\r\n", 
               inet_ntoa(client_addr.sin_addr), 
               ntohs(client_addr.sin_port));

        recv_len = recv(client_fd, recv_buf, sizeof(recv_buf) - 1, 0);
        if (recv_len > 0) {
            recv_buf[recv_len] = '\0';
            handle_http_request(client_fd, recv_buf);
        }

        close(client_fd);
    }

    return HI_NULL;
}