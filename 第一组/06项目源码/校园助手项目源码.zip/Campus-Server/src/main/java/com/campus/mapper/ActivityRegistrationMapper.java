package com.campus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.entity.ActivityRegistration;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ActivityRegistrationMapper extends BaseMapper<ActivityRegistration> {
}
