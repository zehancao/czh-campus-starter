package com.campus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.entity.BrowseHistory;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BrowseHistoryMapper extends BaseMapper<BrowseHistory> {
}
