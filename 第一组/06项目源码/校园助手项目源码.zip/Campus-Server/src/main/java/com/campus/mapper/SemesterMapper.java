package com.campus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.entity.Semester;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SemesterMapper extends BaseMapper<Semester> {
}
