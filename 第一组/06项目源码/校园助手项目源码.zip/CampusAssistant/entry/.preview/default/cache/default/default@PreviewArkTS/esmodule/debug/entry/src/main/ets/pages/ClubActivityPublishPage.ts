if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ClubActivityPublishPage_Params {
    selectedClub?: string;
    customClub?: string;
    title?: string;
    description?: string;
    venue?: string;
    activityTime?: string;
    maxParticipants?: number;
    isSubmitting?: boolean;
    coverImage?: string;
    selectedYear?: number;
    selectedMonth?: number;
    selectedDay?: number;
    selectedHour?: number;
    selectedMinute?: number;
    clubOptions?: string[];
    yearRange?: string[];
    monthRange?: string[];
    hourRange?: string[];
    minuteRange?: string[];
}
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
class ClubActivityPublishPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__selectedClub = new ObservedPropertySimplePU('', this, "selectedClub");
        this.__customClub = new ObservedPropertySimplePU('', this, "customClub");
        this.__title = new ObservedPropertySimplePU('', this, "title");
        this.__description = new ObservedPropertySimplePU('', this, "description");
        this.__venue = new ObservedPropertySimplePU('', this, "venue");
        this.__activityTime = new ObservedPropertySimplePU('', this, "activityTime");
        this.__maxParticipants = new ObservedPropertySimplePU(20, this, "maxParticipants");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.__coverImage = new ObservedPropertySimplePU('', this, "coverImage");
        this.__selectedYear = new ObservedPropertySimplePU(2026, this, "selectedYear");
        this.__selectedMonth = new ObservedPropertySimplePU(1, this, "selectedMonth");
        this.__selectedDay = new ObservedPropertySimplePU(1, this, "selectedDay");
        this.__selectedHour = new ObservedPropertySimplePU(19, this, "selectedHour");
        this.__selectedMinute = new ObservedPropertySimplePU(0, this, "selectedMinute");
        this.clubOptions = ['篮球', '排球', '足球', '羽毛球', '乒乓球', '剧本杀', '桌游', '唱歌', '学习', '琴棋书画', '电竞', '户外', '聚餐', '其他'];
        this.yearRange = [];
        this.monthRange = [];
        this.hourRange = [];
        this.minuteRange = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ClubActivityPublishPage_Params) {
        if (params.selectedClub !== undefined) {
            this.selectedClub = params.selectedClub;
        }
        if (params.customClub !== undefined) {
            this.customClub = params.customClub;
        }
        if (params.title !== undefined) {
            this.title = params.title;
        }
        if (params.description !== undefined) {
            this.description = params.description;
        }
        if (params.venue !== undefined) {
            this.venue = params.venue;
        }
        if (params.activityTime !== undefined) {
            this.activityTime = params.activityTime;
        }
        if (params.maxParticipants !== undefined) {
            this.maxParticipants = params.maxParticipants;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
        if (params.coverImage !== undefined) {
            this.coverImage = params.coverImage;
        }
        if (params.selectedYear !== undefined) {
            this.selectedYear = params.selectedYear;
        }
        if (params.selectedMonth !== undefined) {
            this.selectedMonth = params.selectedMonth;
        }
        if (params.selectedDay !== undefined) {
            this.selectedDay = params.selectedDay;
        }
        if (params.selectedHour !== undefined) {
            this.selectedHour = params.selectedHour;
        }
        if (params.selectedMinute !== undefined) {
            this.selectedMinute = params.selectedMinute;
        }
        if (params.clubOptions !== undefined) {
            this.clubOptions = params.clubOptions;
        }
        if (params.yearRange !== undefined) {
            this.yearRange = params.yearRange;
        }
        if (params.monthRange !== undefined) {
            this.monthRange = params.monthRange;
        }
        if (params.hourRange !== undefined) {
            this.hourRange = params.hourRange;
        }
        if (params.minuteRange !== undefined) {
            this.minuteRange = params.minuteRange;
        }
    }
    updateStateVars(params: ClubActivityPublishPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectedClub.purgeDependencyOnElmtId(rmElmtId);
        this.__customClub.purgeDependencyOnElmtId(rmElmtId);
        this.__title.purgeDependencyOnElmtId(rmElmtId);
        this.__description.purgeDependencyOnElmtId(rmElmtId);
        this.__venue.purgeDependencyOnElmtId(rmElmtId);
        this.__activityTime.purgeDependencyOnElmtId(rmElmtId);
        this.__maxParticipants.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
        this.__coverImage.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedYear.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedMonth.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDay.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedHour.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedMinute.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectedClub.aboutToBeDeleted();
        this.__customClub.aboutToBeDeleted();
        this.__title.aboutToBeDeleted();
        this.__description.aboutToBeDeleted();
        this.__venue.aboutToBeDeleted();
        this.__activityTime.aboutToBeDeleted();
        this.__maxParticipants.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        this.__coverImage.aboutToBeDeleted();
        this.__selectedYear.aboutToBeDeleted();
        this.__selectedMonth.aboutToBeDeleted();
        this.__selectedDay.aboutToBeDeleted();
        this.__selectedHour.aboutToBeDeleted();
        this.__selectedMinute.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __selectedClub: ObservedPropertySimplePU<string>;
    get selectedClub() {
        return this.__selectedClub.get();
    }
    set selectedClub(newValue: string) {
        this.__selectedClub.set(newValue);
    }
    private __customClub: ObservedPropertySimplePU<string>;
    get customClub() {
        return this.__customClub.get();
    }
    set customClub(newValue: string) {
        this.__customClub.set(newValue);
    }
    private __title: ObservedPropertySimplePU<string>;
    get title() {
        return this.__title.get();
    }
    set title(newValue: string) {
        this.__title.set(newValue);
    }
    private __description: ObservedPropertySimplePU<string>;
    get description() {
        return this.__description.get();
    }
    set description(newValue: string) {
        this.__description.set(newValue);
    }
    private __venue: ObservedPropertySimplePU<string>;
    get venue() {
        return this.__venue.get();
    }
    set venue(newValue: string) {
        this.__venue.set(newValue);
    }
    private __activityTime: ObservedPropertySimplePU<string>;
    get activityTime() {
        return this.__activityTime.get();
    }
    set activityTime(newValue: string) {
        this.__activityTime.set(newValue);
    }
    private __maxParticipants: ObservedPropertySimplePU<number>;
    get maxParticipants() {
        return this.__maxParticipants.get();
    }
    set maxParticipants(newValue: number) {
        this.__maxParticipants.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    private __coverImage: ObservedPropertySimplePU<string>;
    get coverImage() {
        return this.__coverImage.get();
    }
    set coverImage(newValue: string) {
        this.__coverImage.set(newValue);
    }
    private __selectedYear: ObservedPropertySimplePU<number>;
    get selectedYear() {
        return this.__selectedYear.get();
    }
    set selectedYear(newValue: number) {
        this.__selectedYear.set(newValue);
    }
    private __selectedMonth: ObservedPropertySimplePU<number>;
    get selectedMonth() {
        return this.__selectedMonth.get();
    }
    set selectedMonth(newValue: number) {
        this.__selectedMonth.set(newValue);
    }
    private __selectedDay: ObservedPropertySimplePU<number>;
    get selectedDay() {
        return this.__selectedDay.get();
    }
    set selectedDay(newValue: number) {
        this.__selectedDay.set(newValue);
    }
    private __selectedHour: ObservedPropertySimplePU<number>;
    get selectedHour() {
        return this.__selectedHour.get();
    }
    set selectedHour(newValue: number) {
        this.__selectedHour.set(newValue);
    }
    private __selectedMinute: ObservedPropertySimplePU<number>;
    get selectedMinute() {
        return this.__selectedMinute.get();
    }
    set selectedMinute(newValue: number) {
        this.__selectedMinute.set(newValue);
    }
    private clubOptions: string[];
    private yearRange: string[];
    private monthRange: string[];
    private hourRange: string[];
    private minuteRange: string[];
    aboutToAppear(): void {
        const now: Date = new Date();
        this.selectedYear = now.getFullYear();
        this.selectedMonth = now.getMonth() + 1;
        this.selectedDay = now.getDate();
        this.selectedHour = 19;
        this.selectedMinute = 0;
        this.buildRanges();
        this.syncActivityTime();
    }
    private buildRanges(): void {
        const currentYear: number = new Date().getFullYear();
        const years: string[] = [];
        for (let y: number = currentYear; y <= currentYear + 3; y++) {
            years.push(`${y}年`);
        }
        this.yearRange = years;
        const months: string[] = [];
        for (let m: number = 1; m <= 12; m++) {
            months.push(`${m}月`);
        }
        this.monthRange = months;
        const hours: string[] = [];
        for (let h: number = 0; h <= 23; h++) {
            hours.push(`${h < 10 ? '0' : ''}${h}时`);
        }
        this.hourRange = hours;
        const minutes: string[] = [];
        for (let mi: number = 0; mi <= 59; mi++) {
            minutes.push(`${mi < 10 ? '0' : ''}${mi}分`);
        }
        this.minuteRange = minutes;
    }
    private daysInMonth(year: number, month: number): number {
        return new Date(year, month, 0).getDate();
    }
    private dayRange(): string[] {
        const max: number = this.daysInMonth(this.selectedYear, this.selectedMonth);
        const days: string[] = [];
        for (let d: number = 1; d <= max; d++) {
            days.push(`${d}日`);
        }
        return days;
    }
    private clampDay(): void {
        const max: number = this.daysInMonth(this.selectedYear, this.selectedMonth);
        if (this.selectedDay > max) {
            this.selectedDay = max;
        }
    }
    private pad2(value: number): string {
        return value < 10 ? `0${value}` : `${value}`;
    }
    private syncActivityTime(): void {
        this.activityTime = `${this.selectedYear}-${this.pad2(this.selectedMonth)}-${this.pad2(this.selectedDay)}T${this.pad2(this.selectedHour)}:${this.pad2(this.selectedMinute)}:00`;
    }
    private formatDisplay(): string {
        return `${this.selectedYear}-${this.pad2(this.selectedMonth)}-${this.pad2(this.selectedDay)} ${this.pad2(this.selectedHour)}:${this.pad2(this.selectedMinute)}`;
    }
    private deadlineDisplay(): string {
        const d: Date = new Date(this.selectedYear, this.selectedMonth - 1, this.selectedDay, this.selectedHour, this.selectedMinute, 0, 0);
        d.setHours(d.getHours() - 1);
        return `${d.getFullYear()}-${this.pad2(d.getMonth() + 1)}-${this.pad2(d.getDate())} ${this.pad2(d.getHours())}:${this.pad2(d.getMinutes())}`;
    }
    private isDeadlineInFuture(): boolean {
        const deadline: Date = new Date(this.selectedYear, this.selectedMonth - 1, this.selectedDay, this.selectedHour, this.selectedMinute, 0, 0);
        deadline.setHours(deadline.getHours() - 1);
        return deadline.getTime() > new Date().getTime();
    }
    private validateForm(): boolean {
        const club: string = this.selectedClub === '其他' ? this.customClub.trim() : this.selectedClub;
        if (club.length === 0) {
            this.showToast('请选择或输入活动类型');
            return false;
        }
        if (this.title.trim().length === 0) {
            this.showToast('请输入活动标题');
            return false;
        }
        if (this.title.trim().length > 200) {
            this.showToast('标题不能超过200字');
            return false;
        }
        if (this.venue.trim().length === 0) {
            this.showToast('请输入活动地点');
            return false;
        }
        this.syncActivityTime();
        if (!this.isDeadlineInFuture()) {
            this.showToast('活动时间至少要晚于当前1小时');
            return false;
        }
        if (this.maxParticipants < 1) {
            this.showToast('人数至少为1人');
            return false;
        }
        return true;
    }
    private showToast(message: string): void {
        this.getUIContext().getPromptAction().showToast({ message: message });
    }
    private async submit(): Promise<void> {
        if (this.isSubmitting) {
            return;
        }
        if (!this.validateForm()) {
            return;
        }
        this.isSubmitting = true;
        const club: string = this.selectedClub === '其他' ? this.customClub.trim() : this.selectedClub;
        const params: Record<string, Object> = {
            'club': club,
            'title': this.title.trim(),
            'description': this.description.trim(),
            'venue': this.venue.trim(),
            'activityTime': this.activityTime.trim(),
            'maxParticipants': this.maxParticipants,
            'coverImage': this.coverImage
        } as Record<string, Object>;
        const result: ApiResult = await ApiService.publishClubActivity(params);
        if (result.code === 200) {
            this.showToast('活动发布成功');
            this.getUIContext().getRouter().back();
        }
        else {
            this.showToast(result.msg.length > 0 ? result.msg : '发布失败');
        }
        this.isSubmitting = false;
    }
    private async pickCover(): Promise<void> {
        try {
            const uris: string[] = await ApiService.pickImages();
            if (uris.length === 0) {
                return;
            }
            const url: string = await ApiService.uploadClubCover(uris[0]);
            if (url.length > 0 && !url.startsWith('ERROR:')) {
                this.coverImage = url;
                this.showToast('封面上传成功');
            }
            else {
                this.showToast('封面上传失败');
            }
        }
        catch (_err) {
            this.showToast('选择图片失败');
        }
    }
    private decreaseParticipants(): void {
        if (this.maxParticipants > 1) {
            this.maxParticipants -= 1;
        }
    }
    private increaseParticipants(): void {
        if (this.maxParticipants < 999) {
            this.maxParticipants += 1;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(204:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '发布活动' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ClubActivityPublishPage.ets", line: 205, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '发布活动'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '发布活动'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(207:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(208:9)", "entry");
            Column.width('100%');
            Column.padding({ left: 16, right: 16, top: 14 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(209:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(10);
            Column.shadow(ShadowStyle.sm);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('活动类型');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(210:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ bottom: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ wrap: FlexWrap.Wrap });
            Flex.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(216:13)", "entry");
            Flex.width('100%');
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const club = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(club);
                    Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(218:17)", "entry");
                    Text.fontSize(14);
                    Text.fontColor(this.selectedClub === club ? Color.White : Theme.textSecondary);
                    Text.padding({ left: 16, right: 16, top: 8, bottom: 8 });
                    Text.backgroundColor(this.selectedClub === club ? Theme.primary : Theme.bgInput);
                    Text.borderRadius(18);
                    Text.margin({ right: 10, bottom: 10 });
                    Text.onClick(() => {
                        this.selectedClub = club;
                    });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.clubOptions, forEachItemGenFunction, (club: string) => club, false, false);
        }, ForEach);
        ForEach.pop();
        Flex.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.selectedClub === '其他') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '请输入活动类型，如：摄影、骑行…', text: this.customClub });
                        TextInput.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(233:15)", "entry");
                        TextInput.height(46);
                        TextInput.fontSize(15);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(8);
                        TextInput.padding({ left: 12, right: 12 });
                        TextInput.margin({ top: 8 });
                        TextInput.onChange((value: string) => {
                            this.customClub = value;
                        });
                    }, TextInput);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(251:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(10);
            Column.margin({ top: 12 });
            Column.shadow(ShadowStyle.sm);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('活动封面');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(252:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ bottom: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(258:13)", "entry");
            Stack.width('100%');
            Stack.onClick(() => {
                this.pickCover();
            });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.coverImage.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(`${ApiService.baseUrl}${this.coverImage}`);
                        Image.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(260:17)", "entry");
                        Image.width('100%');
                        Image.height(160);
                        Image.borderRadius(10);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(266:17)", "entry");
                        Column.width('100%');
                        Column.height(160);
                        Column.backgroundColor(Theme.bgInput);
                        Column.borderRadius(10);
                        Column.border({ width: 1, color: Theme.border, style: BorderStyle.Dashed });
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('🖼️');
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(267:19)", "entry");
                        Text.fontSize(32);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('点击上传活动封面');
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(268:19)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        Stack.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(293:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(10);
            Column.margin({ top: 12 });
            Column.shadow(ShadowStyle.sm);
        }, Column);
        this.FieldLabel.bind(this)('活动标题');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '例如：周五剧本杀组局', text: this.title });
            TextInput.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(295:13)", "entry");
            TextInput.height(46);
            TextInput.fontSize(15);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((value: string) => {
                this.title = value;
            });
        }, TextInput);
        this.FieldLabel.bind(this)('活动地点');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '例如：教学楼A201', text: this.venue });
            TextInput.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(306:13)", "entry");
            TextInput.height(46);
            TextInput.fontSize(15);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((value: string) => {
                this.venue = value;
            });
        }, TextInput);
        this.FieldLabel.bind(this)('活动日期');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(317:13)", "entry");
            Row.width('100%');
            Row.backgroundColor(Theme.bgInput);
            Row.borderRadius(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.yearRange, selected: this.selectedYear - new Date().getFullYear() });
            TextPicker.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(318:15)", "entry");
            TextPicker.width('35%');
            TextPicker.height(140);
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                const i: number = index as number;
                this.selectedYear = new Date().getFullYear() + i;
                this.clampDay();
                this.syncActivityTime();
            });
        }, TextPicker);
        TextPicker.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.monthRange, selected: this.selectedMonth - 1 });
            TextPicker.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(328:15)", "entry");
            TextPicker.width('30%');
            TextPicker.height(140);
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                const i: number = index as number;
                this.selectedMonth = i + 1;
                this.clampDay();
                this.syncActivityTime();
            });
        }, TextPicker);
        TextPicker.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.dayRange(), selected: this.selectedDay - 1 });
            TextPicker.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(338:15)", "entry");
            TextPicker.width('30%');
            TextPicker.height(140);
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                const i: number = index as number;
                this.selectedDay = i + 1;
                this.syncActivityTime();
            });
        }, TextPicker);
        TextPicker.pop();
        Row.pop();
        this.FieldLabel.bind(this)('活动时间');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(352:13)", "entry");
            Row.width('100%');
            Row.backgroundColor(Theme.bgInput);
            Row.borderRadius(10);
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.hourRange, selected: this.selectedHour });
            TextPicker.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(353:15)", "entry");
            TextPicker.width('50%');
            TextPicker.height(140);
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                const i: number = index as number;
                this.selectedHour = i;
                this.syncActivityTime();
            });
        }, TextPicker);
        TextPicker.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.minuteRange, selected: this.selectedMinute });
            TextPicker.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(362:15)", "entry");
            TextPicker.width('50%');
            TextPicker.height(140);
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                const i: number = index as number;
                this.selectedMinute = i;
                this.syncActivityTime();
            });
        }, TextPicker);
        TextPicker.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(376:13)", "entry");
            Row.width('100%');
            Row.margin({ top: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('活动时间');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(377:15)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(380:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.formatDisplay());
            Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(381:15)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(388:13)", "entry");
            Row.width('100%');
            Row.margin({ top: 6 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('报名截止');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(389:15)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(392:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.deadlineDisplay());
            Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(393:15)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.warning);
        }, Text);
        Text.pop();
        Row.pop();
        this.FieldLabel.bind(this)('人数上限');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(401:13)", "entry");
            Row.width('100%');
            Row.height(46);
            Row.padding({ left: 4, right: 4 });
            Row.backgroundColor(Theme.bgInput);
            Row.borderRadius(8);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('-');
            Button.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(402:15)", "entry");
            Button.width(42);
            Button.height(38);
            Button.fontSize(20);
            Button.fontColor(Theme.primary);
            Button.backgroundColor(Theme.primaryLight);
            Button.borderRadius(8);
            Button.onClick(() => {
                this.decreaseParticipants();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.maxParticipants}`);
            Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(412:15)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.textAlign(TextAlign.Center);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('+');
            Button.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(418:15)", "entry");
            Button.width(42);
            Button.height(38);
            Button.fontSize(20);
            Button.fontColor(Color.White);
            Button.backgroundColor(Theme.primary);
            Button.borderRadius(8);
            Button.onClick(() => {
                this.increaseParticipants();
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.FieldLabel.bind(this)('活动介绍');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({ placeholder: '说明活动规则、集合方式、适合人群等', text: this.description });
            TextArea.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(436:13)", "entry");
            TextArea.height(130);
            TextArea.fontSize(15);
            TextArea.backgroundColor(Theme.bgInput);
            TextArea.borderRadius(8);
            TextArea.padding({ left: 12, right: 12, top: 10, bottom: 10 });
            TextArea.onChange((value: string) => {
                this.description = value;
            });
        }, TextArea);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(453:11)", "entry");
            Blank.height(88);
        }, Blank);
        Blank.pop();
        Column.pop();
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(461:7)", "entry");
            Row.width('100%');
            Row.padding({ left: 18, right: 18, top: 10, bottom: 24 });
            Row.backgroundColor(Theme.bgCard);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.isSubmitting ? '发布中' : '发布组局');
            Button.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(462:9)", "entry");
            Button.width('100%');
            Button.height(46);
            Button.fontSize(16);
            Button.fontColor(Color.White);
            Button.backgroundColor(this.isSubmitting ? Theme.primaryLight : Theme.primary);
            Button.borderRadius(23);
            Button.enabled(!this.isSubmitting);
            Button.onClick(() => {
                this.submit();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    FieldLabel(label: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/ClubActivityPublishPage.ets(485:5)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ top: 16, bottom: 8 });
        }, Text);
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "ClubActivityPublishPage";
    }
}
registerNamedRoute(() => new ClubActivityPublishPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/ClubActivityPublishPage", pageFullPath: "entry/src/main/ets/pages/ClubActivityPublishPage", integratedHsp: "false", moduleType: "followWithHap" });
