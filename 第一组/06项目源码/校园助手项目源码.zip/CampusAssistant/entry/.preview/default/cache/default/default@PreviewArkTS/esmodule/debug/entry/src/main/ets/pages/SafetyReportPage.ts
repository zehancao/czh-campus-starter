if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SafetyReportPage_Params {
    selectedType?: number;
    location?: string;
    description?: string;
    imageUris?: string[];
    uploadedImages?: string[];
    isSubmitting?: boolean;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const TYPE_OPTIONS: string[] = ['人身安全', '财物丢失', '火情', '医疗', '其他'];
const TYPE_ICONS: Record<string, string> = {
    '人身安全': '🚨',
    '财物丢失': '💰',
    '火情': '🔥',
    '医疗': '🏥',
    '其他': '⚠️'
};
class SafetyReportPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__selectedType = new ObservedPropertySimplePU(0, this, "selectedType");
        this.__location = new ObservedPropertySimplePU('', this, "location");
        this.__description = new ObservedPropertySimplePU('', this, "description");
        this.__imageUris = new ObservedPropertyObjectPU([], this, "imageUris");
        this.__uploadedImages = new ObservedPropertyObjectPU([], this, "uploadedImages");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SafetyReportPage_Params) {
        if (params.selectedType !== undefined) {
            this.selectedType = params.selectedType;
        }
        if (params.location !== undefined) {
            this.location = params.location;
        }
        if (params.description !== undefined) {
            this.description = params.description;
        }
        if (params.imageUris !== undefined) {
            this.imageUris = params.imageUris;
        }
        if (params.uploadedImages !== undefined) {
            this.uploadedImages = params.uploadedImages;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
    }
    updateStateVars(params: SafetyReportPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectedType.purgeDependencyOnElmtId(rmElmtId);
        this.__location.purgeDependencyOnElmtId(rmElmtId);
        this.__description.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUris.purgeDependencyOnElmtId(rmElmtId);
        this.__uploadedImages.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectedType.aboutToBeDeleted();
        this.__location.aboutToBeDeleted();
        this.__description.aboutToBeDeleted();
        this.__imageUris.aboutToBeDeleted();
        this.__uploadedImages.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __selectedType: ObservedPropertySimplePU<number>;
    get selectedType() {
        return this.__selectedType.get();
    }
    set selectedType(newValue: number) {
        this.__selectedType.set(newValue);
    }
    private __location: ObservedPropertySimplePU<string>;
    get location() {
        return this.__location.get();
    }
    set location(newValue: string) {
        this.__location.set(newValue);
    }
    private __description: ObservedPropertySimplePU<string>;
    get description() {
        return this.__description.get();
    }
    set description(newValue: string) {
        this.__description.set(newValue);
    }
    private __imageUris: ObservedPropertyObjectPU<string[]>;
    get imageUris() {
        return this.__imageUris.get();
    }
    set imageUris(newValue: string[]) {
        this.__imageUris.set(newValue);
    }
    private __uploadedImages: ObservedPropertyObjectPU<string[]>;
    get uploadedImages() {
        return this.__uploadedImages.get();
    }
    set uploadedImages(newValue: string[]) {
        this.__uploadedImages.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    private async doSubmit(): Promise<void> {
        const type: string = TYPE_OPTIONS[this.selectedType];
        if (this.location.length === 0 && this.description.length === 0) {
            this.showToast('请填写位置或情况描述');
            return;
        }
        this.isSubmitting = true;
        for (let i = 0; i < this.imageUris.length; i++) {
            if (this.uploadedImages.length <= i) {
                const url: string = await ApiService.uploadSafetyImage(this.imageUris[i]);
                if (url.startsWith('ERROR')) {
                    this.showToast('图片上传失败');
                    this.isSubmitting = false;
                    return;
                }
                this.uploadedImages.push(url);
            }
        }
        const params: Record<string, Object> = {
            'type': type,
            'location': this.location,
            'description': this.description,
            'images': this.uploadedImages,
        };
        const result = await ApiService.submitSafetyReport(params);
        this.isSubmitting = false;
        if (result.code === 200) {
            this.showToast('求助已提交');
            router.back();
        }
    }
    private async pickImages(): Promise<void> {
        const uris: string[] = await ApiService.pickImages();
        for (let i = 0; i < uris.length; i++) {
            if (this.imageUris.length < 3) {
                this.imageUris.push(uris[i]);
            }
        }
    }
    private removeImage(index: number): void {
        const newUris: string[] = [];
        const newUploaded: string[] = [];
        for (let i = 0; i < this.imageUris.length; i++) {
            if (i !== index) {
                newUris.push(this.imageUris[i]);
                if (i < this.uploadedImages.length) {
                    newUploaded.push(this.uploadedImages[i]);
                }
            }
        }
        this.imageUris = newUris;
        this.uploadedImages = newUploaded;
    }
    private showToast(msg: string): void {
        const ctx = this.getUIContext();
        ctx.getPromptAction().showToast({ message: msg, duration: 2000 });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(90:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '一键求助' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/SafetyReportPage.ets", line: 91, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '一键求助'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '一键求助'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(93:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(94:9)", "entry");
            Column.width('100%');
            Column.padding(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(95:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('⚠️ 紧急类型 *');
            Text.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(96:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(99:13)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const opt = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(101:17)", "entry");
                    Column.width(58);
                    Column.padding({ top: 8, bottom: 8 });
                    Column.backgroundColor(this.selectedType === index ? '#FEE2E2' : '#F3F4F6');
                    Column.borderRadius(12);
                    Column.alignItems(HorizontalAlign.Center);
                    Column.onClick(() => { this.selectedType = index; });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(TYPE_ICONS[opt] ?? '⚠️');
                    Text.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(102:19)", "entry");
                    Text.fontSize(20);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(opt);
                    Text.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(103:19)", "entry");
                    Text.fontSize(11);
                    Text.fontColor(this.selectedType === index ? Theme.danger : Theme.textSecondary);
                    Text.margin({ top: 2 });
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, TYPE_OPTIONS, forEachItemGenFunction, (opt: string) => opt, true, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(121:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📍 位置描述');
            Text.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(122:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '如：3号教学楼2层走廊', text: this.location });
            TextInput.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(124:13)", "entry");
            TextInput.fontSize(14);
            TextInput.width('100%');
            TextInput.margin({ top: 4 });
            TextInput.onChange((value: string) => { this.location = value; });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(130:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📝 情况描述');
            Text.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(131:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请简要描述紧急情况...', text: this.description });
            TextInput.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(133:13)", "entry");
            TextInput.fontSize(14);
            TextInput.width('100%');
            TextInput.margin({ top: 4 });
            TextInput.onChange((value: string) => { this.description = value; });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(139:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📷 现场图片（可选，最多3张）');
            Text.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(140:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(143:13)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const uri = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Stack.create();
                    Stack.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(145:17)", "entry");
                    Stack.width(72);
                    Stack.height(72);
                }, Stack);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(uri);
                    Image.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(146:19)", "entry");
                    Image.width(72);
                    Image.height(72);
                    Image.borderRadius(8);
                    Image.objectFit(ImageFit.Cover);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('×');
                    Text.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(148:19)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#FFFFFF');
                    Text.width(20);
                    Text.height(20);
                    Text.borderRadius(10);
                    Text.backgroundColor('rgba(0,0,0,0.5)');
                    Text.textAlign(TextAlign.Center);
                    Text.position({ x: 56, y: 0 });
                    Text.onClick(() => { this.removeImage(index as number); });
                }, Text);
                Text.pop();
                Stack.pop();
            };
            this.forEachUpdateFunction(elmtId, this.imageUris, forEachItemGenFunction, (uri: string, index: number) => `${index}`, true, true);
        }, ForEach);
        ForEach.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.imageUris.length < 3) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(161:17)", "entry");
                        Column.width(72);
                        Column.height(72);
                        Column.backgroundColor('#F3F4F6');
                        Column.borderRadius(8);
                        Column.justifyContent(FlexAlign.Center);
                        Column.alignItems(HorizontalAlign.Center);
                        Column.onClick(() => { this.pickImages(); });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('+');
                        Text.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(162:19)", "entry");
                        Text.fontSize(24);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('添加图片');
                        Text.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(163:19)", "entry");
                        Text.fontSize(10);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('🚨 提交求助');
            Button.debugLine("entry/src/main/ets/pages/SafetyReportPage.ets(178:11)", "entry");
            Button.width('100%');
            Button.height(48);
            Button.type(ButtonType.Normal);
            Button.backgroundColor(Theme.danger);
            Button.fontColor('#FFFFFF');
            Button.borderRadius(Theme.radiusMd);
            Button.fontSize(16);
            Button.fontWeight(FontWeight.Medium);
            Button.enabled(!this.isSubmitting);
            Button.onClick(() => { this.doSubmit(); });
        }, Button);
        Button.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "SafetyReportPage";
    }
}
registerNamedRoute(() => new SafetyReportPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/SafetyReportPage", pageFullPath: "entry/src/main/ets/pages/SafetyReportPage", integratedHsp: "false", moduleType: "followWithHap" });
