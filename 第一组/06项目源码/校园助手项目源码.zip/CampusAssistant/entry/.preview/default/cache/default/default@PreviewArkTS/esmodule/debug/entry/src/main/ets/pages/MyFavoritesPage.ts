if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MyFavoritesPage_Params {
    favorites?: FavoriteItem[];
    studyFavorites?: StudyShareItem[];
    isLoading?: boolean;
    isLoggedIn?: boolean;
}
interface StudyShareFavoriteCard_Params {
    item?: StudyShareItem;
    onTap?: () => void;
}
interface FavoriteCard_Params {
    item?: FavoriteItem;
    onTap?: () => void;
    onRemove?: () => void;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { FavoriteItem, StudyShareItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const STATUS_LABELS: string[] = ['', '在售', '已售', '下架'];
const STATUS_COLORS: string[] = [Theme.bgCard, Theme.success, Theme.textSecondary, Theme.danger];
class FavoriteCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = new FavoriteItem();
        this.onTap = undefined;
        this.onRemove = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FavoriteCard_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.onTap !== undefined) {
            this.onTap = params.onTap;
        }
        if (params.onRemove !== undefined) {
            this.onRemove = params.onRemove;
        }
    }
    updateStateVars(params: FavoriteCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: FavoriteItem;
    private onTap?: () => void;
    private onRemove?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(19:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(12);
            Row.margin({ bottom: 12 });
            Row.onClick(() => {
                if (this.onTap !== undefined) {
                    this.onTap();
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.productImages.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(ApiService.baseUrl + this.item.productImages[0]);
                        Image.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(21:9)", "entry");
                        Image.width(96);
                        Image.height(96);
                        Image.borderRadius(10);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(27:9)", "entry");
                        Column.width(96);
                        Column.height(96);
                        Column.backgroundColor(Theme.bgPage);
                        Column.borderRadius(10);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83D\uDCF7');
                        Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(28:11)", "entry");
                        Text.fontSize(34);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(38:7)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(39:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.productTitle);
            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(40:11)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(46:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`\u00A5${this.item.productPrice.toFixed(2)}`);
            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(47:11)", "entry");
            Text.fontSize(17);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.secondary);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.sellerName);
            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(54:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
            Text.width('100%');
            Text.margin({ top: 6 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(60:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(STATUS_LABELS[Math.max(0, Math.min(this.item.productStatus, 3))]);
            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(61:11)", "entry");
            Text.fontSize(11);
            Text.fontColor('#FFFFFF');
            Text.backgroundColor(STATUS_COLORS[Math.max(0, Math.min(this.item.productStatus, 3))]);
            Text.borderRadius(4);
            Text.padding({ left: 7, right: 7, top: 2, bottom: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(67:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('取消收藏');
            Button.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(69:11)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(11);
            Button.fontColor(Theme.danger);
            Button.backgroundColor(Theme.dangerLight);
            Button.height(28);
            Button.padding({ left: 10, right: 10 });
            Button.onClick(() => {
                if (this.onRemove !== undefined) {
                    this.onRemove();
                }
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class StudyShareFavoriteCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = new StudyShareItem();
        this.onTap = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StudyShareFavoriteCard_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.onTap !== undefined) {
            this.onTap = params.onTap;
        }
    }
    updateStateVars(params: StudyShareFavoriteCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: StudyShareItem;
    private onTap?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(108:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(12);
            Row.margin({ bottom: 12 });
            Row.onClick(() => {
                if (this.onTap !== undefined) {
                    this.onTap();
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.coverImage.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(ApiService.baseUrl + this.item.coverImage);
                        Image.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(110:9)", "entry");
                        Image.width(72);
                        Image.height(72);
                        Image.borderRadius(10);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(116:9)", "entry");
                        Column.width(72);
                        Column.height(72);
                        Column.backgroundColor(Theme.bgPage);
                        Column.borderRadius(10);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83D\uDCC4');
                        Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(117:11)", "entry");
                        Text.fontSize(34);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(127:7)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.title);
            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(128:9)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.item.courseName} \u00B7 ${this.item.category}`);
            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(135:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 4 });
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(143:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 6 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`\u2764 ${this.item.likeCount}`);
            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(144:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`\u2B07 ${this.item.downloadCount}`);
            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(147:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ left: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(151:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('资料');
            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(152:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.primary);
            Text.backgroundColor(Theme.primaryLight);
            Text.borderRadius(4);
            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class MyFavoritesPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__favorites = new ObservedPropertyObjectPU([], this, "favorites");
        this.__studyFavorites = new ObservedPropertyObjectPU([], this, "studyFavorites");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyFavoritesPage_Params) {
        if (params.favorites !== undefined) {
            this.favorites = params.favorites;
        }
        if (params.studyFavorites !== undefined) {
            this.studyFavorites = params.studyFavorites;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
    }
    updateStateVars(params: MyFavoritesPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__favorites.purgeDependencyOnElmtId(rmElmtId);
        this.__studyFavorites.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__favorites.aboutToBeDeleted();
        this.__studyFavorites.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __favorites: ObservedPropertyObjectPU<FavoriteItem[]>;
    get favorites() {
        return this.__favorites.get();
    }
    set favorites(newValue: FavoriteItem[]) {
        this.__favorites.set(newValue);
    }
    private __studyFavorites: ObservedPropertyObjectPU<StudyShareItem[]>;
    get studyFavorites() {
        return this.__studyFavorites.get();
    }
    set studyFavorites(newValue: StudyShareItem[]) {
        this.__studyFavorites.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    aboutToAppear(): void {
        const store: AppStore = AppStore.getInstance();
        this.isLoggedIn = store.isLoggedIn;
        if (this.isLoggedIn) {
            this.loadData();
        }
        else {
            this.isLoading = false;
        }
    }
    private async loadData(): Promise<void> {
        this.isLoading = true;
        const favResult = await ApiService.getMyFavorites();
        if (favResult.code === 200 && favResult.data !== undefined) {
            this.favorites = ApiService.parseFavoriteList(favResult.data);
        }
        const studyResult = await ApiService.getMyStudyShareFavorites();
        if (studyResult.code === 200 && studyResult.data !== undefined) {
            this.studyFavorites = ApiService.parseStudyShareList(studyResult.data);
        }
        this.isLoading = false;
    }
    private async removeFavorite(item: FavoriteItem): Promise<void> {
        const result = await ApiService.removeFavorite(item.productId);
        if (result.code === 200) {
            const idx: number = this.favorites.findIndex(i => i.productId === item.productId);
            if (idx >= 0) {
                this.favorites.splice(idx, 1);
                this.favorites = this.favorites.slice();
            }
            this.getUIContext().getPromptAction().showToast({ message: '已取消收藏', duration: 1500 });
        }
        else {
            AlertDialog.show({
                message: result.msg || '操作失败',
                confirm: { value: '好的', action: () => { } }
            });
        }
    }
    private goToProductDetail(item: FavoriteItem): void {
        router.pushUrl({
            url: 'pages/ProductDetailPage',
            params: { 'productId': item.productId } as Record<string, Object>
        });
    }
    private goToStudyDetail(item: StudyShareItem): void {
        router.pushUrl({
            url: 'pages/StudyShareDetailPage',
            params: { 'id': `${item.id}` } as Record<string, string>
        });
    }
    private totalCount(): number {
        return this.favorites.length + this.studyFavorites.length;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(246:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '我的收藏',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.totalCount() > 0) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(`${this.totalCount()}`);
                                            Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(249:11)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.backgroundColor(Theme.bgPage);
                                            Text.borderRadius(10);
                                            Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyFavoritesPage.ets", line: 247, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '我的收藏',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.totalCount() > 0) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create(`${this.totalCount()}`);
                                                Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(249:11)", "entry");
                                                Text.fontSize(13);
                                                Text.fontColor(Theme.textTertiary);
                                                Text.backgroundColor(Theme.bgPage);
                                                Text.borderRadius(10);
                                                Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '我的收藏'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(257:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83D\uDD12');
                        Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(258:11)", "entry");
                        Text.fontSize(56);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录查看收藏');
                        Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(260:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(264:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 24 });
                        Button.onClick(() => {
                            router.pushUrl({ url: 'pages/LoginPage' });
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.isLoading) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(278:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(279:11)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.totalCount() === 0) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(289:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83E\uDD0D');
                        Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(290:11)", "entry");
                        Text.fontSize(64);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('还没有收藏内容');
                        Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(292:11)", "entry");
                        Text.fontSize(17);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Medium);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('在商品或资料详情页点击\u2764即可收藏');
                        Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(297:11)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 6 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去逛逛');
                        Button.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(301:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 28 });
                        Button.onClick(() => {
                            AppStore.getInstance().pendingTab = 1;
                            router.pushUrl({ url: 'pages/MainPage' });
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(316:9)", "entry");
                        Scroll.width('100%');
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                        Scroll.align(Alignment.Top);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(317:11)", "entry");
                        Column.width('100%');
                        Column.justifyContent(FlexAlign.Start);
                        Column.align(Alignment.Top);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(318:13)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16, bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`共 ${this.totalCount()} 项收藏`);
                        Text.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(319:15)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textSecondary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(322:15)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyFavoritesPage.ets(327:13)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 12, right: 12, bottom: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    if (isInitialRender) {
                                        let componentCall = new FavoriteCard(this, {
                                            item: item,
                                            onTap: () => this.goToProductDetail(item),
                                            onRemove: () => this.removeFavorite(item)
                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyFavoritesPage.ets", line: 329, col: 17 });
                                        ViewPU.create(componentCall);
                                        let paramsLambda = () => {
                                            return {
                                                item: item,
                                                onTap: () => this.goToProductDetail(item),
                                                onRemove: () => this.removeFavorite(item)
                                            };
                                        };
                                        componentCall.paramsGenerator_ = paramsLambda;
                                    }
                                    else {
                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                    }
                                }, { name: "FavoriteCard" });
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.favorites, forEachItemGenFunction, (item: FavoriteItem) => `product_${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    if (isInitialRender) {
                                        let componentCall = new StudyShareFavoriteCard(this, {
                                            item: item,
                                            onTap: () => this.goToStudyDetail(item)
                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyFavoritesPage.ets", line: 337, col: 17 });
                                        ViewPU.create(componentCall);
                                        let paramsLambda = () => {
                                            return {
                                                item: item,
                                                onTap: () => this.goToStudyDetail(item)
                                            };
                                        };
                                        componentCall.paramsGenerator_ = paramsLambda;
                                    }
                                    else {
                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                    }
                                }, { name: "StudyShareFavoriteCard" });
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.studyFavorites, forEachItemGenFunction, (item: StudyShareItem) => `study_${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "MyFavoritesPage";
    }
}
registerNamedRoute(() => new MyFavoritesPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/MyFavoritesPage", pageFullPath: "entry/src/main/ets/pages/MyFavoritesPage", integratedHsp: "false", moduleType: "followWithHap" });
