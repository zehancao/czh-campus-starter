if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface StudySharePreviewPage_Params {
    loadResult?: pdfService.ParseResult;
    isLoading?: boolean;
    errorMsg?: string;
    currentPage?: number;
    totalPages?: number;
    controller?: pdfViewManager.PdfController;
    localPath?: string;
    shareId?: number;
    fileUrl?: string;
    title?: string;
}
import router from "@ohos:router";
import pdfService from "@hms:officeservice.pdfservice";
import { PdfView } from "@hms:officeservice.PdfView";
import { pdfViewManager } from "@hms:officeservice.PdfView";
import fileIo from "@ohos:file.fs";
import http from "@ohos:net.http";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
class StudySharePreviewPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__loadResult = new ObservedPropertySimplePU(pdfService.ParseResult.PARSE_ERROR_FORMAT, this, "loadResult");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.__currentPage = new ObservedPropertySimplePU(0, this, "currentPage");
        this.__totalPages = new ObservedPropertySimplePU(0, this, "totalPages");
        this.controller = new pdfViewManager.PdfController();
        this.localPath = '';
        this.shareId = 0;
        this.fileUrl = '';
        this.title = '';
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StudySharePreviewPage_Params) {
        if (params.loadResult !== undefined) {
            this.loadResult = params.loadResult;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
        if (params.totalPages !== undefined) {
            this.totalPages = params.totalPages;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.localPath !== undefined) {
            this.localPath = params.localPath;
        }
        if (params.shareId !== undefined) {
            this.shareId = params.shareId;
        }
        if (params.fileUrl !== undefined) {
            this.fileUrl = params.fileUrl;
        }
        if (params.title !== undefined) {
            this.title = params.title;
        }
    }
    updateStateVars(params: StudySharePreviewPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__loadResult.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
        this.__totalPages.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__loadResult.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        this.__currentPage.aboutToBeDeleted();
        this.__totalPages.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __loadResult: ObservedPropertySimplePU<pdfService.ParseResult>;
    get loadResult() {
        return this.__loadResult.get();
    }
    set loadResult(newValue: pdfService.ParseResult) {
        this.__loadResult.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    private __currentPage: ObservedPropertySimplePU<number>;
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: number) {
        this.__currentPage.set(newValue);
    }
    private __totalPages: ObservedPropertySimplePU<number>;
    get totalPages() {
        return this.__totalPages.get();
    }
    set totalPages(newValue: number) {
        this.__totalPages.set(newValue);
    }
    private controller: pdfViewManager.PdfController;
    private localPath: string;
    private shareId: number;
    private fileUrl: string;
    private title: string;
    aboutToAppear(): void {
        const params: Record<string, Object> = router.getParams() as Record<string, Object>;
        if (params !== undefined && params !== null) {
            const idObj: Object = params['shareId'];
            if (idObj !== undefined && idObj !== null) {
                this.shareId = parseInt(idObj as string, 10);
            }
            const urlObj: Object = params['fileUrl'];
            if (urlObj !== undefined && urlObj !== null) {
                this.fileUrl = urlObj as string;
            }
            const titleObj: Object = params['title'];
            if (titleObj !== undefined && titleObj !== null) {
                this.title = titleObj as string;
            }
        }
        this.downloadAndLoad();
    }
    aboutToDisappear(): void {
    }
    private async downloadAndLoad(): Promise<void> {
        this.isLoading = true;
        const store: AppStore = AppStore.getInstance();
        if (store.context === undefined) {
            this.errorMsg = '上下文错误';
            this.isLoading = false;
            return;
        }
        const cacheDir: string = store.context.cacheDir;
        const fileName: string = `preview_${this.shareId}.pdf`;
        this.localPath = `${cacheDir}/${fileName}`;
        try {
            if (fileIo.accessSync(this.localPath)) {
                fileIo.unlinkSync(this.localPath);
            }
        }
        catch (e) {
        }
        const remoteUrl: string = `${ApiService.baseUrl}${this.fileUrl}`;
        const req: http.HttpRequest = http.createHttp();
        try {
            const response: http.HttpResponse = await req.request(remoteUrl, {
                method: http.RequestMethod.GET,
                expectDataType: http.HttpDataType.ARRAY_BUFFER,
                header: {}
            });
            if (response.responseCode === 200) {
                const resultData: ArrayBuffer = response.result as ArrayBuffer;
                const file: fileIo.File = fileIo.openSync(this.localPath, fileIo.OpenMode.READ_WRITE | fileIo.OpenMode.CREATE);
                fileIo.writeSync(file.fd, resultData);
                fileIo.closeSync(file);
                try {
                    this.loadResult = await this.controller.loadDocument(this.localPath);
                }
                catch (e) {
                    this.loadResult = pdfService.ParseResult.PARSE_ERROR_FORMAT;
                }
                if (this.loadResult === pdfService.ParseResult.PARSE_SUCCESS) {
                    this.controller.registerPageCountChangedListener((count: number) => {
                        this.totalPages = count;
                    });
                    this.controller.registerPageChangedListener((page: number) => {
                        this.currentPage = page;
                    });
                }
                else {
                    this.errorMsg = `PDF解析失败(code=${this.loadResult})`;
                }
            }
            else {
                this.errorMsg = `下载失败(code=${response.responseCode})`;
            }
        }
        catch (e) {
            this.errorMsg = '加载失败';
        }
        finally {
            req.destroy();
        }
        this.isLoading = false;
    }
    private prevPage(): void {
        if (this.currentPage > 0) {
            this.controller.goToPage(this.currentPage - 1);
        }
    }
    private nextPage(): void {
        if (this.currentPage < this.totalPages - 1) {
            this.controller.goToPage(this.currentPage + 1);
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(122:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: this.title.length > 0 ? this.title : 'PDF预览' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/StudySharePreviewPage.ets", line: 123, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: this.title.length > 0 ? this.title : 'PDF预览'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: this.title.length > 0 ? this.title : 'PDF预览'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(126:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(127:11)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在加载PDF...');
                        Text.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(128:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(137:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('😕');
                        Text.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(138:11)", "entry");
                        Text.fontSize(48);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(139:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        __Common__.create();
                        __Common__.layoutWeight(1);
                    }, __Common__);
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new PdfView(this, {
                                    controller: this.controller,
                                    pageFit: pdfService.PageFit.FIT_WIDTH,
                                    showScroll: true
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/StudySharePreviewPage.ets", line: 145, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        controller: this.controller,
                                        pageFit: pdfService.PageFit.FIT_WIDTH,
                                        showScroll: true
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "PdfView" });
                    }
                    __Common__.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(152:9)", "entry");
                        Row.width('100%');
                        Row.height(56);
                        Row.padding({ left: 16, right: 16 });
                        Row.backgroundColor('#FFFFFF');
                        Row.alignItems(VerticalAlign.Center);
                        Row.justifyContent(FlexAlign.SpaceBetween);
                        Row.border({ width: { top: 0.5 }, color: Theme.border });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('上一页');
                        Button.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(153:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.height(36);
                        Button.fontSize(13);
                        Button.backgroundColor(this.currentPage > 0 ? Theme.primary : Theme.textDisabled);
                        Button.fontColor('#FFFFFF');
                        Button.enabled(this.currentPage > 0);
                        Button.onClick(() => { this.prevPage(); });
                    }, Button);
                    Button.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.currentPage + 1} / ${this.totalPages}`);
                        Text.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(162:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textPrimary);
                        Text.layoutWeight(1);
                        Text.textAlign(TextAlign.Center);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('下一页');
                        Button.debugLine("entry/src/main/ets/pages/StudySharePreviewPage.ets(168:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.height(36);
                        Button.fontSize(13);
                        Button.backgroundColor(this.currentPage < this.totalPages - 1 ? Theme.primary : Theme.textDisabled);
                        Button.fontColor('#FFFFFF');
                        Button.enabled(this.currentPage < this.totalPages - 1);
                        Button.onClick(() => { this.nextPage(); });
                    }, Button);
                    Button.pop();
                    Row.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "StudySharePreviewPage";
    }
}
registerNamedRoute(() => new StudySharePreviewPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/StudySharePreviewPage", pageFullPath: "entry/src/main/ets/pages/StudySharePreviewPage", integratedHsp: "false", moduleType: "followWithHap" });
