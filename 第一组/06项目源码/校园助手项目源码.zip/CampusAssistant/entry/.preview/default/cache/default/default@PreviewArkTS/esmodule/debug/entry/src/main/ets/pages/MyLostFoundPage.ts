if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MyLostFoundPage_Params {
    items?: LostFoundItem[];
    isLoading?: boolean;
    isLoggedIn?: boolean;
}
interface MyLFItemCard_Params {
    itemData?: LostFoundItem;
    onTapCallback?: () => void;
    onMarkDone?: (item: LostFoundItem) => void;
    onDelete?: (item: LostFoundItem) => void;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { LostFoundItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const STATUS_OPTIONS: string[] = ['进行中', '已找到/已归还'];
const STATUS_COLORS: string[] = [Theme.warning, Theme.success];
class MyLFItemCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.itemData = new LostFoundItem();
        this.onTapCallback = undefined;
        this.onMarkDone = undefined;
        this.onDelete = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyLFItemCard_Params) {
        if (params.itemData !== undefined) {
            this.itemData = params.itemData;
        }
        if (params.onTapCallback !== undefined) {
            this.onTapCallback = params.onTapCallback;
        }
        if (params.onMarkDone !== undefined) {
            this.onMarkDone = params.onMarkDone;
        }
        if (params.onDelete !== undefined) {
            this.onDelete = params.onDelete;
        }
    }
    updateStateVars(params: MyLFItemCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private itemData: LostFoundItem;
    private onTapCallback?: () => void;
    private onMarkDone?: (item: LostFoundItem) => void;
    private onDelete?: (item: LostFoundItem) => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(21:5)", "entry");
            Column.width('100%');
            Column.padding(12);
            Column.backgroundColor('#FFFFFF');
            Column.borderRadius(12);
            Column.margin({ bottom: 8 });
            Column.onClick(() => {
                if (this.onTapCallback !== undefined) {
                    this.onTapCallback();
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(22:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(23:9)", "entry");
            Column.width(56);
            Column.height(56);
            Column.backgroundColor(Theme.secondaryLight);
            Column.borderRadius(10);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.type === 1 ? '🔍' : '📢');
            Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(24:11)", "entry");
            Text.fontSize(28);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.type === 1 ? '寻物' : '招领');
            Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(26:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.secondary);
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(34:9)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(35:11)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.title);
            Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(36:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(STATUS_OPTIONS[Math.max(0, Math.min(this.itemData.status - 1, 1))]);
            Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(40:13)", "entry");
            Text.fontSize(11);
            Text.fontColor('#FFFFFF');
            Text.backgroundColor(STATUS_COLORS[Math.max(0, Math.min(this.itemData.status - 1, 1))]);
            Text.borderRadius(4);
            Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.itemData.description.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.description);
                        Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(50:13)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textSecondary);
                        Text.maxLines(1);
                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                        Text.width('100%');
                        Text.margin({ top: 4 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(57:11)", "entry");
            Row.width('100%');
            Row.margin({ top: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.itemData.category.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.category);
                        Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(59:15)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.textTertiary);
                        Text.backgroundColor(Theme.bgPage);
                        Text.borderRadius(4);
                        Text.padding({ left: 6, right: 6, top: 1, bottom: 1 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.itemData.locationDesc.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.locationDesc);
                        Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(64:15)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ left: 6 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(68:13)", "entry");
        }, Blank);
        Blank.pop();
        Row.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(79:7)", "entry");
            Divider.height(1);
            Divider.color(Theme.divider);
            Divider.width('100%');
            Divider.margin({ top: 8, bottom: 8 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(81:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.createTime.replace('T', ' ').substring(0, 16));
            Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(82:9)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(85:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('标记已找到');
            Button.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(87:9)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(12);
            Button.fontColor(Theme.success);
            Button.backgroundColor(Theme.successLight);
            Button.height(28);
            Button.margin({ right: 8 });
            Button.onClick(() => {
                if (this.onMarkDone !== undefined) {
                    this.onMarkDone(this.itemData);
                }
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('删除');
            Button.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(99:9)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(12);
            Button.fontColor(Theme.danger);
            Button.backgroundColor(Theme.dangerLight);
            Button.height(28);
            Button.onClick(() => {
                if (this.onDelete !== undefined) {
                    this.onDelete(this.itemData);
                }
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class MyLostFoundPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__items = new ObservedPropertyObjectPU([], this, "items");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyLostFoundPage_Params) {
        if (params.items !== undefined) {
            this.items = params.items;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
    }
    updateStateVars(params: MyLostFoundPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__items.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__items.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __items: ObservedPropertyObjectPU<LostFoundItem[]>;
    get items() {
        return this.__items.get();
    }
    set items(newValue: LostFoundItem[]) {
        this.__items.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    aboutToAppear(): void {
        const store: AppStore = AppStore.getInstance();
        this.isLoggedIn = store.isLoggedIn;
        if (this.isLoggedIn) {
            this.loadList();
        }
        else {
            this.isLoading = false;
        }
    }
    onPageShow(): void {
        const store: AppStore = AppStore.getInstance();
        if (store.isLoggedIn) {
            this.loadList();
        }
    }
    private async loadList(): Promise<void> {
        this.isLoading = true;
        const result = await ApiService.getMyLostFoundList();
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            const list: LostFoundItem[] = [];
            for (let i = 0; i < arr.length; i++) {
                const obj: Record<string, Object> = arr[i] as Record<string, Object>;
                const item: LostFoundItem = new LostFoundItem();
                item.id = (obj['id'] as number) ?? 0;
                item.userId = (obj['userId'] as number) ?? 0;
                item.userName = (obj['userName'] as string) ?? '';
                item.type = (obj['type'] as number) ?? 1;
                item.title = (obj['title'] as string) ?? '';
                item.description = (obj['description'] as string) ?? '';
                const imgObj: Object = obj['images'];
                item.images = (imgObj !== null && imgObj !== undefined) ? (imgObj as string) : '[]';
                item.locationDesc = (obj['locationDesc'] as string) ?? '';
                item.category = (obj['category'] as string) ?? '';
                const phObj: Object = obj['contactPhone'];
                item.contactPhone = (phObj !== null && phObj !== undefined) ? (phObj as string) : '';
                item.status = (obj['status'] as number) ?? 1;
                item.createTime = (obj['createTime'] as string) ?? '';
                list.push(item);
            }
            this.items = list;
        }
        this.isLoading = false;
    }
    private async markAsDone(item: LostFoundItem): Promise<void> {
        AlertDialog.show({
            title: '确认操作',
            message: '确定将"' + item.title + '"标记为已找到/已归还吗？此操作将删除该记录。',
            primaryButton: { value: '取消', action: () => { } },
            confirm: {
                value: '标记完成',
                fontColor: Theme.success,
                action: async () => {
                    const result = await ApiService.deleteLostFound(item.id);
                    if (result.code === 200) {
                        promptAction.showToast({ message: '已标记为已找到' });
                        const newArr: LostFoundItem[] = [];
                        for (let i = 0; i < this.items.length; i++) {
                            if (this.items[i].id !== item.id) {
                                newArr.push(this.items[i]);
                            }
                        }
                        this.items = newArr;
                    }
                    else {
                        AlertDialog.show({
                            message: result.msg || '操作失败',
                            confirm: { value: '好的', action: () => { } }
                        });
                    }
                }
            }
        });
    }
    private async deleteItem(item: LostFoundItem): Promise<void> {
        AlertDialog.show({
            title: '确认删除',
            message: '确定要删除"' + item.title + '"吗？此操作不可恢复。',
            primaryButton: { value: '取消', action: () => { } },
            confirm: {
                value: '删除',
                fontColor: Theme.danger,
                action: async () => {
                    const result = await ApiService.deleteLostFound(item.id);
                    if (result.code === 200) {
                        promptAction.showToast({ message: '已删除' });
                        const newArr: LostFoundItem[] = [];
                        for (let i = 0; i < this.items.length; i++) {
                            if (this.items[i].id !== item.id) {
                                newArr.push(this.items[i]);
                            }
                        }
                        this.items = newArr;
                    }
                    else {
                        AlertDialog.show({
                            message: result.msg || '删除失败',
                            confirm: { value: '好的', action: () => { } }
                        });
                    }
                }
            }
        });
    }
    private goToDetail(item: LostFoundItem): void {
        router.pushUrl({
            url: 'pages/LostFoundDetailPage',
            params: { 'id': item.id.toString() } as Record<string, string>
        });
    }
    private goToPublish(): void {
        router.pushUrl({ url: 'pages/LostFoundPublishPage' });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(251:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '我的失物招领',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('发布');
                                Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(253:9)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(Theme.secondary);
                                Text.onClick(() => { this.goToPublish(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyLostFoundPage.ets", line: 252, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '我的失物招领',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('发布');
                                    Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(253:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.secondary);
                                    Text.onClick(() => { this.goToPublish(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '我的失物招领'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(257:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('🔒');
                        Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(258:11)", "entry");
                        Text.fontSize(48);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录');
                        Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(259:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(261:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 20 });
                        Button.onClick(() => { router.pushUrl({ url: 'pages/LoginPage' }); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.isLoading) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(269:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(270:11)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.items.length === 0) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(275:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(276:11)", "entry");
                        Column.width('100%');
                        Column.alignItems(HorizontalAlign.Center);
                        Column.margin({ top: 60 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('📋');
                        Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(277:13)", "entry");
                        Text.fontSize(56);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('还没有发布过失物招领');
                        Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(278:13)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('点击右上角发布信息');
                        Text.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(280:13)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 4 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去发布');
                        Button.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(282:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 20 });
                        Button.onClick(() => { this.goToPublish(); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(293:9)", "entry");
                        Scroll.width('100%');
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyLostFoundPage.ets(294:11)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 12, right: 12, top: 0, bottom: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    if (isInitialRender) {
                                        let componentCall = new MyLFItemCard(this, {
                                            itemData: item,
                                            onTapCallback: () => this.goToDetail(item),
                                            onMarkDone: (i: LostFoundItem) => this.markAsDone(i),
                                            onDelete: (i: LostFoundItem) => this.deleteItem(i)
                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyLostFoundPage.ets", line: 296, col: 15 });
                                        ViewPU.create(componentCall);
                                        let paramsLambda = () => {
                                            return {
                                                itemData: item,
                                                onTapCallback: () => this.goToDetail(item),
                                                onMarkDone: (i: LostFoundItem) => this.markAsDone(i),
                                                onDelete: (i: LostFoundItem) => this.deleteItem(i)
                                            };
                                        };
                                        componentCall.paramsGenerator_ = paramsLambda;
                                    }
                                    else {
                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                    }
                                }, { name: "MyLFItemCard" });
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.items, forEachItemGenFunction, (item: LostFoundItem) => item.id.toString(), false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "MyLostFoundPage";
    }
}
registerNamedRoute(() => new MyLostFoundPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/MyLostFoundPage", pageFullPath: "entry/src/main/ets/pages/MyLostFoundPage", integratedHsp: "false", moduleType: "followWithHap" });
