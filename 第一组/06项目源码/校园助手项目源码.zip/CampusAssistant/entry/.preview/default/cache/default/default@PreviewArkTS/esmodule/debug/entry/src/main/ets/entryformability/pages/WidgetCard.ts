if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface WidgetCard_Params {
    dateStr?: string;
    semesterWeek?: string;
    courseCount?: number;
    nextCourse?: string;
    c0Name?: string;
    c0Room?: string;
    c0Time?: string;
    c1Name?: string;
    c1Room?: string;
    c1Time?: string;
    c2Name?: string;
    c2Room?: string;
    c2Time?: string;
    c3Name?: string;
    c3Room?: string;
    c3Time?: string;
    c4Name?: string;
    c4Room?: string;
    c4Time?: string;
}
let storage: LocalStorage = new LocalStorage();
class WidgetCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: WidgetCard_Params) {
    }
    updateStateVars(params: WidgetCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__dateStr.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__courseCount.purgeDependencyOnElmtId(rmElmtId);
        this.__nextCourse.purgeDependencyOnElmtId(rmElmtId);
        this.__c0Name.purgeDependencyOnElmtId(rmElmtId);
        this.__c0Room.purgeDependencyOnElmtId(rmElmtId);
        this.__c0Time.purgeDependencyOnElmtId(rmElmtId);
        this.__c1Name.purgeDependencyOnElmtId(rmElmtId);
        this.__c1Room.purgeDependencyOnElmtId(rmElmtId);
        this.__c1Time.purgeDependencyOnElmtId(rmElmtId);
        this.__c2Name.purgeDependencyOnElmtId(rmElmtId);
        this.__c2Room.purgeDependencyOnElmtId(rmElmtId);
        this.__c2Time.purgeDependencyOnElmtId(rmElmtId);
        this.__c3Name.purgeDependencyOnElmtId(rmElmtId);
        this.__c3Room.purgeDependencyOnElmtId(rmElmtId);
        this.__c3Time.purgeDependencyOnElmtId(rmElmtId);
        this.__c4Name.purgeDependencyOnElmtId(rmElmtId);
        this.__c4Room.purgeDependencyOnElmtId(rmElmtId);
        this.__c4Time.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__dateStr.aboutToBeDeleted();
        this.__semesterWeek.aboutToBeDeleted();
        this.__courseCount.aboutToBeDeleted();
        this.__nextCourse.aboutToBeDeleted();
        this.__c0Name.aboutToBeDeleted();
        this.__c0Room.aboutToBeDeleted();
        this.__c0Time.aboutToBeDeleted();
        this.__c1Name.aboutToBeDeleted();
        this.__c1Room.aboutToBeDeleted();
        this.__c1Time.aboutToBeDeleted();
        this.__c2Name.aboutToBeDeleted();
        this.__c2Room.aboutToBeDeleted();
        this.__c2Time.aboutToBeDeleted();
        this.__c3Name.aboutToBeDeleted();
        this.__c3Room.aboutToBeDeleted();
        this.__c3Time.aboutToBeDeleted();
        this.__c4Name.aboutToBeDeleted();
        this.__c4Room.aboutToBeDeleted();
        this.__c4Time.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __dateStr: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('dateStr', '', "dateStr");
    get dateStr() {
        return this.__dateStr.get();
    }
    set dateStr(newValue: string) {
        this.__dateStr.set(newValue);
    }
    private __semesterWeek: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('semesterWeek', '', "semesterWeek");
    get semesterWeek() {
        return this.__semesterWeek.get();
    }
    set semesterWeek(newValue: string) {
        this.__semesterWeek.set(newValue);
    }
    private __courseCount: ObservedPropertyAbstractPU<number> = this.createLocalStorageProp<number>('courseCount', 0, "courseCount");
    get courseCount() {
        return this.__courseCount.get();
    }
    set courseCount(newValue: number) {
        this.__courseCount.set(newValue);
    }
    private __nextCourse: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('nextCourse', '', "nextCourse");
    get nextCourse() {
        return this.__nextCourse.get();
    }
    set nextCourse(newValue: string) {
        this.__nextCourse.set(newValue);
    }
    private __c0Name: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c0_name', '', "c0Name");
    get c0Name() {
        return this.__c0Name.get();
    }
    set c0Name(newValue: string) {
        this.__c0Name.set(newValue);
    }
    private __c0Room: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c0_room', '', "c0Room");
    get c0Room() {
        return this.__c0Room.get();
    }
    set c0Room(newValue: string) {
        this.__c0Room.set(newValue);
    }
    private __c0Time: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c0_time', '', "c0Time");
    get c0Time() {
        return this.__c0Time.get();
    }
    set c0Time(newValue: string) {
        this.__c0Time.set(newValue);
    }
    private __c1Name: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c1_name', '', "c1Name");
    get c1Name() {
        return this.__c1Name.get();
    }
    set c1Name(newValue: string) {
        this.__c1Name.set(newValue);
    }
    private __c1Room: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c1_room', '', "c1Room");
    get c1Room() {
        return this.__c1Room.get();
    }
    set c1Room(newValue: string) {
        this.__c1Room.set(newValue);
    }
    private __c1Time: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c1_time', '', "c1Time");
    get c1Time() {
        return this.__c1Time.get();
    }
    set c1Time(newValue: string) {
        this.__c1Time.set(newValue);
    }
    private __c2Name: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c2_name', '', "c2Name");
    get c2Name() {
        return this.__c2Name.get();
    }
    set c2Name(newValue: string) {
        this.__c2Name.set(newValue);
    }
    private __c2Room: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c2_room', '', "c2Room");
    get c2Room() {
        return this.__c2Room.get();
    }
    set c2Room(newValue: string) {
        this.__c2Room.set(newValue);
    }
    private __c2Time: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c2_time', '', "c2Time");
    get c2Time() {
        return this.__c2Time.get();
    }
    set c2Time(newValue: string) {
        this.__c2Time.set(newValue);
    }
    private __c3Name: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c3_name', '', "c3Name");
    get c3Name() {
        return this.__c3Name.get();
    }
    set c3Name(newValue: string) {
        this.__c3Name.set(newValue);
    }
    private __c3Room: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c3_room', '', "c3Room");
    get c3Room() {
        return this.__c3Room.get();
    }
    set c3Room(newValue: string) {
        this.__c3Room.set(newValue);
    }
    private __c3Time: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c3_time', '', "c3Time");
    get c3Time() {
        return this.__c3Time.get();
    }
    set c3Time(newValue: string) {
        this.__c3Time.set(newValue);
    }
    private __c4Name: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c4_name', '', "c4Name");
    get c4Name() {
        return this.__c4Name.get();
    }
    set c4Name(newValue: string) {
        this.__c4Name.set(newValue);
    }
    private __c4Room: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c4_room', '', "c4Room");
    get c4Room() {
        return this.__c4Room.get();
    }
    set c4Room(newValue: string) {
        this.__c4Room.set(newValue);
    }
    private __c4Time: ObservedPropertyAbstractPU<string> = this.createLocalStorageProp<string>('c4_time', '', "c4Time");
    get c4Time() {
        return this.__c4Time.get();
    }
    set c4Time(newValue: string) {
        this.__c4Time.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(27:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding({ left: 14, right: 14, top: 12, bottom: 8 });
            Column.backgroundColor('#FFFFFF');
            Column.borderRadius(24);
            Column.onClick(() => {
                postCardAction(this, {
                    'action': 'router',
                    'abilityName': 'EntryAbility',
                    'params': {
                        'targetPage': 'pages/SchedulePage'
                    }
                });
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(28:7)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.dateStr);
            Text.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(29:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#333333');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.semesterWeek.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.semesterWeek);
                        Text.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(34:11)", "entry");
                        Text.fontSize(12);
                        Text.fontColor('#4F6EF7');
                        Text.margin({ left: 8 });
                        Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                        Text.borderRadius(8);
                        Text.backgroundColor('#EEF0FF');
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.courseCount === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(47:9)", "entry");
                        Column.width('100%');
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('今天没课 🎉');
                        Text.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(48:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor('#999999');
                        Text.margin({ top: 24, bottom: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('好好休息，劳逸结合');
                        Text.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(52:11)", "entry");
                        Text.fontSize(12);
                        Text.fontColor('#BBBBBB');
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(59:9)", "entry");
                        Column.width('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.c0Name.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.CourseRow.bind(this)(this.c0Time, this.c0Name, this.c0Room);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.c1Name.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.CourseRow.bind(this)(this.c1Time, this.c1Name, this.c1Room);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.c2Name.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.CourseRow.bind(this)(this.c2Time, this.c2Name, this.c2Room);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.c3Name.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.CourseRow.bind(this)(this.c3Time, this.c3Name, this.c3Room);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.c4Name.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.CourseRow.bind(this)(this.c4Time, this.c4Name, this.c4Room);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.courseCount > 5) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(`还有${this.courseCount - 5}节课...`);
                                    Text.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(79:11)", "entry");
                                    Text.fontSize(11);
                                    Text.fontColor('#999999');
                                    Text.width('100%');
                                    Text.textAlign(TextAlign.Center);
                                    Text.margin({ top: 4 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.nextCourse.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(88:11)", "entry");
                                    Row.width('100%');
                                    Row.padding({ left: 8, right: 8, top: 4, bottom: 4 });
                                    Row.borderRadius(8);
                                    Row.backgroundColor('#F5F6FF');
                                    Row.margin({ top: 4 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.nextCourse);
                                    Text.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(89:13)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor('#4F6EF7');
                                    Text.fontWeight(FontWeight.Medium);
                                }, Text);
                                Text.pop();
                                Row.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    CourseRow(time: string, name: string, room: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(120:5)", "entry");
            Row.width('100%');
            Row.alignItems(VerticalAlign.Center);
            Row.margin({ bottom: 2 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(121:7)", "entry");
            Column.width(80);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(time);
            Text.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(122:9)", "entry");
            Text.fontSize(10);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(129:7)", "entry");
            Column.height(24);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(130:9)", "entry");
            Row.width(3);
            Row.height('100%');
            Row.backgroundColor('#4F6EF7');
            Row.borderRadius(2);
        }, Row);
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(138:7)", "entry");
            Blank.width(6);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(140:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(name);
            Text.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(141:9)", "entry");
            Text.fontSize(12);
            Text.fontColor('#333333');
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(room.length > 0 ? room : '教室未定');
            Text.debugLine("entry/src/main/ets/entryformability/pages/WidgetCard.ets(147:9)", "entry");
            Text.fontSize(10);
            Text.fontColor('#999999');
            Text.margin({ top: 1 });
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
        this.__dateStr.resetSource();
        this.__semesterWeek.resetSource();
        this.__courseCount.resetSource();
        this.__nextCourse.resetSource();
        this.__c0Name.resetSource();
        this.__c0Room.resetSource();
        this.__c0Time.resetSource();
        this.__c1Name.resetSource();
        this.__c1Room.resetSource();
        this.__c1Time.resetSource();
        this.__c2Name.resetSource();
        this.__c2Room.resetSource();
        this.__c2Time.resetSource();
        this.__c3Name.resetSource();
        this.__c3Room.resetSource();
        this.__c3Time.resetSource();
        this.__c4Name.resetSource();
        this.__c4Room.resetSource();
        this.__c4Time.resetSource();
    }
    static getEntryName(): string {
        return "WidgetCard";
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadEtsCard(new WidgetCard(undefined, {}, storage), "com.campus.assistant/entry/ets/entryformability/pages/WidgetCard");
ViewStackProcessor.StopGetAccessRecording();
