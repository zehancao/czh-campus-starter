if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CampusSafetyPage_Params {
    contacts?: SafetyContact[];
    showPhones?: boolean;
    isLoading?: boolean;
    progressValue?: number;
    isHolding?: boolean;
    isSubmitting?: boolean;
    locationText?: string;
    manualLocation?: string;
    showManualInput?: boolean;
    holdTimer?: number;
    tickCount?: number;
    maxTicks?: number;
}
import call from "@ohos:telephony.call";
import geoLocationManager from "@ohos:geoLocationManager";
import abilityAccessCtrl from "@ohos:abilityAccessCtrl";
import type common from "@ohos:app.ability.common";
import type { BusinessError } from "@ohos:base";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { SafetyContact } from '../model/Models';
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const HOLD_DURATION: number = 2000;
const TICK_INTERVAL: number = 30;
const CATEGORY_COLORS: Record<string, string> = {
    '安保': '#3B82F6',
    '医疗': '#EF4444',
    '消防': '#F97316',
    '心理': '#10B981',
    '其他': '#6B7280'
};
class CampusSafetyPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__contacts = new ObservedPropertyObjectPU([], this, "contacts");
        this.__showPhones = new ObservedPropertySimplePU(false, this, "showPhones");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__progressValue = new ObservedPropertySimplePU(0, this, "progressValue");
        this.__isHolding = new ObservedPropertySimplePU(false, this, "isHolding");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.__locationText = new ObservedPropertySimplePU('', this, "locationText");
        this.__manualLocation = new ObservedPropertySimplePU('', this, "manualLocation");
        this.__showManualInput = new ObservedPropertySimplePU(false, this, "showManualInput");
        this.holdTimer = -1;
        this.tickCount = 0;
        this.maxTicks = Math.floor(HOLD_DURATION / TICK_INTERVAL);
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CampusSafetyPage_Params) {
        if (params.contacts !== undefined) {
            this.contacts = params.contacts;
        }
        if (params.showPhones !== undefined) {
            this.showPhones = params.showPhones;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.progressValue !== undefined) {
            this.progressValue = params.progressValue;
        }
        if (params.isHolding !== undefined) {
            this.isHolding = params.isHolding;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
        if (params.locationText !== undefined) {
            this.locationText = params.locationText;
        }
        if (params.manualLocation !== undefined) {
            this.manualLocation = params.manualLocation;
        }
        if (params.showManualInput !== undefined) {
            this.showManualInput = params.showManualInput;
        }
        if (params.holdTimer !== undefined) {
            this.holdTimer = params.holdTimer;
        }
        if (params.tickCount !== undefined) {
            this.tickCount = params.tickCount;
        }
        if (params.maxTicks !== undefined) {
            this.maxTicks = params.maxTicks;
        }
    }
    updateStateVars(params: CampusSafetyPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__contacts.purgeDependencyOnElmtId(rmElmtId);
        this.__showPhones.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__progressValue.purgeDependencyOnElmtId(rmElmtId);
        this.__isHolding.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
        this.__locationText.purgeDependencyOnElmtId(rmElmtId);
        this.__manualLocation.purgeDependencyOnElmtId(rmElmtId);
        this.__showManualInput.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__contacts.aboutToBeDeleted();
        this.__showPhones.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__progressValue.aboutToBeDeleted();
        this.__isHolding.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        this.__locationText.aboutToBeDeleted();
        this.__manualLocation.aboutToBeDeleted();
        this.__showManualInput.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __contacts: ObservedPropertyObjectPU<SafetyContact[]>;
    get contacts() {
        return this.__contacts.get();
    }
    set contacts(newValue: SafetyContact[]) {
        this.__contacts.set(newValue);
    }
    private __showPhones: ObservedPropertySimplePU<boolean>;
    get showPhones() {
        return this.__showPhones.get();
    }
    set showPhones(newValue: boolean) {
        this.__showPhones.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __progressValue: ObservedPropertySimplePU<number>;
    get progressValue() {
        return this.__progressValue.get();
    }
    set progressValue(newValue: number) {
        this.__progressValue.set(newValue);
    }
    private __isHolding: ObservedPropertySimplePU<boolean>;
    get isHolding() {
        return this.__isHolding.get();
    }
    set isHolding(newValue: boolean) {
        this.__isHolding.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    private __locationText: ObservedPropertySimplePU<string>;
    get locationText() {
        return this.__locationText.get();
    }
    set locationText(newValue: string) {
        this.__locationText.set(newValue);
    }
    private __manualLocation: ObservedPropertySimplePU<string>;
    get manualLocation() {
        return this.__manualLocation.get();
    }
    set manualLocation(newValue: string) {
        this.__manualLocation.set(newValue);
    }
    private __showManualInput: ObservedPropertySimplePU<boolean>;
    get showManualInput() {
        return this.__showManualInput.get();
    }
    set showManualInput(newValue: boolean) {
        this.__showManualInput.set(newValue);
    }
    private holdTimer: number;
    private tickCount: number;
    private maxTicks: number;
    aboutToDisappear(): void {
        if (this.holdTimer !== -1) {
            clearInterval(this.holdTimer);
        }
    }
    private startHold(): void {
        this.isHolding = true;
        this.progressValue = 0;
        this.tickCount = 0;
        this.holdTimer = setInterval(() => {
            this.tickCount = this.tickCount + 1;
            this.progressValue = this.tickCount / this.maxTicks;
            if (this.tickCount >= this.maxTicks) {
                clearInterval(this.holdTimer);
                this.holdTimer = -1;
                this.isHolding = false;
                this.progressValue = 0;
                this.onHoldComplete();
            }
        }, TICK_INTERVAL);
    }
    private cancelHold(): void {
        if (this.holdTimer !== -1) {
            clearInterval(this.holdTimer);
            this.holdTimer = -1;
        }
        this.isHolding = false;
        this.progressValue = 0;
    }
    private async onHoldComplete(): Promise<void> {
        this.isSubmitting = true;
        this.locationText = '正在获取位置...';
        let locationStr: string = '';
        let locationFailed: boolean = false;
        try {
            const context: common.UIAbilityContext = this.getUIContext().getHostContext() as common.UIAbilityContext;
            const atManager = abilityAccessCtrl.createAtManager();
            const grantResult = await atManager.requestPermissionsFromUser(context, ['ohos.permission.APPROXIMATELY_LOCATION', 'ohos.permission.LOCATION']);
            let hasLocation: boolean = false;
            for (let i = 0; i < grantResult.authResults.length; i++) {
                if (grantResult.authResults[i] === 0) {
                    hasLocation = true;
                    break;
                }
            }
            if (hasLocation) {
                const isLocEnabled: boolean = geoLocationManager.isLocationEnabled();
                if (!isLocEnabled) {
                    locationFailed = true;
                    locationStr = '';
                }
                else {
                    const requestInfo: geoLocationManager.SingleLocationRequest = {
                        locatingPriority: geoLocationManager.LocatingPriority.PRIORITY_LOCATING_SPEED,
                        locatingTimeoutMs: 10000
                    };
                    const loc: geoLocationManager.Location = await geoLocationManager.getCurrentLocation(requestInfo);
                    let addressStr: string = `${loc.latitude.toFixed(4)},${loc.longitude.toFixed(4)}`;
                    try {
                        if (geoLocationManager.isGeocoderAvailable()) {
                            const reverseRequest: geoLocationManager.ReverseGeoCodeRequest = {
                                latitude: loc.latitude,
                                longitude: loc.longitude,
                                maxItems: 1
                            };
                            const addresses: Array<geoLocationManager.GeoAddress> = await geoLocationManager.getAddressesFromLocation(reverseRequest);
                            if (addresses.length > 0) {
                                const addr: geoLocationManager.GeoAddress = addresses[0];
                                const parts: string[] = [];
                                if (addr.administrativeArea !== undefined && addr.administrativeArea.length > 0) {
                                    parts.push(addr.administrativeArea);
                                }
                                if (addr.locality !== undefined && addr.locality.length > 0) {
                                    parts.push(addr.locality);
                                }
                                if (addr.subLocality !== undefined && addr.subLocality.length > 0) {
                                    parts.push(addr.subLocality);
                                }
                                if (addr.roadName !== undefined && addr.roadName.length > 0) {
                                    parts.push(addr.roadName);
                                }
                                if (addr.placeName !== undefined && addr.placeName.length > 0 && parts.indexOf(addr.placeName) === -1) {
                                    parts.push(addr.placeName);
                                }
                                if (parts.length > 0) {
                                    addressStr = parts.join('');
                                }
                            }
                        }
                    }
                    catch (geoErr) {
                        addressStr = `${loc.latitude.toFixed(4)},${loc.longitude.toFixed(4)}`;
                    }
                    locationStr = addressStr;
                }
            }
            else {
                locationFailed = true;
                locationStr = '';
            }
        }
        catch (e) {
            locationFailed = true;
            locationStr = '';
        }
        this.locationText = locationStr;
        this.isSubmitting = false;
        if (locationFailed) {
            this.showManualInput = true;
            return;
        }
        this.doSubmit(locationStr);
    }
    private async doSubmit(locationStr: string): Promise<void> {
        this.isSubmitting = true;
        const params: Record<string, Object> = {
            'type': 'emergency',
            'location': locationStr,
            'description': '长按紧急求助按钮触发',
            'images': '[]',
        };
        const submitResult = await ApiService.submitSafetyReport(params);
        this.isSubmitting = false;
        if (submitResult.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '求助已提交', duration: 2000 });
        }
        else {
            this.getUIContext().getPromptAction().showToast({ message: `提交失败: ${submitResult.msg}`, duration: 3000 });
        }
        if (this.contacts.length === 0) {
            this.isLoading = true;
            const result = await ApiService.getSafetyContacts();
            if (result.code === 200 && result.data !== undefined) {
                this.contacts = ApiService.parseSafetyContacts(result.data);
            }
            this.isLoading = false;
        }
        this.showPhones = true;
    }
    private makeCall(phone: string): void {
        call.makeCall(phone, (err: BusinessError) => {
            if (err) {
                this.getUIContext().getPromptAction().showToast({ message: '拨号失败', duration: 2000 });
            }
        });
    }
    private getFiltered(category: string): SafetyContact[] {
        const result: SafetyContact[] = [];
        for (let i = 0; i < this.contacts.length; i++) {
            if (this.contacts[i].category === category) {
                result.push(this.contacts[i]);
            }
        }
        return result;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(200:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '校园安全' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CampusSafetyPage.ets", line: 201, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '校园安全'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '校园安全'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(203:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(204:9)", "entry");
            Column.width('100%');
            Column.padding({ bottom: 24 });
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(205:11)", "entry");
            Stack.width(220);
            Stack.height(220);
            Stack.margin({ top: 36 });
            Stack.onTouch((event: TouchEvent) => {
                if (event.type === TouchType.Down) {
                    this.startHold();
                }
                else if (event.type === TouchType.Up || event.type === TouchType.Cancel) {
                    this.cancelHold();
                }
            });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Progress.create({ value: this.progressValue, total: 1, type: ProgressType.Ring });
            Progress.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(206:13)", "entry");
            Progress.width(220);
            Progress.height(220);
            Progress.color(Theme.danger);
            Progress.style({ strokeWidth: 6 });
            Progress.visibility(this.isHolding ? Visibility.Visible : Visibility.Hidden);
        }, Progress);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(212:13)", "entry");
            Column.width(180);
            Column.height(180);
            Column.borderRadius(90);
            Column.backgroundColor(this.isHolding ? '#DC2626' : Theme.danger);
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
            Column.shadow({ radius: this.isHolding ? 32 : 24, color: '#EF444480', offsetY: 8 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🆘');
            Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(213:15)", "entry");
            Text.fontSize(56);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('紧急求助');
            Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(214:15)", "entry");
            Text.fontSize(22);
            Text.fontColor('#FFFFFF');
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isHolding ? '请持续按住...' : '长按2秒');
            Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(216:15)", "entry");
            Text.fontSize(13);
            Text.fontColor('rgba(255,255,255,0.7)');
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        Column.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isSubmitting) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(237:13)", "entry");
                        Column.margin({ top: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(238:15)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(28);
                        LoadingProgress.height(28);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.locationText);
                        Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(239:15)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showManualInput) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(246:13)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 16, right: 16 });
                        Column.margin({ top: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('⚠️ 定位服务未开启，请输入当前位置');
                        Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(247:15)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.danger);
                        Text.fontWeight(FontWeight.Medium);
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.margin({ bottom: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '例如：3号教学楼2层', text: { value: this.manualLocation, changeEvent: newValue => { this.manualLocation = newValue; } } });
                        TextInput.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(251:15)", "entry");
                        TextInput.width('100%');
                        TextInput.height(44);
                        TextInput.borderRadius(Theme.radiusMd);
                        TextInput.backgroundColor('#FFFFFF');
                        TextInput.padding({ left: 16, right: 16 });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('提交求助');
                        Button.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(257:15)", "entry");
                        Button.width('100%');
                        Button.height(44);
                        Button.backgroundColor(Theme.danger);
                        Button.fontColor('#FFFFFF');
                        Button.borderRadius(Theme.radiusMd);
                        Button.margin({ top: 12 });
                        Button.onClick(() => {
                            if (this.manualLocation.length === 0) {
                                this.getUIContext().getPromptAction().showToast({ message: '请输入当前位置', duration: 2000 });
                                return;
                            }
                            this.showManualInput = false;
                            this.doSubmit(this.manualLocation);
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showPhones && this.contacts.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(279:13)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 16, right: 16 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('求助已发送！请立即拨打以下电话');
                        Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(280:15)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.danger);
                        Text.fontWeight(FontWeight.Medium);
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.margin({ top: 20, bottom: 16 });
                    }, Text);
                    Text.pop();
                    this.ContactSection.bind(this)('🏥 医疗急救', '医疗');
                    this.ContactSection.bind(this)('🛡️ 校内救援', '安保');
                    this.ContactSection.bind(this)('🚒 消防报警', '消防');
                    this.ContactSection.bind(this)('💚 心理援助', '心理');
                    this.ContactSection.bind(this)('📞 其他服务', '其他');
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    ContactSection(title: string, category: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (category === '安保' || category === '医疗' || category === '消防' || category === '心理' || category === '其他') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(308:7)", "entry");
                        Column.width('100%');
                        Column.margin({ bottom: 16 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(title);
                        Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(309:9)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Medium);
                        Text.width('100%');
                        Text.margin({ bottom: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const c = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(314:11)", "entry");
                                Row.width('100%');
                                Row.padding({ left: 16, right: 16, top: 16, bottom: 16 });
                                Row.backgroundColor('#FFFFFF');
                                Row.borderRadius(Theme.radiusMd);
                                Row.margin({ bottom: 6 });
                                Row.shadow(ShadowStyle.sm);
                                Row.onClick(() => { this.makeCall(c.phone); });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(c.name);
                                Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(315:13)", "entry");
                                Text.fontSize(16);
                                Text.fontColor(Theme.textPrimary);
                                Text.fontWeight(FontWeight.Medium);
                                Text.layoutWeight(1);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(319:13)", "entry");
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(c.phone);
                                Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(320:15)", "entry");
                                Text.fontSize(20);
                                Text.fontColor(Theme.primary);
                                Text.fontWeight(FontWeight.Bold);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(' 📞');
                                Text.debugLine("entry/src/main/ets/pages/CampusSafetyPage.ets(322:15)", "entry");
                                Text.fontSize(22);
                            }, Text);
                            Text.pop();
                            Row.pop();
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.getFiltered(category), forEachItemGenFunction, (c: SafetyContact) => `${c.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "CampusSafetyPage";
    }
}
registerNamedRoute(() => new CampusSafetyPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/CampusSafetyPage", pageFullPath: "entry/src/main/ets/pages/CampusSafetyPage", integratedHsp: "false", moduleType: "followWithHap" });
