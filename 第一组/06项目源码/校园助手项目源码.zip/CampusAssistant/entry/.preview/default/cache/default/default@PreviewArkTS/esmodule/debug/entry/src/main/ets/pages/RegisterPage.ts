if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface RegisterPage_Params {
    studentId?: string;
    name?: string;
    password?: string;
    confirmPassword?: string;
    phone?: string;
    hometown?: string;
    errorMsg?: string;
    isLoading?: boolean;
    grade?: string;
    collegeId?: number;
    collegeName?: string;
    majorId?: number;
    majorName?: string;
    classId?: number;
    className?: string;
    classNames?: PickerOption[];
    province?: string;
    grades?: string[];
    colleges?: PickerOption[];
    majors?: PickerOption[];
}
interface SelectField_Params {
    label?: string;
    value?: string;
    onTap?: () => void;
}
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { PickerOption } from '../model/Models';
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
class SelectField extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__label = new SynchedPropertySimpleOneWayPU(params.label, this, "label");
        this.__value = new SynchedPropertySimpleOneWayPU(params.value, this, "value");
        this.onTap = () => { };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SelectField_Params) {
        if (params.label === undefined) {
            this.__label.set('');
        }
        if (params.value === undefined) {
            this.__value.set('');
        }
        if (params.onTap !== undefined) {
            this.onTap = params.onTap;
        }
    }
    updateStateVars(params: SelectField_Params) {
        this.__label.reset(params.label);
        this.__value.reset(params.value);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__label.purgeDependencyOnElmtId(rmElmtId);
        this.__value.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__label.aboutToBeDeleted();
        this.__value.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __label: SynchedPropertySimpleOneWayPU<string>;
    get label() {
        return this.__label.get();
    }
    set label(newValue: string) {
        this.__label.set(newValue);
    }
    private __value: SynchedPropertySimpleOneWayPU<string>;
    get value() {
        return this.__value.get();
    }
    set value(newValue: string) {
        this.__value.set(newValue);
    }
    private onTap: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/RegisterPage.ets(14:5)", "entry");
            Stack.width('100%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
            Stack.margin({ top: 12 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(15:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RegisterPage.ets(19:7)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(28);
            Row.padding({ left: 16, right: 16 });
            Row.margin({ right: 4, bottom: 4 });
            Row.onClick(() => {
                this.onTap();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.value.length > 0 ? this.value : `请选择${this.label}`);
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(20:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(this.value.length > 0 ? Theme.textPrimary : Theme.textDisabled);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RegisterPage.ets(23:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(24:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        Row.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class RegisterPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__studentId = new ObservedPropertySimplePU('', this, "studentId");
        this.__name = new ObservedPropertySimplePU('', this, "name");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__confirmPassword = new ObservedPropertySimplePU('', this, "confirmPassword");
        this.__phone = new ObservedPropertySimplePU('', this, "phone");
        this.__hometown = new ObservedPropertySimplePU('', this, "hometown");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__grade = new ObservedPropertySimplePU('', this, "grade");
        this.__collegeId = new ObservedPropertySimplePU(0, this, "collegeId");
        this.__collegeName = new ObservedPropertySimplePU('', this, "collegeName");
        this.__majorId = new ObservedPropertySimplePU(0, this, "majorId");
        this.__majorName = new ObservedPropertySimplePU('', this, "majorName");
        this.__classId = new ObservedPropertySimplePU(0, this, "classId");
        this.__className = new ObservedPropertySimplePU('', this, "className");
        this.__classNames = new ObservedPropertyObjectPU([], this, "classNames");
        this.__province = new ObservedPropertySimplePU('', this, "province");
        this.__grades = new ObservedPropertyObjectPU([], this, "grades");
        this.__colleges = new ObservedPropertyObjectPU([], this, "colleges");
        this.__majors = new ObservedPropertyObjectPU([], this, "majors");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: RegisterPage_Params) {
        if (params.studentId !== undefined) {
            this.studentId = params.studentId;
        }
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.confirmPassword !== undefined) {
            this.confirmPassword = params.confirmPassword;
        }
        if (params.phone !== undefined) {
            this.phone = params.phone;
        }
        if (params.hometown !== undefined) {
            this.hometown = params.hometown;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.grade !== undefined) {
            this.grade = params.grade;
        }
        if (params.collegeId !== undefined) {
            this.collegeId = params.collegeId;
        }
        if (params.collegeName !== undefined) {
            this.collegeName = params.collegeName;
        }
        if (params.majorId !== undefined) {
            this.majorId = params.majorId;
        }
        if (params.majorName !== undefined) {
            this.majorName = params.majorName;
        }
        if (params.classId !== undefined) {
            this.classId = params.classId;
        }
        if (params.className !== undefined) {
            this.className = params.className;
        }
        if (params.classNames !== undefined) {
            this.classNames = params.classNames;
        }
        if (params.province !== undefined) {
            this.province = params.province;
        }
        if (params.grades !== undefined) {
            this.grades = params.grades;
        }
        if (params.colleges !== undefined) {
            this.colleges = params.colleges;
        }
        if (params.majors !== undefined) {
            this.majors = params.majors;
        }
    }
    updateStateVars(params: RegisterPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__studentId.purgeDependencyOnElmtId(rmElmtId);
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__confirmPassword.purgeDependencyOnElmtId(rmElmtId);
        this.__phone.purgeDependencyOnElmtId(rmElmtId);
        this.__hometown.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__grade.purgeDependencyOnElmtId(rmElmtId);
        this.__collegeId.purgeDependencyOnElmtId(rmElmtId);
        this.__collegeName.purgeDependencyOnElmtId(rmElmtId);
        this.__majorId.purgeDependencyOnElmtId(rmElmtId);
        this.__majorName.purgeDependencyOnElmtId(rmElmtId);
        this.__classId.purgeDependencyOnElmtId(rmElmtId);
        this.__className.purgeDependencyOnElmtId(rmElmtId);
        this.__classNames.purgeDependencyOnElmtId(rmElmtId);
        this.__province.purgeDependencyOnElmtId(rmElmtId);
        this.__grades.purgeDependencyOnElmtId(rmElmtId);
        this.__colleges.purgeDependencyOnElmtId(rmElmtId);
        this.__majors.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__studentId.aboutToBeDeleted();
        this.__name.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__confirmPassword.aboutToBeDeleted();
        this.__phone.aboutToBeDeleted();
        this.__hometown.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__grade.aboutToBeDeleted();
        this.__collegeId.aboutToBeDeleted();
        this.__collegeName.aboutToBeDeleted();
        this.__majorId.aboutToBeDeleted();
        this.__majorName.aboutToBeDeleted();
        this.__classId.aboutToBeDeleted();
        this.__className.aboutToBeDeleted();
        this.__classNames.aboutToBeDeleted();
        this.__province.aboutToBeDeleted();
        this.__grades.aboutToBeDeleted();
        this.__colleges.aboutToBeDeleted();
        this.__majors.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __studentId: ObservedPropertySimplePU<string>;
    get studentId() {
        return this.__studentId.get();
    }
    set studentId(newValue: string) {
        this.__studentId.set(newValue);
    }
    private __name: ObservedPropertySimplePU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __confirmPassword: ObservedPropertySimplePU<string>;
    get confirmPassword() {
        return this.__confirmPassword.get();
    }
    set confirmPassword(newValue: string) {
        this.__confirmPassword.set(newValue);
    }
    private __phone: ObservedPropertySimplePU<string>;
    get phone() {
        return this.__phone.get();
    }
    set phone(newValue: string) {
        this.__phone.set(newValue);
    }
    private __hometown: ObservedPropertySimplePU<string>;
    get hometown() {
        return this.__hometown.get();
    }
    set hometown(newValue: string) {
        this.__hometown.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __grade: ObservedPropertySimplePU<string>;
    get grade() {
        return this.__grade.get();
    }
    set grade(newValue: string) {
        this.__grade.set(newValue);
    }
    private __collegeId: ObservedPropertySimplePU<number>;
    get collegeId() {
        return this.__collegeId.get();
    }
    set collegeId(newValue: number) {
        this.__collegeId.set(newValue);
    }
    private __collegeName: ObservedPropertySimplePU<string>;
    get collegeName() {
        return this.__collegeName.get();
    }
    set collegeName(newValue: string) {
        this.__collegeName.set(newValue);
    }
    private __majorId: ObservedPropertySimplePU<number>;
    get majorId() {
        return this.__majorId.get();
    }
    set majorId(newValue: number) {
        this.__majorId.set(newValue);
    }
    private __majorName: ObservedPropertySimplePU<string>;
    get majorName() {
        return this.__majorName.get();
    }
    set majorName(newValue: string) {
        this.__majorName.set(newValue);
    }
    private __classId: ObservedPropertySimplePU<number>;
    get classId() {
        return this.__classId.get();
    }
    set classId(newValue: number) {
        this.__classId.set(newValue);
    }
    private __className: ObservedPropertySimplePU<string>;
    get className() {
        return this.__className.get();
    }
    set className(newValue: string) {
        this.__className.set(newValue);
    }
    private __classNames: ObservedPropertyObjectPU<PickerOption[]>;
    get classNames() {
        return this.__classNames.get();
    }
    set classNames(newValue: PickerOption[]) {
        this.__classNames.set(newValue);
    }
    private __province: ObservedPropertySimplePU<string>;
    get province() {
        return this.__province.get();
    }
    set province(newValue: string) {
        this.__province.set(newValue);
    }
    private __grades: ObservedPropertyObjectPU<string[]>;
    get grades() {
        return this.__grades.get();
    }
    set grades(newValue: string[]) {
        this.__grades.set(newValue);
    }
    private __colleges: ObservedPropertyObjectPU<PickerOption[]>;
    get colleges() {
        return this.__colleges.get();
    }
    set colleges(newValue: PickerOption[]) {
        this.__colleges.set(newValue);
    }
    private __majors: ObservedPropertyObjectPU<PickerOption[]>;
    get majors() {
        return this.__majors.get();
    }
    set majors(newValue: PickerOption[]) {
        this.__majors.set(newValue);
    }
    aboutToAppear(): void {
        this.loadGrades();
        this.loadColleges();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(83:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgCard);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '注册账号' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RegisterPage.ets", line: 84, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '注册账号'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '注册账号'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/RegisterPage.ets(86:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.padding({ left: 24, right: 24 });
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(87:9)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/RegisterPage.ets(88:11)", "entry");
            Stack.width('100%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(89:13)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入学号', text: this.studentId });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(93:13)", "entry");
            TextInput.type(InputType.Number);
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.backgroundColor('#FFFFFF');
            TextInput.borderRadius(28);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.margin({ right: 4, bottom: 4 });
            TextInput.onChange((value: string) => {
                this.studentId = value;
                this.errorMsg = '';
            });
        }, TextInput);
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/RegisterPage.ets(115:11)", "entry");
            Stack.width('100%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
            Stack.margin({ top: 12 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(116:13)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入姓名', text: this.name });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(120:13)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.backgroundColor('#FFFFFF');
            TextInput.borderRadius(28);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.margin({ right: 4, bottom: 4 });
            TextInput.onChange((value: string) => {
                this.name = value;
                this.errorMsg = '';
            });
        }, TextInput);
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/RegisterPage.ets(142:11)", "entry");
            Stack.width('100%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
            Stack.margin({ top: 12 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(143:13)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入密码', text: this.password });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(147:13)", "entry");
            TextInput.type(InputType.Password);
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.backgroundColor('#FFFFFF');
            TextInput.borderRadius(28);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.margin({ right: 4, bottom: 4 });
            TextInput.onChange((value: string) => {
                this.password = value;
                this.errorMsg = '';
            });
        }, TextInput);
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/RegisterPage.ets(170:11)", "entry");
            Stack.width('100%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
            Stack.margin({ top: 12 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(171:13)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请确认密码', text: this.confirmPassword });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(175:13)", "entry");
            TextInput.type(InputType.Password);
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.backgroundColor('#FFFFFF');
            TextInput.borderRadius(28);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.margin({ right: 4, bottom: 4 });
            TextInput.onChange((value: string) => {
                this.confirmPassword = value;
                this.errorMsg = '';
            });
        }, TextInput);
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/RegisterPage.ets(198:11)", "entry");
            Stack.width('100%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
            Stack.margin({ top: 12 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(199:13)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入手机号', text: this.phone });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(203:13)", "entry");
            TextInput.type(InputType.PhoneNumber);
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.backgroundColor('#FFFFFF');
            TextInput.borderRadius(28);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.margin({ right: 4, bottom: 4 });
            TextInput.onChange((value: string) => {
                this.phone = value;
                this.errorMsg = '';
            });
        }, TextInput);
        Stack.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SelectField(this, { label: '年级', value: this.grade, onTap: () => { this.showGradePicker(); } }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RegisterPage.ets", line: 226, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            label: '年级',
                            value: this.grade,
                            onTap: () => { this.showGradePicker(); }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        label: '年级', value: this.grade
                    });
                }
            }, { name: "SelectField" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SelectField(this, { label: '学院', value: this.collegeName, onTap: () => { this.showCollegePicker(); } }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RegisterPage.ets", line: 227, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            label: '学院',
                            value: this.collegeName,
                            onTap: () => { this.showCollegePicker(); }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        label: '学院', value: this.collegeName
                    });
                }
            }, { name: "SelectField" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SelectField(this, { label: '专业', value: this.majorName, onTap: () => { this.showMajorPicker(); } }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RegisterPage.ets", line: 228, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            label: '专业',
                            value: this.majorName,
                            onTap: () => { this.showMajorPicker(); }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        label: '专业', value: this.majorName
                    });
                }
            }, { name: "SelectField" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SelectField(this, { label: '班级', value: this.className, onTap: () => { this.showClassPicker(); } }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RegisterPage.ets", line: 229, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            label: '班级',
                            value: this.className,
                            onTap: () => { this.showClassPicker(); }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        label: '班级', value: this.className
                    });
                }
            }, { name: "SelectField" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SelectField(this, { label: '籍贯', value: this.province, onTap: () => { this.showProvincePicker(); } }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RegisterPage.ets", line: 230, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            label: '籍贯',
                            value: this.province,
                            onTap: () => { this.showProvincePicker(); }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        label: '籍贯', value: this.province
                    });
                }
            }, { name: "SelectField" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(233:13)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.danger);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/RegisterPage.ets(239:11)", "entry");
            Stack.width('100%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
            Stack.enabled(!this.isLoading);
            Stack.margin({ top: 24, bottom: 24 });
            Stack.onClick(() => {
                this.handleRegister();
            });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(240:13)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(244:13)", "entry");
            Column.width('100%');
            Column.height(48);
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
            Column.borderRadius(28);
            Column.backgroundColor('#FFFFFF');
            Column.margin({ right: 4, bottom: 4 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('注 册');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(245:15)", "entry");
            Text.fontSize(18);
            Text.fontColor(Theme.textPrimary);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        Column.pop();
        Stack.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    private async loadGrades(): Promise<void> {
        const result: ApiResult = await ApiService.getPublicGrades();
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            const list: string[] = [];
            for (let i = 0; i < arr.length; i++) {
                list.push(arr[i] as string);
            }
            this.grades = list;
        }
    }
    private async loadColleges(): Promise<void> {
        const result: ApiResult = await ApiService.getPublicColleges();
        if (result.code === 200 && result.data !== undefined) {
            this.colleges = ApiService.parsePickerOptions(result.data);
        }
    }
    private async loadMajors(collegeId: number): Promise<void> {
        const result: ApiResult = await ApiService.getPublicMajors(collegeId);
        if (result.code === 200 && result.data !== undefined) {
            this.majors = ApiService.parsePickerOptions(result.data);
        }
        else {
            this.majors = [];
        }
    }
    private async loadClasses(grade: string, collegeId: number, majorId: number): Promise<void> {
        if (grade.length === 0 || collegeId === 0 || majorId === 0) {
            this.classNames = [];
            return;
        }
        const result: ApiResult = await ApiService.getPublicClasses(grade, collegeId, majorId);
        if (result.code === 200 && result.data !== undefined) {
            this.classNames = ApiService.parsePickerOptions(result.data);
        }
        else {
            this.classNames = [];
        }
    }
    private showProvincePicker(): void {
        const provinces: string[] = Constants.HOMETOWN_OPTIONS;
        let currentIdx: number = Math.max(provinces.indexOf(this.province), 0);
        TextPickerDialog.show({
            range: provinces,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                currentIdx = value.index as number;
                if (currentIdx >= 0 && currentIdx < provinces.length) {
                    this.province = provinces[currentIdx];
                    this.hometown = this.province;
                }
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < provinces.length) {
                    this.province = provinces[idx];
                }
                this.hometown = this.province;
            }
        });
    }
    private showGradePicker(): void {
        if (this.grades.length === 0) {
            this.errorMsg = '年级数据加载中，请稍候';
            return;
        }
        let currentIdx: number = Math.max(this.grades.indexOf(this.grade), 0);
        TextPickerDialog.show({
            range: this.grades,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                currentIdx = value.index as number;
                this.grade = this.grades[currentIdx];
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < this.grades.length) {
                    this.grade = this.grades[idx];
                }
                this.classId = 0;
                this.className = '';
                this.loadClasses(this.grade, this.collegeId, this.majorId);
            }
        });
    }
    private showCollegePicker(): void {
        if (this.colleges.length === 0) {
            this.errorMsg = '学院数据加载中，请稍候';
            return;
        }
        const names: string[] = [];
        for (let i = 0; i < this.colleges.length; i++) {
            names.push(this.colleges[i].name);
        }
        let currentIdx: number = Math.max(names.indexOf(this.collegeName), 0);
        TextPickerDialog.show({
            range: names,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                currentIdx = value.index as number;
                if (currentIdx >= 0 && currentIdx < this.colleges.length) {
                    this.collegeName = this.colleges[currentIdx].name;
                    this.collegeId = this.colleges[currentIdx].id;
                }
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < this.colleges.length) {
                    this.collegeName = this.colleges[idx].name;
                    this.collegeId = this.colleges[idx].id;
                }
                this.majorId = 0;
                this.majorName = '';
                this.classId = 0;
                this.className = '';
                this.classNames = [];
                this.loadMajors(this.collegeId);
            }
        });
    }
    private showMajorPicker(): void {
        if (this.collegeName.length === 0) {
            this.errorMsg = '请先选择学院';
            return;
        }
        if (this.majors.length === 0) {
            this.errorMsg = '该学院暂无专业数据';
            return;
        }
        const names: string[] = [];
        for (let i = 0; i < this.majors.length; i++) {
            names.push(this.majors[i].name);
        }
        let currentIdx: number = Math.max(names.indexOf(this.majorName), 0);
        TextPickerDialog.show({
            range: names,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                currentIdx = value.index as number;
                if (currentIdx >= 0 && currentIdx < this.majors.length) {
                    this.majorName = this.majors[currentIdx].name;
                    this.majorId = this.majors[currentIdx].id;
                }
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < this.majors.length) {
                    this.majorName = this.majors[idx].name;
                    this.majorId = this.majors[idx].id;
                }
                this.classId = 0;
                this.className = '';
                this.loadClasses(this.grade, this.collegeId, this.majorId);
            }
        });
    }
    private showClassPicker(): void {
        if (this.grade.length === 0 || this.majorName.length === 0) {
            this.errorMsg = '请先选择年级和专业';
            return;
        }
        if (this.classNames.length === 0) {
            this.errorMsg = '暂无匹配的班级数据';
            return;
        }
        const names: string[] = [];
        for (let i = 0; i < this.classNames.length; i++) {
            names.push(this.classNames[i].name);
        }
        let currentIdx: number = Math.max(names.indexOf(this.className), 0);
        TextPickerDialog.show({
            range: names,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                currentIdx = value.index as number;
                if (currentIdx >= 0 && currentIdx < this.classNames.length) {
                    this.className = this.classNames[currentIdx].name;
                    this.classId = this.classNames[currentIdx].id;
                }
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < this.classNames.length) {
                    this.className = this.classNames[idx].name;
                    this.classId = this.classNames[idx].id;
                }
            }
        });
    }
    private async handleRegister(): Promise<void> {
        if (this.studentId.length === 0) {
            this.errorMsg = '请输入学号';
            return;
        }
        if (this.name.length === 0) {
            this.errorMsg = '请输入姓名';
            return;
        }
        if (this.password.length === 0) {
            this.errorMsg = '请输入密码';
            return;
        }
        if (this.password !== this.confirmPassword) {
            this.errorMsg = '两次密码输入不一致';
            return;
        }
        if (this.phone.length === 0) {
            this.errorMsg = '请输入手机号';
            return;
        }
        if (this.collegeName.length === 0) {
            this.errorMsg = '请选择学院';
            return;
        }
        if (this.majorName.length === 0) {
            this.errorMsg = '请选择专业';
            return;
        }
        if (this.grade.length === 0) {
            this.errorMsg = '请选择年级';
            return;
        }
        if (this.className.length === 0) {
            this.errorMsg = '请选择班级';
            return;
        }
        this.isLoading = true;
        const params: Record<string, string> = {
            'name': this.name,
            'studentId': this.studentId,
            'phone': this.phone,
            'grade': this.grade,
            'college': this.collegeName,
            'major': this.majorName,
            'className': this.className,
            'hometown': this.hometown,
            'password': this.password
        };
        const result: ApiResult = await ApiService.register(params);
        this.isLoading = false;
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '注册成功，请登录' });
            this.getUIContext().getRouter().replaceUrl({ url: 'pages/LoginPage' });
        }
        else {
            this.errorMsg = result.msg.length > 0 ? result.msg : '注册失败';
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "RegisterPage";
    }
}
registerNamedRoute(() => new RegisterPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/RegisterPage", pageFullPath: "entry/src/main/ets/pages/RegisterPage", integratedHsp: "false", moduleType: "followWithHap" });
