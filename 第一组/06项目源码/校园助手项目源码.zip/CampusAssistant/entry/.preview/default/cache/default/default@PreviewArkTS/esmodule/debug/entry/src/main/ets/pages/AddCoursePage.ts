if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AddCoursePage_Params {
    courseName?: string;
    classroom?: string;
    teacherName?: string;
    dayOfWeek?: number;
    startSection?: number;
    endSection?: number;
    selectedWeeks?: boolean[];
    semesterWeekCount?: number;
    semesterTitle?: string;
    showWeekSheet?: boolean;
    showPeriodSheet?: boolean;
    showClassroomSheet?: boolean;
    weekParityMode?: string;
    tempDayIndex?: number;
    tempStartIndex?: number;
    tempEndIndex?: number;
    isSaving?: boolean;
    buildings?: string[];
    roomsInBuilding?: string[];
    selectedBuildingIndex?: number;
    selectedRoomIndex?: number;
    semesterId?: number;
}
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import router from "@ohos:router";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const WEEK_DAY_LABELS: string[] = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
class AddCoursePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__courseName = new ObservedPropertySimplePU('', this, "courseName");
        this.__classroom = new ObservedPropertySimplePU('', this, "classroom");
        this.__teacherName = new ObservedPropertySimplePU('', this, "teacherName");
        this.__dayOfWeek = new ObservedPropertySimplePU(1, this, "dayOfWeek");
        this.__startSection = new ObservedPropertySimplePU(1, this, "startSection");
        this.__endSection = new ObservedPropertySimplePU(2, this, "endSection");
        this.__selectedWeeks = new ObservedPropertyObjectPU([], this, "selectedWeeks");
        this.__semesterWeekCount = new ObservedPropertySimplePU(20, this, "semesterWeekCount");
        this.__semesterTitle = new ObservedPropertySimplePU('', this, "semesterTitle");
        this.__showWeekSheet = new ObservedPropertySimplePU(false, this, "showWeekSheet");
        this.__showPeriodSheet = new ObservedPropertySimplePU(false, this, "showPeriodSheet");
        this.__showClassroomSheet = new ObservedPropertySimplePU(false, this, "showClassroomSheet");
        this.__weekParityMode = new ObservedPropertySimplePU('all', this, "weekParityMode");
        this.__tempDayIndex = new ObservedPropertySimplePU(0, this, "tempDayIndex");
        this.__tempStartIndex = new ObservedPropertySimplePU(0, this, "tempStartIndex");
        this.__tempEndIndex = new ObservedPropertySimplePU(1, this, "tempEndIndex");
        this.__isSaving = new ObservedPropertySimplePU(false, this, "isSaving");
        this.__buildings = new ObservedPropertyObjectPU([], this, "buildings");
        this.__roomsInBuilding = new ObservedPropertyObjectPU([], this, "roomsInBuilding");
        this.__selectedBuildingIndex = new ObservedPropertySimplePU(0, this, "selectedBuildingIndex");
        this.__selectedRoomIndex = new ObservedPropertySimplePU(0, this, "selectedRoomIndex");
        this.semesterId = 1;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AddCoursePage_Params) {
        if (params.courseName !== undefined) {
            this.courseName = params.courseName;
        }
        if (params.classroom !== undefined) {
            this.classroom = params.classroom;
        }
        if (params.teacherName !== undefined) {
            this.teacherName = params.teacherName;
        }
        if (params.dayOfWeek !== undefined) {
            this.dayOfWeek = params.dayOfWeek;
        }
        if (params.startSection !== undefined) {
            this.startSection = params.startSection;
        }
        if (params.endSection !== undefined) {
            this.endSection = params.endSection;
        }
        if (params.selectedWeeks !== undefined) {
            this.selectedWeeks = params.selectedWeeks;
        }
        if (params.semesterWeekCount !== undefined) {
            this.semesterWeekCount = params.semesterWeekCount;
        }
        if (params.semesterTitle !== undefined) {
            this.semesterTitle = params.semesterTitle;
        }
        if (params.showWeekSheet !== undefined) {
            this.showWeekSheet = params.showWeekSheet;
        }
        if (params.showPeriodSheet !== undefined) {
            this.showPeriodSheet = params.showPeriodSheet;
        }
        if (params.showClassroomSheet !== undefined) {
            this.showClassroomSheet = params.showClassroomSheet;
        }
        if (params.weekParityMode !== undefined) {
            this.weekParityMode = params.weekParityMode;
        }
        if (params.tempDayIndex !== undefined) {
            this.tempDayIndex = params.tempDayIndex;
        }
        if (params.tempStartIndex !== undefined) {
            this.tempStartIndex = params.tempStartIndex;
        }
        if (params.tempEndIndex !== undefined) {
            this.tempEndIndex = params.tempEndIndex;
        }
        if (params.isSaving !== undefined) {
            this.isSaving = params.isSaving;
        }
        if (params.buildings !== undefined) {
            this.buildings = params.buildings;
        }
        if (params.roomsInBuilding !== undefined) {
            this.roomsInBuilding = params.roomsInBuilding;
        }
        if (params.selectedBuildingIndex !== undefined) {
            this.selectedBuildingIndex = params.selectedBuildingIndex;
        }
        if (params.selectedRoomIndex !== undefined) {
            this.selectedRoomIndex = params.selectedRoomIndex;
        }
        if (params.semesterId !== undefined) {
            this.semesterId = params.semesterId;
        }
    }
    updateStateVars(params: AddCoursePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__courseName.purgeDependencyOnElmtId(rmElmtId);
        this.__classroom.purgeDependencyOnElmtId(rmElmtId);
        this.__teacherName.purgeDependencyOnElmtId(rmElmtId);
        this.__dayOfWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__startSection.purgeDependencyOnElmtId(rmElmtId);
        this.__endSection.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedWeeks.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterWeekCount.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterTitle.purgeDependencyOnElmtId(rmElmtId);
        this.__showWeekSheet.purgeDependencyOnElmtId(rmElmtId);
        this.__showPeriodSheet.purgeDependencyOnElmtId(rmElmtId);
        this.__showClassroomSheet.purgeDependencyOnElmtId(rmElmtId);
        this.__weekParityMode.purgeDependencyOnElmtId(rmElmtId);
        this.__tempDayIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__tempStartIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__tempEndIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__isSaving.purgeDependencyOnElmtId(rmElmtId);
        this.__buildings.purgeDependencyOnElmtId(rmElmtId);
        this.__roomsInBuilding.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedBuildingIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedRoomIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__courseName.aboutToBeDeleted();
        this.__classroom.aboutToBeDeleted();
        this.__teacherName.aboutToBeDeleted();
        this.__dayOfWeek.aboutToBeDeleted();
        this.__startSection.aboutToBeDeleted();
        this.__endSection.aboutToBeDeleted();
        this.__selectedWeeks.aboutToBeDeleted();
        this.__semesterWeekCount.aboutToBeDeleted();
        this.__semesterTitle.aboutToBeDeleted();
        this.__showWeekSheet.aboutToBeDeleted();
        this.__showPeriodSheet.aboutToBeDeleted();
        this.__showClassroomSheet.aboutToBeDeleted();
        this.__weekParityMode.aboutToBeDeleted();
        this.__tempDayIndex.aboutToBeDeleted();
        this.__tempStartIndex.aboutToBeDeleted();
        this.__tempEndIndex.aboutToBeDeleted();
        this.__isSaving.aboutToBeDeleted();
        this.__buildings.aboutToBeDeleted();
        this.__roomsInBuilding.aboutToBeDeleted();
        this.__selectedBuildingIndex.aboutToBeDeleted();
        this.__selectedRoomIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __courseName: ObservedPropertySimplePU<string>;
    get courseName() {
        return this.__courseName.get();
    }
    set courseName(newValue: string) {
        this.__courseName.set(newValue);
    }
    private __classroom: ObservedPropertySimplePU<string>;
    get classroom() {
        return this.__classroom.get();
    }
    set classroom(newValue: string) {
        this.__classroom.set(newValue);
    }
    private __teacherName: ObservedPropertySimplePU<string>;
    get teacherName() {
        return this.__teacherName.get();
    }
    set teacherName(newValue: string) {
        this.__teacherName.set(newValue);
    }
    private __dayOfWeek: ObservedPropertySimplePU<number>;
    get dayOfWeek() {
        return this.__dayOfWeek.get();
    }
    set dayOfWeek(newValue: number) {
        this.__dayOfWeek.set(newValue);
    }
    private __startSection: ObservedPropertySimplePU<number>;
    get startSection() {
        return this.__startSection.get();
    }
    set startSection(newValue: number) {
        this.__startSection.set(newValue);
    }
    private __endSection: ObservedPropertySimplePU<number>;
    get endSection() {
        return this.__endSection.get();
    }
    set endSection(newValue: number) {
        this.__endSection.set(newValue);
    }
    private __selectedWeeks: ObservedPropertyObjectPU<boolean[]>;
    get selectedWeeks() {
        return this.__selectedWeeks.get();
    }
    set selectedWeeks(newValue: boolean[]) {
        this.__selectedWeeks.set(newValue);
    }
    private __semesterWeekCount: ObservedPropertySimplePU<number>;
    get semesterWeekCount() {
        return this.__semesterWeekCount.get();
    }
    set semesterWeekCount(newValue: number) {
        this.__semesterWeekCount.set(newValue);
    }
    private __semesterTitle: ObservedPropertySimplePU<string>;
    get semesterTitle() {
        return this.__semesterTitle.get();
    }
    set semesterTitle(newValue: string) {
        this.__semesterTitle.set(newValue);
    }
    private __showWeekSheet: ObservedPropertySimplePU<boolean>;
    get showWeekSheet() {
        return this.__showWeekSheet.get();
    }
    set showWeekSheet(newValue: boolean) {
        this.__showWeekSheet.set(newValue);
    }
    private __showPeriodSheet: ObservedPropertySimplePU<boolean>;
    get showPeriodSheet() {
        return this.__showPeriodSheet.get();
    }
    set showPeriodSheet(newValue: boolean) {
        this.__showPeriodSheet.set(newValue);
    }
    private __showClassroomSheet: ObservedPropertySimplePU<boolean>;
    get showClassroomSheet() {
        return this.__showClassroomSheet.get();
    }
    set showClassroomSheet(newValue: boolean) {
        this.__showClassroomSheet.set(newValue);
    }
    private __weekParityMode: ObservedPropertySimplePU<string>;
    get weekParityMode() {
        return this.__weekParityMode.get();
    }
    set weekParityMode(newValue: string) {
        this.__weekParityMode.set(newValue);
    }
    private __tempDayIndex: ObservedPropertySimplePU<number>;
    get tempDayIndex() {
        return this.__tempDayIndex.get();
    }
    set tempDayIndex(newValue: number) {
        this.__tempDayIndex.set(newValue);
    }
    private __tempStartIndex: ObservedPropertySimplePU<number>;
    get tempStartIndex() {
        return this.__tempStartIndex.get();
    }
    set tempStartIndex(newValue: number) {
        this.__tempStartIndex.set(newValue);
    }
    private __tempEndIndex: ObservedPropertySimplePU<number>;
    get tempEndIndex() {
        return this.__tempEndIndex.get();
    }
    set tempEndIndex(newValue: number) {
        this.__tempEndIndex.set(newValue);
    }
    private __isSaving: ObservedPropertySimplePU<boolean>;
    get isSaving() {
        return this.__isSaving.get();
    }
    set isSaving(newValue: boolean) {
        this.__isSaving.set(newValue);
    }
    private __buildings: ObservedPropertyObjectPU<string[]>;
    get buildings() {
        return this.__buildings.get();
    }
    set buildings(newValue: string[]) {
        this.__buildings.set(newValue);
    }
    private __roomsInBuilding: ObservedPropertyObjectPU<string[]>;
    get roomsInBuilding() {
        return this.__roomsInBuilding.get();
    }
    set roomsInBuilding(newValue: string[]) {
        this.__roomsInBuilding.set(newValue);
    }
    private __selectedBuildingIndex: ObservedPropertySimplePU<number>;
    get selectedBuildingIndex() {
        return this.__selectedBuildingIndex.get();
    }
    set selectedBuildingIndex(newValue: number) {
        this.__selectedBuildingIndex.set(newValue);
    }
    private __selectedRoomIndex: ObservedPropertySimplePU<number>;
    get selectedRoomIndex() {
        return this.__selectedRoomIndex.get();
    }
    set selectedRoomIndex(newValue: number) {
        this.__selectedRoomIndex.set(newValue);
    }
    private semesterId: number;
    private makeWeekNumbers(): number[] {
        const arr: number[] = [];
        for (let i = 1; i <= this.semesterWeekCount; i++) {
            arr.push(i);
        }
        return arr;
    }
    private makeSectionLabels(): string[] {
        const arr: string[] = [];
        for (let i = 1; i <= Constants.SECTION_TIMES.length; i++) {
            arr.push(`第${i}节`);
        }
        return arr;
    }
    aboutToAppear(): void {
        const params: Object = this.getUIContext().getRouter().getParams();
        if (params !== null && params !== undefined) {
            const p = params as Record<string, Object>;
            const wc = p['semesterWeekCount'];
            if (wc !== undefined && wc !== null) {
                this.semesterWeekCount = wc as number;
            }
            const st = p['semesterTitle'];
            if (st !== undefined && st !== null) {
                this.semesterTitle = st as string;
            }
            const sid = p['semesterId'];
            if (sid !== undefined && sid !== null) {
                this.semesterId = sid as number;
            }
        }
        const weeks: boolean[] = [];
        for (let i = 0; i < this.semesterWeekCount; i++) {
            weeks.push(true);
        }
        this.selectedWeeks = weeks;
        this.loadBuildings();
    }
    private async loadBuildings(): Promise<void> {
        this.buildings = await ApiService.getBuildings();
    }
    private async loadRooms(building: string): Promise<void> {
        this.roomsInBuilding = await ApiService.getRoomsByBuilding(building);
        this.selectedRoomIndex = 0;
    }
    private computeWeekLabel(): string {
        let first: number = -1;
        let last: number = -1;
        for (let i = 0; i < this.selectedWeeks.length; i++) {
            if (this.selectedWeeks[i]) {
                if (first < 0) {
                    first = i;
                }
                last = i;
            }
        }
        if (first < 0) {
            return '请选择周数';
        }
        if (this.weekParityMode === 'odd') {
            return '单周';
        }
        if (this.weekParityMode === 'even') {
            return '双周';
        }
        if (this.weekParityMode === 'all') {
            return `第1-${this.semesterWeekCount}周（全选）`;
        }
        return `第${first + 1}-${last + 1}周`;
    }
    private computePeriodLabel(): string {
        return `${WEEK_DAY_LABELS[this.dayOfWeek - 1]} 第${this.startSection}-${this.endSection}节`;
    }
    private toggleWeek(week: number): void {
        const newW: boolean[] = [];
        for (let i = 0; i < this.selectedWeeks.length; i++) {
            if (i === week - 1) {
                newW.push(!this.selectedWeeks[i]);
            }
            else {
                newW.push(this.selectedWeeks[i]);
            }
        }
        this.selectedWeeks = newW;
        this.weekParityMode = 'custom';
    }
    private setWeekParity(mode: string): void {
        this.weekParityMode = mode;
        const newW: boolean[] = [];
        for (let i = 0; i < this.semesterWeekCount; i++) {
            if (mode === 'all') {
                newW.push(true);
            }
            else if (mode === 'odd') {
                newW.push((i + 1) % 2 === 1);
            }
            else if (mode === 'even') {
                newW.push((i + 1) % 2 === 0);
            }
            else {
                newW.push(false);
            }
        }
        this.selectedWeeks = newW;
    }
    private openPeriodSheet(): void {
        this.tempDayIndex = this.dayOfWeek - 1;
        this.tempStartIndex = this.startSection - 1;
        this.tempEndIndex = this.endSection - 1;
        this.showPeriodSheet = true;
    }
    private confirmPeriod(): void {
        this.dayOfWeek = this.tempDayIndex + 1;
        this.startSection = this.tempStartIndex + 1;
        this.endSection = this.tempEndIndex + 1;
        this.showPeriodSheet = false;
    }
    private openClassroomSheet(): void {
        if (this.buildings.length === 0) {
            return;
        }
        this.selectedBuildingIndex = 0;
        this.selectedRoomIndex = 0;
        const building: string = this.buildings[0];
        this.loadRooms(building);
        this.showClassroomSheet = true;
    }
    private confirmClassroom(): void {
        if (this.roomsInBuilding.length > 0) {
            this.classroom = this.roomsInBuilding[this.selectedRoomIndex];
        }
        this.showClassroomSheet = false;
    }
    private async saveAndBack(): Promise<void> {
        if (this.isSaving) {
            return;
        }
        if (this.courseName.trim().length === 0) {
            this.getUIContext().getPromptAction().showToast({ message: '请输入课程名称' });
            return;
        }
        let first: number = -1;
        let last: number = -1;
        for (let i = 0; i < this.selectedWeeks.length; i++) {
            if (this.selectedWeeks[i]) {
                if (first < 0) {
                    first = i;
                }
                last = i;
            }
        }
        if (first < 0) {
            this.getUIContext().getPromptAction().showToast({ message: '请至少选择一周' });
            return;
        }
        let weekParity: string = 'all';
        if (this.weekParityMode === 'odd') {
            weekParity = 'odd';
        }
        else if (this.weekParityMode === 'even') {
            weekParity = 'even';
        }
        this.isSaving = true;
        const store: AppStore = AppStore.getInstance();
        if (!store.isLoggedIn) {
            this.getUIContext().getPromptAction().showToast({ message: '请先登录' });
            this.isSaving = false;
            return;
        }
        const params: Record<string, Object> = {
            'semesterId': this.semesterId,
            'courseName': this.courseName.trim(),
            'classroom': this.classroom,
            'teacher': this.teacherName.trim(),
            'dayOfWeek': this.dayOfWeek,
            'startSection': this.startSection,
            'endSection': this.endSection,
            'startWeek': first + 1,
            'endWeek': last + 1,
            'remark': weekParity === 'all' ? '' : weekParity === 'odd' ? '单周' : '双周'
        } as Record<string, Object>;
        const result: ApiResult = await ApiService.addPersonalCourse(params);
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '课程已添加' });
            router.back();
        }
        else {
            this.getUIContext().getPromptAction().showToast({ message: result.msg.length > 0 ? result.msg : '添加失败' });
        }
        this.isSaving = false;
    }
    WeekSheetContent(parent = null): void {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(237:5)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius({ topLeft: 28, topRight: 28 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(238:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('取消');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(239:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.textSecondary);
            Text.padding({ left: 20, right: 20, top: 14, bottom: 14 });
            Text.onClick(() => {
                this.showWeekSheet = false;
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(246:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('周数');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(247:9)", "entry");
            Text.fontSize(17);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(251:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('完成');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(252:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.primary);
            Text.padding({ left: 20, right: 20, top: 14, bottom: 14 });
            Text.onClick(() => {
                this.showWeekSheet = false;
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(262:7)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceEvenly);
            Row.padding({ top: 14, bottom: 18 });
        }, Row);
        this.ParityOption.bind(this)('单周', 'odd');
        this.ParityOption.bind(this)('双周', 'even');
        this.ParityOption.bind(this)('全选', 'all');
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Grid.create();
            Grid.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(271:7)", "entry");
            Grid.columnsTemplate('1fr 1fr 1fr 1fr 1fr');
            Grid.width('100%');
            Grid.padding({ left: 14, right: 14, bottom: 28 });
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, idx: number) => {
                const week = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.padding(5);
                        GridItem.onClick(() => {
                            this.toggleWeek(week);
                        });
                        GridItem.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(273:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`${week}`);
                            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(274:13)", "entry");
                            Text.width('100%');
                            Text.aspectRatio(1);
                            Text.fontSize(14);
                            Text.fontColor(this.selectedWeeks[week - 1] ? Color.White : Theme.textSecondary);
                            Text.textAlign(TextAlign.Center);
                            Text.backgroundColor(this.selectedWeeks[week - 1] ? Theme.primary : Theme.bgInput);
                            Text.borderRadius(8);
                        }, Text);
                        Text.pop();
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, this.makeWeekNumbers(), forEachItemGenFunction, (week: number) => `week_${week}`, true, false);
        }, ForEach);
        ForEach.pop();
        Grid.pop();
        Column.pop();
    }
    PeriodSheetContent(parent = null): void {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(300:5)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius({ topLeft: 28, topRight: 28 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(301:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('取消');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(302:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.textSecondary);
            Text.padding({ left: 20, right: 20, top: 14, bottom: 14 });
            Text.onClick(() => {
                this.showPeriodSheet = false;
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(309:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${WEEK_DAY_LABELS[this.tempDayIndex]} 第${this.tempStartIndex + 1}-${this.tempEndIndex + 1}节`);
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(310:9)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(314:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('完成');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(315:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.primary);
            Text.padding({ left: 20, right: 20, top: 14, bottom: 14 });
            Text.onClick(() => {
                this.confirmPeriod();
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(325:7)", "entry");
            Row.width('100%');
            Row.height(200);
            Row.padding({ left: 8, right: 8, bottom: 24 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: WEEK_DAY_LABELS, selected: { value: this.tempDayIndex, changeEvent: newValue => { this.tempDayIndex = newValue; } } });
            TextPicker.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(326:9)", "entry");
            TextPicker.layoutWeight(3);
        }, TextPicker);
        TextPicker.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.makeSectionLabels(), selected: { value: this.tempStartIndex, changeEvent: newValue => { this.tempStartIndex = newValue; } } });
            TextPicker.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(328:9)", "entry");
            TextPicker.layoutWeight(3);
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                if (this.tempEndIndex < this.tempStartIndex) {
                    this.tempEndIndex = this.tempStartIndex;
                }
            });
        }, TextPicker);
        TextPicker.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('—');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(335:9)", "entry");
            Text.layoutWeight(1);
            Text.fontSize(18);
            Text.fontColor(Theme.textSecondary);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.makeSectionLabels(), selected: { value: this.tempEndIndex, changeEvent: newValue => { this.tempEndIndex = newValue; } } });
            TextPicker.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(340:9)", "entry");
            TextPicker.layoutWeight(3);
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                if (this.tempEndIndex < this.tempStartIndex) {
                    this.tempStartIndex = this.tempEndIndex;
                }
            });
        }, TextPicker);
        TextPicker.pop();
        Row.pop();
        Column.pop();
    }
    ClassroomSheetContent(parent = null): void {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(359:5)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius({ topLeft: 28, topRight: 28 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(360:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('取消');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(361:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.textSecondary);
            Text.padding({ left: 20, right: 20, top: 14, bottom: 14 });
            Text.onClick(() => {
                this.showClassroomSheet = false;
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(368:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('选择教室');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(369:9)", "entry");
            Text.fontSize(17);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(373:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('完成');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(374:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.primary);
            Text.padding({ left: 20, right: 20, top: 14, bottom: 14 });
            Text.onClick(() => {
                this.confirmClassroom();
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(384:7)", "entry");
            Row.width('100%');
            Row.height(200);
            Row.padding({ left: 8, right: 8, bottom: 24 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.buildings, selected: { value: this.selectedBuildingIndex, changeEvent: newValue => { this.selectedBuildingIndex = newValue; } } });
            TextPicker.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(385:9)", "entry");
            TextPicker.layoutWeight(1);
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                const idx: number = index as number;
                if (idx >= 0 && idx < this.buildings.length) {
                    this.loadRooms(this.buildings[idx]);
                }
            });
        }, TextPicker);
        TextPicker.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.roomsInBuilding, selected: { value: this.selectedRoomIndex, changeEvent: newValue => { this.selectedRoomIndex = newValue; } } });
            TextPicker.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(393:9)", "entry");
            TextPicker.layoutWeight(1);
        }, TextPicker);
        TextPicker.pop();
        Row.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(406:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '添加课程',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.isSaving ? '保存中' : '保存');
                                Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(408:9)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(Theme.primary);
                                Text.width(64);
                                Text.height(34);
                                Text.textAlign(TextAlign.Center);
                                Text.backgroundColor(Theme.primaryLight);
                                Text.borderRadius(17);
                                Text.onClick(() => { this.saveAndBack(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/AddCoursePage.ets", line: 407, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '添加课程',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.isSaving ? '保存中' : '保存');
                                    Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(408:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.primary);
                                    Text.width(64);
                                    Text.height(34);
                                    Text.textAlign(TextAlign.Center);
                                    Text.backgroundColor(Theme.primaryLight);
                                    Text.borderRadius(17);
                                    Text.onClick(() => { this.saveAndBack(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '添加课程'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(415:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(416:9)", "entry");
            Column.width('100%');
            Column.padding({ left: 16, right: 16, top: 8, bottom: 40 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(417:11)", "entry");
            Row.width('100%');
            Row.padding({ left: 18, right: 18, top: 16, bottom: 16 });
            Row.backgroundColor(Theme.bgCard);
            Row.borderRadius(Theme.cardRadius);
            Row.margin({ bottom: 16 });
            Row.shadow(ShadowStyle.nmRaised);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(418:13)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('当前学期为');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(419:15)", "entry");
            Text.fontSize(Theme.fsSubtitle);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('返回课程表页面即可切换学期');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(423:15)", "entry");
            Text.fontSize(Theme.fsCaption);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 6 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.semesterTitle);
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(430:13)", "entry");
            Text.fontSize(Theme.fsCaption);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.primary);
            Text.padding({ left: 10, right: 10, top: 6, bottom: 6 });
            Text.backgroundColor(Theme.primaryLight);
            Text.borderRadius(Theme.chipRadius);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(445:11)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.shadow(ShadowStyle.nmRaised);
        }, Column);
        this.FormInputRow.bind(this)('课程名称', '请输入课程名称', 1);
        this.RowDivider.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(449:13)", "entry");
            Row.width('100%');
            Row.height(58);
            Row.padding({ left: 16, right: 16 });
            Row.onClick(() => {
                this.showWeekSheet = true;
            });
            Row.bindSheet({ value: this.showWeekSheet, changeEvent: newValue => { this.showWeekSheet = newValue; } }, { builder: () => {
                    this.WeekSheetContent.call(this);
                } }, {
                height: SheetSize.FIT_CONTENT,
                showClose: false,
                onDisappear: () => {
                    this.showWeekSheet = false;
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('课程周期');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(450:15)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textPrimary);
            Text.width(80);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(454:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.computeWeekLabel());
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(455:15)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textSecondary);
            Text.padding({ left: 10, right: 8, top: 5, bottom: 5 });
            Text.backgroundColor(Theme.bgInput);
            Text.borderRadius(Theme.chipRadius);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('›');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(461:15)", "entry");
            Text.fontSize(22);
            Text.fontColor(Theme.textDisabled);
            Text.margin({ left: 6 });
        }, Text);
        Text.pop();
        Row.pop();
        this.RowDivider.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(481:13)", "entry");
            Row.width('100%');
            Row.height(58);
            Row.padding({ left: 16, right: 16 });
            Row.onClick(() => {
                this.openPeriodSheet();
            });
            Row.bindSheet({ value: this.showPeriodSheet, changeEvent: newValue => { this.showPeriodSheet = newValue; } }, { builder: () => {
                    this.PeriodSheetContent.call(this);
                } }, {
                height: SheetSize.FIT_CONTENT,
                showClose: false,
                onDisappear: () => {
                    this.showPeriodSheet = false;
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('课程节数');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(482:15)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textPrimary);
            Text.width(80);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(486:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.computePeriodLabel());
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(487:15)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.danger);
            Text.padding({ left: 10, right: 8, top: 5, bottom: 5 });
            Text.backgroundColor(Theme.dangerLight);
            Text.borderRadius(Theme.chipRadius);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('›');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(493:15)", "entry");
            Text.fontSize(22);
            Text.fontColor(Theme.textDisabled);
            Text.margin({ left: 6 });
        }, Text);
        Text.pop();
        Row.pop();
        this.RowDivider.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(513:13)", "entry");
            Row.width('100%');
            Row.height(58);
            Row.padding({ left: 16, right: 16 });
            Row.onClick(() => {
                this.openClassroomSheet();
            });
            Row.bindSheet({ value: this.showClassroomSheet, changeEvent: newValue => { this.showClassroomSheet = newValue; } }, { builder: () => {
                    this.ClassroomSheetContent.call(this);
                } }, {
                height: SheetSize.FIT_CONTENT,
                showClose: false,
                onDisappear: () => {
                    this.showClassroomSheet = false;
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('选择教室');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(514:15)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textPrimary);
            Text.width(80);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(518:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.classroom.length > 0 ? this.classroom : '教学楼+教室号');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(519:15)", "entry");
            Text.fontSize(14);
            Text.fontColor(this.classroom.length > 0 ? Theme.textSecondary : Theme.textDisabled);
            Text.padding({ left: 10, right: 8, top: 5, bottom: 5 });
            Text.backgroundColor(Theme.bgInput);
            Text.borderRadius(Theme.chipRadius);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('›');
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(525:15)", "entry");
            Text.fontSize(22);
            Text.fontColor(Theme.textDisabled);
            Text.margin({ left: 6 });
        }, Text);
        Text.pop();
        Row.pop();
        this.RowDivider.bind(this)();
        this.FormInputRow.bind(this)('手动填写', '操场/体育馆等', 2);
        this.RowDivider.bind(this)();
        this.FormInputRow.bind(this)('任课老师', '请输入任课老师', 3);
        Column.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    FormInputRow(label: string, placeholder: string, fieldType: number, parent = null): void {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(568:5)", "entry");
            Row.width('100%');
            Row.height(58);
            Row.padding({ left: 16, right: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(569:7)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textPrimary);
            Text.width(80);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: placeholder });
            TextInput.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(573:7)", "entry");
            TextInput.layoutWeight(1);
            TextInput.height(40);
            TextInput.fontSize(15);
            TextInput.fontColor(Theme.textPrimary);
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.textAlign(TextAlign.End);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(20);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((val: string) => {
                if (fieldType === 1) {
                    this.courseName = val;
                }
                else if (fieldType === 2) {
                    this.classroom = val;
                }
                else if (fieldType === 3) {
                    this.teacherName = val;
                }
            });
        }, TextInput);
        Row.pop();
    }
    RowDivider(parent = null): void {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(600:5)", "entry");
            Row.width('100%');
            Row.height(0.5);
            Row.margin({ left: 16 });
            Row.backgroundColor(Theme.border);
        }, Row);
        Row.pop();
    }
    ParityOption(label: string, mode: string, parent = null): void {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(609:5)", "entry");
            Row.onClick(() => {
                this.setWeekParity(mode);
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(610:7)", "entry");
            Stack.width(18);
            Stack.height(18);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(611:9)", "entry");
            Row.width(18);
            Row.height(18);
            Row.borderRadius(9);
            Row.border({ width: 2, color: this.weekParityMode === mode ? Theme.primary : Theme.textDisabled });
        }, Row);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.weekParityMode === mode) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(617:11)", "entry");
                        Row.width(10);
                        Row.height(10);
                        Row.borderRadius(5);
                        Row.backgroundColor(Theme.primary);
                    }, Row);
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/AddCoursePage.ets(626:7)", "entry");
            Text.fontSize(14);
            Text.fontColor(this.weekParityMode === mode ? Theme.primary : Theme.textSecondary);
            Text.margin({ left: 6 });
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "AddCoursePage";
    }
}
registerNamedRoute(() => new AddCoursePage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/AddCoursePage", pageFullPath: "entry/src/main/ets/pages/AddCoursePage", integratedHsp: "false", moduleType: "followWithHap" });
