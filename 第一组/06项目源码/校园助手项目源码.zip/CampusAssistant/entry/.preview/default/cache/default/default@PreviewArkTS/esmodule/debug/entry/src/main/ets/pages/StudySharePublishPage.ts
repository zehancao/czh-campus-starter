if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface StudySharePublishPage_Params {
    titleInput?: string;
    descriptionInput?: string;
    courseNameInput?: string;
    selectedCategory?: number;
    fileUri?: string;
    fileUrl?: string;
    fileTypeName?: string;
    coverUri?: string;
    coverUrl?: string;
    isUploading?: boolean;
    isUploadingCover?: boolean;
    isSubmitting?: boolean;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import picker from "@ohos:file.picker";
import type common from "@ohos:app.ability.common";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const CATEGORIES: string[] = ['课件', '笔记', '真题', '作业', '其他'];
const CATEGORY_COLORS: string[] = ['#0288D1', Theme.ocean, '#D97706', Theme.success, Theme.textSecondary];
class StudySharePublishPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__titleInput = new ObservedPropertySimplePU('', this, "titleInput");
        this.__descriptionInput = new ObservedPropertySimplePU('', this, "descriptionInput");
        this.__courseNameInput = new ObservedPropertySimplePU('', this, "courseNameInput");
        this.__selectedCategory = new ObservedPropertySimplePU(0, this, "selectedCategory");
        this.__fileUri = new ObservedPropertySimplePU('', this, "fileUri");
        this.__fileUrl = new ObservedPropertySimplePU('', this, "fileUrl");
        this.__fileTypeName = new ObservedPropertySimplePU('', this, "fileTypeName");
        this.__coverUri = new ObservedPropertySimplePU('', this, "coverUri");
        this.__coverUrl = new ObservedPropertySimplePU('', this, "coverUrl");
        this.__isUploading = new ObservedPropertySimplePU(false, this, "isUploading");
        this.__isUploadingCover = new ObservedPropertySimplePU(false, this, "isUploadingCover");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StudySharePublishPage_Params) {
        if (params.titleInput !== undefined) {
            this.titleInput = params.titleInput;
        }
        if (params.descriptionInput !== undefined) {
            this.descriptionInput = params.descriptionInput;
        }
        if (params.courseNameInput !== undefined) {
            this.courseNameInput = params.courseNameInput;
        }
        if (params.selectedCategory !== undefined) {
            this.selectedCategory = params.selectedCategory;
        }
        if (params.fileUri !== undefined) {
            this.fileUri = params.fileUri;
        }
        if (params.fileUrl !== undefined) {
            this.fileUrl = params.fileUrl;
        }
        if (params.fileTypeName !== undefined) {
            this.fileTypeName = params.fileTypeName;
        }
        if (params.coverUri !== undefined) {
            this.coverUri = params.coverUri;
        }
        if (params.coverUrl !== undefined) {
            this.coverUrl = params.coverUrl;
        }
        if (params.isUploading !== undefined) {
            this.isUploading = params.isUploading;
        }
        if (params.isUploadingCover !== undefined) {
            this.isUploadingCover = params.isUploadingCover;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
    }
    updateStateVars(params: StudySharePublishPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__titleInput.purgeDependencyOnElmtId(rmElmtId);
        this.__descriptionInput.purgeDependencyOnElmtId(rmElmtId);
        this.__courseNameInput.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedCategory.purgeDependencyOnElmtId(rmElmtId);
        this.__fileUri.purgeDependencyOnElmtId(rmElmtId);
        this.__fileUrl.purgeDependencyOnElmtId(rmElmtId);
        this.__fileTypeName.purgeDependencyOnElmtId(rmElmtId);
        this.__coverUri.purgeDependencyOnElmtId(rmElmtId);
        this.__coverUrl.purgeDependencyOnElmtId(rmElmtId);
        this.__isUploading.purgeDependencyOnElmtId(rmElmtId);
        this.__isUploadingCover.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__titleInput.aboutToBeDeleted();
        this.__descriptionInput.aboutToBeDeleted();
        this.__courseNameInput.aboutToBeDeleted();
        this.__selectedCategory.aboutToBeDeleted();
        this.__fileUri.aboutToBeDeleted();
        this.__fileUrl.aboutToBeDeleted();
        this.__fileTypeName.aboutToBeDeleted();
        this.__coverUri.aboutToBeDeleted();
        this.__coverUrl.aboutToBeDeleted();
        this.__isUploading.aboutToBeDeleted();
        this.__isUploadingCover.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __titleInput: ObservedPropertySimplePU<string>;
    get titleInput() {
        return this.__titleInput.get();
    }
    set titleInput(newValue: string) {
        this.__titleInput.set(newValue);
    }
    private __descriptionInput: ObservedPropertySimplePU<string>;
    get descriptionInput() {
        return this.__descriptionInput.get();
    }
    set descriptionInput(newValue: string) {
        this.__descriptionInput.set(newValue);
    }
    private __courseNameInput: ObservedPropertySimplePU<string>;
    get courseNameInput() {
        return this.__courseNameInput.get();
    }
    set courseNameInput(newValue: string) {
        this.__courseNameInput.set(newValue);
    }
    private __selectedCategory: ObservedPropertySimplePU<number>;
    get selectedCategory() {
        return this.__selectedCategory.get();
    }
    set selectedCategory(newValue: number) {
        this.__selectedCategory.set(newValue);
    }
    private __fileUri: ObservedPropertySimplePU<string>;
    get fileUri() {
        return this.__fileUri.get();
    }
    set fileUri(newValue: string) {
        this.__fileUri.set(newValue);
    }
    private __fileUrl: ObservedPropertySimplePU<string>;
    get fileUrl() {
        return this.__fileUrl.get();
    }
    set fileUrl(newValue: string) {
        this.__fileUrl.set(newValue);
    }
    private __fileTypeName: ObservedPropertySimplePU<string>;
    get fileTypeName() {
        return this.__fileTypeName.get();
    }
    set fileTypeName(newValue: string) {
        this.__fileTypeName.set(newValue);
    }
    private __coverUri: ObservedPropertySimplePU<string>;
    get coverUri() {
        return this.__coverUri.get();
    }
    set coverUri(newValue: string) {
        this.__coverUri.set(newValue);
    }
    private __coverUrl: ObservedPropertySimplePU<string>;
    get coverUrl() {
        return this.__coverUrl.get();
    }
    set coverUrl(newValue: string) {
        this.__coverUrl.set(newValue);
    }
    private __isUploading: ObservedPropertySimplePU<boolean>;
    get isUploading() {
        return this.__isUploading.get();
    }
    set isUploading(newValue: boolean) {
        this.__isUploading.set(newValue);
    }
    private __isUploadingCover: ObservedPropertySimplePU<boolean>;
    get isUploadingCover() {
        return this.__isUploadingCover.get();
    }
    set isUploadingCover(newValue: boolean) {
        this.__isUploadingCover.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    private async pickFile(): Promise<void> {
        this.isUploading = true;
        try {
            const documentSelectOptions: picker.DocumentSelectOptions = new picker.DocumentSelectOptions();
            documentSelectOptions.maxSelectNumber = 1;
            const context: common.UIAbilityContext = this.getUIContext().getHostContext() as common.UIAbilityContext;
            const documentViewPicker: picker.DocumentViewPicker = new picker.DocumentViewPicker(context);
            const uris: string[] = await documentViewPicker.select(documentSelectOptions);
            if (uris.length > 0) {
                this.fileUri = uris[0];
                const url: string = await ApiService.uploadStudyShareFile(this.fileUri);
                if (url.startsWith('ERROR:')) {
                    AlertDialog.show({
                        message: `文件上传失败：${url}`,
                        confirm: { value: '确定', action: () => { } }
                    });
                }
                else {
                    this.fileUrl = url;
                    const ext: string = this.getExtensionFromUri(this.fileUri);
                    this.fileTypeName = ext;
                }
            }
        }
        catch (e) {
            const errMsg: string = e !== null && e !== undefined && typeof e === 'object' ? String(e) : '未知错误';
            AlertDialog.show({
                message: `选择文件失败：${errMsg}`,
                confirm: { value: '确定', action: () => { } }
            });
        }
        this.isUploading = false;
    }
    private async pickCoverImage(): Promise<void> {
        this.isUploadingCover = true;
        const uris: string[] = await ApiService.pickImages();
        if (uris.length > 0) {
            const url: string = await ApiService.uploadStudyShareCover(uris[0]);
            if (url.startsWith('ERROR:')) {
                AlertDialog.show({
                    message: '封面上传失败，请重试',
                    confirm: { value: '确定', action: () => { } }
                });
            }
            else {
                this.coverUri = uris[0];
                this.coverUrl = url;
            }
        }
        this.isUploadingCover = false;
    }
    private removeCover(): void {
        this.coverUri = '';
        this.coverUrl = '';
    }
    private removeFile(): void {
        this.fileUri = '';
        this.fileUrl = '';
        this.fileTypeName = '';
    }
    private getExtensionFromUri(uri: string): string {
        const parts: string[] = uri.split('.');
        if (parts.length > 1) {
            const ext: string = parts[parts.length - 1].toLowerCase();
            if (ext.length <= 5)
                return ext;
        }
        return 'file';
    }
    private async submitPublish(): Promise<void> {
        if (this.titleInput.trim().length === 0) {
            AlertDialog.show({
                message: '请输入资料标题',
                confirm: { value: '好的', action: () => { } }
            });
            return;
        }
        if (this.fileUrl.length === 0) {
            AlertDialog.show({
                message: '请上传资料文件',
                confirm: { value: '好的', action: () => { } }
            });
            return;
        }
        this.isSubmitting = true;
        const params: Record<string, Object> = {
            'title': this.titleInput.trim(),
            'description': this.descriptionInput.trim(),
            'courseName': this.courseNameInput.trim(),
            'category': CATEGORIES[this.selectedCategory],
            'fileUrl': this.fileUrl,
            'fileType': this.fileTypeName,
            'coverImage': this.coverUrl
        };
        const result = await ApiService.publishStudyShare(params);
        this.isSubmitting = false;
        if (result.code === 200) {
            promptAction.showToast({ message: '上传成功！' });
            router.back();
        }
        else {
            AlertDialog.show({
                title: '上传失败',
                message: result.msg !== undefined && result.msg !== null ? result.msg as string : '请稍后重试',
                confirm: { value: '好的', action: () => { } }
            });
        }
    }
    private canSubmit(): boolean {
        return this.titleInput.trim().length > 0 && this.fileUrl.length > 0 && !this.isSubmitting;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(145:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '上传资料',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.isSubmitting ? '上传中…' : '上传');
                                Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(147:9)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(this.canSubmit() ? Theme.primary : Theme.textDisabled);
                                Text.onClick(() => { this.submitPublish(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/StudySharePublishPage.ets", line: 146, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '上传资料',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.isSubmitting ? '上传中…' : '上传');
                                    Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(147:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(this.canSubmit() ? Theme.primary : Theme.textDisabled);
                                    Text.onClick(() => { this.submitPublish(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '上传资料'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(153:7)", "entry");
            Scroll.layoutWeight(1);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(154:9)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(155:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('分类');
            Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(156:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ bottom: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(163:13)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, idx: number) => {
                const cat = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(cat);
                    Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(165:17)", "entry");
                    Text.fontSize(13);
                    Text.fontColor(this.selectedCategory === idx ? '#FFFFFF' : CATEGORY_COLORS[idx]);
                    Text.backgroundColor(this.selectedCategory === idx ? CATEGORY_COLORS[idx] : '#FFFFFF');
                    Text.border({ width: 1, color: CATEGORY_COLORS[idx] });
                    Text.borderRadius(16);
                    Text.padding({ left: 16, right: 16, top: 6, bottom: 6 });
                    Text.margin({ right: 8 });
                    Text.onClick(() => { this.selectedCategory = idx; });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, CATEGORIES, forEachItemGenFunction, (cat: string) => cat, true, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(182:11)", "entry");
            Blank.height(10);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(184:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('标题');
            Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(185:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ bottom: 6 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '输入资料标题', text: this.titleInput });
            TextInput.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(191:13)", "entry");
            TextInput.width('100%');
            TextInput.height(Theme.inputHeight);
            TextInput.fontSize(15);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((val: string) => { this.titleInput = val; });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(204:11)", "entry");
            Blank.height(10);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(206:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('关联课程（可选）');
            Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(207:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ bottom: 6 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '如：高等数学', text: this.courseNameInput });
            TextInput.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(213:13)", "entry");
            TextInput.width('100%');
            TextInput.height(Theme.inputHeight);
            TextInput.fontSize(15);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((val: string) => { this.courseNameInput = val; });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(226:11)", "entry");
            Blank.height(10);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(228:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('描述（可选）');
            Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(229:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ bottom: 6 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({ placeholder: '补充资料说明...', text: this.descriptionInput });
            TextArea.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(235:13)", "entry");
            TextArea.width('100%');
            TextArea.height(100);
            TextArea.fontSize(15);
            TextArea.backgroundColor(Theme.bgInput);
            TextArea.borderRadius(8);
            TextArea.padding({ left: 12, right: 12 });
            TextArea.onChange((val: string) => { this.descriptionInput = val; });
        }, TextArea);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(248:11)", "entry");
            Blank.height(10);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(250:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(251:13)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('上传文件');
            Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(252:15)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('（必填）');
            Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(256:15)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.danger);
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(260:15)", "entry");
        }, Blank);
        Blank.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('支持 PDF / Word / PPT / Excel / 图片 / 压缩包');
            Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(265:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.fileUrl.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(272:15)", "entry");
                        Row.width('100%');
                        Row.height(48);
                        Row.padding({ left: 12, right: 12 });
                        Row.backgroundColor(Theme.bgInput);
                        Row.borderRadius(8);
                        Row.alignItems(VerticalAlign.Center);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('📄');
                        Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(273:17)", "entry");
                        Text.fontSize(20);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.fileTypeName.length > 0 ? this.fileTypeName.toUpperCase() : '文件');
                        Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(275:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textPrimary);
                        Text.margin({ left: 8 });
                        Text.layoutWeight(1);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('×');
                        Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(280:17)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textTertiary);
                        Text.onClick(() => { this.removeFile(); });
                    }, Text);
                    Text.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(292:15)", "entry");
                        Column.width('100%');
                        Column.height(80);
                        Column.backgroundColor(Theme.bgInput);
                        Column.borderRadius(8);
                        Column.border({ width: 1, color: Theme.border, style: BorderStyle.Dashed });
                        Column.justifyContent(FlexAlign.Center);
                        Column.onClick(() => { this.pickFile(); });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.isUploading) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    LoadingProgress.create();
                                    LoadingProgress.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(294:19)", "entry");
                                    LoadingProgress.color(Theme.primary);
                                    LoadingProgress.width(24);
                                    LoadingProgress.height(24);
                                }, LoadingProgress);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('上传中...');
                                    Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(295:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.margin({ top: 4 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('+');
                                    Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(297:19)", "entry");
                                    Text.fontSize(28);
                                    Text.fontColor(Theme.textDisabled);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('选择文件');
                                    Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(298:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textDisabled);
                                    Text.margin({ top: 2 });
                                }, Text);
                                Text.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(314:11)", "entry");
            Blank.height(10);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(316:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(317:13)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('封面图（可选）');
            Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(318:15)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(322:15)", "entry");
        }, Blank);
        Blank.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.coverUrl.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Stack.create();
                        Stack.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(328:15)", "entry");
                    }, Stack);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(ApiService.baseUrl + this.coverUrl);
                        Image.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(329:17)", "entry");
                        Image.width(76);
                        Image.height(76);
                        Image.borderRadius(8);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('×');
                        Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(331:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#FFFFFF');
                        Text.backgroundColor('#00000080');
                        Text.width(18);
                        Text.height(18);
                        Text.borderRadius(9);
                        Text.textAlign(TextAlign.Center);
                        Text.position({ top: -3, right: -3 });
                        Text.onClick(() => { this.removeCover(); });
                    }, Text);
                    Text.pop();
                    Stack.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(340:15)", "entry");
                        Column.width(76);
                        Column.height(76);
                        Column.backgroundColor(Theme.bgInput);
                        Column.borderRadius(8);
                        Column.border({ width: 1, color: Theme.border, style: BorderStyle.Dashed });
                        Column.justifyContent(FlexAlign.Center);
                        Column.onClick(() => { this.pickCoverImage(); });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.isUploadingCover) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    LoadingProgress.create();
                                    LoadingProgress.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(342:19)", "entry");
                                    LoadingProgress.color(Theme.primary);
                                    LoadingProgress.width(24);
                                    LoadingProgress.height(24);
                                }, LoadingProgress);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('+');
                                    Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(344:19)", "entry");
                                    Text.fontSize(28);
                                    Text.fontColor(Theme.textDisabled);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('上传封面');
                                    Text.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(345:19)", "entry");
                                    Text.fontSize(10);
                                    Text.fontColor(Theme.textDisabled);
                                    Text.margin({ top: 2 });
                                }, Text);
                                Text.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(361:11)", "entry");
            Blank.height(24);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('上传资料');
            Button.debugLine("entry/src/main/ets/pages/StudySharePublishPage.ets(363:11)", "entry");
            Button.type(ButtonType.Capsule);
            Button.width('92%');
            Button.height(48);
            Button.backgroundColor(this.canSubmit() ? Theme.primary : Theme.textDisabled);
            Button.fontColor('#FFFFFF');
            Button.enabled(this.canSubmit());
            Button.onClick(() => { this.submitPublish(); });
        }, Button);
        Button.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "StudySharePublishPage";
    }
}
registerNamedRoute(() => new StudySharePublishPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/StudySharePublishPage", pageFullPath: "entry/src/main/ets/pages/StudySharePublishPage", integratedHsp: "false", moduleType: "followWithHap" });
