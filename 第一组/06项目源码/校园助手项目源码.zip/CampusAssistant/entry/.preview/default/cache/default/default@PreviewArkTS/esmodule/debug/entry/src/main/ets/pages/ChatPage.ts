if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ChatPage_Params {
    conversationId?: number;
    otherUserId?: number;
    productId?: number;
    otherUserName?: string;
    messages?: ChatMessage[];
    inputText?: string;
    isLoggedIn?: boolean;
    isLoading?: boolean;
    isSending?: boolean;
    isOtherUserOnline?: boolean;
    errorMsg?: string;
    showImagePreview?: boolean;
    previewImageUrl?: string;
    wsCallback?: MessageCallback | null;
    messageTimer?: number;
    onlineTimer?: number;
    messageScroller?: Scroller;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { ChatMessage } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { WebSocketService } from "@normalized:N&&&entry/src/main/ets/service/WebSocketService&";
import type { WsMessage, MessageCallback } from "@normalized:N&&&entry/src/main/ets/service/WebSocketService&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
class ProductCardMessage {
    productId: number = 0;
    title: string = '';
    price: number = 0;
    image: string = '';
    status: number = 1;
}
class ChatPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__conversationId = new ObservedPropertySimplePU(0, this, "conversationId");
        this.__otherUserId = new ObservedPropertySimplePU(0, this, "otherUserId");
        this.__productId = new ObservedPropertySimplePU(0, this, "productId");
        this.__otherUserName = new ObservedPropertySimplePU('聊天', this, "otherUserName");
        this.__messages = new ObservedPropertyObjectPU([], this, "messages");
        this.__inputText = new ObservedPropertySimplePU('', this, "inputText");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isSending = new ObservedPropertySimplePU(false, this, "isSending");
        this.__isOtherUserOnline = new ObservedPropertySimplePU(false, this, "isOtherUserOnline");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.__showImagePreview = new ObservedPropertySimplePU(false, this, "showImagePreview");
        this.__previewImageUrl = new ObservedPropertySimplePU('', this, "previewImageUrl");
        this.wsCallback = null;
        this.messageTimer = -1;
        this.onlineTimer = -1;
        this.messageScroller = new Scroller();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ChatPage_Params) {
        if (params.conversationId !== undefined) {
            this.conversationId = params.conversationId;
        }
        if (params.otherUserId !== undefined) {
            this.otherUserId = params.otherUserId;
        }
        if (params.productId !== undefined) {
            this.productId = params.productId;
        }
        if (params.otherUserName !== undefined) {
            this.otherUserName = params.otherUserName;
        }
        if (params.messages !== undefined) {
            this.messages = params.messages;
        }
        if (params.inputText !== undefined) {
            this.inputText = params.inputText;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isSending !== undefined) {
            this.isSending = params.isSending;
        }
        if (params.isOtherUserOnline !== undefined) {
            this.isOtherUserOnline = params.isOtherUserOnline;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
        if (params.showImagePreview !== undefined) {
            this.showImagePreview = params.showImagePreview;
        }
        if (params.previewImageUrl !== undefined) {
            this.previewImageUrl = params.previewImageUrl;
        }
        if (params.wsCallback !== undefined) {
            this.wsCallback = params.wsCallback;
        }
        if (params.messageTimer !== undefined) {
            this.messageTimer = params.messageTimer;
        }
        if (params.onlineTimer !== undefined) {
            this.onlineTimer = params.onlineTimer;
        }
        if (params.messageScroller !== undefined) {
            this.messageScroller = params.messageScroller;
        }
    }
    updateStateVars(params: ChatPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__conversationId.purgeDependencyOnElmtId(rmElmtId);
        this.__otherUserId.purgeDependencyOnElmtId(rmElmtId);
        this.__productId.purgeDependencyOnElmtId(rmElmtId);
        this.__otherUserName.purgeDependencyOnElmtId(rmElmtId);
        this.__messages.purgeDependencyOnElmtId(rmElmtId);
        this.__inputText.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isSending.purgeDependencyOnElmtId(rmElmtId);
        this.__isOtherUserOnline.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
        this.__showImagePreview.purgeDependencyOnElmtId(rmElmtId);
        this.__previewImageUrl.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__conversationId.aboutToBeDeleted();
        this.__otherUserId.aboutToBeDeleted();
        this.__productId.aboutToBeDeleted();
        this.__otherUserName.aboutToBeDeleted();
        this.__messages.aboutToBeDeleted();
        this.__inputText.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isSending.aboutToBeDeleted();
        this.__isOtherUserOnline.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        this.__showImagePreview.aboutToBeDeleted();
        this.__previewImageUrl.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __conversationId: ObservedPropertySimplePU<number>;
    get conversationId() {
        return this.__conversationId.get();
    }
    set conversationId(newValue: number) {
        this.__conversationId.set(newValue);
    }
    private __otherUserId: ObservedPropertySimplePU<number>;
    get otherUserId() {
        return this.__otherUserId.get();
    }
    set otherUserId(newValue: number) {
        this.__otherUserId.set(newValue);
    }
    private __productId: ObservedPropertySimplePU<number>;
    get productId() {
        return this.__productId.get();
    }
    set productId(newValue: number) {
        this.__productId.set(newValue);
    }
    private __otherUserName: ObservedPropertySimplePU<string>;
    get otherUserName() {
        return this.__otherUserName.get();
    }
    set otherUserName(newValue: string) {
        this.__otherUserName.set(newValue);
    }
    private __messages: ObservedPropertyObjectPU<ChatMessage[]>;
    get messages() {
        return this.__messages.get();
    }
    set messages(newValue: ChatMessage[]) {
        this.__messages.set(newValue);
    }
    private __inputText: ObservedPropertySimplePU<string>;
    get inputText() {
        return this.__inputText.get();
    }
    set inputText(newValue: string) {
        this.__inputText.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isSending: ObservedPropertySimplePU<boolean>;
    get isSending() {
        return this.__isSending.get();
    }
    set isSending(newValue: boolean) {
        this.__isSending.set(newValue);
    }
    private __isOtherUserOnline: ObservedPropertySimplePU<boolean>;
    get isOtherUserOnline() {
        return this.__isOtherUserOnline.get();
    }
    set isOtherUserOnline(newValue: boolean) {
        this.__isOtherUserOnline.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    private __showImagePreview: ObservedPropertySimplePU<boolean>;
    get showImagePreview() {
        return this.__showImagePreview.get();
    }
    set showImagePreview(newValue: boolean) {
        this.__showImagePreview.set(newValue);
    }
    private __previewImageUrl: ObservedPropertySimplePU<string>;
    get previewImageUrl() {
        return this.__previewImageUrl.get();
    }
    set previewImageUrl(newValue: string) {
        this.__previewImageUrl.set(newValue);
    }
    private wsCallback: MessageCallback | null;
    private messageTimer: number;
    private onlineTimer: number;
    private messageScroller: Scroller;
    aboutToAppear(): void {
        const store: AppStore = AppStore.getInstance();
        this.isLoggedIn = store.isLoggedIn;
        if (!this.isLoggedIn) {
            this.isLoading = false;
            return;
        }
        this.resolveParams();
        this.registerWsCallback();
        WebSocketService.getInstance().connect();
        this.loadOnlineStatus();
        this.prepareConversation();
        this.startPolling();
    }
    aboutToDisappear(): void {
        if (this.wsCallback !== null) {
            WebSocketService.getInstance().removeMessageCallback(this.wsCallback);
            this.wsCallback = null;
        }
        this.stopPolling();
    }
    private startPolling(): void {
        this.stopPolling();
        this.messageTimer = setInterval(() => {
            if (this.isLoggedIn && this.conversationId > 0 && WebSocketService.getInstance().connectionState !== 'connected') {
                this.loadMessages(false);
            }
        }, 2000) as number;
        this.onlineTimer = setInterval(() => {
            if (this.isLoggedIn && this.otherUserId > 0 && WebSocketService.getInstance().connectionState !== 'connected') {
                this.loadOnlineStatus();
            }
        }, 3000) as number;
    }
    private stopPolling(): void {
        if (this.messageTimer !== -1) {
            clearInterval(this.messageTimer);
            this.messageTimer = -1;
        }
        if (this.onlineTimer !== -1) {
            clearInterval(this.onlineTimer);
            this.onlineTimer = -1;
        }
    }
    private registerWsCallback(): void {
        if (this.wsCallback !== null) {
            return;
        }
        this.wsCallback = (msg: WsMessage) => {
            this.handleWsMessage(msg);
        };
        WebSocketService.getInstance().onMessage(this.wsCallback);
    }
    private handleWsMessage(msg: WsMessage): void {
        if (msg.type === 'user_status') {
            const data: Record<string, Object> = msg.data as Record<string, Object>;
            const uid: number = (data['userId'] as number) ?? 0;
            if (uid === this.otherUserId) {
                this.isOtherUserOnline = (data['online'] as boolean) ?? false;
            }
            return;
        }
        if (msg.type === 'online_users_loaded' || msg.type === 'connection_state') {
            const online: boolean = WebSocketService.getInstance().isUserOnline(this.otherUserId);
            if (online) {
                this.isOtherUserOnline = true;
            }
            return;
        }
        if (msg.type === 'message') {
            const item: ChatMessage = this.parseWsChatMessage(msg.data);
            if (item.conversationId === this.conversationId && item.conversationId > 0) {
                this.appendOrUpdateMessage(item);
                WebSocketService.getInstance().sendMarkRead(this.conversationId);
            }
        }
    }
    private parseWsChatMessage(data: Object): ChatMessage {
        const obj: Record<string, Object> = data as Record<string, Object>;
        const item: ChatMessage = new ChatMessage();
        item.id = (obj['id'] as number) ?? 0;
        item.conversationId = (obj['conversationId'] as number) ?? 0;
        item.senderId = (obj['senderId'] as number) ?? 0;
        item.content = (obj['content'] as string) ?? '';
        item.msgType = (obj['msgType'] as string) ?? 'text';
        item.createTime = (obj['createTime'] as string) ?? '';
        item.isMine = item.senderId === AppStore.getInstance().userInfo.id;
        return item;
    }
    private appendOrUpdateMessage(item: ChatMessage): void {
        const next: ChatMessage[] = [];
        let exists: boolean = false;
        for (let i = 0; i < this.messages.length; i++) {
            if (this.messages[i].id === item.id && item.id > 0) {
                next.push(item);
                exists = true;
            }
            else {
                next.push(this.messages[i]);
            }
        }
        if (!exists) {
            next.push(item);
        }
        this.messages = next;
        this.errorMsg = '';
        this.isLoading = false;
        this.scrollToBottom();
    }
    private scrollToBottom(): void {
        if (this.messages.length === 0) {
            return;
        }
        setTimeout(() => {
            try {
                this.messageScroller.scrollToIndex(this.messages.length - 1, true, ScrollAlign.END);
            }
            catch (e) {
            }
        }, 50);
    }
    private getParamText(params: Record<string, Object>, key: string): string {
        const value: Object = params[key];
        if (value === null || value === undefined) {
            return '';
        }
        if (typeof value === 'number') {
            return (value as number).toString();
        }
        return value as string;
    }
    private parseNumberParam(params: Record<string, Object>, key: string): number {
        const text: string = this.getParamText(params, key);
        if (text.length === 0) {
            return 0;
        }
        const value: number = Number(text);
        if (isNaN(value)) {
            return 0;
        }
        return value;
    }
    private resolveParams(): void {
        let paramsObj: Object | undefined = undefined;
        try {
            paramsObj = router.getParams();
        }
        catch (e) {
            paramsObj = undefined;
        }
        if (paramsObj !== undefined && paramsObj !== null) {
            const params: Record<string, Object> = paramsObj as Record<string, Object>;
            this.conversationId = this.parseNumberParam(params, 'conversationId');
            this.otherUserId = this.parseNumberParam(params, 'otherUserId');
            this.productId = this.parseNumberParam(params, 'productId');
            const name: string = this.getParamText(params, 'otherUserName');
            if (name.length > 0) {
                this.otherUserName = name;
            }
        }
    }
    private async loadOnlineStatus(): Promise<void> {
        if (this.otherUserId <= 0) {
            this.isOtherUserOnline = false;
            return;
        }
        if (WebSocketService.getInstance().isUserOnline(this.otherUserId)) {
            this.isOtherUserOnline = true;
            return;
        }
        const result = await ApiService.getOnlineUsers();
        if (result.code === 200 && result.data !== undefined) {
            const ids: number[] = result.data as number[];
            let online: boolean = false;
            for (let i = 0; i < ids.length; i++) {
                if (ids[i] === this.otherUserId) {
                    online = true;
                    break;
                }
            }
            this.isOtherUserOnline = online;
        }
        else {
            this.isOtherUserOnline = false;
        }
    }
    private async prepareConversation(): Promise<void> {
        this.isLoading = true;
        this.errorMsg = '';
        if (this.conversationId > 0) {
            await this.loadMessages();
            return;
        }
        if (this.otherUserId <= 0 || this.productId <= 0) {
            this.errorMsg = '缺少会话参数';
            this.isLoading = false;
            return;
        }
        const result = await ApiService.createConversation(this.otherUserId, this.productId);
        if (result.code === 200 && result.data !== undefined) {
            const data: Object = result.data;
            if (typeof data === 'number') {
                this.conversationId = data as number;
            }
            else {
                const record: Record<string, Object> = data as Record<string, Object>;
                const conversationValue: Object = record['conversationId'];
                if (conversationValue !== null && conversationValue !== undefined) {
                    if (typeof conversationValue === 'number') {
                        this.conversationId = conversationValue as number;
                    }
                    else {
                        const parsedId: number = Number(conversationValue as string);
                        this.conversationId = isNaN(parsedId) ? 0 : parsedId;
                    }
                }
                else {
                    this.conversationId = (record['id'] as number) ?? 0;
                }
            }
            if (this.conversationId > 0) {
                await this.loadMessages();
            }
            else {
                this.errorMsg = '会话创建失败';
                this.isLoading = false;
            }
        }
        else {
            this.errorMsg = result.msg || '会话创建失败';
            this.isLoading = false;
        }
    }
    private async loadMessages(showError: boolean = true): Promise<void> {
        if (this.conversationId <= 0) {
            if (showError) {
                this.errorMsg = '会话不存在';
            }
            this.isLoading = false;
            return;
        }
        const result = await ApiService.getMessages(this.conversationId);
        if (result.code === 200 && result.data !== undefined) {
            const list: ChatMessage[] = ApiService.parseMessageList(result.data);
            const currentUserId: number = AppStore.getInstance().userInfo.id;
            for (let i = 0; i < list.length; i++) {
                list[i].isMine = list[i].senderId === currentUserId;
            }
            this.messages = list;
            this.errorMsg = '';
            WebSocketService.getInstance().sendMarkRead(this.conversationId);
            this.scrollToBottom();
        }
        else if (showError) {
            this.errorMsg = result.msg || '消息加载失败';
        }
        this.isLoading = false;
    }
    private async sendText(): Promise<void> {
        const content: string = this.inputText.trim();
        if (content.length === 0 || this.isSending) {
            return;
        }
        if (this.conversationId <= 0) {
            AlertDialog.show({ message: '会话还没有创建成功', confirm: { value: '好的', action: () => { } } });
            return;
        }
        this.isSending = true;
        const sent: boolean = await this.sendChatContent(content, 'text');
        if (sent) {
            this.inputText = '';
        }
        this.isSending = false;
    }
    private async sendChatContent(content: string, msgType: string): Promise<boolean> {
        if (this.conversationId <= 0) {
            AlertDialog.show({ message: '会话还没有创建成功', confirm: { value: '好的', action: () => { } } });
            return false;
        }
        if (WebSocketService.getInstance().connectionState === 'connected') {
            WebSocketService.getInstance().sendMessage(this.conversationId, content, msgType);
            return true;
        }
        const result = await ApiService.sendMessage(this.conversationId, content, msgType);
        if (result.code === 200) {
            await this.loadMessages();
            return true;
        }
        AlertDialog.show({ title: '发送失败', message: result.msg || '请稍后重试', confirm: { value: '好的', action: () => { } } });
        return false;
    }
    private async sendImage(): Promise<void> {
        if (this.isSending) {
            return;
        }
        if (this.conversationId <= 0) {
            AlertDialog.show({ message: '会话还没有创建成功', confirm: { value: '好的', action: () => { } } });
            return;
        }
        try {
            const uris: string[] = await ApiService.pickImages();
            if (uris.length === 0) {
                return;
            }
            this.isSending = true;
            promptAction.showToast({ message: '正在发送图片', duration: 1200 });
            const url: string = await ApiService.uploadImage(uris[0]);
            if (url.startsWith('ERROR:')) {
                AlertDialog.show({ title: '发送失败', message: '图片上传失败，请重试', confirm: { value: '好的', action: () => { } } });
            }
            else {
                await this.sendChatContent(url, 'image');
            }
        }
        catch (err) {
            AlertDialog.show({ message: '相册无法打开，请用真机或模拟器运行', confirm: { value: '知道了', action: () => { } } });
        }
        finally {
            this.isSending = false;
        }
    }
    private formatTime(text: string): string {
        if (text.length === 0) {
            return '';
        }
        const value: string = text.replace('T', ' ');
        if (value.length >= 16) {
            return value.substring(5, 16);
        }
        return value;
    }
    private normalizeImageUrl(path: string): string {
        if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('file://')) {
            return path;
        }
        if (path.startsWith('/')) {
            return `${ApiService.baseUrl}${path}`;
        }
        return path;
    }
    private openImagePreview(url: string): void {
        this.previewImageUrl = this.normalizeImageUrl(url);
        this.showImagePreview = true;
    }
    private parseProductCard(content: string): ProductCardMessage {
        const card: ProductCardMessage = new ProductCardMessage();
        try {
            const obj: Record<string, Object> = JSON.parse(content) as Record<string, Object>;
            const idObj: Object = obj['productId'];
            if (typeof idObj === 'number') {
                card.productId = idObj as number;
            }
            else if (idObj !== null && idObj !== undefined) {
                const id: number = Number(idObj as string);
                card.productId = isNaN(id) ? 0 : id;
            }
            card.title = (obj['title'] as string) ?? '';
            const priceObj: Object = obj['price'];
            if (typeof priceObj === 'number') {
                card.price = priceObj as number;
            }
            else if (priceObj !== null && priceObj !== undefined) {
                const price: number = Number(priceObj as string);
                card.price = isNaN(price) ? 0 : price;
            }
            card.image = (obj['image'] as string) ?? '';
            card.status = (obj['status'] as number) ?? 1;
        }
        catch (e) {
            card.title = content;
        }
        return card;
    }
    private productCardId(content: string): number {
        return this.parseProductCard(content).productId;
    }
    private productCardTitle(content: string): string {
        const title: string = this.parseProductCard(content).title;
        return title.length > 0 ? title : '商品卡片';
    }
    private productCardPrice(content: string): string {
        return `$${this.parseProductCard(content).price.toFixed(2)}`;
    }
    private productCardImage(content: string): string {
        return this.parseProductCard(content).image;
    }
    private displayContent(item: ChatMessage): string {
        if (item.msgType === 'product') {
            const card: ProductCardMessage = this.parseProductCard(item.content);
            return card.title.length > 0 ? `商品卡片：${card.title}` : '商品卡片';
        }
        if (item.msgType === 'image') {
            return '[图片]';
        }
        return item.content;
    }
    MessageContent(item: ChatMessage, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.msgType === 'image') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.normalizeImageUrl(item.content));
                        Image.debugLine("entry/src/main/ets/pages/ChatPage.ets(449:7)", "entry");
                        Image.width(168);
                        Image.height(168);
                        Image.borderRadius(12);
                        Image.objectFit(ImageFit.Cover);
                        Image.backgroundColor('#FFFFFF');
                        Image.onClick(() => { this.openImagePreview(item.content); });
                    }, Image);
                });
            }
            else if (item.msgType === 'product') {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.ProductCard.bind(this)(item);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(item.content);
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(459:7)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(item.isMine ? '#FFFFFF' : Theme.textPrimary);
                        Text.padding({ left: 12, right: 12, top: 9, bottom: 9 });
                        Text.backgroundColor(item.isMine ? Theme.primary : '#FFFFFF');
                        Text.borderRadius(14);
                        Text.maxLines(8);
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
    }
    ProductCard(item: ChatMessage, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(471:5)", "entry");
            Column.width(238);
            Column.padding(10);
            Column.backgroundColor('#FFFFFF');
            Column.borderRadius(12);
            Column.border({ width: 1, color: Theme.border });
            Column.onClick(() => {
                const id: number = this.productCardId(item.content);
                if (id > 0) {
                    router.pushUrl({
                        url: 'pages/ProductDetailPage',
                        params: { 'productId': id.toString() } as Record<string, string>
                    });
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ChatPage.ets(472:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.productCardImage(item.content).length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.normalizeImageUrl(this.productCardImage(item.content)));
                        Image.debugLine("entry/src/main/ets/pages/ChatPage.ets(474:11)", "entry");
                        Image.width(64);
                        Image.height(64);
                        Image.borderRadius(8);
                        Image.objectFit(ImageFit.Cover);
                        Image.backgroundColor(Theme.bgInput);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(481:11)", "entry");
                        Column.width(64);
                        Column.height(64);
                        Column.borderRadius(8);
                        Column.justifyContent(FlexAlign.Center);
                        Column.backgroundColor(Theme.primaryLight);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('商');
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(482:13)", "entry");
                        Text.fontSize(22);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Theme.primary);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(490:9)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 10 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.productCardTitle(item.content));
            Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(491:11)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.productCardPrice(item.content));
            Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(497:11)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.primary);
            Text.margin({ top: 6 });
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('查看商品详情');
            Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(508:7)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 8 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    ImagePreviewOverlay(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(531:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#000000');
            Column.position({ x: 0, y: 0 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ChatPage.ets(532:7)", "entry");
            Row.width('100%');
            Row.height(56);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('✕');
            Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(533:9)", "entry");
            Text.fontSize(22);
            Text.fontColor('#FFFFFF');
            Text.margin({ left: 16 });
            Text.onClick(() => { this.showImagePreview = false; });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ChatPage.ets(538:9)", "entry");
        }, Blank);
        Blank.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.previewImageUrl);
            Image.debugLine("entry/src/main/ets/pages/ChatPage.ets(543:7)", "entry");
            Image.width('100%');
            Image.layoutWeight(1);
            Image.objectFit(ImageFit.Contain);
        }, Image);
        Column.pop();
    }
    MessageBubble(item: ChatMessage, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ChatPage.ets(556:5)", "entry");
            Row.width('100%');
            Row.padding({ left: 14, right: 14, top: 7, bottom: 7 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.isMine) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ChatPage.ets(558:9)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(559:9)", "entry");
                        Column.alignItems(HorizontalAlign.End);
                        Column.constraintSize({ maxWidth: '76%' });
                    }, Column);
                    this.MessageContent.bind(this)(item);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(item.createTime));
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(561:11)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 4, right: 4 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(565:9)", "entry");
                        Column.alignItems(HorizontalAlign.Start);
                        Column.constraintSize({ maxWidth: '76%' });
                    }, Column);
                    this.MessageContent.bind(this)(item);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(item.createTime));
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(567:11)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 4, left: 4 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ChatPage.ets(570:9)", "entry");
                    }, Blank);
                    Blank.pop();
                });
            }
        }, If);
        If.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/ChatPage.ets(578:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(579:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: this.otherUserName,
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('刷新');
                                Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(581:11)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(Theme.primary);
                                Text.onClick(() => {
                                    this.isLoading = true;
                                    this.loadOnlineStatus();
                                    this.loadMessages();
                                });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ChatPage.ets", line: 580, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: this.otherUserName,
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('刷新');
                                    Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(581:11)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.primary);
                                    Text.onClick(() => {
                                        this.isLoading = true;
                                        this.loadOnlineStatus();
                                        this.loadMessages();
                                    });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: this.otherUserName
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ChatPage.ets(587:9)", "entry");
            Row.width('100%');
            Row.padding({ left: 16, right: 16, top: 4, bottom: 8 });
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('');
            Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(588:11)", "entry");
            Text.width(7);
            Text.height(7);
            Text.borderRadius(4);
            Text.backgroundColor(this.isOtherUserOnline ? Theme.success : Theme.textTertiary);
            Text.margin({ right: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isOtherUserOnline ? '在线' : '离线');
            Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(592:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(this.isOtherUserOnline ? Theme.success : Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.productId > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('  商品 #' + this.productId.toString());
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(595:13)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.textSecondary);
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ChatPage.ets(597:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.otherUserId > 0 && this.otherUserId !== AppStore.getInstance().userInfo.id) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('投诉');
                        Button.debugLine("entry/src/main/ets/pages/ChatPage.ets(599:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.fontSize(12);
                        Button.fontColor('#FFFFFF');
                        Button.backgroundColor(Theme.danger);
                        Button.height(28);
                        Button.padding({ left: 14, right: 14 });
                        Button.onClick(() => {
                            const params: Record<string, Object> = {
                                'defendantId': this.otherUserId,
                                'defendantName': this.otherUserName
                            };
                            if (this.productId > 0) {
                                params['productId'] = this.productId;
                            }
                            router.pushUrl({ url: 'pages/MyComplaintsPage', params: params });
                        });
                    }, Button);
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(623:11)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录');
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(624:13)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('登录后可以联系卖家');
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(625:13)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/ChatPage.ets(626:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.primary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 20 });
                        Button.onClick(() => { router.pushUrl({ url: 'pages/LoginPage' }); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.isLoading) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(632:11)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/ChatPage.ets(633:13)", "entry");
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                        LoadingProgress.color(Theme.primary);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在加载消息');
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(634:13)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(637:11)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(638:13)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('重试');
                        Button.debugLine("entry/src/main/ets/pages/ChatPage.ets(639:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.primary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 18 });
                        Button.onClick(() => { this.prepareConversation(); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ scroller: this.messageScroller });
                        List.debugLine("entry/src/main/ets/pages/ChatPage.ets(645:11)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ top: 8, bottom: 8 });
                        List.backgroundColor(Theme.bgPage);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.messages.length === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                {
                                    const itemCreation = (elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        ListItem.create(deepRenderFunction, true);
                                        if (!isInitialRender) {
                                            ListItem.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    };
                                    const itemCreation2 = (elmtId, isInitialRender) => {
                                        ListItem.create(deepRenderFunction, true);
                                        ListItem.debugLine("entry/src/main/ets/pages/ChatPage.ets(647:15)", "entry");
                                    };
                                    const deepRenderFunction = (elmtId, isInitialRender) => {
                                        itemCreation(elmtId, isInitialRender);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Column.create();
                                            Column.debugLine("entry/src/main/ets/pages/ChatPage.ets(648:17)", "entry");
                                            Column.width('100%');
                                            Column.padding({ top: 40, left: 16, right: 16 });
                                            Column.alignItems(HorizontalAlign.Center);
                                        }, Column);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('还没有消息');
                                            Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(649:19)", "entry");
                                            Text.fontSize(16);
                                            Text.fontColor(Theme.textSecondary);
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('发送第一条消息开始沟通');
                                            Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(650:19)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.margin({ top: 6 });
                                        }, Text);
                                        Text.pop();
                                        Column.pop();
                                        ListItem.pop();
                                    };
                                    this.observeComponentCreation2(itemCreation2, ListItem);
                                    ListItem.pop();
                                }
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        {
                                            const itemCreation = (elmtId, isInitialRender) => {
                                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                ListItem.create(deepRenderFunction, true);
                                                if (!isInitialRender) {
                                                    ListItem.pop();
                                                }
                                                ViewStackProcessor.StopGetAccessRecording();
                                            };
                                            const itemCreation2 = (elmtId, isInitialRender) => {
                                                ListItem.create(deepRenderFunction, true);
                                                ListItem.debugLine("entry/src/main/ets/pages/ChatPage.ets(658:17)", "entry");
                                            };
                                            const deepRenderFunction = (elmtId, isInitialRender) => {
                                                itemCreation(elmtId, isInitialRender);
                                                this.MessageBubble.bind(this)(item);
                                                ListItem.pop();
                                            };
                                            this.observeComponentCreation2(itemCreation2, ListItem);
                                            ListItem.pop();
                                        }
                                    };
                                    this.forEachUpdateFunction(elmtId, this.messages, forEachItemGenFunction, (item: ChatMessage) => item.id.toString(), false, false);
                                }, ForEach);
                                ForEach.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    List.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ChatPage.ets(669:11)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 12, right: 12, top: 10, bottom: 10 });
                        Row.backgroundColor('#FFFFFF');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithChild();
                        Button.debugLine("entry/src/main/ets/pages/ChatPage.ets(670:13)", "entry");
                        Button.type(ButtonType.Normal);
                        Button.width(52);
                        Button.height(40);
                        Button.backgroundColor(Theme.primaryLight);
                        Button.borderRadius(20);
                        Button.enabled(!this.isSending);
                        Button.onClick(() => { this.sendImage(); });
                    }, Button);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('图片');
                        Text.debugLine("entry/src/main/ets/pages/ChatPage.ets(671:15)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(this.isSending ? Theme.textTertiary : Theme.primary);
                    }, Text);
                    Text.pop();
                    Button.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '输入消息', text: this.inputText });
                        TextInput.debugLine("entry/src/main/ets/pages/ChatPage.ets(682:13)", "entry");
                        TextInput.height(42);
                        TextInput.fontSize(15);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(21);
                        TextInput.layoutWeight(1);
                        TextInput.margin({ left: 8 });
                        TextInput.onChange((value: string) => { this.inputText = value; });
                        TextInput.onSubmit(() => { this.sendText(); });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel(this.isSending ? '发送中' : '发送');
                        Button.debugLine("entry/src/main/ets/pages/ChatPage.ets(688:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.height(40);
                        Button.fontSize(14);
                        Button.fontColor('#FFFFFF');
                        Button.backgroundColor(this.inputText.trim().length > 0 ? Theme.primary : Theme.textTertiary);
                        Button.margin({ left: 10 });
                        Button.enabled(this.inputText.trim().length > 0 && !this.isSending);
                        Button.onClick(() => { this.sendText(); });
                    }, Button);
                    Button.pop();
                    Row.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showImagePreview) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.ImagePreviewOverlay.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "ChatPage";
    }
}
registerNamedRoute(() => new ChatPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/ChatPage", pageFullPath: "entry/src/main/ets/pages/ChatPage", integratedHsp: "false", moduleType: "followWithHap" });
