if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface EditProfilePage_Params {
    user?: UserInfo;
    avatar?: string;
    userName?: string;
    phone?: string;
    isUploading?: boolean;
    isSavingName?: boolean;
    isSavingPhone?: boolean;
    showAvatarSheet?: boolean;
    errorMsg?: string;
    emojiList?: string[];
}
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { UserInfo } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import router from "@ohos:router";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
import { AvatarView } from "@normalized:N&&&entry/src/main/ets/common/AvatarView&";
class EditProfilePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__user = new ObservedPropertyObjectPU(new UserInfo(), this, "user");
        this.__avatar = new ObservedPropertySimplePU('', this, "avatar");
        this.__userName = new ObservedPropertySimplePU('', this, "userName");
        this.__phone = new ObservedPropertySimplePU('', this, "phone");
        this.__isUploading = new ObservedPropertySimplePU(false, this, "isUploading");
        this.__isSavingName = new ObservedPropertySimplePU(false, this, "isSavingName");
        this.__isSavingPhone = new ObservedPropertySimplePU(false, this, "isSavingPhone");
        this.__showAvatarSheet = new ObservedPropertySimplePU(false, this, "showAvatarSheet");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.emojiList = ['🐱', '🐶', '🦊', '🐼', '🐨', '🦁', '🐯', '🐸', '🦉', '🐲', '🌸', '🌻', '🍀', '🌙', '⭐', '💎', '🦋', '🐝', '🐙', '🐧'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: EditProfilePage_Params) {
        if (params.user !== undefined) {
            this.user = params.user;
        }
        if (params.avatar !== undefined) {
            this.avatar = params.avatar;
        }
        if (params.userName !== undefined) {
            this.userName = params.userName;
        }
        if (params.phone !== undefined) {
            this.phone = params.phone;
        }
        if (params.isUploading !== undefined) {
            this.isUploading = params.isUploading;
        }
        if (params.isSavingName !== undefined) {
            this.isSavingName = params.isSavingName;
        }
        if (params.isSavingPhone !== undefined) {
            this.isSavingPhone = params.isSavingPhone;
        }
        if (params.showAvatarSheet !== undefined) {
            this.showAvatarSheet = params.showAvatarSheet;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
        if (params.emojiList !== undefined) {
            this.emojiList = params.emojiList;
        }
    }
    updateStateVars(params: EditProfilePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__user.purgeDependencyOnElmtId(rmElmtId);
        this.__avatar.purgeDependencyOnElmtId(rmElmtId);
        this.__userName.purgeDependencyOnElmtId(rmElmtId);
        this.__phone.purgeDependencyOnElmtId(rmElmtId);
        this.__isUploading.purgeDependencyOnElmtId(rmElmtId);
        this.__isSavingName.purgeDependencyOnElmtId(rmElmtId);
        this.__isSavingPhone.purgeDependencyOnElmtId(rmElmtId);
        this.__showAvatarSheet.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__user.aboutToBeDeleted();
        this.__avatar.aboutToBeDeleted();
        this.__userName.aboutToBeDeleted();
        this.__phone.aboutToBeDeleted();
        this.__isUploading.aboutToBeDeleted();
        this.__isSavingName.aboutToBeDeleted();
        this.__isSavingPhone.aboutToBeDeleted();
        this.__showAvatarSheet.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __user: ObservedPropertyObjectPU<UserInfo>;
    get user() {
        return this.__user.get();
    }
    set user(newValue: UserInfo) {
        this.__user.set(newValue);
    }
    private __avatar: ObservedPropertySimplePU<string>;
    get avatar() {
        return this.__avatar.get();
    }
    set avatar(newValue: string) {
        this.__avatar.set(newValue);
    }
    private __userName: ObservedPropertySimplePU<string>;
    get userName() {
        return this.__userName.get();
    }
    set userName(newValue: string) {
        this.__userName.set(newValue);
    }
    private __phone: ObservedPropertySimplePU<string>;
    get phone() {
        return this.__phone.get();
    }
    set phone(newValue: string) {
        this.__phone.set(newValue);
    }
    private __isUploading: ObservedPropertySimplePU<boolean>;
    get isUploading() {
        return this.__isUploading.get();
    }
    set isUploading(newValue: boolean) {
        this.__isUploading.set(newValue);
    }
    private __isSavingName: ObservedPropertySimplePU<boolean>;
    get isSavingName() {
        return this.__isSavingName.get();
    }
    set isSavingName(newValue: boolean) {
        this.__isSavingName.set(newValue);
    }
    private __isSavingPhone: ObservedPropertySimplePU<boolean>;
    get isSavingPhone() {
        return this.__isSavingPhone.get();
    }
    set isSavingPhone(newValue: boolean) {
        this.__isSavingPhone.set(newValue);
    }
    private __showAvatarSheet: ObservedPropertySimplePU<boolean>;
    get showAvatarSheet() {
        return this.__showAvatarSheet.get();
    }
    set showAvatarSheet(newValue: boolean) {
        this.__showAvatarSheet.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    private emojiList: string[];
    aboutToAppear(): void {
        this.initUser();
    }
    private initUser(): void {
        const source: UserInfo = AppStore.getInstance().userInfo;
        const copy: UserInfo = new UserInfo();
        copy.id = source.id;
        copy.studentId = source.studentId;
        copy.name = source.name;
        copy.avatar = source.avatar;
        copy.college = source.college;
        copy.major = source.major;
        copy.grade = source.grade;
        copy.classId = source.classId;
        copy.className = source.className;
        copy.hometown = source.hometown;
        copy.phone = source.phone;
        copy.role = source.role;
        copy.creditScore = source.creditScore;
        this.user = copy;
        this.avatar = copy.avatar;
        this.userName = copy.name;
        this.phone = copy.phone;
    }
    private updateLocalUser(nextName: string, nextAvatar: string): void {
        const next: UserInfo = this.user;
        next.name = nextName;
        next.avatar = nextAvatar;
        this.user = next;
        AppStore.getInstance().setUserInfo(next);
    }
    private showAvatarOptions(): void {
        if (this.isUploading) {
            return;
        }
        this.showAvatarSheet = true;
    }
    private async uploadFromAlbum(): Promise<void> {
        if (this.isUploading) {
            return;
        }
        this.errorMsg = '';
        this.showAvatarSheet = false;
        this.isUploading = true;
        try {
            const uris: string[] = await ApiService.pickImages();
            if (uris.length > 0) {
                const url: string = await ApiService.uploadAvatar(uris[0]);
                if (url.length > 0 && !url.startsWith('ERROR:')) {
                    this.avatar = url;
                    this.updateLocalUser(this.userName, this.avatar);
                    this.getUIContext().getPromptAction().showToast({ message: '头像已更新' });
                }
                else {
                    this.errorMsg = '头像上传失败';
                }
            }
        }
        catch (_err) {
            this.errorMsg = '头像上传失败';
        }
        finally {
            this.isUploading = false;
        }
    }
    private async selectEmoji(emoji: string): Promise<void> {
        if (this.isUploading) {
            return;
        }
        this.showAvatarSheet = false;
        this.isUploading = true;
        try {
            const result: ApiResult = await ApiService.updateAvatar(emoji);
            if (result.code === 200) {
                this.avatar = emoji;
                this.updateLocalUser(this.userName, this.avatar);
                this.getUIContext().getPromptAction().showToast({ message: '头像已更新' });
            }
            else {
                this.errorMsg = result.msg.length > 0 ? result.msg : '设置失败';
            }
        }
        catch (_err) {
            this.errorMsg = '头像设置失败';
        }
        finally {
            this.isUploading = false;
        }
    }
    private async saveUserName(): Promise<void> {
        if (this.isSavingName) {
            return;
        }
        const nextName: string = this.userName.trim();
        if (nextName.length === 0) {
            this.errorMsg = '用户名不能为空';
            return;
        }
        this.errorMsg = '';
        this.isSavingName = true;
        const result: ApiResult = await ApiService.updateName(nextName);
        if (result.code === 200) {
            this.userName = nextName;
            this.updateLocalUser(nextName, this.avatar);
            this.getUIContext().getPromptAction().showToast({ message: '用户名已保存' });
        }
        else {
            this.errorMsg = result.msg.length > 0 ? result.msg : '保存失败';
        }
        this.isSavingName = false;
    }
    private async savePhone(): Promise<void> {
        if (this.isSavingPhone) {
            return;
        }
        const nextPhone: string = this.phone.trim();
        if (nextPhone.length === 0) {
            this.errorMsg = '手机号不能为空';
            return;
        }
        this.errorMsg = '';
        this.isSavingPhone = true;
        const result: ApiResult = await ApiService.updatePhone(nextPhone);
        if (result.code === 200) {
            const next: UserInfo = this.user;
            next.phone = nextPhone;
            this.user = next;
            AppStore.getInstance().setUserInfo(next);
            this.getUIContext().getPromptAction().showToast({ message: '联系方式已保存' });
        }
        else {
            this.errorMsg = result.msg.length > 0 ? result.msg : '保存失败';
        }
        this.isSavingPhone = false;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(159:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(160:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '编辑资料' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/EditProfilePage.ets", line: 161, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '编辑资料'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '编辑资料'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(163:9)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(164:11)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 20, bottom: 40 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(165:13)", "entry");
            Column.width('100%');
            Column.padding({ top: 34, bottom: 30 });
            Column.backgroundColor(Theme.bgCard);
            Column.alignItems(HorizontalAlign.Center);
            Column.borderRadius(Theme.heroRadius);
            Column.shadow(ShadowStyle.nmRaisedLg);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(166:15)", "entry");
            Stack.width(96);
            Stack.height(96);
            Stack.onClick(() => {
                this.showAvatarOptions();
            });
        }, Stack);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new AvatarView(this, { avatar: this.avatar, name: this.userName, avatarSize: 96 }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/EditProfilePage.ets", line: 167, col: 17 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            avatar: this.avatar,
                            name: this.userName,
                            avatarSize: 96
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        avatar: this.avatar, name: this.userName
                    });
                }
            }, { name: "AvatarView" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(168:17)", "entry");
            Column.width(26);
            Column.height(26);
            Column.borderRadius(13);
            Column.backgroundColor('rgba(0,0,0,0.5)');
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
            Column.offset({ x: 30, y: 30 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📷');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(169:19)", "entry");
            Text.fontSize(13);
        }, Text);
        Text.pop();
        Column.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isUploading ? '上传中...' : this.userName);
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(185:15)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.isUploading ? Theme.primary : Theme.textPrimary);
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isUploading ? '' : '点击头像可更换');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(191:15)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(203:13)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.margin({ top: 16 });
            Column.shadow(ShadowStyle.nmRaised);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(204:15)", "entry");
            Row.width('100%');
            Row.height(56);
            Row.padding({ left: 16, right: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('用户名');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(205:17)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textPrimary);
            Text.width(76);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入用户名', text: this.userName });
            TextInput.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(209:17)", "entry");
            TextInput.layoutWeight(1);
            TextInput.height(44);
            TextInput.fontSize(15);
            TextInput.fontColor(Theme.textPrimary);
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.textAlign(TextAlign.End);
            TextInput.backgroundColor(Color.Transparent);
            TextInput.padding({ left: 8, right: 0 });
            TextInput.onChange((value: string) => {
                this.userName = value;
                this.errorMsg = '';
            });
        }, TextInput);
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(234:13)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.margin({ top: 12 });
            Column.shadow(ShadowStyle.nmRaised);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(235:15)", "entry");
            Row.width('100%');
            Row.height(56);
            Row.padding({ left: 16, right: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('联系方式');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(236:17)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textPrimary);
            Text.width(76);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入手机号', text: this.phone });
            TextInput.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(240:17)", "entry");
            TextInput.layoutWeight(1);
            TextInput.height(44);
            TextInput.fontSize(15);
            TextInput.fontColor(Theme.textPrimary);
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.textAlign(TextAlign.End);
            TextInput.backgroundColor(Color.Transparent);
            TextInput.padding({ left: 8, right: 0 });
            TextInput.type(InputType.PhoneNumber);
            TextInput.onChange((value: string) => {
                this.phone = value;
                this.errorMsg = '';
            });
        }, TextInput);
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(267:15)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.danger);
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(275:13)", "entry");
            Row.width('100%');
            Row.height(52);
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.padding({ left: 16, right: 16 });
            Row.backgroundColor(Theme.bgCard);
            Row.borderRadius(Theme.cardRadius);
            Row.margin({ top: 16 });
            Row.onClick(() => {
                router.pushUrl({ url: 'pages/PasswordChangePage' });
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('修改密码');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(276:15)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.primary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('›');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(279:15)", "entry");
            Text.fontSize(20);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.isSavingName ? '保存中...' : '保存修改');
            Button.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(294:13)", "entry");
            Button.width('100%');
            Button.height(48);
            Button.fontSize(16);
            Button.fontColor(Color.White);
            Button.backgroundColor(Theme.primary);
            Button.borderRadius(24);
            Button.margin({ top: 30 });
            Button.shadow(ShadowStyle.sm);
            Button.enabled(!this.isSavingName);
            Button.onClick(() => {
                this.saveUserName();
            });
        }, Button);
        Button.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showAvatarSheet) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.AvatarSheet.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    AvatarSheet(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(328:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(329:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('rgba(0,0,0,0.28)');
            Column.onClick(() => {
                this.showAvatarSheet = false;
            });
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(337:7)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius({ topLeft: 28, topRight: 28 });
            Column.shadow(ShadowStyle.nmRaisedLg);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('修改头像');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(338:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.padding({ left: 24, right: 24, top: 22, bottom: 14 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(345:9)", "entry");
            Row.width('100%');
            Row.height(56);
            Row.padding({ left: 24, right: 24 });
            Row.onClick(() => {
                this.uploadFromAlbum();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('从相册选择');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(346:11)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(349:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('›');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(350:11)", "entry");
            Text.fontSize(22);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('选择表情做头像');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(361:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
            Text.width('100%');
            Text.padding({ left: 24, right: 24, top: 12, bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ wrap: FlexWrap.Wrap });
            Flex.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(367:9)", "entry");
            Flex.width('100%');
            Flex.padding({ left: 24, right: 24, bottom: 12 });
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const emoji = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(emoji);
                    Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(369:13)", "entry");
                    Text.fontSize(26);
                    Text.width(44);
                    Text.height(44);
                    Text.textAlign(TextAlign.Center);
                    Text.backgroundColor(Theme.bgInput);
                    Text.borderRadius(10);
                    Text.margin({ right: 10, bottom: 10 });
                    Text.onClick(() => {
                        this.selectEmoji(emoji);
                    });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.emojiList, forEachItemGenFunction, (emoji: string) => emoji, false, false);
        }, ForEach);
        ForEach.pop();
        Flex.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(385:9)", "entry");
            Row.width('100%');
            Row.height(8);
            Row.backgroundColor(Theme.bgPage);
        }, Row);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('取消');
            Text.debugLine("entry/src/main/ets/pages/EditProfilePage.ets(390:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.textSecondary);
            Text.width('100%');
            Text.height(56);
            Text.textAlign(TextAlign.Center);
            Text.onClick(() => {
                this.showAvatarSheet = false;
            });
        }, Text);
        Text.pop();
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "EditProfilePage";
    }
}
registerNamedRoute(() => new EditProfilePage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/EditProfilePage", pageFullPath: "entry/src/main/ets/pages/EditProfilePage", integratedHsp: "false", moduleType: "followWithHap" });
