if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ClubActivityDetailPage_Params {
    activityId?: number;
    activity?: ClubActivityItem;
    isLoading?: boolean;
    isSubmitting?: boolean;
    errorMessage?: string;
}
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { ClubActivityItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
class ClubActivityDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__activityId = new ObservedPropertySimplePU(0, this, "activityId");
        this.__activity = new ObservedPropertyObjectPU(new ClubActivityItem(), this, "activity");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.__errorMessage = new ObservedPropertySimplePU('', this, "errorMessage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ClubActivityDetailPage_Params) {
        if (params.activityId !== undefined) {
            this.activityId = params.activityId;
        }
        if (params.activity !== undefined) {
            this.activity = params.activity;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
        if (params.errorMessage !== undefined) {
            this.errorMessage = params.errorMessage;
        }
    }
    updateStateVars(params: ClubActivityDetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__activityId.purgeDependencyOnElmtId(rmElmtId);
        this.__activity.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMessage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__activityId.aboutToBeDeleted();
        this.__activity.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        this.__errorMessage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __activityId: ObservedPropertySimplePU<number>;
    get activityId() {
        return this.__activityId.get();
    }
    set activityId(newValue: number) {
        this.__activityId.set(newValue);
    }
    private __activity: ObservedPropertyObjectPU<ClubActivityItem>;
    get activity() {
        return this.__activity.get();
    }
    set activity(newValue: ClubActivityItem) {
        this.__activity.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    private __errorMessage: ObservedPropertySimplePU<string>;
    get errorMessage() {
        return this.__errorMessage.get();
    }
    set errorMessage(newValue: string) {
        this.__errorMessage.set(newValue);
    }
    aboutToAppear(): void {
        this.readParams();
        this.loadDetail();
    }
    onPageShow(): void {
        if (this.activityId > 0) {
            this.loadDetail();
        }
    }
    private readParams(): void {
        const paramsObj: Object | undefined = this.getUIContext().getRouter().getParams();
        if (paramsObj !== undefined) {
            const params: Record<string, Object> = paramsObj as Record<string, Object>;
            const idObj: Object = params['id'];
            if (idObj !== null && idObj !== undefined) {
                if (typeof idObj === 'number') {
                    this.activityId = idObj as number;
                }
                else {
                    const idText: string = idObj as string;
                    const parsed: number = parseInt(idText);
                    this.activityId = parsed > 0 ? parsed : 0;
                }
            }
        }
    }
    private async loadDetail(): Promise<void> {
        if (this.activityId <= 0) {
            this.errorMessage = '活动参数错误';
            return;
        }
        this.isLoading = true;
        this.errorMessage = '';
        const result: ApiResult = await ApiService.getClubActivityDetail(this.activityId);
        if (result.code === 200 && result.data !== undefined) {
            const obj: Record<string, Object> = result.data as Record<string, Object>;
            this.activity = this.parseActivity(obj);
        }
        else {
            this.errorMessage = result.msg.length > 0 ? result.msg : '活动详情加载失败';
        }
        this.isLoading = false;
    }
    private parseActivity(obj: Record<string, Object>): ClubActivityItem {
        const item: ClubActivityItem = new ClubActivityItem();
        item.id = (obj['id'] as number) ?? 0;
        item.userId = (obj['userId'] as number) ?? 0;
        item.userName = (obj['userName'] as string) ?? '';
        item.club = (obj['club'] as string) ?? '';
        item.title = (obj['title'] as string) ?? '';
        item.description = (obj['description'] as string) ?? '';
        item.venue = (obj['venue'] as string) ?? '';
        item.activityTime = (obj['activityTime'] as string) ?? '';
        item.maxParticipants = (obj['maxParticipants'] as number) ?? 20;
        item.currentParticipants = (obj['currentParticipants'] as number) ?? 0;
        item.status = (obj['status'] as number) ?? 1;
        item.createTime = (obj['createTime'] as string) ?? '';
        item.coverImage = (obj['coverImage'] as string) ?? '';
        item.registered = (obj['registered'] as boolean) ?? false;
        const namesObj: Object = obj['participantNames'];
        if (namesObj !== null && namesObj !== undefined) {
            item.participantNames = namesObj as string[];
        }
        return item;
    }
    private async registerActivity(): Promise<void> {
        if (this.activityId <= 0 || this.isSubmitting) {
            return;
        }
        this.isSubmitting = true;
        const result: ApiResult = await ApiService.registerClubActivity(this.activityId);
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '报名成功' });
            await this.loadDetail();
        }
        else {
            this.getUIContext().getPromptAction().showToast({ message: result.msg.length > 0 ? result.msg : '报名失败' });
        }
        this.isSubmitting = false;
    }
    private async cancelActivity(): Promise<void> {
        if (this.activityId <= 0 || this.isSubmitting) {
            return;
        }
        this.isSubmitting = true;
        const result: ApiResult = await ApiService.cancelClubActivity(this.activityId);
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '已取消报名' });
            await this.loadDetail();
        }
        else {
            this.getUIContext().getPromptAction().showToast({ message: result.msg.length > 0 ? result.msg : '取消失败' });
        }
        this.isSubmitting = false;
    }
    private confirmDeleteActivity(): void {
        AlertDialog.show({
            message: '确定删除这个活动吗？删除后不可恢复。',
            primaryButton: {
                value: '取消',
                action: () => { }
            },
            secondaryButton: {
                value: '删除',
                action: () => { this.doDeleteActivity(); }
            }
        });
    }
    private async doDeleteActivity(): Promise<void> {
        const result: ApiResult = await ApiService.deleteClubActivity(this.activityId);
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
            this.getUIContext().getRouter().back();
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    private statusText(status: number): string {
        if (status === 1) {
            return '报名中';
        }
        if (status === 2) {
            return '已满';
        }
        return '未知';
    }
    private statusColor(status: number): string {
        if (status === 1) {
            return Theme.success;
        }
        if (status === 2) {
            return Theme.warning;
        }
        return Theme.textSecondary;
    }
    private statusBg(status: number): string {
        if (status === 1) {
            return Theme.successLight;
        }
        if (status === 2) {
            return Theme.warningLight;
        }
        return Theme.divider;
    }
    private formatTime(time: string): string {
        if (time.length >= 16) {
            return time.replace('T', ' ').substring(0, 16);
        }
        return time;
    }
    private pad2(value: number): string {
        return value < 10 ? `0${value}` : `${value}`;
    }
    private formatDate(date: Date): string {
        return `${date.getFullYear()}-${this.pad2(date.getMonth() + 1)}-${this.pad2(date.getDate())} ${this.pad2(date.getHours())}:${this.pad2(date.getMinutes())}`;
    }
    private deadlineTime(time: string): string {
        if (time.length < 16) {
            return '活动开始前1小时';
        }
        const date: Date = new Date(time);
        const timeMs: number = date.getTime();
        if (timeMs <= 0) {
            return '活动开始前1小时';
        }
        date.setHours(date.getHours() - 1);
        return this.formatDate(date);
    }
    private isBeforeDeadline(): boolean {
        if (this.activity.activityTime.length < 16) {
            return true;
        }
        const date: Date = new Date(this.activity.activityTime);
        const timeMs: number = date.getTime();
        if (timeMs <= 0) {
            return true;
        }
        date.setHours(date.getHours() - 1);
        return new Date().getTime() < date.getTime();
    }
    private joinPercent(): number {
        if (this.activity.maxParticipants <= 0) {
            return 0;
        }
        const percent: number = Math.floor(this.activity.currentParticipants * 100 / this.activity.maxParticipants);
        return percent > 100 ? 100 : percent;
    }
    private canRegister(): boolean {
        return this.activity.status === 1 && this.isBeforeDeadline() && !this.activity.registered && this.activity.currentParticipants < this.activity.maxParticipants;
    }
    private canCancel(): boolean {
        return this.activity.registered && this.activity.status === 1 && this.isBeforeDeadline();
    }
    private actionText(): string {
        if (this.activity.registered) {
            return this.canCancel() ? '取消报名' : '已报名';
        }
        if (!this.isBeforeDeadline()) {
            return '报名已截止';
        }
        return this.canRegister() ? '立即报名' : '暂不可报名';
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(237:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '活动详情' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ClubActivityDetailPage.ets", line: 238, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '活动详情'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '活动详情'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading && this.activity.id === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(241:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(242:11)", "entry");
                        LoadingProgress.width(32);
                        LoadingProgress.height(32);
                        LoadingProgress.color(Theme.primary);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在加载详情');
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(246:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.errorMessage.length > 0 && this.activity.id === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(255:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMessage);
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(256:11)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('重新加载');
                        Button.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(259:11)", "entry");
                        Button.height(36);
                        Button.fontSize(14);
                        Button.fontColor(Color.White);
                        Button.backgroundColor(Theme.primary);
                        Button.borderRadius(18);
                        Button.margin({ top: 16 });
                        Button.onClick(() => {
                            this.loadDetail();
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(274:9)", "entry");
                        Scroll.layoutWeight(1);
                        Scroll.scrollBar(BarState.Off);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(275:11)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 16, right: 16, top: 14 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(276:13)", "entry");
                        Column.width('100%');
                        Column.padding(18);
                        Column.backgroundColor(Theme.bgCard);
                        Column.borderRadius(10);
                        Column.shadow(ShadowStyle.sm);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.activity.coverImage.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Image.create(`${ApiService.baseUrl}${this.activity.coverImage}`);
                                    Image.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(278:17)", "entry");
                                    Image.width('100%');
                                    Image.height(180);
                                    Image.objectFit(ImageFit.Cover);
                                    Image.borderRadius(10);
                                    Image.margin({ bottom: 14 });
                                }, Image);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(285:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.activity.club);
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(286:17)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.primary);
                        Text.padding({ left: 9, right: 9, top: 4, bottom: 4 });
                        Text.backgroundColor(Theme.primaryLight);
                        Text.borderRadius(4);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(292:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.statusText(this.activity.status));
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(293:17)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(this.statusColor(this.activity.status));
                        Text.padding({ left: 9, right: 9, top: 4, bottom: 4 });
                        Text.backgroundColor(this.statusBg(this.activity.status));
                        Text.borderRadius(4);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.activity.title);
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(302:15)", "entry");
                        Text.fontSize(24);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Theme.textPrimary);
                        Text.lineHeight(32);
                        Text.width('100%');
                        Text.margin({ top: 14 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.activity.description.length > 0 ? this.activity.description : '发布者暂未填写活动介绍，快来报名吧！');
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(310:15)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.textSecondary);
                        Text.lineHeight(23);
                        Text.width('100%');
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(323:13)", "entry");
                        Column.width('100%');
                        Column.backgroundColor(Theme.bgCard);
                        Column.borderRadius(10);
                        Column.margin({ top: 12 });
                        Column.shadow(ShadowStyle.sm);
                    }, Column);
                    this.InfoRow.bind(this)('类型', this.activity.club);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(325:15)", "entry");
                        Divider.margin({ left: 16 });
                    }, Divider);
                    this.InfoRow.bind(this)('地点', this.activity.venue);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(327:15)", "entry");
                        Divider.margin({ left: 16 });
                    }, Divider);
                    this.InfoRow.bind(this)('活动时间', this.formatTime(this.activity.activityTime));
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(329:15)", "entry");
                        Divider.margin({ left: 16 });
                    }, Divider);
                    this.InfoRow.bind(this)('报名截止', this.deadlineTime(this.activity.activityTime));
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(331:15)", "entry");
                        Divider.margin({ left: 16 });
                    }, Divider);
                    this.InfoRow.bind(this)('发布人', this.activity.userName.length > 0 ? this.activity.userName : '未知');
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(340:13)", "entry");
                        Column.width('100%');
                        Column.padding(18);
                        Column.backgroundColor(Theme.bgCard);
                        Column.borderRadius(10);
                        Column.margin({ top: 12 });
                        Column.shadow(ShadowStyle.md);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(341:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('报名人数');
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(342:17)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(346:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.activity.currentParticipants}/${this.activity.maxParticipants}`);
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(347:17)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.primary);
                        Text.fontWeight(FontWeight.Medium);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Progress.create({ value: this.joinPercent(), total: 100, type: ProgressType.Linear });
                        Progress.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(354:15)", "entry");
                        Progress.width('100%');
                        Progress.height(8);
                        Progress.color(Theme.primary);
                        Progress.backgroundColor(Theme.border);
                        Progress.margin({ top: 12 });
                    }, Progress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.activity.participantNames.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Flex.create({ wrap: FlexWrap.Wrap });
                                    Flex.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(362:17)", "entry");
                                    Flex.width('100%');
                                    Flex.margin({ top: 10 });
                                }, Flex);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = (_item, index: number) => {
                                        const name = _item;
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(name);
                                            Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(364:21)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textSecondary);
                                            Text.padding({ left: 10, right: 10, top: 5, bottom: 5 });
                                            Text.backgroundColor(Theme.bgInput);
                                            Text.borderRadius(14);
                                            Text.margin({ right: 8, top: 8 });
                                        }, Text);
                                        Text.pop();
                                    };
                                    this.forEachUpdateFunction(elmtId, this.activity.participantNames, forEachItemGenFunction, (name: string, index: number) => `${index}-${name}`, true, true);
                                }, ForEach);
                                ForEach.pop();
                                Flex.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('暂无报名同学');
                                    Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(376:17)", "entry");
                                    Text.fontSize(13);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.margin({ top: 12 });
                                    Text.width('100%');
                                }, Text);
                                Text.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(390:13)", "entry");
                        Blank.height(88);
                    }, Blank);
                    Blank.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.activity.id > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(400:9)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 18, right: 18, top: 10, bottom: 24 });
                        Row.backgroundColor(Theme.bgCard);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (AppStore.getInstance().isLoggedIn && AppStore.getInstance().userInfo.id === this.activity.userId) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('删除活动');
                                    Button.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(402:13)", "entry");
                                    Button.height(46);
                                    Button.fontSize(16);
                                    Button.fontColor(Theme.danger);
                                    Button.backgroundColor(Theme.dangerLight);
                                    Button.borderRadius(23);
                                    Button.layoutWeight(1);
                                    Button.onClick(() => { this.confirmDeleteActivity(); });
                                }, Button);
                                Button.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.activity.registered) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel(this.isSubmitting ? '处理中' : this.actionText());
                                    Button.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(412:13)", "entry");
                                    Button.height(46);
                                    Button.fontSize(16);
                                    Button.fontColor(this.canCancel() ? Theme.danger : Theme.textTertiary);
                                    Button.backgroundColor(this.canCancel() ? Theme.dangerLight : Theme.border);
                                    Button.borderRadius(23);
                                    Button.layoutWeight(1);
                                    Button.enabled(this.canCancel() && !this.isSubmitting);
                                    Button.onClick(() => {
                                        this.cancelActivity();
                                    });
                                }, Button);
                                Button.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel(this.isSubmitting ? '处理中' : this.actionText());
                                    Button.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(424:13)", "entry");
                                    Button.height(46);
                                    Button.fontSize(16);
                                    Button.fontColor(Color.White);
                                    Button.backgroundColor(this.canRegister() ? Theme.primary : Theme.textDisabled);
                                    Button.borderRadius(23);
                                    Button.layoutWeight(1);
                                    Button.enabled(this.canRegister() && !this.isSubmitting);
                                    Button.onClick(() => {
                                        this.registerActivity();
                                    });
                                }, Button);
                                Button.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    InfoRow(label: string, value: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(449:5)", "entry");
            Row.width('100%');
            Row.height(50);
            Row.padding({ left: 16, right: 16, top: 10, bottom: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(450:7)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textSecondary);
            Text.width(70);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(value);
            Text.debugLine("entry/src/main/ets/pages/ClubActivityDetailPage.ets(454:7)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.End);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "ClubActivityDetailPage";
    }
}
registerNamedRoute(() => new ClubActivityDetailPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/ClubActivityDetailPage", pageFullPath: "entry/src/main/ets/pages/ClubActivityDetailPage", integratedHsp: "false", moduleType: "followWithHap" });
