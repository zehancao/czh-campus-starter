if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MyHistoryPage_Params {
    historyList?: BrowseItem[];
    isLoading?: boolean;
    isLoggedIn?: boolean;
}
interface HistoryCard_Params {
    item?: BrowseItem;
    onTap?: () => void;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
class BrowseItem {
    id: number = 0;
    productId: number = 0;
    title: string = '';
    price: number = 0;
    images: string[] = [];
    sellerName: string = '';
    browseTime: string = '';
    status: number = 1;
    conditionLevel: number = 1;
    categoryName: string = '';
}
const STATUS_LABELS: string[] = ['', '在售', '已售', '下架'];
const STATUS_COLORS: string[] = [Theme.bgCard, Theme.success, Theme.textSecondary, Theme.danger];
const CONDITION_LABELS: string[] = ['', '全新', '几乎全新', '轻微使用', '明显磨损'];
function parseImageList(raw: Object): string[] {
    if (raw === null || raw === undefined)
        return [];
    const s: string = raw as string;
    if (s.length === 0)
        return [];
    const cleaned: string = s.replace(/[[\]"]/g, '');
    return cleaned.length > 0 ? cleaned.split(',') : [];
}
function fmtTime(t: string): string {
    if (t.length === 0)
        return '';
    try {
        const d: Date = new Date(t);
        const n: Date = new Date();
        const diff: number = n.getTime() - d.getTime();
        const min: number = Math.floor(diff / 60000);
        if (min < 1)
            return '刚刚';
        if (min < 60)
            return `${min}分钟前`;
        const hour: number = Math.floor(diff / 3600000);
        if (hour < 24)
            return `${hour}小时前`;
        const day: number = Math.floor(diff / 86400000);
        if (day < 7)
            return `${day}天前`;
        return `${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    }
    catch (_) {
        return t;
    }
}
class HistoryCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = new BrowseItem();
        this.onTap = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: HistoryCard_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.onTap !== undefined) {
            this.onTap = params.onTap;
        }
    }
    updateStateVars(params: HistoryCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: BrowseItem;
    private onTap?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(58:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(12);
            Row.margin({ bottom: 12 });
            Row.onClick(() => {
                if (this.onTap !== undefined)
                    this.onTap();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.images.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(ApiService.baseUrl + this.item.images[0]);
                        Image.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(60:9)", "entry");
                        Image.width(96);
                        Image.height(96);
                        Image.borderRadius(10);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(63:9)", "entry");
                        Column.width(96);
                        Column.height(96);
                        Column.backgroundColor(Theme.bgPage);
                        Column.borderRadius(10);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('📷');
                        Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(64:11)", "entry");
                        Text.fontSize(34);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(71:7)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.title);
            Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(72:9)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(77:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`¥${this.item.price.toFixed(2)}`);
            Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(78:11)", "entry");
            Text.fontSize(17);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.secondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(80:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.conditionLevel > 0 && this.item.conditionLevel < CONDITION_LABELS.length) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(CONDITION_LABELS[this.item.conditionLevel]);
                        Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(82:13)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.textTertiary);
                        Text.backgroundColor(Theme.bgPage);
                        Text.borderRadius(4);
                        Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.sellerName);
            Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(90:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(95:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 6 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(STATUS_LABELS[Math.max(0, Math.min(this.item.status, 3))]);
            Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(96:11)", "entry");
            Text.fontSize(11);
            Text.fontColor('#FFFFFF');
            Text.backgroundColor(STATUS_COLORS[Math.max(0, Math.min(this.item.status, 3))]);
            Text.borderRadius(4);
            Text.padding({ left: 7, right: 7, top: 2, bottom: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(100:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(fmtTime(this.item.browseTime));
            Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(101:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class MyHistoryPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__historyList = new ObservedPropertyObjectPU([], this, "historyList");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyHistoryPage_Params) {
        if (params.historyList !== undefined) {
            this.historyList = params.historyList;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
    }
    updateStateVars(params: MyHistoryPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__historyList.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__historyList.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __historyList: ObservedPropertyObjectPU<BrowseItem[]>;
    get historyList() {
        return this.__historyList.get();
    }
    set historyList(newValue: BrowseItem[]) {
        this.__historyList.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    aboutToAppear(): void {
        const store: AppStore = AppStore.getInstance();
        this.isLoggedIn = store.isLoggedIn;
        if (this.isLoggedIn) {
            this.loadHistory();
        }
        else {
            this.isLoading = false;
        }
    }
    private async loadHistory(): Promise<void> {
        const result = await ApiService.getMyBrowseHistory();
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            const list: BrowseItem[] = [];
            for (let i = 0; i < arr.length; i++) {
                const obj: Record<string, Object> = arr[i] as Record<string, Object>;
                const item: BrowseItem = new BrowseItem();
                item.id = (obj['id'] as number) ?? 0;
                item.productId = (obj['productId'] as number) ?? 0;
                item.title = (obj['title'] as string) ?? '';
                item.price = (obj['price'] as number) ?? 0;
                item.images = parseImageList(obj['images']);
                item.sellerName = (obj['sellerName'] as string) ?? '';
                item.browseTime = (obj['browseTime'] as string) ?? '';
                item.status = (obj['status'] as number) ?? 1;
                item.conditionLevel = (obj['conditionLevel'] as number) ?? 1;
                item.categoryName = (obj['categoryName'] as string) ?? '';
                list.push(item);
            }
            this.historyList = list;
        }
        this.isLoading = false;
    }
    private async clearHistory(): Promise<void> {
        AlertDialog.show({
            title: '清空浏览记录',
            message: '确定要清空所有浏览记录吗？',
            primaryButton: {
                value: '取消',
                action: () => { }
            },
            confirm: {
                value: '清空',
                fontColor: Theme.danger,
                action: async () => {
                    const result = await ApiService.clearBrowseHistory();
                    if (result.code === 200) {
                        this.historyList = [];
                        promptAction.showToast({ message: '浏览记录已清空', duration: 1500 });
                    }
                    else {
                        promptAction.showToast({ message: result.msg || '操作失败', duration: 1500 });
                    }
                }
            }
        });
    }
    private goToDetail(item: BrowseItem): void {
        router.pushUrl({
            url: 'pages/ProductDetailPage',
            params: { 'productId': item.productId } as Record<string, Object>
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(191:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '浏览历史',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.historyList.length > 0) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('清空');
                                            Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(194:11)", "entry");
                                            Text.fontSize(14);
                                            Text.fontColor(Theme.danger);
                                            Text.onClick(() => { this.clearHistory(); });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyHistoryPage.ets", line: 192, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '浏览历史',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.historyList.length > 0) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('清空');
                                                Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(194:11)", "entry");
                                                Text.fontSize(14);
                                                Text.fontColor(Theme.danger);
                                                Text.onClick(() => { this.clearHistory(); });
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '浏览历史'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(199:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('🔒');
                        Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(200:11)", "entry");
                        Text.fontSize(56);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录查看浏览记录');
                        Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(201:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(203:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 24 });
                        Button.onClick(() => { router.pushUrl({ url: 'pages/LoginPage' }); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.isLoading) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(212:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(213:11)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.historyList.length === 0) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(218:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('🕐');
                        Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(219:11)", "entry");
                        Text.fontSize(64);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('暂无浏览记录');
                        Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(220:11)", "entry");
                        Text.fontSize(17);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Medium);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('去看看有什么好商品吧');
                        Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(223:11)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 6 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去逛逛');
                        Button.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(225:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 28 });
                        Button.onClick(() => { AppStore.getInstance().pendingTab = 1; router.pushUrl({ url: 'pages/MainPage' }); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(234:9)", "entry");
                        Scroll.width('100%');
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(235:11)", "entry");
                        Column.width('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(236:13)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16, bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`共 ${this.historyList.length} 条记录`);
                        Text.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(237:15)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textSecondary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(239:15)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyHistoryPage.ets(243:13)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 12, right: 12 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    if (isInitialRender) {
                                        let componentCall = new HistoryCard(this, {
                                            item: item,
                                            onTap: () => this.goToDetail(item)
                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyHistoryPage.ets", line: 245, col: 17 });
                                        ViewPU.create(componentCall);
                                        let paramsLambda = () => {
                                            return {
                                                item: item,
                                                onTap: () => this.goToDetail(item)
                                            };
                                        };
                                        componentCall.paramsGenerator_ = paramsLambda;
                                    }
                                    else {
                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                    }
                                }, { name: "HistoryCard" });
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.historyList, forEachItemGenFunction, (item: BrowseItem) => item.id.toString(), false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "MyHistoryPage";
    }
}
registerNamedRoute(() => new MyHistoryPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/MyHistoryPage", pageFullPath: "entry/src/main/ets/pages/MyHistoryPage", integratedHsp: "false", moduleType: "followWithHap" });
