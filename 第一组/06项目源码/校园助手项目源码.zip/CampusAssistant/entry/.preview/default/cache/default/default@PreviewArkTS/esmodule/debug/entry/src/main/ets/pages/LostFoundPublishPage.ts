if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LostFoundPublishPage_Params {
    publishType?: number;
    titleInput?: string;
    descInput?: string;
    locationInput?: string;
    selectedCategoryIndex?: number;
    phoneInput?: string;
    imageUriList?: string[];
    imageUrlList?: string[];
    isUploading?: boolean;
    isSubmitting?: boolean;
    isLoading?: boolean;
    isLoggedIn?: boolean;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { LostFoundItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const CATEGORIES_LIST: string[] = ['电子产品', '证件', '钥匙', '衣物', '其他'];
class LostFoundPublishPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__publishType = new ObservedPropertySimplePU(1, this, "publishType");
        this.__titleInput = new ObservedPropertySimplePU('', this, "titleInput");
        this.__descInput = new ObservedPropertySimplePU('', this, "descInput");
        this.__locationInput = new ObservedPropertySimplePU('', this, "locationInput");
        this.__selectedCategoryIndex = new ObservedPropertySimplePU(-1, this, "selectedCategoryIndex");
        this.__phoneInput = new ObservedPropertySimplePU('', this, "phoneInput");
        this.__imageUriList = new ObservedPropertyObjectPU([], this, "imageUriList");
        this.__imageUrlList = new ObservedPropertyObjectPU([], this, "imageUrlList");
        this.__isUploading = new ObservedPropertySimplePU(false, this, "isUploading");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LostFoundPublishPage_Params) {
        if (params.publishType !== undefined) {
            this.publishType = params.publishType;
        }
        if (params.titleInput !== undefined) {
            this.titleInput = params.titleInput;
        }
        if (params.descInput !== undefined) {
            this.descInput = params.descInput;
        }
        if (params.locationInput !== undefined) {
            this.locationInput = params.locationInput;
        }
        if (params.selectedCategoryIndex !== undefined) {
            this.selectedCategoryIndex = params.selectedCategoryIndex;
        }
        if (params.phoneInput !== undefined) {
            this.phoneInput = params.phoneInput;
        }
        if (params.imageUriList !== undefined) {
            this.imageUriList = params.imageUriList;
        }
        if (params.imageUrlList !== undefined) {
            this.imageUrlList = params.imageUrlList;
        }
        if (params.isUploading !== undefined) {
            this.isUploading = params.isUploading;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
    }
    updateStateVars(params: LostFoundPublishPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__publishType.purgeDependencyOnElmtId(rmElmtId);
        this.__titleInput.purgeDependencyOnElmtId(rmElmtId);
        this.__descInput.purgeDependencyOnElmtId(rmElmtId);
        this.__locationInput.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedCategoryIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__phoneInput.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUriList.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUrlList.purgeDependencyOnElmtId(rmElmtId);
        this.__isUploading.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__publishType.aboutToBeDeleted();
        this.__titleInput.aboutToBeDeleted();
        this.__descInput.aboutToBeDeleted();
        this.__locationInput.aboutToBeDeleted();
        this.__selectedCategoryIndex.aboutToBeDeleted();
        this.__phoneInput.aboutToBeDeleted();
        this.__imageUriList.aboutToBeDeleted();
        this.__imageUrlList.aboutToBeDeleted();
        this.__isUploading.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __publishType: ObservedPropertySimplePU<number>;
    get publishType() {
        return this.__publishType.get();
    }
    set publishType(newValue: number) {
        this.__publishType.set(newValue);
    }
    private __titleInput: ObservedPropertySimplePU<string>;
    get titleInput() {
        return this.__titleInput.get();
    }
    set titleInput(newValue: string) {
        this.__titleInput.set(newValue);
    }
    private __descInput: ObservedPropertySimplePU<string>;
    get descInput() {
        return this.__descInput.get();
    }
    set descInput(newValue: string) {
        this.__descInput.set(newValue);
    }
    private __locationInput: ObservedPropertySimplePU<string>;
    get locationInput() {
        return this.__locationInput.get();
    }
    set locationInput(newValue: string) {
        this.__locationInput.set(newValue);
    }
    private __selectedCategoryIndex: ObservedPropertySimplePU<number>;
    get selectedCategoryIndex() {
        return this.__selectedCategoryIndex.get();
    }
    set selectedCategoryIndex(newValue: number) {
        this.__selectedCategoryIndex.set(newValue);
    }
    private __phoneInput: ObservedPropertySimplePU<string>;
    get phoneInput() {
        return this.__phoneInput.get();
    }
    set phoneInput(newValue: string) {
        this.__phoneInput.set(newValue);
    }
    private __imageUriList: ObservedPropertyObjectPU<string[]>;
    get imageUriList() {
        return this.__imageUriList.get();
    }
    set imageUriList(newValue: string[]) {
        this.__imageUriList.set(newValue);
    }
    private __imageUrlList: ObservedPropertyObjectPU<string[]>;
    get imageUrlList() {
        return this.__imageUrlList.get();
    }
    set imageUrlList(newValue: string[]) {
        this.__imageUrlList.set(newValue);
    }
    private __isUploading: ObservedPropertySimplePU<boolean>;
    get isUploading() {
        return this.__isUploading.get();
    }
    set isUploading(newValue: boolean) {
        this.__isUploading.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    aboutToAppear(): void {
        const store: AppStore = AppStore.getInstance();
        this.isLoggedIn = store.isLoggedIn;
        this.isLoading = false;
    }
    private async pickImagesFromAlbum(): Promise<void> {
        if (this.imageUrlList.length >= 5) {
            AlertDialog.show({
                message: '最多上传5张图片',
                confirm: { value: '知道了', action: () => { } }
            });
            return;
        }
        this.isUploading = true;
        const uris: string[] = await ApiService.pickImages();
        if (uris.length === 0) {
            this.isUploading = false;
            return;
        }
        const maxNew: number = 5 - this.imageUrlList.length;
        const toUpload: string[] = [];
        for (let i = 0; i < Math.min(uris.length, maxNew); i++) {
            toUpload.push(uris[i]);
        }
        for (let i = 0; i < toUpload.length; i++) {
            const url: string = await ApiService.uploadImage(toUpload[i]);
            if (url.startsWith('ERROR:')) {
                AlertDialog.show({
                    message: '图片上传失败，请重试',
                    confirm: { value: '确定', action: () => { } }
                });
            }
            else {
                this.imageUriList.push(toUpload[i]);
                this.imageUrlList.push(url);
            }
        }
        this.isUploading = false;
    }
    private removeImageByIndex(index: number): void {
        const newUris: string[] = [];
        const newUrls: string[] = [];
        for (let i = 0; i < this.imageUriList.length; i++) {
            if (i !== index) {
                newUris.push(this.imageUriList[i]);
                newUrls.push(this.imageUrlList[i]);
            }
        }
        this.imageUriList = newUris;
        this.imageUrlList = newUrls;
    }
    private async submitPublish(): Promise<void> {
        if (!this.isLoggedIn) {
            AlertDialog.show({
                message: '请先登录',
                confirm: { value: '好的', action: () => { } }
            });
            return;
        }
        if (this.titleInput.length === 0) {
            AlertDialog.show({
                message: '请输入标题',
                confirm: { value: '好的', action: () => { } }
            });
            return;
        }
        if (this.phoneInput.length === 0) {
            AlertDialog.show({
                message: '请输入联系方式',
                confirm: { value: '好的', action: () => { } }
            });
            return;
        }
        if (this.phoneInput.length !== 11 || !/^1\d{10}$/.test(this.phoneInput)) {
            AlertDialog.show({
                message: '请输入正确的11位手机号',
                confirm: { value: '好的', action: () => { } }
            });
            return;
        }
        this.isSubmitting = true;
        const lf: LostFoundItem = new LostFoundItem();
        lf.type = this.publishType;
        lf.title = this.titleInput;
        lf.description = this.descInput;
        lf.locationDesc = this.locationInput;
        if (this.selectedCategoryIndex >= 0 && this.selectedCategoryIndex < CATEGORIES_LIST.length) {
            lf.category = CATEGORIES_LIST[this.selectedCategoryIndex];
        }
        else {
            lf.category = '';
        }
        lf.contactPhone = this.phoneInput;
        const imgArr: string[] = [];
        for (let i = 0; i < this.imageUrlList.length; i++) {
            imgArr.push(this.imageUrlList[i]);
        }
        lf.images = JSON.stringify(imgArr);
        const result = await ApiService.publishLostFound(lf);
        this.isSubmitting = false;
        if (result.code === 200) {
            promptAction.showToast({ message: '发布成功！', duration: 2000 });
            router.back();
        }
        else {
            AlertDialog.show({
                title: '发布失败',
                message: result.msg || '请稍后重试',
                confirm: { value: '好的', action: () => { } }
            });
        }
    }
    private canSubmitNow(): boolean {
        return this.titleInput.length > 0 && this.phoneInput.length > 0 && !this.isSubmitting;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(154:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgInput);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '发布信息',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.isSubmitting ? '提交中…' : '发布');
                                Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(156:9)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(this.canSubmitNow() ? Theme.secondary : Theme.textDisabled);
                                Text.onClick(() => { this.submitPublish(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundPublishPage.ets", line: 155, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '发布信息',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.isSubmitting ? '提交中…' : '发布');
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(156:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(this.canSubmitNow() ? Theme.secondary : Theme.textDisabled);
                                    Text.onClick(() => { this.submitPublish(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '发布信息'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(163:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(164:11)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(169:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('🔒');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(170:11)", "entry");
                        Text.fontSize(48);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录再发布信息');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(171:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(173:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 20 });
                        Button.onClick(() => { router.pushUrl({ url: 'pages/LoginPage' }); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(182:9)", "entry");
                        Scroll.layoutWeight(1);
                        Scroll.width('100%');
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(183:11)", "entry");
                        Column.width('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(184:13)", "entry");
                        Column.width('100%');
                        Column.backgroundColor('#FFFFFF');
                        Column.padding(16);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(185:15)", "entry");
                        Row.width('100%');
                        Row.margin({ bottom: 10 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('发布类型');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(186:17)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(187:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(192:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel(this.publishType === 1 ? '🔍 寻物' : '寻物');
                        Button.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(193:17)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(this.publishType === 1 ? Theme.secondary : Theme.bgPage);
                        Button.fontColor(this.publishType === 1 ? '#FFFFFF' : Theme.textSecondary);
                        Button.height(40);
                        Button.layoutWeight(1);
                        Button.margin({ right: 8 });
                        Button.onClick(() => { this.publishType = 1; });
                    }, Button);
                    Button.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel(this.publishType === 2 ? '📢 招领' : '招领');
                        Button.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(199:17)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(this.publishType === 2 ? Theme.success : Theme.bgPage);
                        Button.fontColor(this.publishType === 2 ? '#FFFFFF' : Theme.textSecondary);
                        Button.height(40);
                        Button.layoutWeight(1);
                        Button.onClick(() => { this.publishType = 2; });
                    }, Button);
                    Button.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(208:15)", "entry");
                        Column.width('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(209:17)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 14, bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('添加图片');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(210:19)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('(' + this.imageUrlList.length + '/5)');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(211:19)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ left: 4 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(212:19)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(217:17)", "entry");
                        Scroll.scrollable(ScrollDirection.Horizontal);
                        Scroll.width('100%');
                        Scroll.height(90);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(218:19)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, idx: number) => {
                            const url = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Stack.create();
                                Stack.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(220:23)", "entry");
                                Stack.margin({ right: 8 });
                            }, Stack);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Image.create(ApiService.baseUrl + url);
                                Image.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(221:25)", "entry");
                                Image.width(76);
                                Image.height(76);
                                Image.borderRadius(8);
                                Image.objectFit(ImageFit.Cover);
                            }, Image);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('×');
                                Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(223:25)", "entry");
                                Text.fontSize(14);
                                Text.fontColor('#FFFFFF');
                                Text.backgroundColor('#00000080');
                                Text.width(18);
                                Text.height(18);
                                Text.borderRadius(9);
                                Text.textAlign(TextAlign.Center);
                                Text.position({ top: -3, right: -3 });
                                Text.onClick(() => { this.removeImageByIndex(idx); });
                            }, Text);
                            Text.pop();
                            Stack.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.imageUrlList, forEachItemGenFunction, (url: string) => url, true, false);
                    }, ForEach);
                    ForEach.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.imageUrlList.length < 5) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(235:23)", "entry");
                                    Column.width(76);
                                    Column.height(76);
                                    Column.backgroundColor(Theme.bgInput);
                                    Column.borderRadius(8);
                                    Column.border({ width: 1, color: Theme.border, style: BorderStyle.Dashed });
                                    Column.justifyContent(FlexAlign.Center);
                                    Column.onClick(() => { this.pickImagesFromAlbum(); });
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.isUploading) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                LoadingProgress.create();
                                                LoadingProgress.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(237:27)", "entry");
                                                LoadingProgress.color(Theme.secondary);
                                                LoadingProgress.width(24);
                                                LoadingProgress.height(24);
                                            }, LoadingProgress);
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('+');
                                                Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(239:27)", "entry");
                                                Text.fontSize(28);
                                                Text.fontColor(Theme.textDisabled);
                                            }, Text);
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('上传');
                                                Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(240:27)", "entry");
                                                Text.fontSize(10);
                                                Text.fontColor(Theme.textDisabled);
                                                Text.margin({ top: 2 });
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                }, If);
                                If.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Row.pop();
                    Scroll.pop();
                    Column.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(261:13)", "entry");
                        Blank.height(10);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(264:13)", "entry");
                        Column.width('100%');
                        Column.backgroundColor('#FFFFFF');
                        Column.padding(16);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(265:15)", "entry");
                        Row.width('100%');
                        Row.margin({ bottom: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('标题');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(266:17)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(' *');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(267:17)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.danger);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(268:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '如：丢失校园卡、捡到钥匙串', text: this.titleInput });
                        TextInput.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(272:15)", "entry");
                        TextInput.width('100%');
                        TextInput.height(46);
                        TextInput.fontSize(15);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(8);
                        TextInput.padding({ left: 12, right: 12 });
                        TextInput.onChange((val: string) => { this.titleInput = val; });
                    }, TextInput);
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(283:13)", "entry");
                        Blank.height(10);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(285:13)", "entry");
                        Column.width('100%');
                        Column.backgroundColor('#FFFFFF');
                        Column.padding(16);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(286:15)", "entry");
                        Row.width('100%');
                        Row.margin({ bottom: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('详细描述');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(287:17)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(288:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextArea.create({ placeholder: '描述物品特征、丢失/拾到时间、周围环境等…', text: this.descInput });
                        TextArea.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(292:15)", "entry");
                        TextArea.width('100%');
                        TextArea.height(120);
                        TextArea.fontSize(15);
                        TextArea.backgroundColor(Theme.bgInput);
                        TextArea.borderRadius(8);
                        TextArea.padding({ left: 12, right: 12 });
                        TextArea.onChange((val: string) => { this.descInput = val; });
                    }, TextArea);
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(303:13)", "entry");
                        Blank.height(10);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(305:13)", "entry");
                        Column.width('100%');
                        Column.backgroundColor('#FFFFFF');
                        Column.padding(16);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(306:15)", "entry");
                        Row.width('100%');
                        Row.margin({ bottom: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('地点');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(307:17)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(308:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '如：二教203、一食堂二楼', text: this.locationInput });
                        TextInput.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(312:15)", "entry");
                        TextInput.width('100%');
                        TextInput.height(46);
                        TextInput.fontSize(15);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(8);
                        TextInput.padding({ left: 12, right: 12 });
                        TextInput.onChange((val: string) => { this.locationInput = val; });
                    }, TextInput);
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(323:13)", "entry");
                        Blank.height(10);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(325:13)", "entry");
                        Column.width('100%');
                        Column.backgroundColor('#FFFFFF');
                        Column.padding(16);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(326:15)", "entry");
                        Row.width('100%');
                        Row.margin({ bottom: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('联系方式');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(327:17)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(' *');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(328:17)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.danger);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(329:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '请输入11位手机号', text: this.phoneInput });
                        TextInput.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(333:15)", "entry");
                        TextInput.width('100%');
                        TextInput.height(46);
                        TextInput.fontSize(15);
                        TextInput.type(InputType.Number);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(8);
                        TextInput.padding({ left: 12, right: 12 });
                        TextInput.onChange((val: string) => { this.phoneInput = val; });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('手机号需为11位，以1开头');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(340:15)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.width('100%');
                        Text.margin({ top: 4 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(349:13)", "entry");
                        Blank.height(10);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(351:13)", "entry");
                        Column.width('100%');
                        Column.backgroundColor('#FFFFFF');
                        Column.padding(16);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(352:15)", "entry");
                        Row.width('100%');
                        Row.margin({ bottom: 10 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('物品分类');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(353:17)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(354:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Flex.create({ wrap: FlexWrap.Wrap });
                        Flex.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(359:15)", "entry");
                        Flex.width('100%');
                    }, Flex);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, idx: number) => {
                            const cat = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(cat);
                                Text.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(361:19)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(this.selectedCategoryIndex === idx ? Theme.secondary : Theme.textSecondary);
                                Text.backgroundColor(this.selectedCategoryIndex === idx ? Theme.secondaryLight : Theme.bgPage);
                                Text.border({ width: 1, color: this.selectedCategoryIndex === idx ? Theme.secondary : Theme.border });
                                Text.borderRadius(16);
                                Text.padding({ left: 16, right: 16, top: 6, bottom: 6 });
                                Text.margin({ right: 10, bottom: 10 });
                                Text.onClick(() => { this.selectedCategoryIndex = idx; });
                            }, Text);
                            Text.pop();
                        };
                        this.forEachUpdateFunction(elmtId, CATEGORIES_LIST, forEachItemGenFunction, (cat: string) => cat, true, false);
                    }, ForEach);
                    ForEach.pop();
                    Flex.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(378:13)", "entry");
                        Blank.height(10);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(382:13)", "entry");
                        Blank.height(16);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel(this.isSubmitting ? '发布中…' : '提交' + (this.publishType === 1 ? '寻物' : '招领') + '信息');
                        Button.debugLine("entry/src/main/ets/pages/LostFoundPublishPage.ets(383:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.width('92%');
                        Button.height(48);
                        Button.backgroundColor(this.canSubmitNow() ? (this.publishType === 1 ? Theme.secondary : Theme.success) : Theme.textDisabled);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ bottom: 40 });
                        Button.enabled(this.canSubmitNow());
                        Button.onClick(() => { this.submitPublish(); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "LostFoundPublishPage";
    }
}
registerNamedRoute(() => new LostFoundPublishPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/LostFoundPublishPage", pageFullPath: "entry/src/main/ets/pages/LostFoundPublishPage", integratedHsp: "false", moduleType: "followWithHap" });
