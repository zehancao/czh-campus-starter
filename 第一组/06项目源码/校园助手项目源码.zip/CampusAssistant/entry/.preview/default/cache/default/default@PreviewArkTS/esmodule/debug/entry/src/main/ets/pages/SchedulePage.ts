if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SchedulePage_Params {
    scheduleList?: CourseSchedule[];
    scheduleGrid?: CourseSchedule[][];
    currentWeek?: number;
    todayWeek?: number;
    semesterId?: number;
    semesterWeekCount?: number;
    semesterName?: string;
    semesterStartDate?: string;
    showCourseDetail?: boolean;
    selectedCourse?: CourseSchedule;
    todayCourses?: CourseSchedule[];
    isLoadingSchedule?: boolean;
}
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { CourseSchedule } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import type { Semester } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
import { WidgetDataHelper } from "@normalized:N&&&entry/src/main/ets/service/WidgetDataHelper&";
import router from "@ohos:router";
import { calcSemesterWeek, semesterWeekDate } from "@normalized:N&&&entry/src/main/ets/common/utils&";
const WEEK_DAY_LABELS: string[] = ['一', '二', '三', '四', '五', '六', '日'];
const SCHEDULE_SECTION_HEIGHT: number = 66;
class SchedulePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__scheduleList = new ObservedPropertyObjectPU([], this, "scheduleList");
        this.__scheduleGrid = new ObservedPropertyObjectPU([], this, "scheduleGrid");
        this.__currentWeek = new ObservedPropertySimplePU(1, this, "currentWeek");
        this.__todayWeek = new ObservedPropertySimplePU(1, this, "todayWeek");
        this.__semesterId = new ObservedPropertySimplePU(0, this, "semesterId");
        this.__semesterWeekCount = new ObservedPropertySimplePU(20, this, "semesterWeekCount");
        this.__semesterName = new ObservedPropertySimplePU('', this, "semesterName");
        this.__semesterStartDate = new ObservedPropertySimplePU('', this, "semesterStartDate");
        this.__showCourseDetail = new ObservedPropertySimplePU(false, this, "showCourseDetail");
        this.__selectedCourse = new ObservedPropertyObjectPU(new CourseSchedule(), this, "selectedCourse");
        this.__todayCourses = new ObservedPropertyObjectPU([], this, "todayCourses");
        this.__isLoadingSchedule = new ObservedPropertySimplePU(false, this, "isLoadingSchedule");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SchedulePage_Params) {
        if (params.scheduleList !== undefined) {
            this.scheduleList = params.scheduleList;
        }
        if (params.scheduleGrid !== undefined) {
            this.scheduleGrid = params.scheduleGrid;
        }
        if (params.currentWeek !== undefined) {
            this.currentWeek = params.currentWeek;
        }
        if (params.todayWeek !== undefined) {
            this.todayWeek = params.todayWeek;
        }
        if (params.semesterId !== undefined) {
            this.semesterId = params.semesterId;
        }
        if (params.semesterWeekCount !== undefined) {
            this.semesterWeekCount = params.semesterWeekCount;
        }
        if (params.semesterName !== undefined) {
            this.semesterName = params.semesterName;
        }
        if (params.semesterStartDate !== undefined) {
            this.semesterStartDate = params.semesterStartDate;
        }
        if (params.showCourseDetail !== undefined) {
            this.showCourseDetail = params.showCourseDetail;
        }
        if (params.selectedCourse !== undefined) {
            this.selectedCourse = params.selectedCourse;
        }
        if (params.todayCourses !== undefined) {
            this.todayCourses = params.todayCourses;
        }
        if (params.isLoadingSchedule !== undefined) {
            this.isLoadingSchedule = params.isLoadingSchedule;
        }
    }
    updateStateVars(params: SchedulePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__scheduleList.purgeDependencyOnElmtId(rmElmtId);
        this.__scheduleGrid.purgeDependencyOnElmtId(rmElmtId);
        this.__currentWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__todayWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterId.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterWeekCount.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterName.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterStartDate.purgeDependencyOnElmtId(rmElmtId);
        this.__showCourseDetail.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedCourse.purgeDependencyOnElmtId(rmElmtId);
        this.__todayCourses.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoadingSchedule.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__scheduleList.aboutToBeDeleted();
        this.__scheduleGrid.aboutToBeDeleted();
        this.__currentWeek.aboutToBeDeleted();
        this.__todayWeek.aboutToBeDeleted();
        this.__semesterId.aboutToBeDeleted();
        this.__semesterWeekCount.aboutToBeDeleted();
        this.__semesterName.aboutToBeDeleted();
        this.__semesterStartDate.aboutToBeDeleted();
        this.__showCourseDetail.aboutToBeDeleted();
        this.__selectedCourse.aboutToBeDeleted();
        this.__todayCourses.aboutToBeDeleted();
        this.__isLoadingSchedule.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __scheduleList: ObservedPropertyObjectPU<CourseSchedule[]>;
    get scheduleList() {
        return this.__scheduleList.get();
    }
    set scheduleList(newValue: CourseSchedule[]) {
        this.__scheduleList.set(newValue);
    }
    private __scheduleGrid: ObservedPropertyObjectPU<CourseSchedule[][]>;
    get scheduleGrid() {
        return this.__scheduleGrid.get();
    }
    set scheduleGrid(newValue: CourseSchedule[][]) {
        this.__scheduleGrid.set(newValue);
    }
    private __currentWeek: ObservedPropertySimplePU<number>;
    get currentWeek() {
        return this.__currentWeek.get();
    }
    set currentWeek(newValue: number) {
        this.__currentWeek.set(newValue);
    }
    private __todayWeek: ObservedPropertySimplePU<number>;
    get todayWeek() {
        return this.__todayWeek.get();
    }
    set todayWeek(newValue: number) {
        this.__todayWeek.set(newValue);
    }
    private __semesterId: ObservedPropertySimplePU<number>;
    get semesterId() {
        return this.__semesterId.get();
    }
    set semesterId(newValue: number) {
        this.__semesterId.set(newValue);
    }
    private __semesterWeekCount: ObservedPropertySimplePU<number>;
    get semesterWeekCount() {
        return this.__semesterWeekCount.get();
    }
    set semesterWeekCount(newValue: number) {
        this.__semesterWeekCount.set(newValue);
    }
    private __semesterName: ObservedPropertySimplePU<string>;
    get semesterName() {
        return this.__semesterName.get();
    }
    set semesterName(newValue: string) {
        this.__semesterName.set(newValue);
    }
    private __semesterStartDate: ObservedPropertySimplePU<string>;
    get semesterStartDate() {
        return this.__semesterStartDate.get();
    }
    set semesterStartDate(newValue: string) {
        this.__semesterStartDate.set(newValue);
    }
    private __showCourseDetail: ObservedPropertySimplePU<boolean>;
    get showCourseDetail() {
        return this.__showCourseDetail.get();
    }
    set showCourseDetail(newValue: boolean) {
        this.__showCourseDetail.set(newValue);
    }
    private __selectedCourse: ObservedPropertyObjectPU<CourseSchedule>;
    get selectedCourse() {
        return this.__selectedCourse.get();
    }
    set selectedCourse(newValue: CourseSchedule) {
        this.__selectedCourse.set(newValue);
    }
    private __todayCourses: ObservedPropertyObjectPU<CourseSchedule[]>;
    get todayCourses() {
        return this.__todayCourses.get();
    }
    set todayCourses(newValue: CourseSchedule[]) {
        this.__todayCourses.set(newValue);
    }
    private __isLoadingSchedule: ObservedPropertySimplePU<boolean>;
    get isLoadingSchedule() {
        return this.__isLoadingSchedule.get();
    }
    set isLoadingSchedule(newValue: boolean) {
        this.__isLoadingSchedule.set(newValue);
    }
    aboutToAppear(): void {
        this.loadSemester();
    }
    onPageShow(): void {
        if (this.semesterId > 0 && !this.isLoadingSchedule) {
            this.loadSchedule();
        }
    }
    private async loadSemester(): Promise<void> {
        const result: ApiResult = await ApiService.getCurrentSemester();
        if (result.code === 200 && result.data !== undefined) {
            const semester: Semester = ApiService.parseSemester(result.data);
            this.semesterId = semester.id;
            this.semesterName = semester.name;
            this.semesterStartDate = semester.startDate;
            this.semesterWeekCount = semester.weekCount;
            this.todayWeek = this.calcCurrentWeek(semester.startDate, semester.weekCount);
            this.currentWeek = this.todayWeek;
        }
        this.loadSchedule();
    }
    private calcCurrentWeek(startDateStr: string, weekCount: number): number {
        return calcSemesterWeek(startDateStr, weekCount);
    }
    private async loadSchedule(): Promise<void> {
        if (this.isLoadingSchedule) {
            return;
        }
        this.isLoadingSchedule = true;
        const sid: number = this.semesterId > 0 ? this.semesterId : 1;
        const result: ApiResult = await ApiService.getMySchedule(sid);
        if (result.code === 200) {
            if (result.data !== undefined) {
                this.scheduleList = ApiService.parseScheduleList(result.data);
            }
            else {
                this.scheduleList = [];
            }
            this.updateScheduleGrid();
        }
        this.isLoadingSchedule = false;
    }
    private updateScheduleGrid(): void {
        const today: number = new Date().getDay();
        const dayOfWeek: number = today === 0 ? 7 : today;
        const filtered: CourseSchedule[] = this.scheduleList.filter((item: CourseSchedule) => this.isCourseActiveInWeek(item, this.currentWeek));
        this.todayCourses = filtered.filter((item: CourseSchedule) => item.dayOfWeek === dayOfWeek);
        this.scheduleGrid = [];
        for (let day = 1; day <= 7; day++) {
            const dayList: CourseSchedule[] = [];
            for (let sec = 1; sec <= 10; sec++) {
                const found: CourseSchedule | undefined = filtered.find((item: CourseSchedule) => item.dayOfWeek === day && item.startSection <= sec && item.endSection >= sec);
                dayList.push(found ?? new CourseSchedule());
            }
            this.scheduleGrid.push(dayList);
        }
        const store: AppStore = AppStore.getInstance();
        if (store.context !== undefined) {
            WidgetDataHelper.saveTodayCourses(store.context, this.todayCourses, this.currentWeek);
        }
    }
    private isCourseActiveInWeek(item: CourseSchedule, week: number): boolean {
        if (item.startWeek > week || item.endWeek < week) {
            return false;
        }
        if (item.weekParity === 'odd') {
            return week % 2 === 1;
        }
        if (item.weekParity === 'even') {
            return week % 2 === 0;
        }
        return true;
    }
    private semesterTitle(): string {
        return this.semesterName.length > 0 ? this.semesterName : '当前学期';
    }
    private weekDate(dayIndex: number): Date | null {
        const semesterDate: Date | null = semesterWeekDate(this.semesterStartDate, this.currentWeek, dayIndex);
        if (semesterDate !== null) {
            return semesterDate;
        }
        const parts: string[] = this.semesterStartDate.split('-');
        if (parts.length < 3) {
            return null;
        }
        const date: Date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
        const dow: number = date.getDay();
        const offsetToMonday: number = dow === 0 ? -6 : 1 - dow;
        date.setDate(date.getDate() + offsetToMonday + (this.currentWeek - 1) * 7 + dayIndex);
        return date;
    }
    private weekMonthText(): string {
        const date: Date | null = this.weekDate(0);
        if (date === null) {
            return '';
        }
        return `${date.getMonth() + 1}月`;
    }
    private weekDayText(dayIndex: number): string {
        const date: Date | null = this.weekDate(dayIndex);
        if (date === null) {
            return `${dayIndex + 1}`;
        }
        return `${date.getDate()}`;
    }
    private courseAtStart(day: number, section: number): CourseSchedule {
        for (let i = 0; i < this.scheduleList.length; i++) {
            const item: CourseSchedule = this.scheduleList[i];
            if (item.dayOfWeek === day && item.startSection === section && this.isCourseActiveInWeek(item, this.currentWeek)) {
                return item;
            }
        }
        return new CourseSchedule();
    }
    private hasCourseCovering(day: number, section: number): boolean {
        for (let i = 0; i < this.scheduleList.length; i++) {
            const item: CourseSchedule = this.scheduleList[i];
            if (item.dayOfWeek === day && item.startSection < section && item.endSection >= section && this.isCourseActiveInWeek(item, this.currentWeek)) {
                return true;
            }
        }
        return false;
    }
    private courseDuration(item: CourseSchedule): number {
        const duration: number = item.endSection - item.startSection + 1;
        return duration > 0 ? duration : 1;
    }
    private courseBg(item: CourseSchedule): string {
        if (item.source === 'personal') {
            return Theme.personalCardBg[Math.abs(item.colorIndex) % Theme.personalCardBg.length];
        }
        return Theme.scheduleCardBg[Math.abs(item.colorIndex) % Theme.scheduleCardBg.length];
    }
    private courseFg(item: CourseSchedule): string {
        if (item.source === 'personal') {
            return Theme.personalCardFg[Math.abs(item.colorIndex) % Theme.personalCardFg.length];
        }
        return Theme.scheduleCardFg[Math.abs(item.colorIndex) % Theme.scheduleCardFg.length];
    }
    private sectionStartTime(section: number): string {
        if (section >= 1 && section <= Constants.SECTION_TIMES.length) {
            return Constants.SECTION_TIMES[section - 1][0];
        }
        return '';
    }
    private sectionEndTime(section: number): string {
        if (section >= 1 && section <= Constants.SECTION_TIMES.length) {
            return Constants.SECTION_TIMES[section - 1][1];
        }
        return '';
    }
    private courseTimeText(item: CourseSchedule): string {
        return `${this.sectionStartTime(item.startSection)}-${this.sectionEndTime(item.endSection)}`;
    }
    private courseWeekText(item: CourseSchedule): string {
        let text: string = `第${item.startWeek}-${item.endWeek}周`;
        if (item.weekParity === 'odd') {
            text += ' 单周';
        }
        if (item.weekParity === 'even') {
            text += ' 双周';
        }
        return text;
    }
    private courseBriefText(item: CourseSchedule): string {
        const room: string = item.classroom.length > 0 ? item.classroom : '教室未填';
        if (item.teacherName.length > 0) {
            return `${item.courseName} @${room}\n${item.teacherName}`;
        }
        return `${item.courseName} @${room}`;
    }
    private showWeekPicker(): void {
        const weeks: string[] = [];
        for (let i = 1; i <= this.semesterWeekCount; i++) {
            weeks.push(`第${i}周`);
        }
        let currentIdx: number = this.currentWeek - 1;
        TextPickerDialog.show({
            range: weeks,
            selected: currentIdx,
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < weeks.length) {
                    this.currentWeek = idx + 1;
                    this.updateScheduleGrid();
                }
            }
        });
    }
    private backToCurrentWeek(): void {
        this.currentWeek = this.todayWeek;
        this.updateScheduleGrid();
    }
    private openCourseDetail(item: CourseSchedule): void {
        this.selectedCourse = item;
        this.showCourseDetail = true;
    }
    private closeCourseDetail(): void {
        this.showCourseDetail = false;
        this.selectedCourse = new CourseSchedule();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(259:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '我的课表' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/SchedulePage.ets", line: 260, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '我的课表'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '我的课表'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/SchedulePage.ets(262:7)", "entry");
            Stack.layoutWeight(1);
            Stack.width('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(263:9)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        this.ScheduleHeader.bind(this)();
        this.ScheduleWeekHeader.bind(this)();
        this.ScheduleGrid.bind(this)();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentWeek !== this.todayWeek) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/SchedulePage.ets(273:11)", "entry");
                        Row.width('100%');
                        Row.height('100%');
                        Row.justifyContent(FlexAlign.End);
                        Row.alignItems(VerticalAlign.Bottom);
                        Row.hitTestBehavior(HitTestMode.None);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('切回本周');
                        Button.debugLine("entry/src/main/ets/pages/SchedulePage.ets(274:13)", "entry");
                        Button.height(42);
                        Button.fontSize(15);
                        Button.fontColor(Color.White);
                        Button.backgroundColor(Theme.primary);
                        Button.borderRadius(24);
                        Button.padding({ left: 24, right: 24 });
                        Button.shadow(ShadowStyle.sm);
                        Button.margin({ right: 16, bottom: 16 });
                        Button.onClick(() => {
                            this.backToCurrentWeek();
                        });
                    }, Button);
                    Button.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showCourseDetail) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.CourseDetailOverlay.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
        Column.pop();
    }
    ScheduleHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SchedulePage.ets(308:5)", "entry");
            Row.width('100%');
            Row.height(62);
            Row.padding({ left: 16, right: 16, top: 6, bottom: 6 });
            Row.backgroundColor(Theme.bgCard);
            Row.borderRadius(Theme.cardRadius);
            Row.shadow(ShadowStyle.nmRaised);
            Row.margin({ left: 12, right: 12, top: 8, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(309:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SchedulePage.ets(310:9)", "entry");
            Row.onClick(() => {
                this.showWeekPicker();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`第${this.currentWeek}周`);
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(311:11)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('▼');
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(315:11)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.primary);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.semesterTitle());
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(323:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 3 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('+');
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(331:7)", "entry");
            Text.fontSize(28);
            Text.fontColor(Theme.primary);
            Text.fontWeight(FontWeight.Bold);
            Text.width(42);
            Text.height(42);
            Text.textAlign(TextAlign.Center);
            Text.backgroundColor(Theme.primaryLight);
            Text.borderRadius(21);
            Text.shadow(ShadowStyle.sm);
            Text.onClick(() => {
                router.pushUrl({
                    url: 'pages/AddCoursePage',
                    params: {
                        semesterId: this.semesterId,
                        semesterWeekCount: this.semesterWeekCount,
                        semesterTitle: this.semesterTitle()
                    }
                }).catch(() => {
                    this.getUIContext().getPromptAction().showToast({ message: '打开添课页失败' });
                });
            });
        }, Text);
        Text.pop();
        Row.pop();
    }
    ScheduleWeekHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SchedulePage.ets(365:5)", "entry");
            Row.width('100%');
            Row.height(60);
            Row.backgroundColor(Theme.bgCard);
            Row.borderRadius(18);
            Row.shadow(ShadowStyle.sm);
            Row.margin({ left: 8, right: 8, bottom: 6 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(366:7)", "entry");
            Column.width(50);
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.weekMonthText().length > 0 ? this.weekMonthText().replace('月', '') : '');
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(367:9)", "entry");
            Text.fontSize(17);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('月');
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(370:9)", "entry");
            Text.fontSize(17);
            Text.fontColor(Theme.textPrimary);
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const day = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(379:9)", "entry");
                    Column.layoutWeight(1);
                    Column.height(58);
                    Column.justifyContent(FlexAlign.Center);
                    Column.alignItems(HorizontalAlign.Center);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(day);
                    Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(380:11)", "entry");
                    Text.fontSize(19);
                    Text.fontColor(Theme.textPrimary);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.weekDayText(index));
                    Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(383:11)", "entry");
                    Text.fontSize(15);
                    Text.fontColor(Theme.textTertiary);
                    Text.margin({ top: 8 });
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, WEEK_DAY_LABELS, forEachItemGenFunction, (day: string, index: number) => `${index}-${day}`, true, true);
        }, ForEach);
        ForEach.pop();
        Row.pop();
    }
    ScheduleGrid(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/SchedulePage.ets(404:5)", "entry");
            Scroll.layoutWeight(1);
            Scroll.backgroundColor(Theme.bgCard);
            Scroll.borderRadius(18);
            Scroll.margin({ left: 8, right: 8, bottom: 8 });
            Scroll.scrollBar(BarState.Off);
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SchedulePage.ets(405:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(406:9)", "entry");
            Column.width(50);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const section = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(408:13)", "entry");
                    Column.width(50);
                    Column.height(SCHEDULE_SECTION_HEIGHT);
                    Column.justifyContent(FlexAlign.Center);
                    Column.alignItems(HorizontalAlign.Center);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(`${section}`);
                    Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(409:15)", "entry");
                    Text.fontSize(18);
                    Text.fontColor(Theme.textPrimary);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.sectionStartTime(section));
                    Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(412:15)", "entry");
                    Text.fontSize(11);
                    Text.fontColor(Theme.textTertiary);
                    Text.margin({ top: 3 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.sectionEndTime(section));
                    Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(416:15)", "entry");
                    Text.fontSize(11);
                    Text.fontColor(Theme.textTertiary);
                    Text.margin({ top: 1 });
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], forEachItemGenFunction, (section: number) => `${section}`, false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SchedulePage.ets(429:9)", "entry");
            Row.layoutWeight(1);
            Row.padding({ right: 6 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const day = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(431:13)", "entry");
                    Column.layoutWeight(1);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const section = _item;
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Stack.create();
                            Stack.debugLine("entry/src/main/ets/pages/SchedulePage.ets(433:17)", "entry");
                            Stack.width('100%');
                            Stack.height(SCHEDULE_SECTION_HEIGHT);
                        }, Stack);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Divider.create();
                            Divider.debugLine("entry/src/main/ets/pages/SchedulePage.ets(434:19)", "entry");
                            Divider.height(1);
                            Divider.color(Theme.border);
                            Divider.width('100%');
                            Divider.position({ x: 0, y: SCHEDULE_SECTION_HEIGHT - 1 });
                        }, Divider);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            if (!this.hasCourseCovering(day, section)) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.ScheduleCell.bind(this)(day, section);
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                });
                            }
                        }, If);
                        If.pop();
                        Stack.pop();
                    };
                    this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], forEachItemGenFunction, (section: number) => `${day}-${section}`, false, false);
                }, ForEach);
                ForEach.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7], forEachItemGenFunction, (day: number) => `${day}`, false, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Row.pop();
        Scroll.pop();
    }
    ScheduleCell(day: number, section: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(465:5)", "entry");
            Column.width('100%');
            Column.height(SCHEDULE_SECTION_HEIGHT);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.courseAtStart(day, section).courseName.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.ScheduleCourseCard.bind(this)(this.courseAtStart(day, section));
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    ScheduleCourseCard(item: CourseSchedule, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(476:5)", "entry");
            Column.width('92%');
            Column.height(this.courseDuration(item) * SCHEDULE_SECTION_HEIGHT - 8);
            Column.padding({ left: 7, right: 5, top: 8, bottom: 6 });
            Column.backgroundColor(this.courseBg(item));
            Column.borderRadius(8);
            Column.shadow(ShadowStyle.sm);
            Column.margin({ left: 3, right: 3, top: 4 });
            Column.alignItems(HorizontalAlign.Start);
            Column.onClick(() => {
                this.openCourseDetail(item);
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.courseBriefText(item));
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(477:7)", "entry");
            Text.fontSize(12);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.courseFg(item));
            Text.lineHeight(18);
            Text.maxLines(this.courseDuration(item) <= 1 ? 2 : 5);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Column.pop();
    }
    CourseDetailOverlay(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/SchedulePage.ets(500:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(501:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('rgba(255,255,255,0.87)');
            Column.onClick(() => {
                this.closeCourseDetail();
            });
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(509:7)", "entry");
            Column.width('90%');
            Column.position({ x: 20, y: 200 });
        }, Column);
        this.CourseDetailCard.bind(this)(ObservedObject.GetRawObject(this.selectedCourse), false);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.selectedCourse.weekParity !== 'all') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.CourseDetailCard.bind(this)(ObservedObject.GetRawObject(this.selectedCourse), true);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Stack.pop();
    }
    CourseDetailCard(item: CourseSchedule, parityCard: boolean, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SchedulePage.ets(524:5)", "entry");
            Column.width('100%');
            Column.padding(24);
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.shadow(ShadowStyle.nmRaisedLg);
            Column.margin({ bottom: 18 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SchedulePage.ets(525:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (parityCard) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('非本周');
                        Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(527:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Color.White);
                        Text.backgroundColor(Theme.textPrimary);
                        Text.borderRadius(4);
                        Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                        Text.margin({ right: 8 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.courseName.length > 0 ? item.courseName : '课程名称未录入');
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(535:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.source === 'personal') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('个人');
                        Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(541:11)", "entry");
                        Text.fontSize(11);
                        Text.fontColor('#FFFFFF');
                        Text.backgroundColor(Theme.danger);
                        Text.borderRadius(4);
                        Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                        Text.margin({ left: 4 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.source === 'personal') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('删除');
                        Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(550:11)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.danger);
                        Text.padding({ left: 12, right: 12, top: 8, bottom: 8 });
                        Text.backgroundColor(Color.White);
                        Text.borderRadius(5);
                        Text.onClick(async () => {
                            const result: ApiResult = await ApiService.deletePersonalCourse(item.id);
                            if (result.code === 200) {
                                this.getUIContext().getPromptAction().showToast({ message: '已删除' });
                                this.showCourseDetail = false;
                                this.loadSchedule();
                            }
                            else {
                                this.getUIContext().getPromptAction().showToast({ message: result.msg.length > 0 ? result.msg : '删除失败' });
                            }
                        });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('编辑');
                        Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(567:11)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.textTertiary);
                        Text.padding({ left: 12, right: 12, top: 8, bottom: 8 });
                        Text.backgroundColor(Color.White);
                        Text.borderRadius(5);
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.courseWeekText(item));
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(577:7)", "entry");
            Text.fontSize(17);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ top: 18 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`周${WEEK_DAY_LABELS[item.dayOfWeek - 1]} | 第${item.startSection}-${item.endSection}节 | ${this.courseTimeText(item)}`);
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(582:7)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`教室：${item.classroom.length > 0 ? item.classroom : '未填写'}`);
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(587:7)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`老师：${item.teacherName.length > 0 ? item.teacherName : '未填写'}`);
            Text.debugLine("entry/src/main/ets/pages/SchedulePage.ets(592:7)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "SchedulePage";
    }
}
registerNamedRoute(() => new SchedulePage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/SchedulePage", pageFullPath: "entry/src/main/ets/pages/SchedulePage", integratedHsp: "false", moduleType: "followWithHap" });
