if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ProductDetailPage_Params {
    product?: Product;
    parsedImages?: string[];
    parsedTags?: string[];
    isFavorite?: boolean;
    isLoading?: boolean;
    isLoggedIn?: boolean;
    errorMsg?: string;
    sellerPhoneText?: string;
    isSharing?: boolean;
    productId?: number;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { Product } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import type { Conversation } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
const CONDITION_LABELS: string[] = ['', '全新', '几乎全新', '有使用痕迹'];
const STATUS_LABELS: string[] = ['', '在售', '已售', '下架'];
const STATUS_COLORS: string[] = [Theme.bgCard, Theme.success, Theme.textSecondary, Theme.danger];
class ProductDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__product = new ObservedPropertyObjectPU(new Product(), this, "product");
        this.__parsedImages = new ObservedPropertyObjectPU([], this, "parsedImages");
        this.__parsedTags = new ObservedPropertyObjectPU([], this, "parsedTags");
        this.__isFavorite = new ObservedPropertySimplePU(false, this, "isFavorite");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.__sellerPhoneText = new ObservedPropertySimplePU('', this, "sellerPhoneText");
        this.__isSharing = new ObservedPropertySimplePU(false, this, "isSharing");
        this.productId = 0;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ProductDetailPage_Params) {
        if (params.product !== undefined) {
            this.product = params.product;
        }
        if (params.parsedImages !== undefined) {
            this.parsedImages = params.parsedImages;
        }
        if (params.parsedTags !== undefined) {
            this.parsedTags = params.parsedTags;
        }
        if (params.isFavorite !== undefined) {
            this.isFavorite = params.isFavorite;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
        if (params.sellerPhoneText !== undefined) {
            this.sellerPhoneText = params.sellerPhoneText;
        }
        if (params.isSharing !== undefined) {
            this.isSharing = params.isSharing;
        }
        if (params.productId !== undefined) {
            this.productId = params.productId;
        }
    }
    updateStateVars(params: ProductDetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__product.purgeDependencyOnElmtId(rmElmtId);
        this.__parsedImages.purgeDependencyOnElmtId(rmElmtId);
        this.__parsedTags.purgeDependencyOnElmtId(rmElmtId);
        this.__isFavorite.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
        this.__sellerPhoneText.purgeDependencyOnElmtId(rmElmtId);
        this.__isSharing.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__product.aboutToBeDeleted();
        this.__parsedImages.aboutToBeDeleted();
        this.__parsedTags.aboutToBeDeleted();
        this.__isFavorite.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        this.__sellerPhoneText.aboutToBeDeleted();
        this.__isSharing.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __product: ObservedPropertyObjectPU<Product>;
    get product() {
        return this.__product.get();
    }
    set product(newValue: Product) {
        this.__product.set(newValue);
    }
    private __parsedImages: ObservedPropertyObjectPU<string[]>;
    get parsedImages() {
        return this.__parsedImages.get();
    }
    set parsedImages(newValue: string[]) {
        this.__parsedImages.set(newValue);
    }
    private __parsedTags: ObservedPropertyObjectPU<string[]>;
    get parsedTags() {
        return this.__parsedTags.get();
    }
    set parsedTags(newValue: string[]) {
        this.__parsedTags.set(newValue);
    }
    private __isFavorite: ObservedPropertySimplePU<boolean>;
    get isFavorite() {
        return this.__isFavorite.get();
    }
    set isFavorite(newValue: boolean) {
        this.__isFavorite.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    private __sellerPhoneText: ObservedPropertySimplePU<string>;
    get sellerPhoneText() {
        return this.__sellerPhoneText.get();
    }
    set sellerPhoneText(newValue: string) {
        this.__sellerPhoneText.set(newValue);
    }
    private __isSharing: ObservedPropertySimplePU<boolean>;
    get isSharing() {
        return this.__isSharing.get();
    }
    set isSharing(newValue: boolean) {
        this.__isSharing.set(newValue);
    }
    private productId: number;
    aboutToAppear(): void {
        this.resolveId();
        const store: AppStore = AppStore.getInstance();
        this.isLoggedIn = store.isLoggedIn;
        if (this.productId > 0) {
            this.loadDetail();
        }
        else {
            this.errorMsg = '商品ID无效';
            this.isLoading = false;
        }
    }
    private resolveId(): void {
        let id: number = 0;
        try {
            const ctx = this.getUIContext();
            if (ctx !== null && ctx !== undefined) {
                const routerCtx = ctx.getRouter();
                if (routerCtx !== null && routerCtx !== undefined) {
                    const params: Object = routerCtx.getParams();
                    if (params !== null && params !== undefined) {
                        const p: Record<string, Object> = params as Record<string, Object>;
                        let v: Object = p['productId'];
                        if (v === null || v === undefined) {
                            v = p['id'];
                        }
                        if (v !== null && v !== undefined) {
                            if (typeof v === 'number') {
                                id = v as number;
                            }
                            else {
                                const n: number = Number(v as string);
                                if (!isNaN(n)) {
                                    id = n;
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (e) { }
        if (id === 0) {
            try {
                const params: Object = router.getParams();
                if (params !== null && params !== undefined) {
                    const p: Record<string, Object> = params as Record<string, Object>;
                    let v: Object = p['productId'];
                    if (v === null || v === undefined) {
                        v = p['id'];
                    }
                    if (v !== null && v !== undefined) {
                        if (typeof v === 'number') {
                            id = v as number;
                        }
                        else {
                            const n: number = Number(v as string);
                            if (!isNaN(n)) {
                                id = n;
                            }
                        }
                    }
                }
            }
            catch (e) { }
        }
        this.productId = id;
    }
    private async loadDetail(): Promise<void> {
        this.isLoading = true;
        try {
            const result = await ApiService.getProductDetail(this.productId);
            if (result.code === 200 && result.data !== undefined) {
                const obj: Record<string, Object> = result.data as Record<string, Object>;
                const p: Product = new Product();
                p.id = (obj['id'] as number) ?? 0;
                p.sellerId = (obj['sellerId'] as number) ?? 0;
                p.sellerName = (obj['sellerName'] as string) ?? '';
                p.categoryId = (obj['categoryId'] as number) ?? 0;
                p.categoryName = (obj['categoryName'] as string) ?? '';
                p.title = (obj['title'] as string) ?? '';
                p.description = (obj['description'] as string) ?? '';
                p.price = (obj['price'] as number) ?? 0;
                p.originalPrice = (obj['originalPrice'] as number) ?? 0;
                p.conditionLevel = (obj['conditionLevel'] as number) ?? 1;
                p.status = (obj['status'] as number) ?? 1;
                p.viewCount = (obj['viewCount'] as number) ?? 0;
                p.campusLocation = (obj['campusLocation'] as string) ?? '';
                p.createTime = (obj['createTime'] as string) ?? '';
                this.product = p;
                const phObj: Object = obj['sellerPhone'];
                if (phObj !== null && phObj !== undefined) {
                    this.sellerPhoneText = phObj as string;
                }
                else {
                    this.sellerPhoneText = '';
                }
                const imgObj: Object = obj['images'];
                if (imgObj !== null && imgObj !== undefined) {
                    if (typeof imgObj === 'object') {
                        const arr: Object[] = imgObj as Object[];
                        const imgs: string[] = [];
                        for (let k = 0; k < arr.length; k++) {
                            const s: string = arr[k] as string;
                            if (s.length > 0) {
                                imgs.push(s);
                            }
                        }
                        this.parsedImages = imgs;
                    }
                    else {
                        const raw: string = imgObj as string;
                        if (raw.length > 0) {
                            const c: string = raw.replace('[', '').replace(']', '').replace(new RegExp('"', 'g'), '');
                            if (c.length > 0) {
                                this.parsedImages = c.split(',');
                            }
                        }
                    }
                }
                const tagObj: Object = obj['tags'];
                if (tagObj !== null && tagObj !== undefined) {
                    const raw: string = tagObj as string;
                    if (raw.length > 0) {
                        const c: string = raw.replace('[', '').replace(']', '').replace(new RegExp('"', 'g'), '');
                        if (c.length > 0) {
                            this.parsedTags = c.split(',');
                        }
                    }
                }
                if (this.isLoggedIn && p.id > 0) {
                    try {
                        const fav = await ApiService.checkFavorite(p.id);
                        if (fav.code === 200 && fav.data !== undefined) {
                            this.isFavorite = fav.data as boolean;
                        }
                    }
                    catch (_err) { }
                }
            }
            else {
                this.errorMsg = result.msg.length > 0 ? result.msg : '加载失败';
            }
        }
        catch (_err) {
            this.errorMsg = '网络错误，请检查网络连接';
        }
        this.isLoading = false;
    }
    private async toggleFavorite(): Promise<void> {
        if (!this.isLoggedIn) {
            AlertDialog.show({ message: '请先登录', confirm: { value: '好的', action: () => { } } });
            return;
        }
        if (this.isFavorite) {
            const r = await ApiService.removeFavorite(this.product.id);
            if (r.code === 200) {
                this.isFavorite = false;
                promptAction.showToast({ message: '已取消收藏' });
            }
        }
        else {
            const r = await ApiService.addFavorite(this.product.id);
            if (r.code === 200) {
                this.isFavorite = true;
                promptAction.showToast({ message: '已收藏' });
            }
        }
    }
    private contactSeller(): void {
        if (!this.isLoggedIn) {
            AlertDialog.show({ message: '请先登录后联系卖家', confirm: { value: '好的', action: () => { } } });
            return;
        }
        if (this.product.sellerId === 0) {
            AlertDialog.show({ message: '卖家信息异常', confirm: { value: '好的', action: () => { } } });
            return;
        }
        const store: AppStore = AppStore.getInstance();
        if (store.userInfo.id === this.product.sellerId) {
            AlertDialog.show({ message: '这是您自己的商品', confirm: { value: '好的', action: () => { } } });
            return;
        }
        router.pushUrl({
            url: 'pages/ChatPage',
            params: {
                'otherUserId': this.product.sellerId.toString(),
                'otherUserName': this.product.sellerName,
                'productId': this.product.id.toString()
            } as Record<string, string>
        });
    }
    private reportProduct(): void {
        if (!this.isLoggedIn) {
            AlertDialog.show({ message: '请先登录', confirm: { value: '好的', action: () => { } } });
            return;
        }
        const store: AppStore = AppStore.getInstance();
        if (store.userInfo.id === this.product.sellerId) {
            AlertDialog.show({ message: '不能投诉自己的商品', confirm: { value: '好的', action: () => { } } });
            return;
        }
        router.pushUrl({
            url: 'pages/MyComplaintsPage',
            params: {
                'defendantId': this.product.sellerId.toString(),
                'productId': this.product.id.toString(),
                'defendantName': this.product.sellerName
            } as Record<string, string>
        });
    }
    private buildProductCardContent(): string {
        const payload: Record<string, Object> = {
            'productId': this.product.id,
            'title': this.product.title,
            'price': this.product.price,
            'image': this.parsedImages.length > 0 ? this.parsedImages[0] : '',
            'status': this.product.status
        };
        return JSON.stringify(payload);
    }
    private async shareProduct(): Promise<void> {
        if (!this.isLoggedIn) {
            AlertDialog.show({ message: '请先登录后分享商品', confirm: { value: '好的', action: () => { } } });
            return;
        }
        if (this.product.id <= 0 || this.isSharing) {
            return;
        }
        this.isSharing = true;
        const result = await ApiService.getConversations();
        this.isSharing = false;
        if (result.code !== 200 || result.data === undefined) {
            AlertDialog.show({ message: result.msg || '会话加载失败', confirm: { value: '好的', action: () => { } } });
            return;
        }
        const all: Conversation[] = ApiService.parseConversationList(result.data);
        const candidates: Conversation[] = [];
        const options: string[] = [];
        const currentUserId: number = AppStore.getInstance().userInfo.id;
        for (let i = 0; i < all.length; i++) {
            if (all[i].otherUserId > 0 && all[i].otherUserId !== currentUserId) {
                candidates.push(all[i]);
                options.push(all[i].otherUserName.length > 0 ? all[i].otherUserName : `用户${all[i].otherUserId}`);
            }
        }
        if (candidates.length === 0) {
            AlertDialog.show({ message: '暂无可分享的会话，请先和好友建立聊天关系', confirm: { value: '好的', action: () => { } } });
            return;
        }
        TextPickerDialog.show({
            range: options,
            selected: 0,
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < candidates.length) {
                    this.sendProductCard(candidates[idx]);
                }
            }
        });
    }
    private async sendProductCard(target: Conversation): Promise<void> {
        if (this.isSharing) {
            return;
        }
        this.isSharing = true;
        const result = await ApiService.sendMessage(target.id, this.buildProductCardContent(), 'product');
        this.isSharing = false;
        if (result.code === 200) {
            promptAction.showToast({ message: '商品卡片已发送', duration: 1600 });
        }
        else {
            AlertDialog.show({ title: '分享失败', message: result.msg || '请稍后重试', confirm: { value: '好的', action: () => { } } });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(319:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(320:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(322:11)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(323:13)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(48);
                        LoadingProgress.height(48);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('加载中...');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(324:13)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(329:11)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('???');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(330:13)", "entry");
                        Text.fontSize(48);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(331:13)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('重试');
                        Button.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(332:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.primary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 20 });
                        Button.onClick(() => {
                            this.errorMsg = '';
                            this.isLoading = true;
                            this.resolveId();
                            if (this.productId > 0) {
                                this.loadDetail();
                            }
                            else {
                                this.errorMsg = '商品ID无效';
                                this.isLoading = false;
                            }
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(350:11)", "entry");
                        Scroll.layoutWeight(1);
                        Scroll.width('100%');
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(351:13)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 图片轮播
                        if (this.parsedImages.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Swiper.create();
                                    Swiper.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(354:17)", "entry");
                                    Swiper.width('100%');
                                    Swiper.height(300);
                                    Swiper.autoPlay(false);
                                    Swiper.indicator(true);
                                    Swiper.loop(false);
                                }, Swiper);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const img = _item;
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Image.create(ApiService.baseUrl + img);
                                            Image.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(356:21)", "entry");
                                            Image.width('100%');
                                            Image.height(300);
                                            Image.objectFit(ImageFit.Cover);
                                        }, Image);
                                    };
                                    this.forEachUpdateFunction(elmtId, this.parsedImages, forEachItemGenFunction, (img: string) => img, false, false);
                                }, ForEach);
                                ForEach.pop();
                                Swiper.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(368:17)", "entry");
                                    Column.width('100%');
                                    Column.height(300);
                                    Column.backgroundColor(Theme.bgInput);
                                    Column.justifyContent(FlexAlign.Center);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('???');
                                    Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(369:19)", "entry");
                                    Text.fontSize(64);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('暂无图片');
                                    Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(370:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.margin({ top: 8 });
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 基本信息
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(378:15)", "entry");
                        // 基本信息
                        Column.width('100%');
                        // 基本信息
                        Column.padding(18);
                        // 基本信息
                        Column.backgroundColor(Theme.bgCard);
                        // 基本信息
                        Column.borderRadius(Theme.cardRadius);
                        // 基本信息
                        Column.shadow(ShadowStyle.nmRaised);
                        // 基本信息
                        Column.margin({ left: 14, right: 14, top: 12 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(379:17)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.product.title);
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(380:19)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.layoutWeight(1);
                        Text.maxLines(2);
                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(384:19)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(388:17)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(('$') + this.product.price.toFixed(2));
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(389:19)", "entry");
                        Text.fontSize(28);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Theme.primary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.product.originalPrice > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(('$') + this.product.originalPrice.toFixed(2));
                                    Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(392:21)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.decoration({ type: TextDecorationType.LineThrough });
                                    Text.margin({ left: 8 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(397:19)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(401:17)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(STATUS_LABELS[Math.max(0, Math.min(this.product.status, 3))]);
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(402:19)", "entry");
                        Text.fontSize(12);
                        Text.fontColor('#FFFFFF');
                        Text.backgroundColor(STATUS_COLORS[Math.max(0, Math.min(this.product.status, 3))]);
                        Text.borderRadius(4);
                        Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(CONDITION_LABELS[Math.max(0, Math.min(this.product.conditionLevel, 3))]);
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(406:19)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.primary);
                        Text.backgroundColor(Theme.primaryLight);
                        Text.borderRadius(4);
                        Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                        Text.margin({ left: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.product.categoryName.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.product.categoryName);
                                    Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(412:21)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textSecondary);
                                    Text.backgroundColor(Theme.bgPage);
                                    Text.borderRadius(4);
                                    Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                                    Text.margin({ left: 8 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(418:19)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    // 基本信息
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(426:15)", "entry");
                        Blank.height(12);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 卖家信息 + 电话
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(429:15)", "entry");
                        // 卖家信息 + 电话
                        Row.width('100%');
                        // 卖家信息 + 电话
                        Row.padding(18);
                        // 卖家信息 + 电话
                        Row.backgroundColor(Theme.bgCard);
                        // 卖家信息 + 电话
                        Row.borderRadius(Theme.cardRadius);
                        // 卖家信息 + 电话
                        Row.shadow(ShadowStyle.nmRaised);
                        // 卖家信息 + 电话
                        Row.margin({ left: 14, right: 14 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(430:17)", "entry");
                        Column.alignItems(HorizontalAlign.Start);
                        Column.margin({ right: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.product.sellerName);
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(431:19)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(FontWeight.Medium);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('卖家');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(432:19)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 2 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.sellerPhoneText.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('??? ' + this.sellerPhoneText);
                                    Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(434:21)", "entry");
                                    Text.fontSize(13);
                                    Text.fontColor(Theme.primary);
                                    Text.margin({ top: 4 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.product.campusLocation.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Divider.create();
                                    Divider.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(443:19)", "entry");
                                    Divider.vertical(true);
                                    Divider.height(30);
                                    Divider.color(Theme.border);
                                }, Divider);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(444:19)", "entry");
                                    Column.alignItems(HorizontalAlign.Center);
                                    Column.margin({ left: 16 });
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('交易地点');
                                    Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(445:21)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textTertiary);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.product.campusLocation);
                                    Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(446:21)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textPrimary);
                                    Text.margin({ top: 2 });
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(450:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(451:17)", "entry");
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('浏览量');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(452:19)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.product.viewCount.toString());
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(453:19)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.margin({ top: 2 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    // 卖家信息 + 电话
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(462:15)", "entry");
                        Blank.height(12);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 商品描述
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(465:15)", "entry");
                        // 商品描述
                        Column.width('100%');
                        // 商品描述
                        Column.padding(18);
                        // 商品描述
                        Column.backgroundColor(Theme.bgCard);
                        // 商品描述
                        Column.borderRadius(Theme.cardRadius);
                        // 商品描述
                        Column.shadow(ShadowStyle.nmRaised);
                        // 商品描述
                        Column.margin({ left: 14, right: 14 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(466:17)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('商品描述');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(467:19)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(FontWeight.Bold);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(468:19)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.product.description.length > 0 ? this.product.description : '暂无描述');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(471:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.width('100%');
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    // 商品描述
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(478:15)", "entry");
                        Blank.height(12);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 标签
                        if (this.parsedTags.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(482:17)", "entry");
                                    Column.width('100%');
                                    Column.padding(18);
                                    Column.backgroundColor(Theme.bgCard);
                                    Column.borderRadius(Theme.cardRadius);
                                    Column.shadow(ShadowStyle.nmRaised);
                                    Column.margin({ left: 14, right: 14 });
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(483:19)", "entry");
                                    Row.width('100%');
                                    Row.margin({ bottom: 8 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('标签');
                                    Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(484:21)", "entry");
                                    Text.fontSize(16);
                                    Text.fontWeight(FontWeight.Bold);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Blank.create();
                                    Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(485:21)", "entry");
                                }, Blank);
                                Blank.pop();
                                Row.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Flex.create({ wrap: FlexWrap.Wrap });
                                    Flex.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(488:19)", "entry");
                                    Flex.width('100%');
                                }, Flex);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const tag = _item;
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(tag);
                                            Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(490:23)", "entry");
                                            Text.fontSize(12);
                                            Text.fontColor(Theme.primary);
                                            Text.backgroundColor(Theme.primaryLight);
                                            Text.borderRadius(12);
                                            Text.padding({ left: 10, right: 10, top: 3, bottom: 3 });
                                            Text.margin({ right: 8, bottom: 4 });
                                        }, Text);
                                        Text.pop();
                                    };
                                    this.forEachUpdateFunction(elmtId, this.parsedTags, forEachItemGenFunction, (tag: string) => tag, false, false);
                                }, ForEach);
                                ForEach.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Blank.create();
                                    Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(497:21)", "entry");
                                }, Blank);
                                Blank.pop();
                                Flex.pop();
                                Column.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Blank.create();
                                    Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(504:17)", "entry");
                                    Blank.height(12);
                                }, Blank);
                                Blank.pop();
                            });
                        }
                        // 时间信息
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 时间信息
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(508:15)", "entry");
                        // 时间信息
                        Column.width('100%');
                        // 时间信息
                        Column.padding(18);
                        // 时间信息
                        Column.backgroundColor(Theme.bgCard);
                        // 时间信息
                        Column.borderRadius(Theme.cardRadius);
                        // 时间信息
                        Column.shadow(ShadowStyle.nmRaised);
                        // 时间信息
                        Column.margin({ left: 14, right: 14 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(509:17)", "entry");
                        Row.width('100%');
                        Row.padding({ top: 4, bottom: 4 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('发布时间');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(510:19)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textTertiary);
                        Text.width(80);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(this.product.createTime));
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(511:19)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(512:19)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    // 时间信息
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(520:15)", "entry");
                        Blank.height(16);
                    }, Blank);
                    Blank.pop();
                    Column.pop();
                    Scroll.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(525:11)", "entry");
                        Row.width('100%');
                        Row.height(64);
                        Row.padding({ left: 16, right: 16 });
                        Row.backgroundColor(Theme.bgCard);
                        Row.shadow(ShadowStyle.nmRaised);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(526:13)", "entry");
                        Column.width(48);
                        Column.height(48);
                        Column.backgroundColor(this.isFavorite ? Theme.primaryLight : Theme.bgPage);
                        Column.borderRadius(24);
                        Column.justifyContent(FlexAlign.Center);
                        Column.onClick(() => { this.toggleFavorite(); });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.isFavorite ? '❤️' : '🤍');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(527:15)", "entry");
                        Text.fontSize(22);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(535:13)", "entry");
                        Column.width(48);
                        Column.height(48);
                        Column.backgroundColor(Theme.bgPage);
                        Column.borderRadius(24);
                        Column.margin({ left: 10 });
                        Column.justifyContent(FlexAlign.Center);
                        Column.onClick(() => { this.reportProduct(); });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('⚠️');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(536:15)", "entry");
                        Text.fontSize(20);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(545:13)", "entry");
                        Column.width(54);
                        Column.height(48);
                        Column.backgroundColor(Theme.primaryLight);
                        Column.borderRadius(24);
                        Column.margin({ left: 10 });
                        Column.justifyContent(FlexAlign.Center);
                        Column.onClick(() => { this.shareProduct(); });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.isSharing ? '...' : '分享');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(546:15)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.primary);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(555:13)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('联系卖家');
                        Button.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(557:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.primary);
                        Button.fontColor('#FFFFFF');
                        Button.borderRadius(22);
                        Button.height(44);
                        Button.padding({ left: 28, right: 28 });
                        Button.onClick(() => { this.contactSeller(); });
                    }, Button);
                    Button.pop();
                    Row.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 左上角悬浮返回按钮
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(576:7)", "entry");
            // 左上角悬浮返回按钮
            Row.width(36);
            // 左上角悬浮返回按钮
            Row.height(36);
            // 左上角悬浮返回按钮
            Row.backgroundColor('rgba(0,0,0,0.3)');
            // 左上角悬浮返回按钮
            Row.borderRadius(18);
            // 左上角悬浮返回按钮
            Row.justifyContent(FlexAlign.Center);
            // 左上角悬浮返回按钮
            Row.alignItems(VerticalAlign.Center);
            // 左上角悬浮返回按钮
            Row.position({ x: 15, y: 44 });
            // 左上角悬浮返回按钮
            Row.onClick(() => { router.back(); });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('<');
            Text.debugLine("entry/src/main/ets/pages/ProductDetailPage.ets(577:9)", "entry");
            Text.fontSize(28);
            Text.fontColor('#FFFFFF');
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        // 左上角悬浮返回按钮
        Row.pop();
        Stack.pop();
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0) {
            return '';
        }
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16) {
            return t.substring(0, 16);
        }
        return t;
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "ProductDetailPage";
    }
}
registerNamedRoute(() => new ProductDetailPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/ProductDetailPage", pageFullPath: "entry/src/main/ets/pages/ProductDetailPage", integratedHsp: "false", moduleType: "followWithHap" });
