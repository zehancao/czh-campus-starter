if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LostFoundListPage_Params {
    items?: LostFoundItem[];
    activeTab?: number;
    keywordValue?: string;
    isLoading?: boolean;
    currentPage?: number;
    hasMore?: boolean;
    isLoadingMore?: boolean;
}
interface LFListCard_Params {
    itemData?: LostFoundItem;
    onTapCallback?: () => void;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { LostFoundItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const TYPE_TABS: string[] = ['全部', '寻物', '招领'];
const STATUS_LABELS: string[] = ['进行中', '已找到'];
const PAGE_SIZE: number = 20;
class LFListCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.itemData = new LostFoundItem();
        this.onTapCallback = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LFListCard_Params) {
        if (params.itemData !== undefined) {
            this.itemData = params.itemData;
        }
        if (params.onTapCallback !== undefined) {
            this.onTapCallback = params.onTapCallback;
        }
    }
    updateStateVars(params: LFListCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private itemData: LostFoundItem;
    private onTapCallback?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(17:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(Theme.cardRadius);
            Row.margin({ bottom: 8 });
            Row.shadow(ShadowStyle.sm);
            Row.onClick(() => {
                if (this.onTapCallback !== undefined) {
                    this.onTapCallback();
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(18:7)", "entry");
            Column.width(60);
            Column.height(60);
            Column.backgroundColor(Theme.secondaryLight);
            Column.borderRadius(Theme.radiusMd);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.getFirstImageUrl().length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(`${ApiService.baseUrl}${this.getFirstImageUrl()}`);
                        Image.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(20:11)", "entry");
                        Image.width(60);
                        Image.height(60);
                        Image.borderRadius(Theme.radiusMd);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.type === 1 ? '🔍' : '📢');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(23:11)", "entry");
                        Text.fontSize(28);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.type === 1 ? '寻物' : '招领');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(25:11)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.secondary);
                        Text.margin({ top: 2 });
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(34:7)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(35:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.title);
            Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(36:11)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(STATUS_LABELS[Math.max(0, Math.min(this.itemData.status - 1, 1))]);
            Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(40:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(this.itemData.status === 1 ? Theme.warning : Theme.success);
            Text.backgroundColor(this.itemData.status === 1 ? Theme.warningLight : Theme.successLight);
            Text.borderRadius(4);
            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.description);
            Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(49:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(55:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 6 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.itemData.category.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.category);
                        Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(57:13)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.textTertiary);
                        Text.backgroundColor(Theme.bgPage);
                        Text.borderRadius(4);
                        Text.padding({ left: 6, right: 6, top: 1, bottom: 1 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.itemData.locationDesc.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.locationDesc);
                        Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(62:13)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.textTertiary);
                        Text.backgroundColor(Theme.bgPage);
                        Text.borderRadius(4);
                        Text.padding({ left: 6, right: 6, top: 1, bottom: 1 });
                        Text.margin({ left: 6 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(67:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.userName);
            Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(68:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(' | ');
            Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(70:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.formatTime(this.itemData.createTime));
            Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(72:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0) {
            return '';
        }
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16) {
            return t.substring(0, 16);
        }
        return t;
    }
    private getFirstImageUrl(): string {
        const raw: string = this.itemData.images;
        if (raw.length === 0) {
            return '';
        }
        let s: string = raw.trim();
        if (s.startsWith('[')) {
            s = s.substring(1);
        }
        if (s.endsWith(']')) {
            s = s.substring(0, s.length - 1);
        }
        s = s.replace(new RegExp('"', 'g'), '').replace(new RegExp("'", 'g'), '');
        s = s.trim();
        if (s.length === 0) {
            return '';
        }
        return s.split(',')[0].trim();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class LostFoundListPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__items = new ObservedPropertyObjectPU([], this, "items");
        this.__activeTab = new ObservedPropertySimplePU(0, this, "activeTab");
        this.__keywordValue = new ObservedPropertySimplePU('', this, "keywordValue");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__currentPage = new ObservedPropertySimplePU(1, this, "currentPage");
        this.__hasMore = new ObservedPropertySimplePU(true, this, "hasMore");
        this.__isLoadingMore = new ObservedPropertySimplePU(false, this, "isLoadingMore");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LostFoundListPage_Params) {
        if (params.items !== undefined) {
            this.items = params.items;
        }
        if (params.activeTab !== undefined) {
            this.activeTab = params.activeTab;
        }
        if (params.keywordValue !== undefined) {
            this.keywordValue = params.keywordValue;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
        if (params.hasMore !== undefined) {
            this.hasMore = params.hasMore;
        }
        if (params.isLoadingMore !== undefined) {
            this.isLoadingMore = params.isLoadingMore;
        }
    }
    updateStateVars(params: LostFoundListPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__items.purgeDependencyOnElmtId(rmElmtId);
        this.__activeTab.purgeDependencyOnElmtId(rmElmtId);
        this.__keywordValue.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
        this.__hasMore.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoadingMore.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__items.aboutToBeDeleted();
        this.__activeTab.aboutToBeDeleted();
        this.__keywordValue.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__currentPage.aboutToBeDeleted();
        this.__hasMore.aboutToBeDeleted();
        this.__isLoadingMore.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __items: ObservedPropertyObjectPU<LostFoundItem[]>;
    get items() {
        return this.__items.get();
    }
    set items(newValue: LostFoundItem[]) {
        this.__items.set(newValue);
    }
    private __activeTab: ObservedPropertySimplePU<number>;
    get activeTab() {
        return this.__activeTab.get();
    }
    set activeTab(newValue: number) {
        this.__activeTab.set(newValue);
    }
    private __keywordValue: ObservedPropertySimplePU<string>;
    get keywordValue() {
        return this.__keywordValue.get();
    }
    set keywordValue(newValue: string) {
        this.__keywordValue.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __currentPage: ObservedPropertySimplePU<number>;
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: number) {
        this.__currentPage.set(newValue);
    }
    private __hasMore: ObservedPropertySimplePU<boolean>;
    get hasMore() {
        return this.__hasMore.get();
    }
    set hasMore(newValue: boolean) {
        this.__hasMore.set(newValue);
    }
    private __isLoadingMore: ObservedPropertySimplePU<boolean>;
    get isLoadingMore() {
        return this.__isLoadingMore.get();
    }
    set isLoadingMore(newValue: boolean) {
        this.__isLoadingMore.set(newValue);
    }
    onPageShow(): void {
        this.refreshList();
    }
    private async refreshList(): Promise<void> {
        this.isLoading = true;
        this.currentPage = 1;
        this.hasMore = true;
        let typeVal: number = 0;
        if (this.activeTab === 1) {
            typeVal = 1;
        }
        if (this.activeTab === 2) {
            typeVal = 2;
        }
        try {
            const list: LostFoundItem[] = await ApiService.getLostFoundList(typeVal, this.keywordValue, this.currentPage);
            this.items = list;
            this.hasMore = list.length >= PAGE_SIZE;
        }
        catch (err) {
            console.error("加载列表异常", JSON.stringify(err));
            this.items = [];
        }
        finally {
            this.isLoading = false;
        }
    }
    private async loadMore(): Promise<void> {
        if (this.isLoadingMore || !this.hasMore) {
            return;
        }
        this.isLoadingMore = true;
        let typeVal: number = 0;
        if (this.activeTab === 1) {
            typeVal = 1;
        }
        if (this.activeTab === 2) {
            typeVal = 2;
        }
        this.currentPage = this.currentPage + 1;
        try {
            const newItems: LostFoundItem[] = await ApiService.getLostFoundList(typeVal, this.keywordValue, this.currentPage);
            this.items = [...this.items, ...newItems];
            this.hasMore = newItems.length >= PAGE_SIZE;
        }
        catch (err) {
            console.error("加载更多异常", JSON.stringify(err));
        }
        finally {
            this.isLoadingMore = false;
        }
    }
    private onTabChange(index: number): void {
        this.activeTab = index;
        this.refreshList();
    }
    private goToDetail(item: LostFoundItem): void {
        try {
            router.pushUrl({
                url: 'pages/LostFoundDetailPage',
                params: { 'id': item.id.toString() } as Record<string, string>
            });
        }
        catch (e) {
            console.error("跳转详情页失败", e);
        }
    }
    private goToPublish(): void {
        try {
            router.pushUrl({ url: 'pages/LostFoundPublishPage' });
        }
        catch (e) {
            console.error("跳转发布页失败", e);
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(214:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '失物招领',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('发布');
                                Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(216:9)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(Theme.secondary);
                                Text.onClick(() => { this.goToPublish(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundListPage.ets", line: 215, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '失物招领',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('发布');
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(216:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.secondary);
                                    Text.onClick(() => { this.goToPublish(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '失物招领'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(219:7)", "entry");
            Row.width('100%');
            Row.padding({ left: 16, right: 16, top: 4, bottom: 8 });
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '搜索失物或招领…', text: this.keywordValue });
            TextInput.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(220:9)", "entry");
            TextInput.width('85%');
            TextInput.height(36);
            TextInput.fontSize(14);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(Theme.radiusPill);
            TextInput.padding({ left: 16 });
            TextInput.onChange((val: string) => { this.keywordValue = val; });
            TextInput.onSubmit(() => { this.refreshList(); });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(229:9)", "entry");
        }, Blank);
        Blank.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(235:7)", "entry");
            Row.width('100%');
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const tab = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(237:11)", "entry");
                    Column.layoutWeight(1);
                    Column.alignItems(HorizontalAlign.Center);
                    Column.padding({ top: 4, bottom: 4 });
                    Column.onClick(() => { this.onTabChange(index); });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(tab);
                    Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(238:13)", "entry");
                    Text.fontSize(15);
                    Text.fontColor(this.activeTab === index ? Theme.secondary : Theme.textSecondary);
                    Text.fontWeight(this.activeTab === index ? FontWeight.Medium : FontWeight.Regular);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(242:13)", "entry");
                    Divider.height(2);
                    Divider.width(24);
                    Divider.color(this.activeTab === index ? Theme.secondary : 'transparent');
                    Divider.borderRadius(1);
                    Divider.margin({ top: 4 });
                }, Divider);
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, TYPE_TABS, forEachItemGenFunction, (tab: string) => tab, true, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(258:7)", "entry");
            Divider.height(1);
            Divider.color(Theme.border);
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 0 });
            List.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(260:7)", "entry");
            List.layoutWeight(1);
            List.edgeEffect(EdgeEffect.Spring);
            List.padding({ left: 12, right: 12, top: 4, bottom: 20 });
            List.onReachEnd(() => { this.loadMore(); });
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, true);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(261:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(262:11)", "entry");
                    Row.width('100%');
                    Row.padding({ left: 16, right: 16, bottom: 8 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('共 ' + this.items.length + ' 条');
                    Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(263:13)", "entry");
                    Text.fontSize(12);
                    Text.fontColor(Theme.textTertiary);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Blank.create();
                    Blank.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(265:13)", "entry");
                }, Blank);
                Blank.pop();
                Row.pop();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.items.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(273:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new LFListCard(this, {
                                                    itemData: item,
                                                    onTapCallback: () => this.goToDetail(item)
                                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundListPage.ets", line: 274, col: 15 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {
                                                        itemData: item,
                                                        onTapCallback: () => this.goToDetail(item)
                                                    };
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "LFListCard" });
                                    }
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.items, forEachItemGenFunction, (item: LostFoundItem) => item.id.toString(), false, false);
                    }, ForEach);
                    ForEach.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    {
                        const itemCreation = (elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            ListItem.create(deepRenderFunction, true);
                            if (!isInitialRender) {
                                ListItem.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        };
                        const itemCreation2 = (elmtId, isInitialRender) => {
                            ListItem.create(deepRenderFunction, true);
                            ListItem.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(281:11)", "entry");
                        };
                        const deepRenderFunction = (elmtId, isInitialRender) => {
                            itemCreation(elmtId, isInitialRender);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(282:13)", "entry");
                                Column.width('100%');
                                Column.alignItems(HorizontalAlign.Center);
                                Column.margin({ top: 40 });
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('🕊️');
                                Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(283:15)", "entry");
                                Text.fontSize(56);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.keywordValue.length > 0 ? '没有找到相关结果' : '暂无失物招领信息');
                                Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(284:15)", "entry");
                                Text.fontSize(15);
                                Text.fontColor(Theme.textSecondary);
                                Text.margin({ top: 8 });
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.keywordValue.length > 0) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('试试其他关键词');
                                            Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(287:17)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.margin({ top: 4 });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('点击右上角"发布"发布失物或招领信息');
                                            Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(290:17)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.margin({ top: 4 });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                            }, If);
                            If.pop();
                            Column.pop();
                            ListItem.pop();
                        };
                        this.observeComponentCreation2(itemCreation2, ListItem);
                        ListItem.pop();
                    }
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.hasMore && this.items.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        const itemCreation = (elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            ListItem.create(deepRenderFunction, true);
                            if (!isInitialRender) {
                                ListItem.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        };
                        const itemCreation2 = (elmtId, isInitialRender) => {
                            ListItem.create(deepRenderFunction, true);
                            ListItem.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(301:11)", "entry");
                        };
                        const deepRenderFunction = (elmtId, isInitialRender) => {
                            itemCreation(elmtId, isInitialRender);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(302:13)", "entry");
                                Row.width('100%');
                                Row.justifyContent(FlexAlign.Center);
                                Row.padding({ top: 12, bottom: 12 });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                LoadingProgress.create();
                                LoadingProgress.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(303:15)", "entry");
                                LoadingProgress.width(20);
                                LoadingProgress.height(20);
                            }, LoadingProgress);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('加载更多...');
                                Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(304:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(Theme.textTertiary);
                                Text.margin({ left: 8 });
                            }, Text);
                            Text.pop();
                            Row.pop();
                            ListItem.pop();
                        };
                        this.observeComponentCreation2(itemCreation2, ListItem);
                        ListItem.pop();
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.hasMore && this.items.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        const itemCreation = (elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            ListItem.create(deepRenderFunction, true);
                            if (!isInitialRender) {
                                ListItem.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        };
                        const itemCreation2 = (elmtId, isInitialRender) => {
                            ListItem.create(deepRenderFunction, true);
                            ListItem.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(314:11)", "entry");
                        };
                        const deepRenderFunction = (elmtId, isInitialRender) => {
                            itemCreation(elmtId, isInitialRender);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('- 没有更多了 -');
                                Text.debugLine("entry/src/main/ets/pages/LostFoundListPage.ets(315:13)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(Theme.textTertiary);
                                Text.width('100%');
                                Text.textAlign(TextAlign.Center);
                                Text.padding({ top: 12, bottom: 12 });
                            }, Text);
                            Text.pop();
                            ListItem.pop();
                        };
                        this.observeComponentCreation2(itemCreation2, ListItem);
                        ListItem.pop();
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "LostFoundListPage";
    }
}
registerNamedRoute(() => new LostFoundListPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/LostFoundListPage", pageFullPath: "entry/src/main/ets/pages/LostFoundListPage", integratedHsp: "false", moduleType: "followWithHap" });
