if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MainPage_Params {
    currentTab?: number;
    userInfo?: UserInfo;
    scheduleList?: CourseSchedule[];
    announcements?: Announcement[];
    myActivities?: ClubActivityItem[];
    myCarpools?: CarpoolOrder[];
    products?: Product[];
    productPage?: number;
    productHasMore?: boolean;
    productLoadingMore?: boolean;
    productError?: string;
    todayCourses?: CourseSchedule[];
    scheduleGrid?: CourseSchedule[][];
    isRefreshing?: boolean;
    currentWeek?: number;
    todayWeek?: number;
    semesterId?: number;
    semesterWeekCount?: number;
    semesterName?: string;
    semesterStartDate?: string;
    unreadCount?: number;
    conversations?: Conversation[];
    onlineUserIds?: number[];
    conversationKeyword?: string;
    conversationLoading?: boolean;
    conversationError?: string;
    conversationLoadedOnce?: boolean;
    categories?: ProductCategory[];
    selectedCategoryId?: number;
    showAddCourseForm?: boolean;
    showCourseDetail?: boolean;
    selectedCourse?: CourseSchedule;
    addCourseName?: string;
    addClassroom?: string;
    addTeacherName?: string;
    addDayOfWeek?: number;
    addStartSection?: number;
    addEndSection?: number;
    addStartWeek?: number;
    addEndWeek?: number;
    mainWsCallback?: MessageCallback | null;
    aiMessages?: AiMsg[];
    aiInputText?: string;
    aiIsLoading?: boolean;
    aiStreamingIndex?: number;
    aiThinking?: boolean;
    aiStreamText?: string;
    aiScroller?: Scroller;
    textDecoder?: util.TextDecoder;
    aiHttpRequest?: http.HttpRequest | null;
    aiPendingText?: string;
    aiFlushTimer?: number;
    searchKeyword?: string;
    searchSuggestions?: string[];
    showSuggestions?: boolean;
    marketRefreshing?: boolean;
}
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { UserInfo, CourseSchedule, Product, ClubActivityItem, Conversation, ChatMessage } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import type { Announcement, Semester, ProductCategory, CarpoolOrder } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { WebSocketService } from "@normalized:N&&&entry/src/main/ets/service/WebSocketService&";
import type { WsMessage, MessageCallback } from "@normalized:N&&&entry/src/main/ets/service/WebSocketService&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { AvatarView } from "@normalized:N&&&entry/src/main/ets/common/AvatarView&";
import { WidgetDataHelper } from "@normalized:N&&&entry/src/main/ets/service/WidgetDataHelper&";
import http from "@ohos:net.http";
import util from "@ohos:util";
import router from "@ohos:router";
import type { BusinessError } from "@ohos:base";
import { calcSemesterWeek, semesterWeekDate } from "@normalized:N&&&entry/src/main/ets/common/utils&";
interface TimelineItem {
    time: string;
    title: string;
    location: string;
    type: number; // 0 = 课程, 1 = 活动
    courseData: CourseSchedule | null;
    activityData: ClubActivityItem | null;
}
const WEEK_DAY_LABELS: string[] = ['一', '二', '三', '四', '五', '六', '日'];
const SCHEDULE_SECTION_HEIGHT: number = 66;
class MainPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentTab = new ObservedPropertySimplePU(0, this, "currentTab");
        this.__userInfo = new ObservedPropertyObjectPU(new UserInfo(), this, "userInfo");
        this.__scheduleList = new ObservedPropertyObjectPU([], this, "scheduleList");
        this.__announcements = new ObservedPropertyObjectPU([], this, "announcements");
        this.__myActivities = new ObservedPropertyObjectPU([], this, "myActivities");
        this.__myCarpools = new ObservedPropertyObjectPU([], this, "myCarpools");
        this.__products = new ObservedPropertyObjectPU([], this, "products");
        this.__productPage = new ObservedPropertySimplePU(1, this, "productPage");
        this.__productHasMore = new ObservedPropertySimplePU(true, this, "productHasMore");
        this.__productLoadingMore = new ObservedPropertySimplePU(false, this, "productLoadingMore");
        this.__productError = new ObservedPropertySimplePU('', this, "productError");
        this.__todayCourses = new ObservedPropertyObjectPU([], this, "todayCourses");
        this.__scheduleGrid = new ObservedPropertyObjectPU([], this, "scheduleGrid");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.__currentWeek = new ObservedPropertySimplePU(1, this, "currentWeek");
        this.__todayWeek = new ObservedPropertySimplePU(1, this, "todayWeek");
        this.__semesterId = new ObservedPropertySimplePU(0, this, "semesterId");
        this.__semesterWeekCount = new ObservedPropertySimplePU(20, this, "semesterWeekCount");
        this.__semesterName = new ObservedPropertySimplePU('', this, "semesterName");
        this.__semesterStartDate = new ObservedPropertySimplePU('', this, "semesterStartDate");
        this.__unreadCount = new ObservedPropertySimplePU(0, this, "unreadCount");
        this.__conversations = new ObservedPropertyObjectPU([], this, "conversations");
        this.__onlineUserIds = new ObservedPropertyObjectPU([], this, "onlineUserIds");
        this.__conversationKeyword = new ObservedPropertySimplePU('', this, "conversationKeyword");
        this.__conversationLoading = new ObservedPropertySimplePU(true, this, "conversationLoading");
        this.__conversationError = new ObservedPropertySimplePU('', this, "conversationError");
        this.conversationLoadedOnce = false;
        this.__categories = new ObservedPropertyObjectPU([], this, "categories");
        this.__selectedCategoryId = new ObservedPropertySimplePU(0, this, "selectedCategoryId");
        this.__showAddCourseForm = new ObservedPropertySimplePU(false, this, "showAddCourseForm");
        this.__showCourseDetail = new ObservedPropertySimplePU(false, this, "showCourseDetail");
        this.__selectedCourse = new ObservedPropertyObjectPU(new CourseSchedule(), this, "selectedCourse");
        this.__addCourseName = new ObservedPropertySimplePU('', this, "addCourseName");
        this.__addClassroom = new ObservedPropertySimplePU('', this, "addClassroom");
        this.__addTeacherName = new ObservedPropertySimplePU('', this, "addTeacherName");
        this.__addDayOfWeek = new ObservedPropertySimplePU(1, this, "addDayOfWeek");
        this.__addStartSection = new ObservedPropertySimplePU(1, this, "addStartSection");
        this.__addEndSection = new ObservedPropertySimplePU(2, this, "addEndSection");
        this.__addStartWeek = new ObservedPropertySimplePU(1, this, "addStartWeek");
        this.__addEndWeek = new ObservedPropertySimplePU(20, this, "addEndWeek");
        this.mainWsCallback = null;
        this.__aiMessages = new ObservedPropertyObjectPU([], this, "aiMessages");
        this.__aiInputText = new ObservedPropertySimplePU('', this, "aiInputText");
        this.__aiIsLoading = new ObservedPropertySimplePU(false, this, "aiIsLoading");
        this.__aiStreamingIndex = new ObservedPropertySimplePU(-1, this, "aiStreamingIndex");
        this.__aiThinking = new ObservedPropertySimplePU(false, this, "aiThinking");
        this.__aiStreamText = new ObservedPropertySimplePU('', this, "aiStreamText");
        this.aiScroller = new Scroller();
        this.textDecoder = new util.TextDecoder('utf-8');
        this.aiHttpRequest = null;
        this.aiPendingText = '';
        this.aiFlushTimer = -1;
        this.__searchKeyword = new ObservedPropertySimplePU('', this, "searchKeyword");
        this.__searchSuggestions = new ObservedPropertyObjectPU([], this, "searchSuggestions");
        this.__showSuggestions = new ObservedPropertySimplePU(false, this, "showSuggestions");
        this.__marketRefreshing = new ObservedPropertySimplePU(false, this, "marketRefreshing");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MainPage_Params) {
        if (params.currentTab !== undefined) {
            this.currentTab = params.currentTab;
        }
        if (params.userInfo !== undefined) {
            this.userInfo = params.userInfo;
        }
        if (params.scheduleList !== undefined) {
            this.scheduleList = params.scheduleList;
        }
        if (params.announcements !== undefined) {
            this.announcements = params.announcements;
        }
        if (params.myActivities !== undefined) {
            this.myActivities = params.myActivities;
        }
        if (params.myCarpools !== undefined) {
            this.myCarpools = params.myCarpools;
        }
        if (params.products !== undefined) {
            this.products = params.products;
        }
        if (params.productPage !== undefined) {
            this.productPage = params.productPage;
        }
        if (params.productHasMore !== undefined) {
            this.productHasMore = params.productHasMore;
        }
        if (params.productLoadingMore !== undefined) {
            this.productLoadingMore = params.productLoadingMore;
        }
        if (params.productError !== undefined) {
            this.productError = params.productError;
        }
        if (params.todayCourses !== undefined) {
            this.todayCourses = params.todayCourses;
        }
        if (params.scheduleGrid !== undefined) {
            this.scheduleGrid = params.scheduleGrid;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.currentWeek !== undefined) {
            this.currentWeek = params.currentWeek;
        }
        if (params.todayWeek !== undefined) {
            this.todayWeek = params.todayWeek;
        }
        if (params.semesterId !== undefined) {
            this.semesterId = params.semesterId;
        }
        if (params.semesterWeekCount !== undefined) {
            this.semesterWeekCount = params.semesterWeekCount;
        }
        if (params.semesterName !== undefined) {
            this.semesterName = params.semesterName;
        }
        if (params.semesterStartDate !== undefined) {
            this.semesterStartDate = params.semesterStartDate;
        }
        if (params.unreadCount !== undefined) {
            this.unreadCount = params.unreadCount;
        }
        if (params.conversations !== undefined) {
            this.conversations = params.conversations;
        }
        if (params.onlineUserIds !== undefined) {
            this.onlineUserIds = params.onlineUserIds;
        }
        if (params.conversationKeyword !== undefined) {
            this.conversationKeyword = params.conversationKeyword;
        }
        if (params.conversationLoading !== undefined) {
            this.conversationLoading = params.conversationLoading;
        }
        if (params.conversationError !== undefined) {
            this.conversationError = params.conversationError;
        }
        if (params.conversationLoadedOnce !== undefined) {
            this.conversationLoadedOnce = params.conversationLoadedOnce;
        }
        if (params.categories !== undefined) {
            this.categories = params.categories;
        }
        if (params.selectedCategoryId !== undefined) {
            this.selectedCategoryId = params.selectedCategoryId;
        }
        if (params.showAddCourseForm !== undefined) {
            this.showAddCourseForm = params.showAddCourseForm;
        }
        if (params.showCourseDetail !== undefined) {
            this.showCourseDetail = params.showCourseDetail;
        }
        if (params.selectedCourse !== undefined) {
            this.selectedCourse = params.selectedCourse;
        }
        if (params.addCourseName !== undefined) {
            this.addCourseName = params.addCourseName;
        }
        if (params.addClassroom !== undefined) {
            this.addClassroom = params.addClassroom;
        }
        if (params.addTeacherName !== undefined) {
            this.addTeacherName = params.addTeacherName;
        }
        if (params.addDayOfWeek !== undefined) {
            this.addDayOfWeek = params.addDayOfWeek;
        }
        if (params.addStartSection !== undefined) {
            this.addStartSection = params.addStartSection;
        }
        if (params.addEndSection !== undefined) {
            this.addEndSection = params.addEndSection;
        }
        if (params.addStartWeek !== undefined) {
            this.addStartWeek = params.addStartWeek;
        }
        if (params.addEndWeek !== undefined) {
            this.addEndWeek = params.addEndWeek;
        }
        if (params.mainWsCallback !== undefined) {
            this.mainWsCallback = params.mainWsCallback;
        }
        if (params.aiMessages !== undefined) {
            this.aiMessages = params.aiMessages;
        }
        if (params.aiInputText !== undefined) {
            this.aiInputText = params.aiInputText;
        }
        if (params.aiIsLoading !== undefined) {
            this.aiIsLoading = params.aiIsLoading;
        }
        if (params.aiStreamingIndex !== undefined) {
            this.aiStreamingIndex = params.aiStreamingIndex;
        }
        if (params.aiThinking !== undefined) {
            this.aiThinking = params.aiThinking;
        }
        if (params.aiStreamText !== undefined) {
            this.aiStreamText = params.aiStreamText;
        }
        if (params.aiScroller !== undefined) {
            this.aiScroller = params.aiScroller;
        }
        if (params.textDecoder !== undefined) {
            this.textDecoder = params.textDecoder;
        }
        if (params.aiHttpRequest !== undefined) {
            this.aiHttpRequest = params.aiHttpRequest;
        }
        if (params.aiPendingText !== undefined) {
            this.aiPendingText = params.aiPendingText;
        }
        if (params.aiFlushTimer !== undefined) {
            this.aiFlushTimer = params.aiFlushTimer;
        }
        if (params.searchKeyword !== undefined) {
            this.searchKeyword = params.searchKeyword;
        }
        if (params.searchSuggestions !== undefined) {
            this.searchSuggestions = params.searchSuggestions;
        }
        if (params.showSuggestions !== undefined) {
            this.showSuggestions = params.showSuggestions;
        }
        if (params.marketRefreshing !== undefined) {
            this.marketRefreshing = params.marketRefreshing;
        }
    }
    updateStateVars(params: MainPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentTab.purgeDependencyOnElmtId(rmElmtId);
        this.__userInfo.purgeDependencyOnElmtId(rmElmtId);
        this.__scheduleList.purgeDependencyOnElmtId(rmElmtId);
        this.__announcements.purgeDependencyOnElmtId(rmElmtId);
        this.__myActivities.purgeDependencyOnElmtId(rmElmtId);
        this.__myCarpools.purgeDependencyOnElmtId(rmElmtId);
        this.__products.purgeDependencyOnElmtId(rmElmtId);
        this.__productPage.purgeDependencyOnElmtId(rmElmtId);
        this.__productHasMore.purgeDependencyOnElmtId(rmElmtId);
        this.__productLoadingMore.purgeDependencyOnElmtId(rmElmtId);
        this.__productError.purgeDependencyOnElmtId(rmElmtId);
        this.__todayCourses.purgeDependencyOnElmtId(rmElmtId);
        this.__scheduleGrid.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
        this.__currentWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__todayWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterId.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterWeekCount.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterName.purgeDependencyOnElmtId(rmElmtId);
        this.__semesterStartDate.purgeDependencyOnElmtId(rmElmtId);
        this.__unreadCount.purgeDependencyOnElmtId(rmElmtId);
        this.__conversations.purgeDependencyOnElmtId(rmElmtId);
        this.__onlineUserIds.purgeDependencyOnElmtId(rmElmtId);
        this.__conversationKeyword.purgeDependencyOnElmtId(rmElmtId);
        this.__conversationLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__conversationError.purgeDependencyOnElmtId(rmElmtId);
        this.__categories.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedCategoryId.purgeDependencyOnElmtId(rmElmtId);
        this.__showAddCourseForm.purgeDependencyOnElmtId(rmElmtId);
        this.__showCourseDetail.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedCourse.purgeDependencyOnElmtId(rmElmtId);
        this.__addCourseName.purgeDependencyOnElmtId(rmElmtId);
        this.__addClassroom.purgeDependencyOnElmtId(rmElmtId);
        this.__addTeacherName.purgeDependencyOnElmtId(rmElmtId);
        this.__addDayOfWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__addStartSection.purgeDependencyOnElmtId(rmElmtId);
        this.__addEndSection.purgeDependencyOnElmtId(rmElmtId);
        this.__addStartWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__addEndWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__aiMessages.purgeDependencyOnElmtId(rmElmtId);
        this.__aiInputText.purgeDependencyOnElmtId(rmElmtId);
        this.__aiIsLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__aiStreamingIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__aiThinking.purgeDependencyOnElmtId(rmElmtId);
        this.__aiStreamText.purgeDependencyOnElmtId(rmElmtId);
        this.__searchKeyword.purgeDependencyOnElmtId(rmElmtId);
        this.__searchSuggestions.purgeDependencyOnElmtId(rmElmtId);
        this.__showSuggestions.purgeDependencyOnElmtId(rmElmtId);
        this.__marketRefreshing.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentTab.aboutToBeDeleted();
        this.__userInfo.aboutToBeDeleted();
        this.__scheduleList.aboutToBeDeleted();
        this.__announcements.aboutToBeDeleted();
        this.__myActivities.aboutToBeDeleted();
        this.__myCarpools.aboutToBeDeleted();
        this.__products.aboutToBeDeleted();
        this.__productPage.aboutToBeDeleted();
        this.__productHasMore.aboutToBeDeleted();
        this.__productLoadingMore.aboutToBeDeleted();
        this.__productError.aboutToBeDeleted();
        this.__todayCourses.aboutToBeDeleted();
        this.__scheduleGrid.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        this.__currentWeek.aboutToBeDeleted();
        this.__todayWeek.aboutToBeDeleted();
        this.__semesterId.aboutToBeDeleted();
        this.__semesterWeekCount.aboutToBeDeleted();
        this.__semesterName.aboutToBeDeleted();
        this.__semesterStartDate.aboutToBeDeleted();
        this.__unreadCount.aboutToBeDeleted();
        this.__conversations.aboutToBeDeleted();
        this.__onlineUserIds.aboutToBeDeleted();
        this.__conversationKeyword.aboutToBeDeleted();
        this.__conversationLoading.aboutToBeDeleted();
        this.__conversationError.aboutToBeDeleted();
        this.__categories.aboutToBeDeleted();
        this.__selectedCategoryId.aboutToBeDeleted();
        this.__showAddCourseForm.aboutToBeDeleted();
        this.__showCourseDetail.aboutToBeDeleted();
        this.__selectedCourse.aboutToBeDeleted();
        this.__addCourseName.aboutToBeDeleted();
        this.__addClassroom.aboutToBeDeleted();
        this.__addTeacherName.aboutToBeDeleted();
        this.__addDayOfWeek.aboutToBeDeleted();
        this.__addStartSection.aboutToBeDeleted();
        this.__addEndSection.aboutToBeDeleted();
        this.__addStartWeek.aboutToBeDeleted();
        this.__addEndWeek.aboutToBeDeleted();
        this.__aiMessages.aboutToBeDeleted();
        this.__aiInputText.aboutToBeDeleted();
        this.__aiIsLoading.aboutToBeDeleted();
        this.__aiStreamingIndex.aboutToBeDeleted();
        this.__aiThinking.aboutToBeDeleted();
        this.__aiStreamText.aboutToBeDeleted();
        this.__searchKeyword.aboutToBeDeleted();
        this.__searchSuggestions.aboutToBeDeleted();
        this.__showSuggestions.aboutToBeDeleted();
        this.__marketRefreshing.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentTab: ObservedPropertySimplePU<number>;
    get currentTab() {
        return this.__currentTab.get();
    }
    set currentTab(newValue: number) {
        this.__currentTab.set(newValue);
    }
    private __userInfo: ObservedPropertyObjectPU<UserInfo>;
    get userInfo() {
        return this.__userInfo.get();
    }
    set userInfo(newValue: UserInfo) {
        this.__userInfo.set(newValue);
    }
    private __scheduleList: ObservedPropertyObjectPU<CourseSchedule[]>;
    get scheduleList() {
        return this.__scheduleList.get();
    }
    set scheduleList(newValue: CourseSchedule[]) {
        this.__scheduleList.set(newValue);
    }
    private __announcements: ObservedPropertyObjectPU<Announcement[]>;
    get announcements() {
        return this.__announcements.get();
    }
    set announcements(newValue: Announcement[]) {
        this.__announcements.set(newValue);
    }
    private __myActivities: ObservedPropertyObjectPU<ClubActivityItem[]>;
    get myActivities() {
        return this.__myActivities.get();
    }
    set myActivities(newValue: ClubActivityItem[]) {
        this.__myActivities.set(newValue);
    }
    private __myCarpools: ObservedPropertyObjectPU<CarpoolOrder[]>;
    get myCarpools() {
        return this.__myCarpools.get();
    }
    set myCarpools(newValue: CarpoolOrder[]) {
        this.__myCarpools.set(newValue);
    }
    private __products: ObservedPropertyObjectPU<Product[]>;
    get products() {
        return this.__products.get();
    }
    set products(newValue: Product[]) {
        this.__products.set(newValue);
    }
    private __productPage: ObservedPropertySimplePU<number>;
    get productPage() {
        return this.__productPage.get();
    }
    set productPage(newValue: number) {
        this.__productPage.set(newValue);
    }
    private __productHasMore: ObservedPropertySimplePU<boolean>;
    get productHasMore() {
        return this.__productHasMore.get();
    }
    set productHasMore(newValue: boolean) {
        this.__productHasMore.set(newValue);
    }
    private __productLoadingMore: ObservedPropertySimplePU<boolean>;
    get productLoadingMore() {
        return this.__productLoadingMore.get();
    }
    set productLoadingMore(newValue: boolean) {
        this.__productLoadingMore.set(newValue);
    }
    private __productError: ObservedPropertySimplePU<string>;
    get productError() {
        return this.__productError.get();
    }
    set productError(newValue: string) {
        this.__productError.set(newValue);
    }
    private __todayCourses: ObservedPropertyObjectPU<CourseSchedule[]>;
    get todayCourses() {
        return this.__todayCourses.get();
    }
    set todayCourses(newValue: CourseSchedule[]) {
        this.__todayCourses.set(newValue);
    }
    private __scheduleGrid: ObservedPropertyObjectPU<CourseSchedule[][]>;
    get scheduleGrid() {
        return this.__scheduleGrid.get();
    }
    set scheduleGrid(newValue: CourseSchedule[][]) {
        this.__scheduleGrid.set(newValue);
    }
    private __isRefreshing: ObservedPropertySimplePU<boolean>;
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue: boolean) {
        this.__isRefreshing.set(newValue);
    }
    private __currentWeek: ObservedPropertySimplePU<number>;
    get currentWeek() {
        return this.__currentWeek.get();
    }
    set currentWeek(newValue: number) {
        this.__currentWeek.set(newValue);
    }
    private __todayWeek: ObservedPropertySimplePU<number>;
    get todayWeek() {
        return this.__todayWeek.get();
    }
    set todayWeek(newValue: number) {
        this.__todayWeek.set(newValue);
    }
    private __semesterId: ObservedPropertySimplePU<number>;
    get semesterId() {
        return this.__semesterId.get();
    }
    set semesterId(newValue: number) {
        this.__semesterId.set(newValue);
    }
    private __semesterWeekCount: ObservedPropertySimplePU<number>;
    get semesterWeekCount() {
        return this.__semesterWeekCount.get();
    }
    set semesterWeekCount(newValue: number) {
        this.__semesterWeekCount.set(newValue);
    }
    private __semesterName: ObservedPropertySimplePU<string>;
    get semesterName() {
        return this.__semesterName.get();
    }
    set semesterName(newValue: string) {
        this.__semesterName.set(newValue);
    }
    private __semesterStartDate: ObservedPropertySimplePU<string>;
    get semesterStartDate() {
        return this.__semesterStartDate.get();
    }
    set semesterStartDate(newValue: string) {
        this.__semesterStartDate.set(newValue);
    }
    private __unreadCount: ObservedPropertySimplePU<number>;
    get unreadCount() {
        return this.__unreadCount.get();
    }
    set unreadCount(newValue: number) {
        this.__unreadCount.set(newValue);
    }
    private __conversations: ObservedPropertyObjectPU<Conversation[]>;
    get conversations() {
        return this.__conversations.get();
    }
    set conversations(newValue: Conversation[]) {
        this.__conversations.set(newValue);
    }
    private __onlineUserIds: ObservedPropertyObjectPU<number[]>;
    get onlineUserIds() {
        return this.__onlineUserIds.get();
    }
    set onlineUserIds(newValue: number[]) {
        this.__onlineUserIds.set(newValue);
    }
    private __conversationKeyword: ObservedPropertySimplePU<string>;
    get conversationKeyword() {
        return this.__conversationKeyword.get();
    }
    set conversationKeyword(newValue: string) {
        this.__conversationKeyword.set(newValue);
    }
    private __conversationLoading: ObservedPropertySimplePU<boolean>;
    get conversationLoading() {
        return this.__conversationLoading.get();
    }
    set conversationLoading(newValue: boolean) {
        this.__conversationLoading.set(newValue);
    }
    private __conversationError: ObservedPropertySimplePU<string>;
    get conversationError() {
        return this.__conversationError.get();
    }
    set conversationError(newValue: string) {
        this.__conversationError.set(newValue);
    }
    private conversationLoadedOnce: boolean;
    private __categories: ObservedPropertyObjectPU<ProductCategory[]>;
    get categories() {
        return this.__categories.get();
    }
    set categories(newValue: ProductCategory[]) {
        this.__categories.set(newValue);
    }
    private __selectedCategoryId: ObservedPropertySimplePU<number>;
    get selectedCategoryId() {
        return this.__selectedCategoryId.get();
    }
    set selectedCategoryId(newValue: number) {
        this.__selectedCategoryId.set(newValue);
    }
    private __showAddCourseForm: ObservedPropertySimplePU<boolean>;
    get showAddCourseForm() {
        return this.__showAddCourseForm.get();
    }
    set showAddCourseForm(newValue: boolean) {
        this.__showAddCourseForm.set(newValue);
    }
    private __showCourseDetail: ObservedPropertySimplePU<boolean>;
    get showCourseDetail() {
        return this.__showCourseDetail.get();
    }
    set showCourseDetail(newValue: boolean) {
        this.__showCourseDetail.set(newValue);
    }
    private __selectedCourse: ObservedPropertyObjectPU<CourseSchedule>;
    get selectedCourse() {
        return this.__selectedCourse.get();
    }
    set selectedCourse(newValue: CourseSchedule) {
        this.__selectedCourse.set(newValue);
    }
    private __addCourseName: ObservedPropertySimplePU<string>;
    get addCourseName() {
        return this.__addCourseName.get();
    }
    set addCourseName(newValue: string) {
        this.__addCourseName.set(newValue);
    }
    private __addClassroom: ObservedPropertySimplePU<string>;
    get addClassroom() {
        return this.__addClassroom.get();
    }
    set addClassroom(newValue: string) {
        this.__addClassroom.set(newValue);
    }
    private __addTeacherName: ObservedPropertySimplePU<string>;
    get addTeacherName() {
        return this.__addTeacherName.get();
    }
    set addTeacherName(newValue: string) {
        this.__addTeacherName.set(newValue);
    }
    private __addDayOfWeek: ObservedPropertySimplePU<number>;
    get addDayOfWeek() {
        return this.__addDayOfWeek.get();
    }
    set addDayOfWeek(newValue: number) {
        this.__addDayOfWeek.set(newValue);
    }
    private __addStartSection: ObservedPropertySimplePU<number>;
    get addStartSection() {
        return this.__addStartSection.get();
    }
    set addStartSection(newValue: number) {
        this.__addStartSection.set(newValue);
    }
    private __addEndSection: ObservedPropertySimplePU<number>;
    get addEndSection() {
        return this.__addEndSection.get();
    }
    set addEndSection(newValue: number) {
        this.__addEndSection.set(newValue);
    }
    private __addStartWeek: ObservedPropertySimplePU<number>;
    get addStartWeek() {
        return this.__addStartWeek.get();
    }
    set addStartWeek(newValue: number) {
        this.__addStartWeek.set(newValue);
    }
    private __addEndWeek: ObservedPropertySimplePU<number>;
    get addEndWeek() {
        return this.__addEndWeek.get();
    }
    set addEndWeek(newValue: number) {
        this.__addEndWeek.set(newValue);
    }
    private mainWsCallback: MessageCallback | null;
    private __aiMessages: ObservedPropertyObjectPU<AiMsg[]>;
    get aiMessages() {
        return this.__aiMessages.get();
    }
    set aiMessages(newValue: AiMsg[]) {
        this.__aiMessages.set(newValue);
    }
    private __aiInputText: ObservedPropertySimplePU<string>;
    get aiInputText() {
        return this.__aiInputText.get();
    }
    set aiInputText(newValue: string) {
        this.__aiInputText.set(newValue);
    }
    private __aiIsLoading: ObservedPropertySimplePU<boolean>;
    get aiIsLoading() {
        return this.__aiIsLoading.get();
    }
    set aiIsLoading(newValue: boolean) {
        this.__aiIsLoading.set(newValue);
    }
    private __aiStreamingIndex: ObservedPropertySimplePU<number>;
    get aiStreamingIndex() {
        return this.__aiStreamingIndex.get();
    }
    set aiStreamingIndex(newValue: number) {
        this.__aiStreamingIndex.set(newValue);
    }
    private __aiThinking: ObservedPropertySimplePU<boolean>;
    get aiThinking() {
        return this.__aiThinking.get();
    }
    set aiThinking(newValue: boolean) {
        this.__aiThinking.set(newValue);
    }
    private __aiStreamText: ObservedPropertySimplePU<string>;
    get aiStreamText() {
        return this.__aiStreamText.get();
    }
    set aiStreamText(newValue: string) {
        this.__aiStreamText.set(newValue);
    }
    private aiScroller: Scroller;
    private textDecoder: util.TextDecoder;
    private aiHttpRequest: http.HttpRequest | null;
    private aiPendingText: string;
    private aiFlushTimer: number;
    aboutToAppear(): void {
        const store: AppStore = AppStore.getInstance();
        if (store.pendingTab >= 0) {
            this.currentTab = store.pendingTab;
            store.pendingTab = -1;
        }
        this.userInfo = store.userInfo;
        const welcome: AiMsg = new AiMsg();
        welcome.role = 'assistant';
        welcome.content = '你好！我是中飞院智能校园助手，可以回答校规、办事流程等问题，请问有什么可以帮你的？';
        this.aiMessages.push(welcome);
        this.loadSemester();
        this.loadAnnouncements();
        this.loadCategories();
        this.refreshProducts();
        this.loadUnreadCount();
        this.loadMyActivities();
        this.loadMyCarpools();
        this.mainWsCallback = (msg: WsMessage) => {
            if (msg.type === 'unread_update') {
                const data: Record<string, Object> = msg.data as Record<string, Object>;
                this.unreadCount = (data['unreadCount'] as number) ?? 0;
            }
            if (msg.type === 'message') {
                this.handleConversationWsMessage(msg);
            }
            if (msg.type === 'user_status') {
                const data: Record<string, Object> = msg.data as Record<string, Object>;
                const uid: number = (data['userId'] as number) ?? 0;
                const online: boolean = (data['online'] as boolean) ?? false;
                this.updateOnlineUser(uid, online);
            }
            if (msg.type === 'online_users_loaded' || msg.type === 'connection_state') {
                this.loadConversations(false);
            }
        };
        WebSocketService.getInstance().onMessage(this.mainWsCallback);
    }
    onPageShow(): void {
        const store: AppStore = AppStore.getInstance();
        const freshInfo: UserInfo = new UserInfo();
        freshInfo.id = store.userInfo.id;
        freshInfo.studentId = store.userInfo.studentId;
        freshInfo.name = store.userInfo.name;
        freshInfo.avatar = store.userInfo.avatar;
        freshInfo.college = store.userInfo.college;
        freshInfo.major = store.userInfo.major;
        freshInfo.grade = store.userInfo.grade;
        freshInfo.classId = store.userInfo.classId;
        freshInfo.className = store.userInfo.className;
        freshInfo.hometown = store.userInfo.hometown;
        freshInfo.phone = store.userInfo.phone;
        freshInfo.role = store.userInfo.role;
        freshInfo.creditScore = store.userInfo.creditScore;
        this.userInfo = freshInfo;
        this.loadSemester();
        this.refreshProducts();
        this.loadMyActivities();
        this.loadMyCarpools();
        this.loadUnreadCount();
        if (store.isLoggedIn && this.conversationLoadedOnce) {
            this.loadConversations(false);
        }
    }
    aboutToDisappear(): void {
        if (this.mainWsCallback !== null) {
            WebSocketService.getInstance().removeMessageCallback(this.mainWsCallback);
        }
        if (this.aiHttpRequest !== null) {
            this.aiHttpRequest.off('dataReceive');
            this.aiHttpRequest.off('dataEnd');
            this.aiHttpRequest.destroy();
            this.aiHttpRequest = null;
        }
        if (this.aiFlushTimer !== -1) {
            clearInterval(this.aiFlushTimer);
            this.aiFlushTimer = -1;
        }
    }
    private async loadUnreadCount(): Promise<void> {
        const result: ApiResult = await ApiService.getUnreadCount();
        if (result.code === 200 && result.data !== undefined) {
            const obj: Record<string, Object> = result.data as Record<string, Object>;
            this.unreadCount = (obj['unreadCount'] as number) ?? 0;
        }
    }
    private async loadConversations(showLoading: boolean = true): Promise<void> {
        if (showLoading || !this.conversationLoadedOnce) {
            this.conversationLoading = true;
        }
        if (showLoading) {
            this.conversationError = '';
        }
        const result: ApiResult = await ApiService.getConversations();
        if (result.code === 200 && result.data !== undefined) {
            this.conversations = ApiService.parseConversationList(result.data);
            this.conversationError = '';
        }
        else if (showLoading) {
            this.conversationError = result.msg;
        }
        const onlineResult: ApiResult = await ApiService.getOnlineUsers();
        if (onlineResult.code === 200 && onlineResult.data !== undefined) {
            this.onlineUserIds = onlineResult.data as number[];
        }
        this.conversationLoadedOnce = true;
        this.conversationLoading = false;
    }
    private handleConversationWsMessage(msg: WsMessage): void {
        const data: Record<string, Object> = msg.data as Record<string, Object>;
        const item: ChatMessage = new ChatMessage();
        item.id = (data['id'] as number) ?? 0;
        item.conversationId = (data['conversationId'] as number) ?? 0;
        item.senderId = (data['senderId'] as number) ?? 0;
        item.content = (data['content'] as string) ?? '';
        item.msgType = (data['msgType'] as string) ?? 'text';
        item.createTime = (data['createTime'] as string) ?? '';
        item.isMine = item.senderId === AppStore.getInstance().userInfo.id;
        if (item.conversationId <= 0) {
            return;
        }
        const next: Conversation[] = [];
        let found: boolean = false;
        for (let i: number = 0; i < this.conversations.length; i++) {
            const source: Conversation = this.conversations[i];
            if (source.id === item.conversationId) {
                const updated: Conversation = new Conversation();
                updated.id = source.id;
                updated.otherUserId = source.otherUserId;
                updated.otherUserName = source.otherUserName;
                updated.otherUserAvatar = source.otherUserAvatar;
                updated.lastMessage = this.messagePreviewByType(item.msgType, item.content);
                updated.lastTime = item.createTime;
                updated.unreadCount = item.isMine ? source.unreadCount : source.unreadCount + 1;
                updated.productId = source.productId;
                next.unshift(updated);
                found = true;
            }
            else {
                next.push(source);
            }
        }
        if (found) {
            this.conversations = next;
        }
        else {
            this.loadConversations(false);
        }
    }
    private updateOnlineUser(userId: number, online: boolean): void {
        if (userId <= 0) {
            return;
        }
        const next: number[] = [];
        let exists: boolean = false;
        for (let i: number = 0; i < this.onlineUserIds.length; i++) {
            if (this.onlineUserIds[i] === userId) {
                exists = true;
                if (online) {
                    next.push(this.onlineUserIds[i]);
                }
            }
            else {
                next.push(this.onlineUserIds[i]);
            }
        }
        if (online && !exists) {
            next.push(userId);
        }
        this.onlineUserIds = next;
    }
    private isUserOnline(userId: number): boolean {
        for (let i: number = 0; i < this.onlineUserIds.length; i++) {
            if (this.onlineUserIds[i] === userId) {
                return true;
            }
        }
        return false;
    }
    private shouldShowConversation(item: Conversation): boolean {
        const key: string = this.conversationKeyword.trim();
        if (key.length === 0) {
            return true;
        }
        return item.otherUserName.indexOf(key) >= 0 || item.lastMessage.indexOf(key) >= 0;
    }
    private messagePreviewByType(msgType: string, content: string): string {
        if (msgType === 'image') {
            return '[图片]';
        }
        if (msgType === 'product') {
            return '[商品卡片]';
        }
        return content;
    }
    private formatConvTime(text: string): string {
        if (text.length === 0) {
            return '';
        }
        const value: string = text.replace('T', ' ');
        if (value.length >= 16) {
            return value.substring(5, 16);
        }
        return value;
    }
    private previewConvText(item: Conversation): string {
        if (item.lastMessage.length === 0) {
            return '暂无消息';
        }
        return item.lastMessage;
    }
    private markConversationReadLocally(conversationId: number): void {
        const nextList: Conversation[] = [];
        for (let i: number = 0; i < this.conversations.length; i++) {
            const source: Conversation = this.conversations[i];
            if (source.id === conversationId) {
                const updated: Conversation = new Conversation();
                updated.id = source.id;
                updated.otherUserId = source.otherUserId;
                updated.otherUserName = source.otherUserName;
                updated.otherUserAvatar = source.otherUserAvatar;
                updated.lastMessage = source.lastMessage;
                updated.lastTime = source.lastTime;
                updated.unreadCount = 0;
                updated.productId = source.productId;
                nextList.push(updated);
            }
            else {
                nextList.push(source);
            }
        }
        this.conversations = nextList;
    }
    private goChat(item: Conversation): void {
        this.markConversationReadLocally(item.id);
        router.pushUrl({
            url: 'pages/ChatPage',
            params: {
                'conversationId': item.id.toString(),
                'otherUserId': item.otherUserId.toString(),
                'otherUserName': item.otherUserName,
                'productId': item.productId.toString()
            } as Record<string, string>
        });
    }
    private openEditProfilePage(): void {
        router.pushUrl({ url: 'pages/EditProfilePage' }).catch(() => {
            this.getUIContext().getPromptAction().showToast({ message: '打开编辑资料失败，请重新编译后再试' });
        });
    }
    private async loadCategories(): Promise<void> {
        const result: ApiResult = await ApiService.getProductCategories();
        if (result.code === 200 && result.data !== undefined) {
            this.categories = ApiService.parseProductCategoryList(result.data);
        }
    }
    private async loadSemester(): Promise<void> {
        const result: ApiResult = await ApiService.getCurrentSemester();
        if (result.code === 200 && result.data !== undefined) {
            const semester: Semester = ApiService.parseSemester(result.data);
            this.semesterId = semester.id;
            this.semesterName = semester.name;
            this.semesterStartDate = semester.startDate;
            this.semesterWeekCount = semester.weekCount;
            this.addEndWeek = semester.weekCount;
            this.todayWeek = this.calcCurrentWeek(semester.startDate, semester.weekCount);
            this.currentWeek = this.todayWeek;
        }
        this.loadSchedule();
    }
    private calcCurrentWeek(startDateStr: string, weekCount: number): number {
        return calcSemesterWeek(startDateStr, weekCount);
    }
    private async loadSchedule(): Promise<void> {
        const sid: number = this.semesterId > 0 ? this.semesterId : 1;
        const result: ApiResult = await ApiService.getMySchedule(sid);
        if (result.code === 200) {
            if (result.data !== undefined) {
                this.scheduleList = ApiService.parseScheduleList(result.data);
            }
            else {
                this.scheduleList = [];
            }
            this.updateScheduleGrid();
        }
    }
    private updateScheduleGrid(): void {
        const today: number = new Date().getDay();
        const dayOfWeek: number = today === 0 ? 7 : today;
        const filtered: CourseSchedule[] = this.scheduleList.filter((item: CourseSchedule) => this.isCourseActiveInWeek(item, this.currentWeek));
        this.todayCourses = filtered.filter((item: CourseSchedule) => item.dayOfWeek === dayOfWeek);
        this.scheduleGrid = [];
        for (let day = 1; day <= 7; day++) {
            const dayList: CourseSchedule[] = [];
            for (let sec = 1; sec <= 10; sec++) {
                const found: CourseSchedule | undefined = filtered.find((item: CourseSchedule) => item.dayOfWeek === day && item.startSection <= sec && item.endSection >= sec);
                dayList.push(found ?? new CourseSchedule());
            }
            this.scheduleGrid.push(dayList);
        }
        const store: AppStore = AppStore.getInstance();
        if (store.context !== undefined) {
            WidgetDataHelper.saveTodayCourses(store.context, this.todayCourses, this.currentWeek);
        }
    }
    private async loadAnnouncements(): Promise<void> {
        const result: ApiResult = await ApiService.getAnnouncementList('');
        if (result.code === 200 && result.data !== undefined) {
            this.announcements = ApiService.parseAnnouncementList(result.data);
        }
    }
    private async searchProducts(): Promise<void> {
        this.showSuggestions = false;
        if (this.searchKeyword.trim().length === 0) {
            this.refreshProducts();
            return;
        }
        const result: ApiResult = await ApiService.request(http.RequestMethod.GET, `/api/product/search?keyword=${encodeURIComponent(this.searchKeyword.trim())}`, undefined, false);
        if (result.code === 200 && result.data !== undefined) {
            this.productError = '';
            const arr: Object[] = result.data as Object[];
            this.products = [];
            for (let i = 0; i < arr.length; i++) {
                const obj: Record<string, Object> = arr[i] as Record<string, Object>;
                const item: Product = new Product();
                item.id = (obj['id'] as number) ?? 0;
                item.sellerId = (obj['sellerId'] as number) ?? 0;
                item.sellerName = (obj['sellerName'] as string) ?? '';
                item.categoryId = (obj['categoryId'] as number) ?? 0;
                item.categoryName = (obj['categoryName'] as string) ?? '';
                item.title = (obj['title'] as string) ?? '';
                item.description = (obj['description'] as string) ?? '';
                item.price = (obj['price'] as number) ?? 0;
                item.originalPrice = (obj['originalPrice'] as number) ?? 0;
                item.conditionLevel = (obj['conditionLevel'] as number) ?? 1;
                item.status = (obj['status'] as number) ?? 1;
                item.viewCount = (obj['viewCount'] as number) ?? 0;
                item.campusLocation = (obj['campusLocation'] as string) ?? '';
                item.createTime = (obj['createTime'] as string) ?? '';
                const imagesObj: Object = obj['images'];
                if (imagesObj !== null && imagesObj !== undefined) {
                    item.images = imagesObj as string[];
                }
                this.products.push(item);
            }
        }
        else {
            this.products = [];
            this.productError = result.msg.length > 0 ? result.msg : '商品搜索失败';
        }
    }
    private async loadSearchSuggestions(keyword: string): Promise<void> {
        if (keyword.trim().length === 0) {
            this.searchSuggestions = [];
            this.showSuggestions = false;
            return;
        }
        const result: ApiResult = await ApiService.request(http.RequestMethod.GET, `/api/product/search-suggest?keyword=${encodeURIComponent(keyword.trim())}`, undefined, false);
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            const list: string[] = [];
            for (const obj of arr) {
                list.push(obj as string);
            }
            this.searchSuggestions = list;
            this.showSuggestions = list.length > 0;
        }
        else {
            this.searchSuggestions = [];
            this.showSuggestions = false;
        }
    }
    private async refreshProducts(): Promise<void> {
        this.productPage = 1;
        this.productHasMore = true;
        this.productError = '';
        const result: ApiResult = await ApiService.getProductList(this.selectedCategoryId, 1, 20);
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            this.products = [];
            for (let i = 0; i < arr.length; i++) {
                const obj: Record<string, Object> = arr[i] as Record<string, Object>;
                const item: Product = this.parseProduct(obj);
                this.products.push(item);
            }
            if (arr.length < 20) {
                this.productHasMore = false;
            }
        }
        else {
            this.products = [];
            this.productHasMore = false;
            this.productError = result.msg.length > 0 ? result.msg : '商品加载失败';
        }
    }
    private async loadMoreProducts(): Promise<void> {
        if (this.productLoadingMore || !this.productHasMore) {
            return;
        }
        this.productLoadingMore = true;
        this.productPage = this.productPage + 1;
        const result: ApiResult = await ApiService.getProductList(this.selectedCategoryId, this.productPage, 20);
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            for (let i = 0; i < arr.length; i++) {
                const obj: Record<string, Object> = arr[i] as Record<string, Object>;
                const item: Product = this.parseProduct(obj);
                this.products.push(item);
            }
            if (arr.length < 20) {
                this.productHasMore = false;
            }
        }
        else {
            this.productPage = Math.max(1, this.productPage - 1);
            this.productError = result.msg.length > 0 ? result.msg : '加载更多失败';
        }
        this.productLoadingMore = false;
    }
    private parseProduct(obj: Record<string, Object>): Product {
        const item: Product = new Product();
        item.id = (obj['id'] as number) ?? 0;
        item.sellerId = (obj['sellerId'] as number) ?? 0;
        item.sellerName = (obj['sellerName'] as string) ?? '';
        item.categoryId = (obj['categoryId'] as number) ?? 0;
        item.categoryName = (obj['categoryName'] as string) ?? '';
        item.title = (obj['title'] as string) ?? '';
        item.description = (obj['description'] as string) ?? '';
        item.price = (obj['price'] as number) ?? 0;
        item.originalPrice = (obj['originalPrice'] as number) ?? 0;
        item.conditionLevel = (obj['conditionLevel'] as number) ?? 1;
        item.status = (obj['status'] as number) ?? 1;
        item.viewCount = (obj['viewCount'] as number) ?? 0;
        item.campusLocation = (obj['campusLocation'] as string) ?? '';
        item.createTime = (obj['createTime'] as string) ?? '';
        const imagesObj: Object = obj['images'];
        if (imagesObj !== null && imagesObj !== undefined) {
            item.images = imagesObj as string[];
        }
        return item;
    }
    private async loadAllData(): Promise<void> {
        this.isRefreshing = true;
        await Promise.all([this.loadSchedule(), this.loadAnnouncements(), this.refreshProducts(), this.loadMyActivities(), this.loadUnreadCount()]);
        this.isRefreshing = false;
    }
    private async loadMyActivities(): Promise<void> {
        const result: ApiResult = await ApiService.getMyClubActivities(1, 5);
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            this.myActivities = [];
            for (let i = 0; i < arr.length; i++) {
                const obj: Record<string, Object> = arr[i] as Record<string, Object>;
                const item: ClubActivityItem = new ClubActivityItem();
                item.id = (obj['id'] as number) ?? 0;
                item.club = (obj['club'] as string) ?? '';
                item.title = (obj['title'] as string) ?? '';
                item.venue = (obj['venue'] as string) ?? '';
                item.activityTime = (obj['activityTime'] as string) ?? '';
                item.coverImage = (obj['coverImage'] as string) ?? '';
                item.currentParticipants = (obj['currentParticipants'] as number) ?? 0;
                item.maxParticipants = (obj['maxParticipants'] as number) ?? 0;
                this.myActivities.push(item);
            }
        }
    }
    private async loadMyCarpools(): Promise<void> {
        const store: AppStore = AppStore.getInstance();
        if (!store.isLoggedIn)
            return;
        const result: ApiResult = await ApiService.getMyCarpoolOrders();
        if (result.code === 200 && result.data !== undefined) {
            this.myCarpools = ApiService.parseCarpoolOrders(result.data);
        }
    }
    private getGreeting(): string {
        const hour: number = new Date().getHours();
        if (hour < 12)
            return '早上好';
        if (hour < 18)
            return '下午好';
        return '晚上好';
    }
    private getTodayDate(): string {
        const now: Date = new Date();
        const dayNames: string[] = ['日', '一', '二', '三', '四', '五', '六'];
        const month: number = now.getMonth() + 1;
        const day: number = now.getDate();
        const weekDay: string = dayNames[now.getDay()];
        return `${month}月${day}日 星期${weekDay}`;
    }
    private getAnnouncementCategoryColor(category: string): string {
        if (category === '教务')
            return Theme.ocean;
        if (category === '紧急' || category === '重要')
            return Theme.danger;
        if (category === '活动' || category === '社团')
            return Theme.primary;
        return Theme.ocean;
    }
    private getAnnouncementCategoryBg(category: string): string {
        if (category === '教务')
            return Theme.secondaryLight;
        if (category === '紧急' || category === '重要')
            return Theme.dangerLight;
        if (category === '活动' || category === '社团')
            return Theme.primaryLight;
        return Theme.secondaryLight;
    }
    private getCombinedTimeline(): TimelineItem[] {
        const items: TimelineItem[] = [];
        for (const course of this.todayCourses) {
            const startTime: string = Constants.SECTION_TIMES[course.startSection - 1][0];
            const endTime: string = Constants.SECTION_TIMES[course.endSection - 1][1];
            items.push({
                time: `${startTime} - ${endTime}`,
                title: course.courseName,
                location: course.classroom && course.classroom.length > 0 ? course.classroom : '未定教室',
                type: 0,
                courseData: course,
                activityData: null
            });
        }
        items.sort((a: TimelineItem, b: TimelineItem) => {
            const timeA: string = a.time.length > 0 ? a.time : '99:99';
            const timeB: string = b.time.length > 0 ? b.time : '99:99';
            return timeA.localeCompare(timeB);
        });
        return items;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create({ barPosition: BarPosition.End, index: this.currentTab });
            Tabs.debugLine("entry/src/main/ets/pages/MainPage.ets(633:5)", "entry");
            Tabs.width('100%');
            Tabs.height('100%');
            Tabs.backgroundColor(Theme.bgPage);
            Tabs.onChange((index: number) => {
                this.currentTab = index;
                if (index === 2 && !this.conversationLoadedOnce) {
                    this.loadConversations();
                }
            });
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.HomeContent.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabItem.call(this, 0, '首页');
                } });
            TabContent.debugLine("entry/src/main/ets/pages/MainPage.ets(634:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.MarketContent.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabItem.call(this, 1, '交易');
                } });
            TabContent.debugLine("entry/src/main/ets/pages/MainPage.ets(638:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.MessageContent.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabItem.call(this, 2, '消息');
                } });
            TabContent.debugLine("entry/src/main/ets/pages/MainPage.ets(642:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.AIChatContent.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabItem.call(this, 3, 'AI');
                } });
            TabContent.debugLine("entry/src/main/ets/pages/MainPage.ets(646:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.ProfileContent.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabItem.call(this, 4, '我的');
                } });
            TabContent.debugLine("entry/src/main/ets/pages/MainPage.ets(650:7)", "entry");
        }, TabContent);
        TabContent.pop();
        Tabs.pop();
    }
    TabItem(index: number, label: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(667:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (index === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.currentTab === 0 ? { "id": 16777248, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" } : { "id": 16777221, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/MainPage.ets(669:9)", "entry");
                        Image.width(22);
                        Image.height(22);
                    }, Image);
                });
            }
            else if (index === 1) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.currentTab === 1 ? { "id": 16777250, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" } : { "id": 16777229, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/MainPage.ets(672:9)", "entry");
                        Image.width(22);
                        Image.height(22);
                    }, Image);
                });
            }
            else if (index === 2) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.currentTab === 2 ? { "id": 16777246, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" } : { "id": 16777241, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/MainPage.ets(675:9)", "entry");
                        Image.width(22);
                        Image.height(22);
                    }, Image);
                });
            }
            else if (index === 3) {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.currentTab === 3 ? { "id": 16777256, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" } : { "id": 16777223, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/MainPage.ets(678:9)", "entry");
                        Image.width(22);
                        Image.height(22);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(4, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.currentTab === 4 ? { "id": 16777260, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" } : { "id": 16777222, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/MainPage.ets(681:9)", "entry");
                        Image.width(22);
                        Image.height(22);
                    }, Image);
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(684:7)", "entry");
            Text.fontSize(10);
            Text.fontColor(this.currentTab === index ? Theme.primary : Theme.textTertiary);
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    QuickEntry(emoji: string, label: string, targetPage: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(697:5)", "entry");
            Column.width(68);
            Column.height(88);
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
            Column.borderRadius(Theme.cardRadius);
            Column.backgroundColor(Theme.bgCard);
            Column.shadow(ShadowStyle.sm);
            Column.onClick(() => {
                this.getUIContext().getRouter().pushUrl({ url: targetPage });
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(698:7)", "entry");
            Column.width(48);
            Column.height(48);
            Column.borderRadius(Theme.radiusMd);
            Column.backgroundColor(Theme.primaryLight);
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
            Column.margin({ bottom: 6 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(emoji);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(699:9)", "entry");
            Text.fontSize(28);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(709:7)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        Column.pop();
    }
    HomeContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Refresh.create({ refreshing: { value: this.isRefreshing, changeEvent: newValue => { this.isRefreshing = newValue; } } });
            Refresh.debugLine("entry/src/main/ets/pages/MainPage.ets(726:5)", "entry");
            Refresh.onRefreshing(() => {
                this.loadAllData();
            });
        }, Refresh);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/MainPage.ets(727:7)", "entry");
            Scroll.scrollBar(BarState.Off);
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(728:9)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(729:11)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 28, bottom: 32 });
            Column.linearGradient({
                angle: 160,
                colors: [['#FF8C42', 0.0], ['#FF6B2C', 0.6], ['#FFA869', 1.0]]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(730:13)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.userInfo.college} · 校园助手`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(731:15)", "entry");
            Text.fontSize(13);
            Text.fontColor(Color.White);
            Text.opacity(0.9);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(735:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`第 ${this.currentWeek} 周`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(736:15)", "entry");
            Text.fontSize(12);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Medium);
            Text.backgroundColor('rgba(255,255,255,0.2)');
            Text.borderRadius(Theme.radiusPill);
            Text.padding({ left: 14, right: 14, top: 4, bottom: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(747:13)", "entry");
            Row.width('100%');
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(748:15)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.getGreeting()}，${this.userInfo.name}`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(749:17)", "entry");
            Text.fontSize(26);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.userInfo.major} · ${this.userInfo.college}`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(753:17)", "entry");
            Text.fontSize(13);
            Text.fontColor(Color.White);
            Text.opacity(0.85);
            Text.margin({ top: 6 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.getTodayDate()} · 今日 ${this.todayCourses.length} 节课`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(758:17)", "entry");
            Text.fontSize(12);
            Text.fontColor(Color.White);
            Text.opacity(0.65);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Center });
            Stack.debugLine("entry/src/main/ets/pages/MainPage.ets(767:15)", "entry");
            Stack.width(52);
            Stack.height(52);
            Stack.borderRadius(Theme.radiusPill);
            Stack.backgroundColor('rgba(255,255,255,0.25)');
            Stack.margin({ left: 12 });
        }, Stack);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new AvatarView(this, { avatar: this.userInfo.avatar, name: this.userInfo.name, avatarSize: 38 }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MainPage.ets", line: 768, col: 17 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            avatar: this.userInfo.avatar,
                            name: this.userInfo.name,
                            avatarSize: 38
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        avatar: this.userInfo.avatar, name: this.userInfo.name
                    });
                }
            }, { name: "AvatarView" });
        }
        Stack.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(785:11)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.shadow(ShadowStyle.md);
            Column.padding({ top: 14, bottom: 12, left: 4, right: 4 });
            Column.margin({ left: 16, right: 16, top: -16, bottom: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(786:13)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceAround);
        }, Row);
        this.QuickEntry.bind(this)('📅', '课表', 'pages/SchedulePage');
        this.QuickEntry.bind(this)('🏫', '空教室', 'pages/EmptyRoomPage');
        this.QuickEntry.bind(this)('🎉', '活动', 'pages/ClubActivityListPage');
        this.QuickEntry.bind(this)('🔍', '招领', 'pages/LostFoundListPage');
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(795:13)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceAround);
            Row.margin({ top: 4 });
        }, Row);
        this.QuickEntry.bind(this)('🚗', '拼车', 'pages/CarpoolPage');
        this.QuickEntry.bind(this)('💌', '表白墙', 'pages/ConfessionWallPage');
        this.QuickEntry.bind(this)('🆘', '安全', 'pages/CampusSafetyPage');
        this.QuickEntry.bind(this)('📚', '资料', 'pages/StudySharePage');
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(812:11)", "entry");
            Column.width('100%');
            Column.padding({ left: 16, right: 16, top: 20, bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(813:13)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(814:15)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(815:17)", "entry");
            Row.width(4);
            Row.height(18);
            Row.borderRadius(2);
            Row.backgroundColor(Theme.primary);
        }, Row);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('今日课程');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(819:17)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(825:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`共 ${this.getCombinedTimeline().length} 项`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(826:15)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.primary);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        Row.pop();
        this.TimelineView.bind(this)();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.myActivities.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(840:13)", "entry");
                        Column.width('100%');
                        Column.padding({ top: 12, bottom: 12 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MainPage.ets(841:15)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16 });
                        Row.margin({ bottom: 12 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MainPage.ets(842:17)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MainPage.ets(843:19)", "entry");
                        Row.width(4);
                        Row.height(18);
                        Row.borderRadius(2);
                        Row.backgroundColor(Theme.ocean);
                    }, Row);
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('我的活动');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(847:19)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.margin({ left: 8 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(853:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('更多 >');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(854:17)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.ocean);
                        Text.onClick(() => {
                            this.getUIContext().getRouter().pushUrl({ url: 'pages/ClubActivityListPage' });
                        });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MainPage.ets(865:15)", "entry");
                        Scroll.scrollable(ScrollDirection.Horizontal);
                        Scroll.scrollBar(BarState.Off);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MainPage.ets(866:17)", "entry");
                        Row.padding({ left: 16, right: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(868:21)", "entry");
                                Column.width(200);
                                Column.backgroundColor(Theme.bgCard);
                                Column.borderRadius(Theme.cardRadius);
                                Column.border({ width: 1, color: Theme.secondaryLight });
                                Column.shadow(ShadowStyle.sm);
                                Column.margin({ right: 10 });
                                Column.onClick(() => {
                                    this.getUIContext().getRouter().pushUrl({
                                        url: 'pages/ClubActivityDetailPage',
                                        params: { 'id': `${item.id}` } as Record<string, string>
                                    });
                                });
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (item.coverImage.length > 0) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Stack.create();
                                            Stack.debugLine("entry/src/main/ets/pages/MainPage.ets(870:25)", "entry");
                                            Stack.width('100%');
                                            Stack.height(120);
                                            Stack.borderRadius({ topLeft: Theme.cardRadius, topRight: Theme.cardRadius });
                                            Stack.clip(true);
                                        }, Stack);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Image.create(`${ApiService.baseUrl}${item.coverImage}`);
                                            Image.debugLine("entry/src/main/ets/pages/MainPage.ets(871:27)", "entry");
                                            Image.width('100%');
                                            Image.height(120);
                                            Image.borderRadius({ topLeft: Theme.cardRadius, topRight: Theme.cardRadius });
                                            Image.objectFit(ImageFit.Cover);
                                        }, Image);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Column.create();
                                            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(876:27)", "entry");
                                            Column.position({ x: 8, y: 8 });
                                        }, Column);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(item.club);
                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(877:29)", "entry");
                                            Text.fontSize(10);
                                            Text.fontColor('#FFFFFF');
                                            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                                            Text.borderRadius(8);
                                            Text.backgroundColor('#40' + Theme.ocean.substring(1));
                                        }, Text);
                                        Text.pop();
                                        Column.pop();
                                        Stack.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Column.create();
                                            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(891:25)", "entry");
                                            Column.width('100%');
                                            Column.height(120);
                                            Column.backgroundColor(Theme.secondaryLight);
                                            Column.borderRadius({ topLeft: Theme.cardRadius, topRight: Theme.cardRadius });
                                            Column.justifyContent(FlexAlign.Center);
                                            Column.alignItems(HorizontalAlign.Center);
                                        }, Column);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('🎉');
                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(892:27)", "entry");
                                            Text.fontSize(32);
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(item.club);
                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(894:27)", "entry");
                                            Text.fontSize(12);
                                            Text.fontColor(Theme.ocean);
                                            Text.margin({ top: 4 });
                                        }, Text);
                                        Text.pop();
                                        Column.pop();
                                    });
                                }
                            }, If);
                            If.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(906:23)", "entry");
                                Column.padding({ left: 12, right: 12, top: 10, bottom: 12 });
                                Column.alignItems(HorizontalAlign.Start);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.title);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(907:25)", "entry");
                                Text.fontSize(14);
                                Text.fontWeight(FontWeight.Medium);
                                Text.fontColor(Theme.textPrimary);
                                Text.maxLines(2);
                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                Text.width('100%');
                                Text.margin({ bottom: 4 });
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(915:25)", "entry");
                                Row.width('100%');
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.venue.length > 0 ? item.venue : '');
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(916:27)", "entry");
                                Text.fontSize(11);
                                Text.fontColor(Theme.ocean);
                                Text.layoutWeight(1);
                                Text.maxLines(1);
                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(`${item.currentParticipants}/${item.maxParticipants}人`);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(922:27)", "entry");
                                Text.fontSize(11);
                                Text.fontColor(Theme.ocean);
                            }, Text);
                            Text.pop();
                            Row.pop();
                            Column.pop();
                            Column.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.myActivities, forEachItemGenFunction, (item: ClubActivityItem) => `${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Row.pop();
                    Scroll.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.myCarpools.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(955:13)", "entry");
                        Column.width('100%');
                        Column.padding({ top: 12, bottom: 12 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MainPage.ets(956:15)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16 });
                        Row.margin({ bottom: 12 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MainPage.ets(957:17)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MainPage.ets(958:19)", "entry");
                        Row.width(4);
                        Row.height(18);
                        Row.borderRadius(2);
                        Row.backgroundColor('#10B981');
                    }, Row);
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('我的约车');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(962:19)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.margin({ left: 8 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(968:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('更多 >');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(969:17)", "entry");
                        Text.fontSize(13);
                        Text.fontColor('#10B981');
                        Text.onClick(() => {
                            this.getUIContext().getRouter().pushUrl({ url: 'pages/CarpoolPage' });
                        });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(980:15)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 16, right: 16 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(982:17)", "entry");
                                Row.width('100%');
                                Row.padding({ left: 12, right: 12, top: 10, bottom: 10 });
                                Row.backgroundColor(Theme.bgCard);
                                Row.borderRadius(Theme.radiusMd);
                                Row.margin({ bottom: 8 });
                                Row.onClick(() => {
                                    this.getUIContext().getRouter().pushUrl({
                                        url: 'pages/CarpoolDetailPage',
                                        params: { 'id': `${item.id}` } as Record<string, string>
                                    });
                                });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(983:19)", "entry");
                                Column.width(44);
                                Column.height(44);
                                Column.backgroundColor('#ECFDF5');
                                Column.borderRadius(10);
                                Column.justifyContent(FlexAlign.Center);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('\uD83D\uDE97');
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(984:21)", "entry");
                                Text.fontSize(24);
                            }, Text);
                            Text.pop();
                            Column.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(993:19)", "entry");
                                Column.layoutWeight(1);
                                Column.margin({ left: 12 });
                                Column.alignItems(HorizontalAlign.Start);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(994:21)", "entry");
                                Row.width('100%');
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.departure);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(995:23)", "entry");
                                Text.fontSize(14);
                                Text.fontWeight(FontWeight.Medium);
                                Text.fontColor(Theme.textPrimary);
                                Text.maxLines(1);
                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(' \u2192 ');
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1001:23)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(Theme.textTertiary);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.destination);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1004:23)", "entry");
                                Text.fontSize(14);
                                Text.fontWeight(FontWeight.Medium);
                                Text.fontColor(Theme.textPrimary);
                                Text.maxLines(1);
                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                Text.layoutWeight(1);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Blank.create();
                                Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(1011:23)", "entry");
                            }, Blank);
                            Blank.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (item.status === 0) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('招募中');
                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1013:25)", "entry");
                                            Text.fontSize(11);
                                            Text.fontColor('#FFFFFF');
                                            Text.backgroundColor('#10B981');
                                            Text.borderRadius(4);
                                            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else if (item.status === 1) {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('已满');
                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1020:25)", "entry");
                                            Text.fontSize(11);
                                            Text.fontColor('#FFFFFF');
                                            Text.backgroundColor('#F59E0B');
                                            Text.borderRadius(4);
                                            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else if (item.status === 3) {
                                    this.ifElseBranchUpdateFunction(2, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('已取消');
                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1027:25)", "entry");
                                            Text.fontSize(11);
                                            Text.fontColor(Theme.textDisabled);
                                            Text.backgroundColor(Theme.bgPage);
                                            Text.borderRadius(4);
                                            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(3, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                            Row.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1037:21)", "entry");
                                Row.width('100%');
                                Row.margin({ top: 4 });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.departureTime);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1038:23)", "entry");
                                Text.fontSize(12);
                                Text.fontColor(Theme.textTertiary);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(` \u00B7 `);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1041:23)", "entry");
                                Text.fontSize(12);
                                Text.fontColor(Theme.textTertiary);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(`${item.currentPassengers}/${item.maxPassengers}人`);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1044:23)", "entry");
                                Text.fontSize(12);
                                Text.fontColor(Theme.textTertiary);
                            }, Text);
                            Text.pop();
                            Row.pop();
                            Column.pop();
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.myCarpools, forEachItemGenFunction, (item: CarpoolOrder) => `${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1075:11)", "entry");
            Column.width('100%');
            Column.padding({ top: 12, bottom: 24 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1076:13)", "entry");
            Row.width('100%');
            Row.padding({ left: 16, right: 16 });
            Row.margin({ bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1077:15)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1078:17)", "entry");
            Row.width(4);
            Row.height(18);
            Row.borderRadius(2);
            Row.backgroundColor(Theme.primary);
        }, Row);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('校园公告');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1082:17)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1095:15)", "entry");
                    Row.width('100%');
                    Row.padding({ left: 16, right: 16, top: 12, bottom: 12 });
                    Row.alignItems(VerticalAlign.Center);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1096:17)", "entry");
                    Column.width(48);
                    Column.alignItems(HorizontalAlign.Center);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.category);
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1097:19)", "entry");
                    Text.fontSize(10);
                    Text.fontWeight(FontWeight.Medium);
                    Text.fontColor(Theme.primary);
                    Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                    Text.borderRadius(10);
                    Text.backgroundColor(Theme.primaryLight);
                }, Text);
                Text.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1108:17)", "entry");
                    Column.layoutWeight(1);
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.title);
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1109:19)", "entry");
                    Text.fontSize(14);
                    Text.fontWeight(FontWeight.Medium);
                    Text.fontColor(Theme.textPrimary);
                    Text.maxLines(1);
                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    Text.width('100%');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.summary);
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1116:19)", "entry");
                    Text.fontSize(12);
                    Text.fontColor(Theme.textTertiary);
                    Text.maxLines(1);
                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    Text.width('100%');
                    Text.margin({ top: 3 });
                }, Text);
                Text.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.publishTime && item.publishTime.length >= 10 ? item.publishTime.substring(5, 10) : '');
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1127:17)", "entry");
                    Text.fontSize(11);
                    Text.fontColor(Theme.primary);
                    Text.margin({ left: 8 });
                }, Text);
                Text.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.announcements, forEachItemGenFunction, (item: Announcement) => `${item.id}`, false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        Column.pop();
        Scroll.pop();
        Refresh.pop();
    }
    TodaySchedule(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.todayCourses.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1153:7)", "entry");
                        Column.width('100%');
                        Column.alignItems(HorizontalAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('今天没有课程');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1154:9)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.padding({ left: 16, top: 8, bottom: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1163:9)", "entry");
                                Row.width('100%');
                                Row.backgroundColor(Theme.bgCard);
                                Row.borderRadius(Theme.cardRadius);
                                Row.padding({ left: 10, right: 10, top: 6, bottom: 6 });
                                Row.alignItems(VerticalAlign.Center);
                                Row.shadow(ShadowStyle.sm);
                                Row.margin({ bottom: 6 });
                                Row.onClick(() => {
                                    this.selectedCourse = item;
                                    this.showCourseDetail = true;
                                });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1164:11)", "entry");
                                Column.width(36);
                                Column.alignItems(HorizontalAlign.Center);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(Constants.SECTION_TIMES[item.startSection - 1][0]);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1165:13)", "entry");
                                Text.fontSize(11);
                                Text.fontColor(Theme.textTertiary);
                            }, Text);
                            Text.pop();
                            Column.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1172:11)", "entry");
                                Column.height(40);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1173:13)", "entry");
                                Row.width(3);
                                Row.height('100%');
                                Row.backgroundColor(Constants.SCHEDULE_COLORS[item.colorIndex % Constants.SCHEDULE_COLORS.length]);
                                Row.borderRadius(2);
                            }, Row);
                            Row.pop();
                            Column.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Blank.create();
                                Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(1181:11)", "entry");
                                Blank.width(6);
                            }, Blank);
                            Blank.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1183:11)", "entry");
                                Column.layoutWeight(1);
                                Column.alignItems(HorizontalAlign.Start);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.courseName);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1184:13)", "entry");
                                Text.fontSize(13);
                                Text.fontWeight(FontWeight.Medium);
                                Text.fontColor(Theme.textPrimary);
                                Text.maxLines(1);
                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.classroom.length > 0 ? item.classroom : '未定');
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1190:13)", "entry");
                                Text.fontSize(11);
                                Text.fontColor(Theme.textTertiary);
                                Text.margin({ top: 2 });
                                Text.maxLines(1);
                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            }, Text);
                            Text.pop();
                            Column.pop();
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.todayCourses, forEachItemGenFunction, (item: CourseSchedule) => `${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                });
            }
        }, If);
        If.pop();
    }
    MyActivitiesList(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.myActivities.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1218:7)", "entry");
                        Column.width('100%');
                        Column.alignItems(HorizontalAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('暂无活动');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1219:9)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.padding({ left: 16, top: 8, bottom: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const act = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1228:9)", "entry");
                                Row.width('100%');
                                Row.backgroundColor(Theme.bgCard);
                                Row.borderRadius(Theme.cardRadius);
                                Row.padding({ left: 10, right: 10, top: 6, bottom: 6 });
                                Row.alignItems(VerticalAlign.Center);
                                Row.shadow(ShadowStyle.sm);
                                Row.margin({ bottom: 6 });
                                Row.onClick(() => {
                                    this.getUIContext().getRouter().pushUrl({
                                        url: 'pages/ClubActivityDetailPage',
                                        params: { 'id': `${act.id}` } as Record<string, string>
                                    });
                                });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Blank.create();
                                Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(1229:11)", "entry");
                                Blank.width(36);
                            }, Blank);
                            Blank.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1231:11)", "entry");
                                Column.height(40);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1232:13)", "entry");
                                Row.width(3);
                                Row.height('100%');
                                Row.backgroundColor(Theme.ocean);
                                Row.borderRadius(2);
                            }, Row);
                            Row.pop();
                            Column.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Blank.create();
                                Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(1240:11)", "entry");
                                Blank.width(6);
                            }, Blank);
                            Blank.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1242:11)", "entry");
                                Column.layoutWeight(1);
                                Column.alignItems(HorizontalAlign.Start);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1243:13)", "entry");
                                Row.width('100%');
                                Row.alignItems(VerticalAlign.Center);
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(act.title);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1244:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(Theme.textPrimary);
                                Text.fontWeight(FontWeight.Medium);
                                Text.maxLines(1);
                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                Text.layoutWeight(1);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(act.activityTime.length > 0 ? act.activityTime : '');
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1251:15)", "entry");
                                Text.fontSize(11);
                                Text.fontColor(Theme.textTertiary);
                            }, Text);
                            Text.pop();
                            Row.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(act.venue.length > 0 ? act.venue : '');
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1257:13)", "entry");
                                Text.fontSize(11);
                                Text.fontColor(Theme.textTertiary);
                                Text.width('100%');
                                Text.margin({ top: 2 });
                                Text.maxLines(1);
                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            }, Text);
                            Text.pop();
                            Column.pop();
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.myActivities, forEachItemGenFunction, (act: ClubActivityItem) => `${act.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                });
            }
        }, If);
        If.pop();
    }
    TimelineView(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1287:5)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.todayCourses.length === 0 && this.myActivities.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('今天暂无日程');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1289:9)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.padding({ top: 4, bottom: 4 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1295:9)", "entry");
                    Row.width('100%');
                    Row.alignItems(VerticalAlign.Center);
                    Row.margin({ bottom: 8 });
                    Row.onClick(() => {
                        if (item.type === 0 && item.courseData !== null) {
                            this.selectedCourse = item.courseData;
                            this.showCourseDetail = true;
                        }
                        else if (item.type === 1 && item.activityData !== null) {
                            this.getUIContext().getRouter().pushUrl({
                                url: 'pages/ClubActivityDetailPage',
                                params: { 'id': `${item.activityData.id}` } as Record<string, string>
                            });
                        }
                    });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1296:11)", "entry");
                    Column.width(68);
                    Column.alignItems(HorizontalAlign.Center);
                    Column.padding({ right: 8 });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.time);
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1297:13)", "entry");
                    Text.fontSize(11);
                    Text.fontWeight(FontWeight.Medium);
                    Text.fontColor(item.type === 0 ? Theme.scheduleCardFg[index % Theme.scheduleCardFg.length] : Theme.ocean);
                }, Text);
                Text.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1306:11)", "entry");
                    Column.margin({ right: 10 });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1307:13)", "entry");
                    Row.width(3);
                    Row.height(48);
                    Row.backgroundColor(item.type === 0 ? Theme.scheduleCardFg[index % Theme.scheduleCardFg.length] : Theme.ocean);
                    Row.borderRadius(2);
                }, Row);
                Row.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1315:11)", "entry");
                    Column.layoutWeight(1);
                    Column.alignItems(HorizontalAlign.Start);
                    Column.backgroundColor(item.type === 0 ? Theme.scheduleCardBg[index % Theme.scheduleCardBg.length] : Theme.oceanLight);
                    Column.borderRadius(Theme.cardRadius);
                    Column.padding({ left: 12, right: 12, top: 8, bottom: 8 });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.title);
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1316:13)", "entry");
                    Text.fontSize(14);
                    Text.fontWeight(FontWeight.Medium);
                    Text.fontColor(item.type === 0 ? Theme.scheduleCardFg[index % Theme.scheduleCardFg.length] : Theme.ocean);
                    Text.maxLines(1);
                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    Text.width('100%');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.location);
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1323:13)", "entry");
                    Text.fontSize(12);
                    Text.fontColor(Theme.textSecondary);
                    Text.margin({ top: 3 });
                    Text.maxLines(1);
                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    Text.width('100%');
                }, Text);
                Text.pop();
                Column.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.getCombinedTimeline(), forEachItemGenFunction, (item: TimelineItem, index: number) => `${item.type}_${index}`, true, true);
        }, ForEach);
        ForEach.pop();
        Column.pop();
    }
    private isCourseActiveInWeek(item: CourseSchedule, week: number): boolean {
        if (item.startWeek > week || item.endWeek < week) {
            return false;
        }
        if (item.weekParity === 'odd') {
            return week % 2 === 1;
        }
        if (item.weekParity === 'even') {
            return week % 2 === 0;
        }
        return true;
    }
    private semesterTitle(): string {
        return this.semesterName.length > 0 ? this.semesterName : '当前学期';
    }
    private weekDate(dayIndex: number): Date | null {
        const semesterDate: Date | null = semesterWeekDate(this.semesterStartDate, this.currentWeek, dayIndex);
        if (semesterDate !== null) {
            return semesterDate;
        }
        const parts: string[] = this.semesterStartDate.split('-');
        if (parts.length < 3) {
            return null;
        }
        const date: Date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
        const dow: number = date.getDay();
        const offsetToMonday: number = dow === 0 ? -6 : 1 - dow;
        date.setDate(date.getDate() + offsetToMonday + (this.currentWeek - 1) * 7 + dayIndex);
        return date;
    }
    private todayDayIndex(): number {
        const day: number = new Date().getDay();
        return day === 0 ? 6 : day - 1;
    }
    private weekMonthText(): string {
        const date: Date | null = this.weekDate(0);
        if (date === null) {
            return '';
        }
        return `${date.getMonth() + 1}月`;
    }
    private weekDayText(dayIndex: number): string {
        const date: Date | null = this.weekDate(dayIndex);
        if (date === null) {
            return `${dayIndex + 1}`;
        }
        return `${date.getDate()}`;
    }
    private courseAtStart(day: number, section: number): CourseSchedule {
        for (let i = 0; i < this.scheduleList.length; i++) {
            const item: CourseSchedule = this.scheduleList[i];
            if (item.dayOfWeek === day && item.startSection === section && this.isCourseActiveInWeek(item, this.currentWeek)) {
                return item;
            }
        }
        return new CourseSchedule();
    }
    private hasCourseCovering(day: number, section: number): boolean {
        for (let i = 0; i < this.scheduleList.length; i++) {
            const item: CourseSchedule = this.scheduleList[i];
            if (item.dayOfWeek === day && item.startSection < section && item.endSection >= section && this.isCourseActiveInWeek(item, this.currentWeek)) {
                return true;
            }
        }
        return false;
    }
    private courseDuration(item: CourseSchedule): number {
        const duration: number = item.endSection - item.startSection + 1;
        return duration > 0 ? duration : 1;
    }
    private courseBg(item: CourseSchedule): string {
        if (item.source === 'personal') {
            return Theme.personalCardBg[Math.abs(item.colorIndex) % Theme.personalCardBg.length];
        }
        return Theme.scheduleCardBg[Math.abs(item.colorIndex) % Theme.scheduleCardBg.length];
    }
    private courseFg(item: CourseSchedule): string {
        if (item.source === 'personal') {
            return Theme.personalCardFg[Math.abs(item.colorIndex) % Theme.personalCardFg.length];
        }
        return Theme.scheduleCardFg[Math.abs(item.colorIndex) % Theme.scheduleCardFg.length];
    }
    private sectionStartTime(section: number): string {
        if (section >= 1 && section <= Constants.SECTION_TIMES.length) {
            return Constants.SECTION_TIMES[section - 1][0];
        }
        return '';
    }
    private sectionEndTime(section: number): string {
        if (section >= 1 && section <= Constants.SECTION_TIMES.length) {
            return Constants.SECTION_TIMES[section - 1][1];
        }
        return '';
    }
    private courseTimeText(item: CourseSchedule): string {
        return `${this.sectionStartTime(item.startSection)}-${this.sectionEndTime(item.endSection)}`;
    }
    private courseWeekText(item: CourseSchedule): string {
        let text: string = `第${item.startWeek}-${item.endWeek}周`;
        if (item.weekParity === 'odd') {
            text += ' 单周';
        }
        if (item.weekParity === 'even') {
            text += ' 双周';
        }
        return text;
    }
    private courseBriefText(item: CourseSchedule): string {
        const room: string = item.classroom.length > 0 ? item.classroom : '教室未填';
        if (item.teacherName.length > 0) {
            return `${item.courseName} @${room}\n${item.teacherName}`;
        }
        return `${item.courseName} @${room}`;
    }
    private showWeekPicker(): void {
        const weeks: string[] = [];
        for (let i = 1; i <= this.semesterWeekCount; i++) {
            weeks.push(`第${i}周`);
        }
        let currentIdx: number = this.currentWeek - 1;
        TextPickerDialog.show({
            range: weeks,
            selected: currentIdx,
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < weeks.length) {
                    this.currentWeek = idx + 1;
                    this.updateScheduleGrid();
                }
            }
        });
    }
    private backToCurrentWeek(): void {
        this.currentWeek = this.todayWeek;
        this.updateScheduleGrid();
    }
    private openCourseDetail(item: CourseSchedule): void {
        this.selectedCourse = item;
        this.showCourseDetail = true;
    }
    private closeCourseDetail(): void {
        this.showCourseDetail = false;
        this.selectedCourse = new CourseSchedule();
    }
    private showAddCourse(): void {
        router.pushUrl({
            url: 'pages/AddCoursePage',
            params: {
                semesterWeekCount: this.semesterWeekCount,
                semesterTitle: this.semesterTitle()
            }
        }).catch((err: Error) => {
            console.error('[AddCourse] navigate failed:', err.message);
            this.getUIContext().getPromptAction().showToast({ message: '打开添课页失败，请重新编译' });
        });
    }
    private hideAddCourse(): void {
        this.showAddCourseForm = false;
    }
    private showAddDayPicker(): void {
        let currentIdx: number = this.addDayOfWeek - 1;
        TextPickerDialog.show({
            range: WEEK_DAY_LABELS,
            selected: currentIdx,
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < WEEK_DAY_LABELS.length) {
                    this.addDayOfWeek = idx + 1;
                }
            }
        });
    }
    private showAddStartSectionPicker(): void {
        const options: string[] = [];
        for (let i = 1; i <= Constants.SECTION_TIMES.length; i++) {
            options.push(`第${i}节 ${this.sectionStartTime(i)}-${this.sectionEndTime(i)}`);
        }
        TextPickerDialog.show({
            range: options,
            selected: this.addStartSection - 1,
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.addStartSection = idx + 1;
                    if (this.addEndSection < this.addStartSection) {
                        this.addEndSection = this.addStartSection;
                    }
                }
            }
        });
    }
    private showAddEndSectionPicker(): void {
        const options: string[] = [];
        for (let i = 1; i <= Constants.SECTION_TIMES.length; i++) {
            options.push(`第${i}节 ${this.sectionStartTime(i)}-${this.sectionEndTime(i)}`);
        }
        TextPickerDialog.show({
            range: options,
            selected: this.addEndSection - 1,
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.addEndSection = idx + 1;
                    if (this.addEndSection < this.addStartSection) {
                        this.addStartSection = this.addEndSection;
                    }
                }
            }
        });
    }
    private showAddStartWeekPicker(): void {
        const options: string[] = [];
        for (let i = 1; i <= this.semesterWeekCount; i++) {
            options.push(`第${i}周`);
        }
        TextPickerDialog.show({
            range: options,
            selected: this.addStartWeek - 1,
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.addStartWeek = idx + 1;
                    if (this.addEndWeek < this.addStartWeek) {
                        this.addEndWeek = this.addStartWeek;
                    }
                }
            }
        });
    }
    private showAddEndWeekPicker(): void {
        const options: string[] = [];
        for (let i = 1; i <= this.semesterWeekCount; i++) {
            options.push(`第${i}周`);
        }
        TextPickerDialog.show({
            range: options,
            selected: this.addEndWeek - 1,
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.addEndWeek = idx + 1;
                    if (this.addEndWeek < this.addStartWeek) {
                        this.addStartWeek = this.addEndWeek;
                    }
                }
            }
        });
    }
    private async saveManualCourse(): Promise<void> {
        if (this.addCourseName.trim().length === 0) {
            this.getUIContext().getPromptAction().showToast({ message: '请输入课程名称' });
            return;
        }
        const store: AppStore = AppStore.getInstance();
        if (!store.isLoggedIn) {
            this.getUIContext().getPromptAction().showToast({ message: '请先登录' });
            return;
        }
        const params: Record<string, Object> = {
            'semesterId': this.semesterId,
            'courseName': this.addCourseName.trim(),
            'classroom': this.addClassroom.trim(),
            'teacher': this.addTeacherName.trim(),
            'dayOfWeek': this.addDayOfWeek,
            'startSection': this.addStartSection,
            'endSection': this.addEndSection,
            'startWeek': this.addStartWeek,
            'endWeek': this.addEndWeek
        } as Record<string, Object>;
        const result: ApiResult = await ApiService.addPersonalCourse(params);
        if (result.code === 200) {
            this.showAddCourseForm = false;
            this.getUIContext().getPromptAction().showToast({ message: '课程已添加' });
            this.loadSchedule();
        }
        else {
            this.getUIContext().getPromptAction().showToast({ message: result.msg.length > 0 ? result.msg : '添加失败' });
        }
    }
    ScheduleContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/MainPage.ets(1664:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
            Stack.backgroundColor('#FFFFFF');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showAddCourseForm) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.AddCourseContent.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1668:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.backgroundColor('#FFFFFF');
                    }, Column);
                    this.ScheduleHeader.bind(this)();
                    this.ScheduleWeekHeader.bind(this)();
                    this.ScheduleGrid.bind(this)();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.currentWeek !== this.todayWeek) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('切回本周');
                                    Button.debugLine("entry/src/main/ets/pages/MainPage.ets(1678:11)", "entry");
                                    Button.width(88);
                                    Button.height(Theme.buttonHeightSm);
                                    Button.fontSize(14);
                                    Button.fontColor(Color.White);
                                    Button.backgroundColor(Theme.primary);
                                    Button.borderRadius(Theme.buttonRadius);
                                    Button.shadow(ShadowStyle.primary);
                                    Button.position({ x: 292, y: 610 });
                                    Button.onClick(() => {
                                        this.backToCurrentWeek();
                                    });
                                }, Button);
                                Button.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.showCourseDetail) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.CourseDetailOverlay.bind(this)();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    ScheduleHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1704:5)", "entry");
            Row.width('100%');
            Row.height(58);
            Row.padding({ left: 12, right: 14, top: 2, bottom: 2 });
            Row.backgroundColor(Color.White);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1705:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1706:9)", "entry");
            Row.onClick(() => {
                this.showWeekPicker();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`第${this.currentWeek}周`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1707:11)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.danger);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('▼');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1711:11)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.textPrimary);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.semesterTitle());
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1719:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 3 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('+');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1727:7)", "entry");
            Text.fontSize(30);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Bold);
            Text.width(42);
            Text.height(42);
            Text.textAlign(TextAlign.Center);
            Text.backgroundColor(Theme.primary);
            Text.borderRadius(Theme.radiusPill);
            Text.shadow(ShadowStyle.primary);
            Text.onClick(() => {
                this.showAddCourse();
            });
        }, Text);
        Text.pop();
        Row.pop();
    }
    ScheduleWeekHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1749:5)", "entry");
            Row.width('100%');
            Row.height(60);
            Row.border({ width: 1, color: Theme.border });
            Row.backgroundColor(Color.White);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1750:7)", "entry");
            Column.width(50);
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.weekMonthText().length > 0 ? this.weekMonthText().replace('月', '') : '');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1751:9)", "entry");
            Text.fontSize(17);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('月');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1754:9)", "entry");
            Text.fontSize(17);
            Text.fontColor(Theme.textPrimary);
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const day = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1763:9)", "entry");
                    Column.layoutWeight(1);
                    Column.height(58);
                    Column.justifyContent(FlexAlign.Center);
                    Column.alignItems(HorizontalAlign.Center);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(day);
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1764:11)", "entry");
                    Text.fontSize(19);
                    Text.fontColor(Theme.textPrimary);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.weekDayText(index));
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1767:11)", "entry");
                    Text.fontSize(15);
                    Text.fontColor(Theme.textTertiary);
                    Text.margin({ top: 8 });
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, WEEK_DAY_LABELS, forEachItemGenFunction, (day: string, index: number) => `${index}-${day}`, true, true);
        }, ForEach);
        ForEach.pop();
        Row.pop();
    }
    ScheduleGrid(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/MainPage.ets(1786:5)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Off);
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1787:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1788:9)", "entry");
            Column.width(50);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const section = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1790:13)", "entry");
                    Column.width(50);
                    Column.height(SCHEDULE_SECTION_HEIGHT);
                    Column.justifyContent(FlexAlign.Center);
                    Column.alignItems(HorizontalAlign.Center);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(`${section}`);
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1791:15)", "entry");
                    Text.fontSize(18);
                    Text.fontColor(Theme.textPrimary);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.sectionStartTime(section));
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1794:15)", "entry");
                    Text.fontSize(11);
                    Text.fontColor(Theme.textTertiary);
                    Text.margin({ top: 3 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.sectionEndTime(section));
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1798:15)", "entry");
                    Text.fontSize(11);
                    Text.fontColor(Theme.textTertiary);
                    Text.margin({ top: 1 });
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], forEachItemGenFunction, (section: number) => `${section}`, false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1811:9)", "entry");
            Row.layoutWeight(1);
            Row.padding({ right: 6 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const day = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1813:13)", "entry");
                    Column.layoutWeight(1);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const section = _item;
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Stack.create();
                            Stack.debugLine("entry/src/main/ets/pages/MainPage.ets(1815:17)", "entry");
                            Stack.width('100%');
                            Stack.height(SCHEDULE_SECTION_HEIGHT);
                        }, Stack);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Divider.create();
                            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(1816:19)", "entry");
                            Divider.height(1);
                            Divider.color(Theme.border);
                            Divider.width('100%');
                            Divider.position({ x: 0, y: SCHEDULE_SECTION_HEIGHT - 1 });
                        }, Divider);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            if (!this.hasCourseCovering(day, section)) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.ScheduleCell.bind(this)(day, section);
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                });
                            }
                        }, If);
                        If.pop();
                        Stack.pop();
                    };
                    this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], forEachItemGenFunction, (section: number) => `${day}-${section}`, false, false);
                }, ForEach);
                ForEach.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7], forEachItemGenFunction, (day: number) => `${day}`, false, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Row.pop();
        Scroll.pop();
    }
    ScheduleCell(day: number, section: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1844:5)", "entry");
            Column.width('100%');
            Column.height(SCHEDULE_SECTION_HEIGHT);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.courseAtStart(day, section).courseName.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.ScheduleCourseCard.bind(this)(this.courseAtStart(day, section));
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    ScheduleCourseCard(item: CourseSchedule, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1855:5)", "entry");
            Column.width('92%');
            Column.height(this.courseDuration(item) * SCHEDULE_SECTION_HEIGHT - 8);
            Column.padding({ left: 7, right: 5, top: 8, bottom: 6 });
            Column.backgroundColor(this.courseBg(item));
            Column.border({ width: 1, color: this.courseFg(item) });
            Column.borderRadius(8);
            Column.margin({ left: 3, right: 3, top: 4 });
            Column.alignItems(HorizontalAlign.Start);
            Column.onClick(() => {
                this.openCourseDetail(item);
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.courseBriefText(item));
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1856:7)", "entry");
            Text.fontSize(12);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.courseFg(item));
            Text.lineHeight(18);
            Text.maxLines(this.courseDuration(item) <= 1 ? 2 : 5);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Column.pop();
    }
    CourseDetailOverlay(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/MainPage.ets(1879:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1880:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('rgba(255,255,255,0.87)');
            Column.onClick(() => {
                this.closeCourseDetail();
            });
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1888:7)", "entry");
            Column.width('90%');
            Column.position({ x: 20, y: 245 });
        }, Column);
        this.CourseDetailCard.bind(this)(ObservedObject.GetRawObject(this.selectedCourse), false);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.selectedCourse.weekParity !== 'all') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.CourseDetailCard.bind(this)(ObservedObject.GetRawObject(this.selectedCourse), true);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Stack.pop();
    }
    CourseDetailCard(item: CourseSchedule, parityCard: boolean, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1903:5)", "entry");
            Column.width('100%');
            Column.padding(24);
            Column.backgroundColor(Theme.bgPage);
            Column.borderRadius(Theme.cardRadius);
            Column.shadow(ShadowStyle.md);
            Column.margin({ bottom: 18 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1904:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (parityCard) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('非本周');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1906:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Color.White);
                        Text.backgroundColor(Theme.textPrimary);
                        Text.borderRadius(4);
                        Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                        Text.margin({ right: 8 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.courseName.length > 0 ? item.courseName : '课程名称未录入');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1914:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.source === 'personal') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('个人');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1920:11)", "entry");
                        Text.fontSize(11);
                        Text.fontColor('#FFFFFF');
                        Text.backgroundColor(Theme.danger);
                        Text.borderRadius(4);
                        Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                        Text.margin({ left: 4 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.source === 'personal') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('删除');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1929:11)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.danger);
                        Text.padding({ left: 12, right: 12, top: 8, bottom: 8 });
                        Text.backgroundColor(Color.White);
                        Text.borderRadius(5);
                        Text.onClick(async () => {
                            const result: ApiResult = await ApiService.deletePersonalCourse(item.id);
                            if (result.code === 200) {
                                this.getUIContext().getPromptAction().showToast({ message: '已删除' });
                                this.showCourseDetail = false;
                                this.loadSchedule();
                            }
                            else {
                                this.getUIContext().getPromptAction().showToast({ message: result.msg.length > 0 ? result.msg : '删除失败' });
                            }
                        });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('编辑');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1946:11)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.textTertiary);
                        Text.padding({ left: 12, right: 12, top: 8, bottom: 8 });
                        Text.backgroundColor(Color.White);
                        Text.borderRadius(5);
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.courseWeekText(item));
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1956:7)", "entry");
            Text.fontSize(17);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ top: 18 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`周${WEEK_DAY_LABELS[item.dayOfWeek - 1]} | 第${item.startSection}-${item.endSection}节 | ${this.courseTimeText(item)}`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1961:7)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`教室：${item.classroom.length > 0 ? item.classroom : '未填写'}`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1966:7)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`老师：${item.teacherName.length > 0 ? item.teacherName : '未填写'}`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1971:7)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    AddCourseContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(1988:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Color.White);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(1989:7)", "entry");
            Row.width('100%');
            Row.height(52);
            Row.padding({ left: 18, right: 18 });
            Row.border({ width: 1, color: Theme.border });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('<');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1990:9)", "entry");
            Text.fontSize(30);
            Text.fontColor(Theme.textPrimary);
            Text.width(50);
            Text.onClick(() => {
                this.hideAddCourse();
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('添加课程');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(1997:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('保存');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2003:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.primary);
            Text.width(50);
            Text.textAlign(TextAlign.End);
            Text.onClick(() => {
                this.saveManualCourse();
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/MainPage.ets(2017:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2018:9)", "entry");
            Column.width('100%');
            Column.padding({ left: 28, right: 28, bottom: 30 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2019:11)", "entry");
            Row.width('100%');
            Row.padding(20);
            Row.backgroundColor(Theme.primaryLight);
            Row.borderRadius(3);
            Row.margin({ top: 8, bottom: 18 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2020:13)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('当前学期为');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2021:15)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.primary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('返回课程表页面即可切换学期');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2025:15)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.primary);
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.semesterTitle());
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2032:13)", "entry");
            Text.fontSize(18);
            Text.fontColor(Theme.primary);
        }, Text);
        Text.pop();
        Row.pop();
        this.AddInputRow.bind(this)('课程名称', '请输入添加的课程名称', this.addCourseName, 1);
        this.AddSelectRow.bind(this)('课程周期', `第${this.addStartWeek}-${this.addEndWeek}周`, 1);
        this.AddSelectRow.bind(this)('课程节数', `周${WEEK_DAY_LABELS[this.addDayOfWeek - 1]} 第${this.addStartSection}-${this.addEndSection}节`, 2);
        this.AddInputRow.bind(this)('教室地点', '请输入教室地点', this.addClassroom, 2);
        this.AddInputRow.bind(this)('任课老师', '请输入任课老师', this.addTeacherName, 3);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('如果有多个上课时间，点此增加上课时间  +');
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(2048:11)", "entry");
            Button.width('100%');
            Button.height(58);
            Button.fontSize(17);
            Button.fontColor(Theme.primary);
            Button.backgroundColor(Theme.primaryLight);
            Button.borderRadius(8);
            Button.margin({ top: 34 });
            Button.onClick(() => {
                this.getUIContext().getPromptAction().showToast({ message: '当前版本先支持一个上课时间' });
            });
        }, Button);
        Button.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    AddInputRow(label: string, placeholder: string, value: string, type: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2073:5)", "entry");
            Row.width('100%');
            Row.height(70);
            Row.border({ width: 1, color: Theme.border });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2074:7)", "entry");
            Text.fontSize(19);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width(104);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: placeholder, text: value });
            TextInput.debugLine("entry/src/main/ets/pages/MainPage.ets(2079:7)", "entry");
            TextInput.layoutWeight(1);
            TextInput.height(52);
            TextInput.fontSize(16);
            TextInput.textAlign(TextAlign.End);
            TextInput.backgroundColor('#00000000');
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.onChange((val: string) => {
                if (type === 1) {
                    this.addCourseName = val;
                }
                if (type === 2) {
                    this.addClassroom = val;
                }
                if (type === 3) {
                    this.addTeacherName = val;
                }
            });
        }, TextInput);
        Row.pop();
    }
    AddSelectRow(label: string, value: string, type: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2105:5)", "entry");
            Row.width('100%');
            Row.height(70);
            Row.border({ width: 1, color: Theme.border });
            Row.onClick(() => {
                if (type === 1) {
                    this.showAddStartWeekPicker();
                    setTimeout(() => {
                        this.showAddEndWeekPicker();
                    }, 400);
                }
                if (type === 2) {
                    this.showAddDayPicker();
                    setTimeout(() => {
                        this.showAddStartSectionPicker();
                    }, 400);
                    setTimeout(() => {
                        this.showAddEndSectionPicker();
                    }, 800);
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2106:7)", "entry");
            Text.fontSize(19);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width(104);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2111:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(value);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2112:7)", "entry");
            Text.fontSize(17);
            Text.fontColor(type === 2 ? Theme.danger : Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2115:7)", "entry");
            Text.fontSize(24);
            Text.fontColor(Theme.textDisabled);
            Text.margin({ left: 10 });
        }, Text);
        Text.pop();
        Row.pop();
    }
    private __searchKeyword: ObservedPropertySimplePU<string>;
    get searchKeyword() {
        return this.__searchKeyword.get();
    }
    set searchKeyword(newValue: string) {
        this.__searchKeyword.set(newValue);
    }
    private __searchSuggestions: ObservedPropertyObjectPU<string[]>;
    get searchSuggestions() {
        return this.__searchSuggestions.get();
    }
    set searchSuggestions(newValue: string[]) {
        this.__searchSuggestions.set(newValue);
    }
    private __showSuggestions: ObservedPropertySimplePU<boolean>;
    get showSuggestions() {
        return this.__showSuggestions.get();
    }
    set showSuggestions(newValue: boolean) {
        this.__showSuggestions.set(newValue);
    }
    private __marketRefreshing: ObservedPropertySimplePU<boolean>;
    get marketRefreshing() {
        return this.__marketRefreshing.get();
    }
    set marketRefreshing(newValue: boolean) {
        this.__marketRefreshing.set(newValue);
    }
    private async refreshMarket(): Promise<void> {
        this.marketRefreshing = true;
        await this.refreshProducts();
        this.marketRefreshing = false;
    }
    ProductCard(item: Product, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2156:5)", "entry");
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.shadow(ShadowStyle.nmRaised);
            Column.onClick(() => {
                const detailParams: Record<string, Object> = {
                    'productId': item.id
                } as Record<string, Object>;
                this.getUIContext().getRouter().pushUrl({
                    url: 'pages/ProductDetailPage',
                    params: detailParams
                });
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.images.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(`${ApiService.baseUrl}${item.images[0]}`);
                        Image.debugLine("entry/src/main/ets/pages/MainPage.ets(2158:9)", "entry");
                        Image.width('100%');
                        Image.aspectRatio(1);
                        Image.borderRadius({ topLeft: Theme.cardRadius, topRight: Theme.cardRadius });
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2164:9)", "entry");
                        Column.width('100%');
                        Column.aspectRatio(1);
                        Column.backgroundColor(Theme.bgInput);
                        Column.borderRadius({ topLeft: Theme.cardRadius, topRight: Theme.cardRadius });
                        Column.justifyContent(FlexAlign.Center);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('暂无图片');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2165:11)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2176:7)", "entry");
            Column.padding({ left: 10, right: 10, top: 9, bottom: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2177:9)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.maxLines(2);
            Text.lineHeight(18);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2184:9)", "entry");
            Row.margin({ top: 6 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`¥${item.price}`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2185:11)", "entry");
            Text.fontSize(16);
            Text.fontColor(Theme.primary);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.originalPrice > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`¥${item.originalPrice}`);
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2190:13)", "entry");
                        Text.fontSize(10);
                        Text.fontColor(Theme.textDisabled);
                        Text.decoration({ type: TextDecorationType.LineThrough });
                        Text.margin({ left: 4 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.campusLocation.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(item.campusLocation);
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2199:11)", "entry");
                        Text.fontSize(10);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 4 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Column.pop();
    }
    MarketContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Refresh.create({ refreshing: { value: this.marketRefreshing, changeEvent: newValue => { this.marketRefreshing = newValue; } } });
            Refresh.debugLine("entry/src/main/ets/pages/MainPage.ets(2224:5)", "entry");
            Refresh.onRefreshing(() => {
                this.refreshMarket();
            });
            Refresh.backgroundColor(Theme.bgPage);
            Refresh.width('100%');
            Refresh.height('100%');
        }, Refresh);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2225:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2226:9)", "entry");
            Row.width('100%');
            Row.padding({ left: 20, right: 20, top: 18, bottom: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('二手交易');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2227:11)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2231:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('+ 发布');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2232:11)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.primary);
            Text.fontWeight(FontWeight.Medium);
            Text.onClick(() => {
                this.getUIContext().getRouter().pushUrl({ url: 'pages/PublishPage' });
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2239:11)", "entry");
            Blank.width(16);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/MainPage.ets(2240:11)", "entry");
            Stack.width(28);
            Stack.height(28);
            Stack.onClick(() => {
                this.unreadCount = 0;
                this.currentTab = 2;
            });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('💬');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2241:13)", "entry");
            Text.fontSize(20);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.unreadCount > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.unreadCount > 99 ? '99+' : `${this.unreadCount}`);
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2244:15)", "entry");
                        Text.fontSize(9);
                        Text.fontColor(Color.White);
                        Text.padding({ left: 4, right: 4, top: 1, bottom: 1 });
                        Text.borderRadius(10);
                        Text.backgroundColor(Theme.danger);
                        Text.position({ x: 14, y: -4 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/MainPage.ets(2263:9)", "entry");
            Stack.width('100%');
            Stack.padding({ left: 20, right: 20, bottom: 4 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '搜索商品...', text: this.searchKeyword });
            TextInput.debugLine("entry/src/main/ets/pages/MainPage.ets(2264:11)", "entry");
            TextInput.fontSize(14);
            TextInput.height(40);
            TextInput.borderRadius(20);
            TextInput.backgroundColor(Theme.bgCard);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.shadow(ShadowStyle.sm);
            TextInput.onChange((v: string) => {
                this.searchKeyword = v;
                this.loadSearchSuggestions(v);
            });
            TextInput.onSubmit(() => {
                this.searchProducts();
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showSuggestions && this.searchSuggestions.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2279:13)", "entry");
                        Column.width('92%');
                        Column.backgroundColor(Theme.bgCard);
                        Column.borderRadius(Theme.cardRadius);
                        Column.shadow(ShadowStyle.md);
                        Column.position({ y: 42 });
                        Column.zIndex(10);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const suggestion = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2281:17)", "entry");
                                Row.width('100%');
                                Row.onClick(() => {
                                    this.searchKeyword = suggestion;
                                    this.showSuggestions = false;
                                    this.searchProducts();
                                });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(suggestion);
                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2282:19)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(Theme.textPrimary);
                                Text.padding({ left: 16, right: 16, top: 8, bottom: 8 });
                            }, Text);
                            Text.pop();
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.searchSuggestions, forEachItemGenFunction, (suggestion: string, index: number) => `${index}`, false, true);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/MainPage.ets(2306:9)", "entry");
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2307:11)", "entry");
            Row.padding({ left: 20, right: 20, bottom: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('全部');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2308:13)", "entry");
            Text.fontSize(13);
            Text.fontColor(this.selectedCategoryId === 0 ? Theme.primary : Theme.textSecondary);
            Text.padding({ left: 12, right: 12, top: 6, bottom: 6 });
            Text.borderRadius(Theme.radiusPill);
            Text.backgroundColor(this.selectedCategoryId === 0 ? Theme.primaryLight : Theme.bgCard);
            Text.shadow(ShadowStyle.sm);
            Text.onClick(() => {
                this.selectedCategoryId = 0;
                this.refreshProducts();
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const cat = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(cat.name);
                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2320:15)", "entry");
                    Text.fontSize(13);
                    Text.fontColor(this.selectedCategoryId === cat.id ? Theme.primary : Theme.textSecondary);
                    Text.padding({ left: cat.parentId === 0 ? 12 : 8, right: cat.parentId === 0 ? 12 : 8, top: 6, bottom: 6 });
                    Text.borderRadius(Theme.radiusPill);
                    Text.backgroundColor(this.selectedCategoryId === cat.id ? Theme.primaryLight : Theme.bgCard);
                    Text.shadow(ShadowStyle.sm);
                    Text.onClick(() => {
                        this.selectedCategoryId = cat.id;
                        this.refreshProducts();
                    });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.categories, forEachItemGenFunction, (cat: ProductCategory) => `${cat.id}`, false, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.productError.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2339:11)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.productError);
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2340:13)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.textSecondary);
                        Text.textAlign(TextAlign.Center);
                        Text.padding({ left: 20, right: 20 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('重试');
                        Button.debugLine("entry/src/main/ets/pages/MainPage.ets(2345:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.height(40);
                        Button.fontSize(14);
                        Button.fontColor('#FFFFFF');
                        Button.backgroundColor(Theme.primary);
                        Button.margin({ top: 16 });
                        Button.onClick(() => { this.refreshProducts(); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.products.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2358:11)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('暂无商品');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2359:13)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('点击右上角发布你的第一件二手商品');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2363:13)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create();
                        List.debugLine("entry/src/main/ets/pages/MainPage.ets(2372:11)", "entry");
                        List.layoutWeight(1);
                        List.scrollBar(BarState.Auto);
                        List.edgeEffect(EdgeEffect.Spring);
                        List.padding({ left: 12, right: 12, top: 4 });
                        List.onReachEnd(() => {
                            this.loadMoreProducts();
                        });
                    }, List);
                    {
                        const itemCreation = (elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            ListItem.create(deepRenderFunction, true);
                            if (!isInitialRender) {
                                ListItem.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        };
                        const itemCreation2 = (elmtId, isInitialRender) => {
                            ListItem.create(deepRenderFunction, true);
                            ListItem.debugLine("entry/src/main/ets/pages/MainPage.ets(2373:13)", "entry");
                        };
                        const deepRenderFunction = (elmtId, isInitialRender) => {
                            itemCreation(elmtId, isInitialRender);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create({ space: 8 });
                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2374:15)", "entry");
                                Row.width('100%');
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create({ space: 8 });
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2375:17)", "entry");
                                Column.layoutWeight(1);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                ForEach.create();
                                const forEachItemGenFunction = _item => {
                                    const item = _item;
                                    this.ProductCard.bind(this)(item);
                                };
                                this.forEachUpdateFunction(elmtId, this.products.filter((_v: Product, i: number) => i % 2 === 0), forEachItemGenFunction, (item: Product, _index: number) => `l-${item.id}`, false, true);
                            }, ForEach);
                            ForEach.pop();
                            Column.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create({ space: 8 });
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2382:17)", "entry");
                                Column.layoutWeight(1);
                                Column.margin({ top: 24 });
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                ForEach.create();
                                const forEachItemGenFunction = _item => {
                                    const item = _item;
                                    this.ProductCard.bind(this)(item);
                                };
                                this.forEachUpdateFunction(elmtId, this.products.filter((_v: Product, i: number) => i % 2 === 1), forEachItemGenFunction, (item: Product, _index: number) => `r-${item.id}`, false, true);
                            }, ForEach);
                            ForEach.pop();
                            Column.pop();
                            Row.pop();
                            ListItem.pop();
                        };
                        this.observeComponentCreation2(itemCreation2, ListItem);
                        ListItem.pop();
                    }
                    {
                        const itemCreation = (elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            ListItem.create(deepRenderFunction, true);
                            if (!isInitialRender) {
                                ListItem.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        };
                        const itemCreation2 = (elmtId, isInitialRender) => {
                            ListItem.create(deepRenderFunction, true);
                            ListItem.debugLine("entry/src/main/ets/pages/MainPage.ets(2393:13)", "entry");
                        };
                        const deepRenderFunction = (elmtId, isInitialRender) => {
                            itemCreation(elmtId, isInitialRender);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2394:15)", "entry");
                                Column.width('100%');
                                Column.padding({ bottom: 80 });
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.productLoadingMore) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Row.create();
                                            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2396:19)", "entry");
                                            Row.justifyContent(FlexAlign.Center);
                                            Row.width('100%');
                                            Row.padding({ top: 12, bottom: 12 });
                                        }, Row);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            LoadingProgress.create();
                                            LoadingProgress.debugLine("entry/src/main/ets/pages/MainPage.ets(2397:21)", "entry");
                                            LoadingProgress.width(20);
                                            LoadingProgress.height(20);
                                            LoadingProgress.color(Theme.primary);
                                        }, LoadingProgress);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('加载更多...');
                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2398:21)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textSecondary);
                                            Text.margin({ left: 8 });
                                        }, Text);
                                        Text.pop();
                                        Row.pop();
                                    });
                                }
                                else if (!this.productHasMore) {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('- 没有更多了 -');
                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2405:19)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.width('100%');
                                            Text.textAlign(TextAlign.Center);
                                            Text.padding({ top: 12, bottom: 12 });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(2, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                            Column.pop();
                            ListItem.pop();
                        };
                        this.observeComponentCreation2(itemCreation2, ListItem);
                        ListItem.pop();
                    }
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Refresh.pop();
    }
    private cleanMarkdown(md: string): string {
        let text: string = md;
        text = text.replace(new RegExp('###\\s+', 'g'), '');
        text = text.replace(new RegExp('##\\s+', 'g'), '');
        text = text.replace(new RegExp('#\\s+', 'g'), '');
        text = text.replace(new RegExp('\\*\\*(.+?)\\*\\*', 'g'), '$1');
        return text;
    }
    private sendAiMessage(): void {
        const text: string = this.aiInputText.trim();
        if (text.length === 0 || this.aiIsLoading) {
            return;
        }
        const userMsg: AiMsg = new AiMsg();
        userMsg.role = 'user';
        userMsg.content = text;
        this.aiMessages.push(userMsg);
        this.aiInputText = '';
        this.aiIsLoading = true;
        this.aiStreamingIndex = this.aiMessages.length;
        this.aiStreamText = '';
        this.aiThinking = false;
        const aiMsg: AiMsg = new AiMsg();
        aiMsg.role = 'assistant';
        aiMsg.content = '';
        this.aiMessages.push(aiMsg);
        this.aiMessages = [...this.aiMessages];
        setTimeout(() => {
            this.aiScroller.scrollEdge(Edge.Bottom);
        }, 50);
        const sIdx: number = this.aiStreamingIndex;
        const baseUrl: string = `${ApiService.baseUrl.substring(0, ApiService.baseUrl.lastIndexOf(':'))}:8000`;
        const url: string = `${baseUrl}/api/ai/chat`;
        const req: http.HttpRequest = http.createHttp();
        this.aiHttpRequest = req;
        let sseBuffer: string = '';
        this.aiPendingText = '';
        this.aiFlushTimer = setInterval(() => {
            if (this.aiPendingText.length > 0) {
                this.aiStreamText += this.aiPendingText;
                this.aiPendingText = '';
                this.aiScroller.scrollEdge(Edge.Bottom);
            }
        }, 80);
        req.on('dataReceive', (data: ArrayBuffer) => {
            const chunk: string = this.textDecoder.decodeToString(new Uint8Array(data));
            sseBuffer += chunk;
            const lines: string[] = sseBuffer.split('\n');
            sseBuffer = '';
            for (let i: number = 0; i < lines.length; i++) {
                const line: string = lines[i].trim();
                if (line.length === 0) {
                    continue;
                }
                if (line === 'data: [DONE]') {
                    continue;
                }
                if (line.startsWith('data: ')) {
                    const jsonStr: string = line.substring(6);
                    try {
                        const parsed: Record<string, string> = JSON.parse(jsonStr) as Record<string, string>;
                        if (parsed['error'] !== undefined) {
                            this.aiStreamText = 'AI 服务出错: ' + parsed['error'];
                            this.aiScroller.scrollEdge(Edge.Bottom);
                        }
                        else if (parsed['status'] === 'thinking') {
                            this.aiThinking = true;
                            this.aiScroller.scrollEdge(Edge.Bottom);
                        }
                        else {
                            const content: string = parsed['content'] ?? '';
                            if (content.length > 0) {
                                this.aiThinking = false;
                                this.aiPendingText += content;
                            }
                        }
                    }
                    catch (_e) {
                    }
                }
                else if (!line.startsWith('data:')) {
                    sseBuffer = line;
                }
            }
        });
        req.on('dataEnd', () => {
            if (this.aiFlushTimer !== -1) {
                clearInterval(this.aiFlushTimer);
                this.aiFlushTimer = -1;
            }
            if (this.aiPendingText.length > 0) {
                this.aiStreamText += this.aiPendingText;
                this.aiPendingText = '';
            }
            const finalText: string = this.aiStreamText.length > 0 ? this.aiStreamText : '抱歉，AI 服务未返回内容';
            this.aiMessages[sIdx].content = finalText;
            this.aiMessages = [...this.aiMessages];
            this.aiStreamingIndex = -1;
            this.aiIsLoading = false;
            this.aiThinking = false;
            this.aiStreamText = '';
            req.off('dataReceive');
            req.off('dataEnd');
            req.destroy();
            this.aiHttpRequest = null;
            this.aiScroller.scrollEdge(Edge.Bottom);
        });
        req.requestInStream(url, {
            method: http.RequestMethod.POST,
            header: {
                'Content-Type': 'application/json',
                'Accept': 'text/event-stream'
            },
            extraData: JSON.stringify({ 'question': text } as Record<string, string>),
            readTimeout: 120000,
            connectTimeout: 15000
        }, (err: BusinessError, data: number) => {
            if (err) {
                if (this.aiFlushTimer !== -1) {
                    clearInterval(this.aiFlushTimer);
                    this.aiFlushTimer = -1;
                }
                this.aiMessages[sIdx].content = '网络错误，无法连接 AI 服务';
                this.aiMessages = [...this.aiMessages];
                this.aiStreamingIndex = -1;
                this.aiIsLoading = false;
                this.aiThinking = false;
                this.aiStreamText = '';
                this.aiPendingText = '';
                req.off('dataReceive');
                req.off('dataEnd');
                req.destroy();
                this.aiHttpRequest = null;
            }
        });
    }
    AIChatContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2581:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2582:7)", "entry");
            Row.width('100%');
            Row.padding({ left: 20, right: 20, top: 16, bottom: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('AI 校园助手');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2583:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 12, scroller: this.aiScroller });
            List.debugLine("entry/src/main/ets/pages/MainPage.ets(2591:7)", "entry");
            List.layoutWeight(1);
            List.width('100%');
            List.scrollBar(BarState.Auto);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const msg = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, true);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/MainPage.ets(2593:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2594:13)", "entry");
                            Row.width('100%');
                            Row.alignItems(VerticalAlign.Top);
                            Row.padding({ left: 16, right: 16, top: 6, bottom: 6 });
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            if (msg.role === 'user') {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2596:17)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2597:17)", "entry");
                                        Column.padding(12);
                                        Column.backgroundColor(Theme.primary);
                                        Column.borderRadius({ topLeft: 16, topRight: 4, bottomLeft: 16, bottomRight: 16 });
                                        Column.constraintSize({ maxWidth: '75%' });
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(msg.content);
                                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2598:19)", "entry");
                                        Text.fontSize(15);
                                        Text.fontColor(Color.White);
                                        Text.lineHeight(22);
                                    }, Text);
                                    Text.pop();
                                    Column.pop();
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2608:17)", "entry");
                                        Column.padding(12);
                                        Column.backgroundColor(Theme.border);
                                        Column.borderRadius({ topLeft: 4, topRight: 16, bottomLeft: 16, bottomRight: 16 });
                                        Column.constraintSize({ maxWidth: '75%' });
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        If.create();
                                        if (this.aiThinking && index === this.aiStreamingIndex) {
                                            this.ifElseBranchUpdateFunction(0, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Row.create({ space: 4 });
                                                    Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2610:21)", "entry");
                                                }, Row);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    LoadingProgress.create();
                                                    LoadingProgress.debugLine("entry/src/main/ets/pages/MainPage.ets(2611:23)", "entry");
                                                    LoadingProgress.width(16);
                                                    LoadingProgress.height(16);
                                                    LoadingProgress.color(Theme.primary);
                                                }, LoadingProgress);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create('正在检索知识库...');
                                                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2615:23)", "entry");
                                                    Text.fontSize(14);
                                                    Text.fontColor(Theme.textTertiary);
                                                }, Text);
                                                Text.pop();
                                                Row.pop();
                                            });
                                        }
                                        else if (index === this.aiStreamingIndex && this.aiIsLoading) {
                                            this.ifElseBranchUpdateFunction(1, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    If.create();
                                                    if (this.aiStreamText.length > 0) {
                                                        this.ifElseBranchUpdateFunction(0, () => {
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Text.create(this.cleanMarkdown(this.aiStreamText));
                                                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2621:23)", "entry");
                                                                Text.fontSize(15);
                                                                Text.fontColor(Theme.textPrimary);
                                                                Text.lineHeight(22);
                                                            }, Text);
                                                            Text.pop();
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Text.create('▍');
                                                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2625:23)", "entry");
                                                                Text.fontSize(15);
                                                                Text.fontColor(Theme.primary);
                                                            }, Text);
                                                            Text.pop();
                                                        });
                                                    }
                                                    else {
                                                        this.ifElseBranchUpdateFunction(1, () => {
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Row.create({ space: 4 });
                                                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2629:23)", "entry");
                                                            }, Row);
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                LoadingProgress.create();
                                                                LoadingProgress.debugLine("entry/src/main/ets/pages/MainPage.ets(2630:25)", "entry");
                                                                LoadingProgress.width(16);
                                                                LoadingProgress.height(16);
                                                                LoadingProgress.color(Theme.primary);
                                                            }, LoadingProgress);
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Text.create('思考中...');
                                                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2634:25)", "entry");
                                                                Text.fontSize(14);
                                                                Text.fontColor(Theme.textTertiary);
                                                            }, Text);
                                                            Text.pop();
                                                            Row.pop();
                                                        });
                                                    }
                                                }, If);
                                                If.pop();
                                            });
                                        }
                                        else if (msg.content.length > 0) {
                                            this.ifElseBranchUpdateFunction(2, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create(this.cleanMarkdown(msg.content));
                                                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2640:21)", "entry");
                                                    Text.fontSize(15);
                                                    Text.fontColor(Theme.textPrimary);
                                                    Text.lineHeight(22);
                                                }, Text);
                                                Text.pop();
                                            });
                                        }
                                        else {
                                            this.ifElseBranchUpdateFunction(3, () => {
                                            });
                                        }
                                    }, If);
                                    If.pop();
                                    Column.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2650:17)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                });
                            }
                        }, If);
                        If.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.aiMessages, forEachItemGenFunction, (msg: AiMsg, index: number) => `${index}`, true, true);
        }, ForEach);
        ForEach.pop();
        List.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2663:7)", "entry");
            Row.width('100%');
            Row.padding({ left: 16, right: 16, top: 8, bottom: 24 });
            Row.backgroundColor(Color.White);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '输入你的问题...', text: this.aiInputText });
            TextInput.debugLine("entry/src/main/ets/pages/MainPage.ets(2664:9)", "entry");
            TextInput.layoutWeight(1);
            TextInput.height(44);
            TextInput.fontSize(14);
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(22);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.enabled(!this.aiIsLoading);
            TextInput.onChange((v: string) => { this.aiInputText = v; });
            TextInput.onSubmit(() => { this.sendAiMessage(); });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('发送');
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(2675:9)", "entry");
            Button.height(44);
            Button.fontSize(14);
            Button.fontColor(Color.White);
            Button.backgroundColor(Theme.primary);
            Button.borderRadius(22);
            Button.margin({ left: 8 });
            Button.padding({ left: 16, right: 16 });
            Button.enabled(!this.aiIsLoading);
            Button.type(ButtonType.Capsule);
            Button.onClick(() => { this.sendAiMessage(); });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    MessageContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2698:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2699:7)", "entry");
            Row.width('100%');
            Row.padding({ left: 20, right: 20, top: 16, bottom: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('消息');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2700:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2704:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('刷新');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2705:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.primary);
            Text.onClick(() => { this.loadConversations(); });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!AppStore.getInstance().isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2714:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2715:11)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('登录后可以查看买卖双方的会话');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2719:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/MainPage.ets(2723:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.primary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 20 });
                        Button.onClick(() => { router.pushUrl({ url: 'pages/LoginPage' }); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.conversationLoading) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2734:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MainPage.ets(2735:11)", "entry");
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                        LoadingProgress.color(Theme.primary);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在加载会话');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2736:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.conversationError.length > 0) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2745:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.conversationError);
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2746:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('重试');
                        Button.debugLine("entry/src/main/ets/pages/MainPage.ets(2749:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.primary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 18 });
                        Button.onClick(() => { this.loadConversations(); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2760:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Start);
                        Column.backgroundColor('#FFFFFF');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '搜索联系人或消息', text: this.conversationKeyword });
                        TextInput.debugLine("entry/src/main/ets/pages/MainPage.ets(2761:11)", "entry");
                        TextInput.height(40);
                        TextInput.fontSize(14);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(20);
                        TextInput.margin({ left: 16, right: 16, top: 12, bottom: 12 });
                        TextInput.onChange((value: string) => { this.conversationKeyword = value; });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.conversations.length === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2770:13)", "entry");
                                    Column.width('100%');
                                    Column.padding({ top: 40, left: 16, right: 16 });
                                    Column.alignItems(HorizontalAlign.Center);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('暂无会话');
                                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2771:15)", "entry");
                                    Text.fontSize(18);
                                    Text.fontWeight(FontWeight.Medium);
                                    Text.fontColor(Theme.textPrimary);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('从商品详情页联系卖家后，会话会显示在这里');
                                    Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2775:15)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textSecondary);
                                    Text.margin({ top: 8 });
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    List.create();
                                    List.debugLine("entry/src/main/ets/pages/MainPage.ets(2784:13)", "entry");
                                    List.width('100%');
                                    List.layoutWeight(1);
                                    List.backgroundColor('#FFFFFF');
                                }, List);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        {
                                            const itemCreation = (elmtId, isInitialRender) => {
                                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                ListItem.create(deepRenderFunction, true);
                                                if (!isInitialRender) {
                                                    ListItem.pop();
                                                }
                                                ViewStackProcessor.StopGetAccessRecording();
                                            };
                                            const itemCreation2 = (elmtId, isInitialRender) => {
                                                ListItem.create(deepRenderFunction, true);
                                                ListItem.debugLine("entry/src/main/ets/pages/MainPage.ets(2786:17)", "entry");
                                            };
                                            const deepRenderFunction = (elmtId, isInitialRender) => {
                                                itemCreation(elmtId, isInitialRender);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    If.create();
                                                    if (this.shouldShowConversation(item)) {
                                                        this.ifElseBranchUpdateFunction(0, () => {
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Column.create();
                                                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2788:21)", "entry");
                                                                Column.width('100%');
                                                            }, Column);
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Row.create();
                                                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2789:23)", "entry");
                                                                Row.width('100%');
                                                                Row.padding({ left: 16, right: 16, top: 14, bottom: 14 });
                                                                Row.backgroundColor('#FFFFFF');
                                                                Row.onClick(() => { this.goChat(item); });
                                                            }, Row);
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Stack.create({ alignContent: Alignment.BottomEnd });
                                                                Stack.debugLine("entry/src/main/ets/pages/MainPage.ets(2790:25)", "entry");
                                                                Stack.width(50);
                                                                Stack.height(50);
                                                            }, Stack);
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Text.create(item.otherUserName.length > 0 ? item.otherUserName.substring(0, 1) : '聊');
                                                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2791:27)", "entry");
                                                                Text.fontSize(20);
                                                                Text.fontWeight(FontWeight.Bold);
                                                                Text.fontColor('#FFFFFF');
                                                                Text.width(48);
                                                                Text.height(48);
                                                                Text.borderRadius(24);
                                                                Text.textAlign(TextAlign.Center);
                                                                Text.backgroundColor(Theme.primary);
                                                            }, Text);
                                                            Text.pop();
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                If.create();
                                                                if (this.isUserOnline(item.otherUserId)) {
                                                                    this.ifElseBranchUpdateFunction(0, () => {
                                                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                            Text.create('');
                                                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2797:29)", "entry");
                                                                            Text.width(11);
                                                                            Text.height(11);
                                                                            Text.borderRadius(6);
                                                                            Text.backgroundColor(Theme.success);
                                                                            Text.border({ width: 2, color: '#FFFFFF' });
                                                                        }, Text);
                                                                        Text.pop();
                                                                    });
                                                                }
                                                                else {
                                                                    this.ifElseBranchUpdateFunction(1, () => {
                                                                    });
                                                                }
                                                            }, If);
                                                            If.pop();
                                                            Stack.pop();
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Column.create();
                                                                Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2804:25)", "entry");
                                                                Column.layoutWeight(1);
                                                                Column.margin({ left: 12 });
                                                            }, Column);
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Row.create();
                                                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2805:27)", "entry");
                                                                Row.width('100%');
                                                            }, Row);
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Text.create(item.otherUserName.length > 0 ? item.otherUserName : '用户');
                                                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2806:29)", "entry");
                                                                Text.fontSize(16);
                                                                Text.fontWeight(FontWeight.Medium);
                                                                Text.fontColor(Theme.textPrimary);
                                                                Text.maxLines(1);
                                                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                                                Text.layoutWeight(1);
                                                            }, Text);
                                                            Text.pop();
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Text.create(this.formatConvTime(item.lastTime));
                                                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2810:29)", "entry");
                                                                Text.fontSize(12);
                                                                Text.fontColor(Theme.textTertiary);
                                                            }, Text);
                                                            Text.pop();
                                                            Row.pop();
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Row.create();
                                                                Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2813:27)", "entry");
                                                                Row.width('100%');
                                                                Row.margin({ top: 6 });
                                                            }, Row);
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Text.create(this.previewConvText(item));
                                                                Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2814:29)", "entry");
                                                                Text.fontSize(14);
                                                                Text.fontColor(item.unreadCount > 0 ? Theme.textPrimary : Theme.textTertiary);
                                                                Text.maxLines(1);
                                                                Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                                                Text.layoutWeight(1);
                                                            }, Text);
                                                            Text.pop();
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                If.create();
                                                                if (item.unreadCount > 0) {
                                                                    this.ifElseBranchUpdateFunction(0, () => {
                                                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                            Text.create(item.unreadCount > 99 ? '99+' : item.unreadCount.toString());
                                                                            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2819:31)", "entry");
                                                                            Text.fontSize(11);
                                                                            Text.fontColor('#FFFFFF');
                                                                            Text.textAlign(TextAlign.Center);
                                                                            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                                                                            Text.borderRadius(10);
                                                                            Text.backgroundColor(Theme.danger);
                                                                            Text.margin({ left: 8 });
                                                                        }, Text);
                                                                        Text.pop();
                                                                    });
                                                                }
                                                                else {
                                                                    this.ifElseBranchUpdateFunction(1, () => {
                                                                    });
                                                                }
                                                            }, If);
                                                            If.pop();
                                                            Row.pop();
                                                            Column.pop();
                                                            Row.pop();
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Divider.create();
                                                                Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(2832:23)", "entry");
                                                                Divider.height(1);
                                                                Divider.color(Theme.divider);
                                                                Divider.margin({ left: 78 });
                                                            }, Divider);
                                                            Column.pop();
                                                        });
                                                    }
                                                    else {
                                                        this.ifElseBranchUpdateFunction(1, () => {
                                                        });
                                                    }
                                                }, If);
                                                If.pop();
                                                ListItem.pop();
                                            };
                                            this.observeComponentCreation2(itemCreation2, ListItem);
                                            ListItem.pop();
                                        }
                                    };
                                    this.forEachUpdateFunction(elmtId, this.conversations, forEachItemGenFunction, (item: Conversation) => `${item.id}-${item.lastTime}-${item.unreadCount}-${item.lastMessage}`, false, false);
                                }, ForEach);
                                ForEach.pop();
                                List.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    ProfileContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/MainPage.ets(2856:5)", "entry");
            Scroll.scrollBar(BarState.Off);
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2857:7)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2858:9)", "entry");
            Row.width('100%');
            Row.padding({ left: 24, right: 20, top: 26, bottom: 26 });
            Row.backgroundColor(Theme.bgCard);
            Row.borderRadius(Theme.heroRadius);
            Row.shadow(ShadowStyle.nmRaisedLg);
            Row.margin({ left: 20, right: 20, top: 22 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2859:11)", "entry");
            Column.padding(6);
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(42);
            Column.shadow(ShadowStyle.nmRaised);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new AvatarView(this, { avatar: this.userInfo.avatar, name: this.userInfo.name, avatarSize: 72 }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MainPage.ets", line: 2860, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            avatar: this.userInfo.avatar,
                            name: this.userInfo.name,
                            avatarSize: 72
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        avatar: this.userInfo.avatar, name: this.userInfo.name
                    });
                }
            }, { name: "AvatarView" });
        }
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2867:11)", "entry");
            Column.margin({ left: 16 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.userInfo.name);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2868:13)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`学号：${this.userInfo.studentId}`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2872:13)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2879:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('编辑资料');
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(2880:11)", "entry");
            Button.height(38);
            Button.fontSize(13);
            Button.fontColor(Theme.primary);
            Button.backgroundColor(Theme.bgCard);
            Button.borderRadius(Theme.buttonRadius);
            Button.padding({ left: 16, right: 16 });
            Button.shadow(ShadowStyle.sm);
            Button.onClick(() => {
                this.openEditProfilePage();
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(2899:9)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.shadow(ShadowStyle.nmRaised);
            Column.margin({ left: 20, right: 20, top: 14 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2900:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('学院');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2901:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2904:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.userInfo.college);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2905:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(2913:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2915:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('专业');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2916:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2919:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.userInfo.major);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2920:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(2928:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2930:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('年级');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2931:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2934:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.userInfo.grade);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2935:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(2943:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2945:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('信用分');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2946:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2949:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.userInfo.creditScore}`);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2950:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(this.userInfo.creditScore >= 85 ? '#4CAF50' : '#F44336');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.userInfo.creditScore < 85) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('(无法发布)');
                        Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2955:15)", "entry");
                        Text.fontSize(12);
                        Text.fontColor('#F44336');
                        Text.margin({ left: 4 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(2965:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2967:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('班级');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2968:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2971:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.userInfo.className);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2972:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(2980:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(2982:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('手机号');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2983:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(2986:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.userInfo.phone);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(2987:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(3001:9)", "entry");
            Column.width('100%');
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.shadow(ShadowStyle.nmRaised);
            Column.margin({ left: 20, right: 20, top: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(3002:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
            Row.onClick(() => {
                this.getUIContext().getRouter().pushUrl({ url: 'pages/MyPublishPage' });
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的发布');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3003:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(3006:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3007:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(3018:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(3020:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
            Row.onClick(() => {
                this.getUIContext().getRouter().pushUrl({ url: 'pages/MyFavoritesPage' });
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的收藏');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3021:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(3024:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3025:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(3036:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(3038:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
            Row.onClick(() => {
                this.getUIContext().getRouter().pushUrl({ url: 'pages/MyLostFoundPage' });
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的失物招领');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3039:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(3042:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3043:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(3054:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(3056:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
            Row.onClick(() => {
                this.getUIContext().getRouter().pushUrl({ url: 'pages/MyHistoryPage' });
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('浏览记录');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3057:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(3060:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3061:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(3072:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(3074:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
            Row.onClick(() => {
                this.getUIContext().getRouter().pushUrl({ url: 'pages/MyComplaintsPage' });
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的投诉');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3075:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(3078:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3079:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MainPage.ets(3090:11)", "entry");
            Divider.margin({ left: 20, right: 20 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MainPage.ets(3092:11)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.padding({ left: 20, right: 20 });
            Row.onClick(() => {
                this.getUIContext().getRouter().pushUrl({ url: 'pages/SettingsPage' });
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('与我们联系');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3093:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(3096:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(3097:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textDisabled);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('退出登录');
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(3114:9)", "entry");
            Button.width('88%');
            Button.height(46);
            Button.fontSize(16);
            Button.fontColor(Theme.danger);
            Button.backgroundColor(Theme.bgCard);
            Button.borderRadius(23);
            Button.shadow(ShadowStyle.sm);
            Button.margin({ top: 24 });
            Button.onClick(() => {
                const store: AppStore = AppStore.getInstance();
                store.logout();
                this.getUIContext().getRouter().replaceUrl({ url: 'pages/LoginPage' });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MainPage.ets(3129:9)", "entry");
            Blank.height(40);
        }, Blank);
        Blank.pop();
        Column.pop();
        Scroll.pop();
    }
    private findCourse(day: number, section: number): CourseSchedule | undefined {
        for (let i = 0; i < this.scheduleList.length; i++) {
            const item: CourseSchedule = this.scheduleList[i];
            if (item.dayOfWeek === day && section >= item.startSection && section <= item.endSection) {
                return item;
            }
        }
        return undefined;
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "MainPage";
    }
}
class AiMsg {
    role: string = 'user';
    content: string = '';
}
registerNamedRoute(() => new MainPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/MainPage", pageFullPath: "entry/src/main/ets/pages/MainPage", integratedHsp: "false", moduleType: "followWithHap" });
