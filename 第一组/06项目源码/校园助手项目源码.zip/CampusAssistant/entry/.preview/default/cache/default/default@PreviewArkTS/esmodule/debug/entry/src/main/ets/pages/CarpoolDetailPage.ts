if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CarpoolDetailPage_Params {
    order?: CarpoolOrder;
    passengers?: PassengerItem[];
    isLoading?: boolean;
    isOwner?: boolean;
    orderId?: number;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { CarpoolOrder } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import type { PassengerItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
const STATUS_LABELS: Record<string, string> = {
    '0': '招募中',
    '1': '已满',
    '2': '已出发',
    '3': '已取消'
};
const STATUS_COLORS: Record<string, string> = {
    '0': Theme.success,
    '1': Theme.warning,
    '2': Theme.primary,
    '3': Theme.textDisabled
};
class CarpoolDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__order = new ObservedPropertyObjectPU(new CarpoolOrder(), this, "order");
        this.__passengers = new ObservedPropertyObjectPU([], this, "passengers");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isOwner = new ObservedPropertySimplePU(false, this, "isOwner");
        this.orderId = 0;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CarpoolDetailPage_Params) {
        if (params.order !== undefined) {
            this.order = params.order;
        }
        if (params.passengers !== undefined) {
            this.passengers = params.passengers;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isOwner !== undefined) {
            this.isOwner = params.isOwner;
        }
        if (params.orderId !== undefined) {
            this.orderId = params.orderId;
        }
    }
    updateStateVars(params: CarpoolDetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__order.purgeDependencyOnElmtId(rmElmtId);
        this.__passengers.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isOwner.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__order.aboutToBeDeleted();
        this.__passengers.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isOwner.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __order: ObservedPropertyObjectPU<CarpoolOrder>;
    get order() {
        return this.__order.get();
    }
    set order(newValue: CarpoolOrder) {
        this.__order.set(newValue);
    }
    private __passengers: ObservedPropertyObjectPU<PassengerItem[]>;
    get passengers() {
        return this.__passengers.get();
    }
    set passengers(newValue: PassengerItem[]) {
        this.__passengers.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isOwner: ObservedPropertySimplePU<boolean>;
    get isOwner() {
        return this.__isOwner.get();
    }
    set isOwner(newValue: boolean) {
        this.__isOwner.set(newValue);
    }
    private orderId: number;
    aboutToAppear(): void {
        const params: Record<string, string> = router.getParams() as Record<string, string>;
        if (params !== null && params !== undefined && params['id'] !== undefined) {
            this.orderId = parseInt(params['id'], 10);
        }
        this.loadDetail();
    }
    private async loadDetail(): Promise<void> {
        this.isLoading = true;
        const result = await ApiService.getCarpoolDetail(this.orderId);
        if (result.code === 200 && result.data !== undefined) {
            const obj: Record<string, Object> = result.data as Record<string, Object>;
            this.order = new CarpoolOrder();
            this.order.id = (obj['id'] as number) ?? 0;
            this.order.userId = (obj['userId'] as number) ?? 0;
            this.order.publisherName = (obj['publisherName'] as string) ?? '';
            this.order.publisherAvatar = (obj['publisherAvatar'] as string) ?? '';
            this.order.departure = (obj['departure'] as string) ?? '';
            this.order.destination = (obj['destination'] as string) ?? '';
            this.order.departureTime = (obj['departureTime'] as string) ?? '';
            this.order.maxPassengers = (obj['maxPassengers'] as number) ?? 4;
            this.order.currentPassengers = (obj['currentPassengers'] as number) ?? 0;
            this.order.contactPhone = (obj['contactPhone'] as string) ?? '';
            this.order.remark = (obj['remark'] as string) ?? '';
            this.order.status = (obj['status'] as number) ?? 0;
            this.order.joined = (obj['joined'] as boolean) ?? false;
            this.order.createTime = (obj['createTime'] as string) ?? '';
            const psgObj: Object = obj['passengers'];
            if (psgObj !== null && psgObj !== undefined) {
                this.passengers = ApiService.parsePassengers(psgObj);
            }
            const store: AppStore = AppStore.getInstance();
            this.isOwner = this.order.userId === store.userInfo.id;
        }
        this.isLoading = false;
    }
    private async joinOrder(): Promise<void> {
        const result = await ApiService.joinCarpool(this.orderId);
        if (result.code === 200) {
            this.loadDetail();
        }
    }
    private async cancelJoin(): Promise<void> {
        const result = await ApiService.cancelJoinCarpool(this.orderId);
        if (result.code === 200) {
            this.loadDetail();
        }
    }
    private async cancelOrder(): Promise<void> {
        const result = await ApiService.cancelCarpool(this.orderId);
        if (result.code === 200) {
            this.loadDetail();
        }
    }
    private confirmDeleteCarpool(): void {
        AlertDialog.show({
            message: '确定删除这条拼车信息吗？删除后不可恢复。',
            primaryButton: {
                value: '取消',
                action: () => { }
            },
            secondaryButton: {
                value: '删除',
                action: () => { this.doDeleteCarpool(); }
            }
        });
    }
    private async doDeleteCarpool(): Promise<void> {
        const result: ApiResult = await ApiService.deleteCarpool(this.orderId);
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
            this.getUIContext().getRouter().back();
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0)
            return '';
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16)
            return t.substring(0, 16);
        return t;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(124:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '拼车详情' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CarpoolDetailPage.ets", line: 125, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '拼车详情'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '拼车详情'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(128:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(129:11)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(133:9)", "entry");
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(134:11)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 16, right: 16, top: 8, bottom: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(135:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                        Column.borderRadius(Theme.cardRadius);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(136:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.order.publisherName);
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(137:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Medium);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(this.order.createTime));
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(139:17)", "entry");
                        Text.fontSize(11);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ left: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(141:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(STATUS_LABELS[`${this.order.status}`] ?? '未知');
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(142:17)", "entry");
                        Text.fontSize(11);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(STATUS_COLORS[`${this.order.status}`] ?? Theme.textTertiary);
                        Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                        Text.borderRadius(10);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(150:15)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 16 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(151:17)", "entry");
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.order.departure);
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(152:19)", "entry");
                        Text.fontSize(18);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Bold);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('出发地');
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(154:19)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 2 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(159:17)", "entry");
                        Column.justifyContent(FlexAlign.Center);
                        Column.width(60);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('🚗→');
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(160:19)", "entry");
                        Text.fontSize(24);
                        Text.fontColor(Theme.primary);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(164:17)", "entry");
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.order.destination);
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(165:19)", "entry");
                        Text.fontSize(18);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Bold);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('目的地');
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(167:19)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 2 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(174:15)", "entry");
                        Divider.margin({ top: 12, bottom: 12 });
                        Divider.color(Theme.border);
                    }, Divider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(176:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(177:17)", "entry");
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('出发时间');
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(178:19)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(this.order.departureTime));
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(180:19)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textPrimary);
                        Text.margin({ top: 4 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(185:17)", "entry");
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('座位情况');
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(186:19)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.order.currentPassengers}/${this.order.maxPassengers}人`);
                        Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(188:19)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.primary);
                        Text.margin({ top: 4 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.order.contactPhone.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(196:17)", "entry");
                                    Row.width('100%');
                                    Row.margin({ top: 12 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('联系电话');
                                    Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(197:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textTertiary);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.order.contactPhone);
                                    Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(199:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.primary);
                                    Text.margin({ left: 8 });
                                }, Text);
                                Text.pop();
                                Row.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.order.remark.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(206:17)", "entry");
                                    Column.width('100%');
                                    Column.margin({ top: 12 });
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('备注');
                                    Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(207:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.width('100%');
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.order.remark);
                                    Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(209:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textPrimary);
                                    Text.margin({ top: 4 });
                                    Text.width('100%');
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.passengers.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(221:15)", "entry");
                                    Column.width('100%');
                                    Column.padding(16);
                                    Column.backgroundColor('#FFFFFF');
                                    Column.borderRadius(Theme.cardRadius);
                                    Column.margin({ top: 10 });
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('乘客列表');
                                    Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(222:17)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textPrimary);
                                    Text.fontWeight(FontWeight.Medium);
                                    Text.width('100%');
                                    Text.margin({ bottom: 8 });
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const p = _item;
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Row.create();
                                            Row.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(227:19)", "entry");
                                            Row.width('100%');
                                            Row.padding({ top: 6, bottom: 6 });
                                        }, Row);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('👤');
                                            Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(228:21)", "entry");
                                            Text.fontSize(18);
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(p.nickname);
                                            Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(229:21)", "entry");
                                            Text.fontSize(14);
                                            Text.fontColor(Theme.textPrimary);
                                            Text.margin({ left: 8 });
                                        }, Text);
                                        Text.pop();
                                        Row.pop();
                                    };
                                    this.forEachUpdateFunction(elmtId, this.passengers, forEachItemGenFunction, (p: PassengerItem) => `${p.userId}`, false, false);
                                }, ForEach);
                                ForEach.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(243:13)", "entry");
                        Column.width('100%');
                        Column.margin({ top: 16 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.isOwner) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('删除拼车');
                                    Button.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(245:17)", "entry");
                                    Button.width('100%');
                                    Button.height(44);
                                    Button.type(ButtonType.Normal);
                                    Button.backgroundColor('#FEE2E2');
                                    Button.fontColor(Theme.danger);
                                    Button.borderRadius(Theme.radiusMd);
                                    Button.margin({ bottom: 10 });
                                    Button.onClick(() => { this.confirmDeleteCarpool(); });
                                }, Button);
                                Button.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.order.status === 0) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Button.createWithLabel('取消拼车');
                                                Button.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(252:19)", "entry");
                                                Button.width('100%');
                                                Button.height(44);
                                                Button.type(ButtonType.Normal);
                                                Button.backgroundColor('#FEF3C7');
                                                Button.fontColor(Theme.warning);
                                                Button.borderRadius(Theme.radiusMd);
                                                Button.onClick(() => { this.cancelOrder(); });
                                            }, Button);
                                            Button.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            });
                        }
                        else if (this.order.status === 0 || this.order.status === 1) {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.order.joined) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Button.createWithLabel('退出拼车');
                                                Button.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(260:19)", "entry");
                                                Button.width('100%');
                                                Button.height(44);
                                                Button.type(ButtonType.Normal);
                                                Button.backgroundColor('#FEF3C7');
                                                Button.fontColor(Theme.warning);
                                                Button.borderRadius(Theme.radiusMd);
                                                Button.onClick(() => { this.cancelJoin(); });
                                            }, Button);
                                            Button.pop();
                                        });
                                    }
                                    else if (this.order.currentPassengers < this.order.maxPassengers) {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Button.createWithLabel('加入拼车');
                                                Button.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(266:19)", "entry");
                                                Button.width('100%');
                                                Button.height(44);
                                                Button.type(ButtonType.Normal);
                                                Button.backgroundColor(Theme.primary);
                                                Button.fontColor('#FFFFFF');
                                                Button.borderRadius(Theme.radiusMd);
                                                Button.onClick(() => { this.joinOrder(); });
                                            }, Button);
                                            Button.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(2, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('已满员，无法加入');
                                                Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(272:19)", "entry");
                                                Text.fontSize(14);
                                                Text.fontColor(Theme.textDisabled);
                                                Text.width('100%');
                                                Text.textAlign(TextAlign.Center);
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                }, If);
                                If.pop();
                            });
                        }
                        else if (this.order.status === 3) {
                            this.ifElseBranchUpdateFunction(2, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('该拼车已取消');
                                    Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(277:17)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textDisabled);
                                    Text.width('100%');
                                    Text.textAlign(TextAlign.Center);
                                }, Text);
                                Text.pop();
                            });
                        }
                        else if (this.order.status === 2) {
                            this.ifElseBranchUpdateFunction(3, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('该拼车已出发');
                                    Text.debugLine("entry/src/main/ets/pages/CarpoolDetailPage.ets(281:17)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textDisabled);
                                    Text.width('100%');
                                    Text.textAlign(TextAlign.Center);
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(4, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "CarpoolDetailPage";
    }
}
registerNamedRoute(() => new CarpoolDetailPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/CarpoolDetailPage", pageFullPath: "entry/src/main/ets/pages/CarpoolDetailPage", integratedHsp: "false", moduleType: "followWithHap" });
