if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PasswordChangePage_Params {
    step?: number;
    oldPassword?: string;
    newPassword?: string;
    confirmPassword?: string;
    isLoading?: boolean;
    errorMsg?: string;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
class PasswordChangePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__step = new ObservedPropertySimplePU(0, this, "step");
        this.__oldPassword = new ObservedPropertySimplePU('', this, "oldPassword");
        this.__newPassword = new ObservedPropertySimplePU('', this, "newPassword");
        this.__confirmPassword = new ObservedPropertySimplePU('', this, "confirmPassword");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__errorMsg = new ObservedPropertySimplePU(''
        /** 验证原密码环节不再调用 changePassword(old, old)（会把密码改成自身、有副作用），
         *  仅做非空校验后进入第二步；真正的原密码校验在 submitNewPassword 调用
         *  changePassword(old, new) 时由后端一次性完成。
         */
        , this, "errorMsg");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PasswordChangePage_Params) {
        if (params.step !== undefined) {
            this.step = params.step;
        }
        if (params.oldPassword !== undefined) {
            this.oldPassword = params.oldPassword;
        }
        if (params.newPassword !== undefined) {
            this.newPassword = params.newPassword;
        }
        if (params.confirmPassword !== undefined) {
            this.confirmPassword = params.confirmPassword;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
    }
    updateStateVars(params: PasswordChangePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__step.purgeDependencyOnElmtId(rmElmtId);
        this.__oldPassword.purgeDependencyOnElmtId(rmElmtId);
        this.__newPassword.purgeDependencyOnElmtId(rmElmtId);
        this.__confirmPassword.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__step.aboutToBeDeleted();
        this.__oldPassword.aboutToBeDeleted();
        this.__newPassword.aboutToBeDeleted();
        this.__confirmPassword.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 0: 验证原密码  1: 设置新密码
    private __step: ObservedPropertySimplePU<number>;
    get step() {
        return this.__step.get();
    }
    set step(newValue: number) {
        this.__step.set(newValue);
    }
    private __oldPassword: ObservedPropertySimplePU<string>;
    get oldPassword() {
        return this.__oldPassword.get();
    }
    set oldPassword(newValue: string) {
        this.__oldPassword.set(newValue);
    }
    private __newPassword: ObservedPropertySimplePU<string>;
    get newPassword() {
        return this.__newPassword.get();
    }
    set newPassword(newValue: string) {
        this.__newPassword.set(newValue);
    }
    private __confirmPassword: ObservedPropertySimplePU<string>;
    get confirmPassword() {
        return this.__confirmPassword.get();
    }
    set confirmPassword(newValue: string) {
        this.__confirmPassword.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    /** 验证原密码环节不再调用 changePassword(old, old)（会把密码改成自身、有副作用），
     *  仅做非空校验后进入第二步；真正的原密码校验在 submitNewPassword 调用
     *  changePassword(old, new) 时由后端一次性完成。
     */
    private verifyOldPassword(): void {
        const old: string = this.oldPassword.trim();
        if (old.length === 0) {
            this.errorMsg = '请输入原密码';
            return;
        }
        this.errorMsg = '';
        this.step = 1;
    }
    private async submitNewPassword(): Promise<void> {
        if (this.isLoading)
            return;
        const np: string = this.newPassword.trim();
        const cp: string = this.confirmPassword.trim();
        if (np.length === 0 || cp.length === 0) {
            this.errorMsg = '请完整填写新密码';
            return;
        }
        if (np.length < 6) {
            this.errorMsg = '新密码至少6位';
            return;
        }
        if (np !== cp) {
            this.errorMsg = '两次输入的新密码不一致';
            return;
        }
        this.errorMsg = '';
        this.isLoading = true;
        try {
            const result: ApiResult = await ApiService.changePassword(this.oldPassword.trim(), np);
            if (result.code === 200) {
                this.getUIContext().getPromptAction().showToast({ message: '密码修改成功' });
                router.back();
            }
            else {
                this.errorMsg = result.msg.length > 0 ? result.msg : '密码修改失败，请重试';
            }
        }
        catch (_err) {
            this.errorMsg = '网络异常，请重试';
        }
        finally {
            this.isLoading = false;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(70:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '修改密码' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/PasswordChangePage.ets", line: 71, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '修改密码'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '修改密码'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 步骤指示器
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(74:7)", "entry");
            // 步骤指示器
            Row.width('100%');
            // 步骤指示器
            Row.justifyContent(FlexAlign.Center);
            // 步骤指示器
            Row.alignItems(VerticalAlign.Center);
            // 步骤指示器
            Row.padding({ top: 30, bottom: 22 });
        }, Row);
        this.StepDot.bind(this)(1, this.step >= 0, '验证身份');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(76:9)", "entry");
            Row.width(52);
            Row.height(2);
            Row.backgroundColor(this.step >= 1 ? Theme.primary : Theme.textDisabled);
        }, Row);
        Row.pop();
        this.StepDot.bind(this)(2, this.step >= 1, '设置新密码');
        // 步骤指示器
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 表单区域
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(85:7)", "entry");
            // 表单区域
            Column.width('88%');
            // 表单区域
            Column.padding(22);
            // 表单区域
            Column.backgroundColor(Theme.bgCard);
            // 表单区域
            Column.borderRadius(Theme.cardRadius);
            // 表单区域
            Column.shadow(ShadowStyle.nmRaisedLg);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.step === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.Step1Content.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.Step2Content.bind(this)();
                });
            }
        }, If);
        If.pop();
        // 表单区域
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 错误提示
            if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(100:9)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.danger);
                        Text.width('88%');
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    StepDot(num: number, active: boolean, label: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(113:5)", "entry");
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${num}`);
            Text.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(114:7)", "entry");
            Text.width(32);
            Text.height(32);
            Text.borderRadius(16);
            Text.backgroundColor(active ? Theme.primary : Theme.textDisabled);
            Text.fontColor(Color.White);
            Text.fontSize(14);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(121:7)", "entry");
            Text.fontSize(11);
            Text.fontColor(active ? Theme.primary : Theme.textTertiary);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    Step1Content(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('请输入原密码以验证身份');
            Text.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(131:5)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textSecondary);
            Text.width('100%');
            Text.margin({ bottom: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入原密码', text: this.oldPassword });
            TextInput.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(137:5)", "entry");
            TextInput.type(InputType.Password);
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.fontColor(Theme.textPrimary);
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(Theme.radiusPill);
            TextInput.padding({ left: 14, right: 14 });
            TextInput.onChange((value: string) => {
                this.oldPassword = value;
                this.errorMsg = '';
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.isLoading ? '验证中...' : '下一步');
            Button.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(151:5)", "entry");
            Button.width('100%');
            Button.height(44);
            Button.fontSize(16);
            Button.fontColor(Color.White);
            Button.backgroundColor(Theme.primary);
            Button.borderRadius(Theme.buttonRadius);
            Button.margin({ top: 20 });
            Button.shadow(ShadowStyle.sm);
            Button.enabled(!this.isLoading);
            Button.onClick(() => { this.verifyOldPassword(); });
        }, Button);
        Button.pop();
    }
    Step2Content(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('请设置新密码（至少6位）');
            Text.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(166:5)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textSecondary);
            Text.width('100%');
            Text.margin({ bottom: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入新密码', text: this.newPassword });
            TextInput.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(172:5)", "entry");
            TextInput.type(InputType.Password);
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.fontColor(Theme.textPrimary);
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(Theme.radiusPill);
            TextInput.padding({ left: 14, right: 14 });
            TextInput.onChange((value: string) => {
                this.newPassword = value;
                this.errorMsg = '';
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请再次输入新密码', text: this.confirmPassword });
            TextInput.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(186:5)", "entry");
            TextInput.type(InputType.Password);
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.fontColor(Theme.textPrimary);
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(Theme.radiusPill);
            TextInput.padding({ left: 14, right: 14 });
            TextInput.margin({ top: 12 });
            TextInput.onChange((value: string) => {
                this.confirmPassword = value;
                this.errorMsg = '';
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.isLoading ? '提交中...' : '确认修改');
            Button.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(201:5)", "entry");
            Button.width('100%');
            Button.height(44);
            Button.fontSize(16);
            Button.fontColor(Color.White);
            Button.backgroundColor(Theme.primary);
            Button.borderRadius(Theme.buttonRadius);
            Button.margin({ top: 20 });
            Button.shadow(ShadowStyle.sm);
            Button.enabled(!this.isLoading);
            Button.onClick(() => { this.submitNewPassword(); });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('返回上一步');
            Button.debugLine("entry/src/main/ets/pages/PasswordChangePage.ets(213:5)", "entry");
            Button.width('100%');
            Button.height(44);
            Button.fontSize(16);
            Button.fontColor(Theme.primary);
            Button.backgroundColor(Theme.bgCard);
            Button.borderRadius(Theme.buttonRadius);
            Button.margin({ top: 10 });
            Button.shadow(ShadowStyle.sm);
            Button.onClick(() => {
                this.step = 0;
                this.newPassword = '';
                this.confirmPassword = '';
                this.errorMsg = '';
            });
        }, Button);
        Button.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "PasswordChangePage";
    }
}
registerNamedRoute(() => new PasswordChangePage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/PasswordChangePage", pageFullPath: "entry/src/main/ets/pages/PasswordChangePage", integratedHsp: "false", moduleType: "followWithHap" });
