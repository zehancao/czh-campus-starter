if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface StudySharePage_Params {
    shares?: StudyShareItem[];
    activeTab?: number;
    isLoading?: boolean;
    searchInput?: string;
    currentPage?: number;
    hasMore?: boolean;
    isLoadingMore?: boolean;
}
interface ShareCard_Params {
    itemData?: StudyShareItem;
    onTapCallback?: () => void;
    onLikeCallback?: () => void;
    onFavoriteCallback?: () => void;
    onDeleteCallback?: () => void;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { StudyShareItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
const CATEGORY_TABS: string[] = ['全部', '课件', '笔记', '真题', '作业', '其他'];
const CATEGORY_COLORS: string[] = [Theme.primary, '#0288D1', Theme.ocean, '#D97706', Theme.success, Theme.textSecondary];
const CATEGORY_BG_COLORS: string[] = [Theme.primaryLight, '#E0F0FF', Theme.oceanLight, '#FFF9E6', Theme.successLight, '#F3F4F6'];
const FILE_TYPE_ICONS: Record<string, string> = {
    'pdf': '📄',
    'doc': '📝',
    'docx': '📝',
    'ppt': '📊',
    'pptx': '📊',
    'xls': '📈',
    'xlsx': '📈',
    'jpg': '🖼️',
    'jpeg': '🖼️',
    'png': '🖼️',
    'zip': '📦',
    'rar': '📦'
};
const PAGE_SIZE: number = 20;
class ShareCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.itemData = new StudyShareItem();
        this.onTapCallback = undefined;
        this.onLikeCallback = undefined;
        this.onFavoriteCallback = undefined;
        this.onDeleteCallback = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ShareCard_Params) {
        if (params.itemData !== undefined) {
            this.itemData = params.itemData;
        }
        if (params.onTapCallback !== undefined) {
            this.onTapCallback = params.onTapCallback;
        }
        if (params.onLikeCallback !== undefined) {
            this.onLikeCallback = params.onLikeCallback;
        }
        if (params.onFavoriteCallback !== undefined) {
            this.onFavoriteCallback = params.onFavoriteCallback;
        }
        if (params.onDeleteCallback !== undefined) {
            this.onDeleteCallback = params.onDeleteCallback;
        }
    }
    updateStateVars(params: ShareCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private itemData: StudyShareItem;
    private onTapCallback?: () => void;
    private onLikeCallback?: () => void;
    private onFavoriteCallback?: () => void;
    private onDeleteCallback?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePage.ets(38:5)", "entry");
            Column.width('100%');
            Column.padding(14);
            Column.backgroundColor('#FFFFFF');
            Column.borderRadius(Theme.cardRadius);
            Column.margin({ bottom: 10 });
            Column.shadow(ShadowStyle.sm);
            Column.onClick(() => {
                if (this.onTapCallback !== undefined) {
                    this.onTapCallback();
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(39:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.uploaderName);
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(40:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.formatTime(this.itemData.createTime));
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(43:9)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudySharePage.ets(47:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (AppStore.getInstance().isLoggedIn && AppStore.getInstance().userInfo.id === this.itemData.userId) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('删除');
                        Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(49:11)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ right: 8 });
                        Text.onClick(() => {
                            if (this.onDeleteCallback !== undefined) {
                                this.onDeleteCallback();
                            }
                        });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.category);
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(59:9)", "entry");
            Text.fontSize(10);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(CATEGORY_COLORS[this.getCategoryIndex()]);
            Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
            Text.borderRadius(10);
            Text.backgroundColor(CATEGORY_BG_COLORS[this.getCategoryIndex()]);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(69:7)", "entry");
            Row.margin({ top: 10 });
            Row.width('100%');
            Row.alignItems(VerticalAlign.Top);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.itemData.coverImage.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(`${ApiService.baseUrl}${this.itemData.coverImage}`);
                        Image.debugLine("entry/src/main/ets/pages/StudySharePage.ets(71:11)", "entry");
                        Image.width(60);
                        Image.height(60);
                        Image.borderRadius(Theme.radiusSm);
                        Image.objectFit(ImageFit.Cover);
                        Image.margin({ right: 12 });
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudySharePage.ets(78:11)", "entry");
                        Column.width(60);
                        Column.height(60);
                        Column.backgroundColor(Theme.bgInput);
                        Column.borderRadius(Theme.radiusSm);
                        Column.justifyContent(FlexAlign.Center);
                        Column.margin({ right: 12 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.getFileIcon());
                        Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(79:13)", "entry");
                        Text.fontSize(24);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.fileType.toUpperCase());
                        Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(81:13)", "entry");
                        Text.fontSize(9);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 2 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePage.ets(94:9)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.title);
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(95:11)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.itemData.courseName.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`📚 ${this.itemData.courseName}`);
                        Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(104:13)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.ocean);
                        Text.margin({ top: 4 });
                        Text.maxLines(1);
                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(112:11)", "entry");
            Row.margin({ top: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.formatFileSize(this.itemData.fileSize));
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(113:13)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('·');
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(116:13)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ left: 4, right: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.itemData.downloadCount}次下载`);
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(120:13)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(133:7)", "entry");
            Row.margin({ top: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(134:9)", "entry");
            Row.onClick(() => {
                if (this.onLikeCallback !== undefined) {
                    this.onLikeCallback();
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.liked ? '❤️' : '🤍');
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(135:11)", "entry");
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.itemData.likeCount}`);
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(137:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(this.itemData.liked ? Theme.danger : Theme.textTertiary);
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(148:9)", "entry");
            Row.margin({ left: 20 });
            Row.onClick(() => {
                if (this.onFavoriteCallback !== undefined) {
                    this.onFavoriteCallback();
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.favorited ? '⭐' : '☆');
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(149:11)", "entry");
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.itemData.favoriteCount}`);
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(151:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(this.itemData.favorited ? '#D97706' : Theme.textTertiary);
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
        Column.pop();
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0)
            return '';
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16)
            return t.substring(0, 16);
        return t;
    }
    private getCategoryIndex(): number {
        if (this.itemData.category === '课件')
            return 1;
        if (this.itemData.category === '笔记')
            return 2;
        if (this.itemData.category === '真题')
            return 3;
        if (this.itemData.category === '作业')
            return 4;
        if (this.itemData.category === '其他')
            return 5;
        return 0;
    }
    private getFileIcon(): string {
        const icon: string | undefined = FILE_TYPE_ICONS[this.itemData.fileType.toLowerCase()];
        return icon !== undefined ? icon : '📁';
    }
    private formatFileSize(bytes: number): string {
        if (bytes <= 0)
            return '';
        if (bytes < 1024)
            return `${bytes}B`;
        if (bytes < 1024 * 1024)
            return `${(bytes / 1024).toFixed(1)}KB`;
        return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class StudySharePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__shares = new ObservedPropertyObjectPU([], this, "shares");
        this.__activeTab = new ObservedPropertySimplePU(0, this, "activeTab");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__searchInput = new ObservedPropertySimplePU('', this, "searchInput");
        this.__currentPage = new ObservedPropertySimplePU(1, this, "currentPage");
        this.__hasMore = new ObservedPropertySimplePU(true, this, "hasMore");
        this.__isLoadingMore = new ObservedPropertySimplePU(false, this, "isLoadingMore");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StudySharePage_Params) {
        if (params.shares !== undefined) {
            this.shares = params.shares;
        }
        if (params.activeTab !== undefined) {
            this.activeTab = params.activeTab;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.searchInput !== undefined) {
            this.searchInput = params.searchInput;
        }
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
        if (params.hasMore !== undefined) {
            this.hasMore = params.hasMore;
        }
        if (params.isLoadingMore !== undefined) {
            this.isLoadingMore = params.isLoadingMore;
        }
    }
    updateStateVars(params: StudySharePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__shares.purgeDependencyOnElmtId(rmElmtId);
        this.__activeTab.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__searchInput.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
        this.__hasMore.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoadingMore.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__shares.aboutToBeDeleted();
        this.__activeTab.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__searchInput.aboutToBeDeleted();
        this.__currentPage.aboutToBeDeleted();
        this.__hasMore.aboutToBeDeleted();
        this.__isLoadingMore.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __shares: ObservedPropertyObjectPU<StudyShareItem[]>;
    get shares() {
        return this.__shares.get();
    }
    set shares(newValue: StudyShareItem[]) {
        this.__shares.set(newValue);
    }
    private __activeTab: ObservedPropertySimplePU<number>;
    get activeTab() {
        return this.__activeTab.get();
    }
    set activeTab(newValue: number) {
        this.__activeTab.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __searchInput: ObservedPropertySimplePU<string>;
    get searchInput() {
        return this.__searchInput.get();
    }
    set searchInput(newValue: string) {
        this.__searchInput.set(newValue);
    }
    private __currentPage: ObservedPropertySimplePU<number>;
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: number) {
        this.__currentPage.set(newValue);
    }
    private __hasMore: ObservedPropertySimplePU<boolean>;
    get hasMore() {
        return this.__hasMore.get();
    }
    set hasMore(newValue: boolean) {
        this.__hasMore.set(newValue);
    }
    private __isLoadingMore: ObservedPropertySimplePU<boolean>;
    get isLoadingMore() {
        return this.__isLoadingMore.get();
    }
    set isLoadingMore(newValue: boolean) {
        this.__isLoadingMore.set(newValue);
    }
    onPageShow(): void {
        this.refreshList();
    }
    private async refreshList(): Promise<void> {
        this.isLoading = true;
        this.currentPage = 1;
        this.hasMore = true;
        const category: string = this.activeTab === 0 ? '' : CATEGORY_TABS[this.activeTab];
        const result = await ApiService.getStudyShareList(this.searchInput.trim(), category, 1, PAGE_SIZE);
        const newItems: StudyShareItem[] = [];
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            for (let i = 0; i < arr.length; i++) {
                const obj: Record<string, Object> = arr[i] as Record<string, Object>;
                const item: StudyShareItem = new StudyShareItem();
                item.id = (obj['id'] as number) ?? 0;
                item.userId = (obj['userId'] as number) ?? 0;
                item.uploaderName = (obj['uploaderName'] as string) ?? '';
                item.uploaderAvatar = (obj['uploaderAvatar'] as string) ?? '';
                item.title = (obj['title'] as string) ?? '';
                item.description = (obj['description'] as string) ?? '';
                item.courseName = (obj['courseName'] as string) ?? '';
                item.category = (obj['category'] as string) ?? '其他';
                item.fileUrl = (obj['fileUrl'] as string) ?? '';
                item.fileType = (obj['fileType'] as string) ?? '';
                item.fileSize = (obj['fileSize'] as number) ?? 0;
                item.coverImage = (obj['coverImage'] as string) ?? '';
                item.likeCount = (obj['likeCount'] as number) ?? 0;
                item.favoriteCount = (obj['favoriteCount'] as number) ?? 0;
                item.downloadCount = (obj['downloadCount'] as number) ?? 0;
                item.liked = (obj['liked'] as boolean) ?? false;
                item.favorited = (obj['favorited'] as boolean) ?? false;
                item.status = (obj['status'] as number) ?? 0;
                item.createTime = (obj['createTime'] as string) ?? '';
                newItems.push(item);
            }
            this.hasMore = arr.length >= PAGE_SIZE;
        }
        this.shares = newItems;
        this.isLoading = false;
    }
    private async loadMore(): Promise<void> {
        if (this.isLoadingMore || !this.hasMore) {
            return;
        }
        this.isLoadingMore = true;
        this.currentPage = this.currentPage + 1;
        const category: string = this.activeTab === 0 ? '' : CATEGORY_TABS[this.activeTab];
        const result = await ApiService.getStudyShareList(this.searchInput.trim(), category, this.currentPage, PAGE_SIZE);
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            for (let i = 0; i < arr.length; i++) {
                const obj: Record<string, Object> = arr[i] as Record<string, Object>;
                const item: StudyShareItem = new StudyShareItem();
                item.id = (obj['id'] as number) ?? 0;
                item.userId = (obj['userId'] as number) ?? 0;
                item.uploaderName = (obj['uploaderName'] as string) ?? '';
                item.uploaderAvatar = (obj['uploaderAvatar'] as string) ?? '';
                item.title = (obj['title'] as string) ?? '';
                item.description = (obj['description'] as string) ?? '';
                item.courseName = (obj['courseName'] as string) ?? '';
                item.category = (obj['category'] as string) ?? '其他';
                item.fileUrl = (obj['fileUrl'] as string) ?? '';
                item.fileType = (obj['fileType'] as string) ?? '';
                item.fileSize = (obj['fileSize'] as number) ?? 0;
                item.coverImage = (obj['coverImage'] as string) ?? '';
                item.likeCount = (obj['likeCount'] as number) ?? 0;
                item.favoriteCount = (obj['favoriteCount'] as number) ?? 0;
                item.downloadCount = (obj['downloadCount'] as number) ?? 0;
                item.liked = (obj['liked'] as boolean) ?? false;
                item.favorited = (obj['favorited'] as boolean) ?? false;
                item.status = (obj['status'] as number) ?? 0;
                item.createTime = (obj['createTime'] as string) ?? '';
                this.shares.push(item);
            }
            this.hasMore = arr.length >= PAGE_SIZE;
        }
        this.isLoadingMore = false;
    }
    private onTabChange(index: number): void {
        this.activeTab = index;
        this.refreshList();
    }
    private goToDetail(item: StudyShareItem): void {
        router.pushUrl({
            url: 'pages/StudyShareDetailPage',
            params: { 'id': `${item.id}` } as Record<string, string>
        });
    }
    private goToPublish(): void {
        router.pushUrl({ url: 'pages/StudySharePublishPage' });
    }
    private async toggleLike(item: StudyShareItem): Promise<void> {
        const result = await ApiService.likeStudyShare(item.id);
        if (result.code === 200) {
            this.refreshList();
        }
    }
    private async toggleFavorite(item: StudyShareItem): Promise<void> {
        const result = await ApiService.favoriteStudyShare(item.id);
        if (result.code === 200) {
            this.refreshList();
        }
    }
    private confirmDeleteShare(item: StudyShareItem): void {
        AlertDialog.show({
            message: '确定删除这份资料吗？',
            primaryButton: {
                value: '取消',
                action: () => { }
            },
            secondaryButton: {
                value: '删除',
                action: () => { this.doDeleteShare(item.id); }
            }
        });
    }
    private async doDeleteShare(shareId: number): Promise<void> {
        const result: ApiResult = await ApiService.deleteStudyShare(shareId);
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
            this.refreshList();
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    private doSearch(): void {
        this.refreshList();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudySharePage.ets(360:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '学习资料',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('上传');
                                Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(362:9)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(Theme.primary);
                                Text.onClick(() => { this.goToPublish(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/StudySharePage.ets", line: 361, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '学习资料',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('上传');
                                    Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(362:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.primary);
                                    Text.onClick(() => { this.goToPublish(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '学习资料'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(365:7)", "entry");
            Row.width('100%');
            Row.padding({ left: 12, right: 12, top: 8, bottom: 4 });
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '搜索课程名...', text: this.searchInput });
            TextInput.debugLine("entry/src/main/ets/pages/StudySharePage.ets(366:9)", "entry");
            TextInput.layoutWeight(1);
            TextInput.height(36);
            TextInput.fontSize(14);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(18);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.onChange((val: string) => { this.searchInput = val; });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('搜索');
            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(374:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.primary);
            Text.margin({ left: 10 });
            Text.onClick(() => { this.doSearch(); });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(384:7)", "entry");
            Row.width('100%');
            Row.padding({ left: 12, right: 12, top: 6, bottom: 6 });
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/StudySharePage.ets(385:9)", "entry");
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.scrollBar(BarState.Off);
            Scroll.width('100%');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(386:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const tab = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/StudySharePage.ets(388:15)", "entry");
                    Column.margin({ right: 4 });
                    Column.onClick(() => { this.onTabChange(index); });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(tab);
                    Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(389:17)", "entry");
                    Text.fontSize(13);
                    Text.fontColor(this.activeTab === index ? CATEGORY_COLORS[index] : Theme.textSecondary);
                    Text.fontWeight(this.activeTab === index ? FontWeight.Medium : FontWeight.Regular);
                    Text.padding({ left: 12, right: 12, top: 6, bottom: 6 });
                    Text.borderRadius(16);
                    Text.backgroundColor(this.activeTab === index ? CATEGORY_BG_COLORS[index] : 'transparent');
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, CATEGORY_TABS, forEachItemGenFunction, (tab: string) => tab, true, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Scroll.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/StudySharePage.ets(410:7)", "entry");
            Divider.height(1);
            Divider.color(Theme.border);
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudySharePage.ets(413:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/StudySharePage.ets(414:11)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 0 });
                        List.debugLine("entry/src/main/ets/pages/StudySharePage.ets(419:9)", "entry");
                        List.layoutWeight(1);
                        List.edgeEffect(EdgeEffect.Spring);
                        List.padding({ left: 12, right: 12, top: 4, bottom: 20 });
                        List.onReachEnd(() => {
                            this.loadMore();
                        });
                    }, List);
                    {
                        const itemCreation = (elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            ListItem.create(deepRenderFunction, true);
                            if (!isInitialRender) {
                                ListItem.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        };
                        const itemCreation2 = (elmtId, isInitialRender) => {
                            ListItem.create(deepRenderFunction, true);
                            ListItem.debugLine("entry/src/main/ets/pages/StudySharePage.ets(420:11)", "entry");
                        };
                        const deepRenderFunction = (elmtId, isInitialRender) => {
                            itemCreation(elmtId, isInitialRender);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(421:13)", "entry");
                                Row.width('100%');
                                Row.padding({ left: 16, right: 16, bottom: 8 });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(`共 ${this.shares.length} 项`);
                                Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(422:15)", "entry");
                                Text.fontSize(12);
                                Text.fontColor(Theme.textTertiary);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Blank.create();
                                Blank.debugLine("entry/src/main/ets/pages/StudySharePage.ets(424:15)", "entry");
                            }, Blank);
                            Blank.pop();
                            Row.pop();
                            ListItem.pop();
                        };
                        this.observeComponentCreation2(itemCreation2, ListItem);
                        ListItem.pop();
                    }
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.shares.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        {
                                            const itemCreation = (elmtId, isInitialRender) => {
                                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                ListItem.create(deepRenderFunction, true);
                                                if (!isInitialRender) {
                                                    ListItem.pop();
                                                }
                                                ViewStackProcessor.StopGetAccessRecording();
                                            };
                                            const itemCreation2 = (elmtId, isInitialRender) => {
                                                ListItem.create(deepRenderFunction, true);
                                                ListItem.debugLine("entry/src/main/ets/pages/StudySharePage.ets(432:15)", "entry");
                                            };
                                            const deepRenderFunction = (elmtId, isInitialRender) => {
                                                itemCreation(elmtId, isInitialRender);
                                                {
                                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                        if (isInitialRender) {
                                                            let componentCall = new ShareCard(this, {
                                                                itemData: item,
                                                                onTapCallback: () => this.goToDetail(item),
                                                                onLikeCallback: () => this.toggleLike(item),
                                                                onFavoriteCallback: () => this.toggleFavorite(item),
                                                                onDeleteCallback: () => this.confirmDeleteShare(item)
                                                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/StudySharePage.ets", line: 433, col: 17 });
                                                            ViewPU.create(componentCall);
                                                            let paramsLambda = () => {
                                                                return {
                                                                    itemData: item,
                                                                    onTapCallback: () => this.goToDetail(item),
                                                                    onLikeCallback: () => this.toggleLike(item),
                                                                    onFavoriteCallback: () => this.toggleFavorite(item),
                                                                    onDeleteCallback: () => this.confirmDeleteShare(item)
                                                                };
                                                            };
                                                            componentCall.paramsGenerator_ = paramsLambda;
                                                        }
                                                        else {
                                                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                                                        }
                                                    }, { name: "ShareCard" });
                                                }
                                                ListItem.pop();
                                            };
                                            this.observeComponentCreation2(itemCreation2, ListItem);
                                            ListItem.pop();
                                        }
                                    };
                                    this.forEachUpdateFunction(elmtId, this.shares, forEachItemGenFunction, (item: StudyShareItem) => `${item.id}`, false, false);
                                }, ForEach);
                                ForEach.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.hasMore) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            {
                                                const itemCreation = (elmtId, isInitialRender) => {
                                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                    ListItem.create(deepRenderFunction, true);
                                                    if (!isInitialRender) {
                                                        ListItem.pop();
                                                    }
                                                    ViewStackProcessor.StopGetAccessRecording();
                                                };
                                                const itemCreation2 = (elmtId, isInitialRender) => {
                                                    ListItem.create(deepRenderFunction, true);
                                                    ListItem.debugLine("entry/src/main/ets/pages/StudySharePage.ets(444:15)", "entry");
                                                };
                                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                                    itemCreation(elmtId, isInitialRender);
                                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                        Row.create();
                                                        Row.debugLine("entry/src/main/ets/pages/StudySharePage.ets(445:17)", "entry");
                                                        Row.width('100%');
                                                        Row.justifyContent(FlexAlign.Center);
                                                        Row.padding({ top: 12, bottom: 12 });
                                                    }, Row);
                                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                        LoadingProgress.create();
                                                        LoadingProgress.debugLine("entry/src/main/ets/pages/StudySharePage.ets(446:19)", "entry");
                                                        LoadingProgress.color(Theme.primary);
                                                        LoadingProgress.width(20);
                                                        LoadingProgress.height(20);
                                                    }, LoadingProgress);
                                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                        Text.create('加载更多...');
                                                        Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(447:19)", "entry");
                                                        Text.fontSize(13);
                                                        Text.fontColor(Theme.textTertiary);
                                                        Text.margin({ left: 8 });
                                                    }, Text);
                                                    Text.pop();
                                                    Row.pop();
                                                    ListItem.pop();
                                                };
                                                this.observeComponentCreation2(itemCreation2, ListItem);
                                                ListItem.pop();
                                            }
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                            {
                                                const itemCreation = (elmtId, isInitialRender) => {
                                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                    ListItem.create(deepRenderFunction, true);
                                                    if (!isInitialRender) {
                                                        ListItem.pop();
                                                    }
                                                    ViewStackProcessor.StopGetAccessRecording();
                                                };
                                                const itemCreation2 = (elmtId, isInitialRender) => {
                                                    ListItem.create(deepRenderFunction, true);
                                                    ListItem.debugLine("entry/src/main/ets/pages/StudySharePage.ets(457:15)", "entry");
                                                };
                                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                                    itemCreation(elmtId, isInitialRender);
                                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                        Text.create('- 没有更多了 -');
                                                        Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(458:17)", "entry");
                                                        Text.fontSize(13);
                                                        Text.fontColor(Theme.textTertiary);
                                                        Text.width('100%');
                                                        Text.textAlign(TextAlign.Center);
                                                        Text.padding({ top: 12, bottom: 12 });
                                                    }, Text);
                                                    Text.pop();
                                                    ListItem.pop();
                                                };
                                                this.observeComponentCreation2(itemCreation2, ListItem);
                                                ListItem.pop();
                                            }
                                        });
                                    }
                                }, If);
                                If.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                {
                                    const itemCreation = (elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        ListItem.create(deepRenderFunction, true);
                                        if (!isInitialRender) {
                                            ListItem.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    };
                                    const itemCreation2 = (elmtId, isInitialRender) => {
                                        ListItem.create(deepRenderFunction, true);
                                        ListItem.debugLine("entry/src/main/ets/pages/StudySharePage.ets(467:13)", "entry");
                                    };
                                    const deepRenderFunction = (elmtId, isInitialRender) => {
                                        itemCreation(elmtId, isInitialRender);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Column.create();
                                            Column.debugLine("entry/src/main/ets/pages/StudySharePage.ets(468:15)", "entry");
                                            Column.width('100%');
                                            Column.alignItems(HorizontalAlign.Center);
                                            Column.margin({ top: 40 });
                                        }, Column);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('📚');
                                            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(469:17)", "entry");
                                            Text.fontSize(56);
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('暂无资料');
                                            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(470:17)", "entry");
                                            Text.fontSize(15);
                                            Text.fontColor(Theme.textSecondary);
                                            Text.margin({ top: 8 });
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('点击右上角"上传"分享学习资料');
                                            Text.debugLine("entry/src/main/ets/pages/StudySharePage.ets(472:17)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.margin({ top: 4 });
                                        }, Text);
                                        Text.pop();
                                        Column.pop();
                                        ListItem.pop();
                                    };
                                    this.observeComponentCreation2(itemCreation2, ListItem);
                                    ListItem.pop();
                                }
                            });
                        }
                    }, If);
                    If.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "StudySharePage";
    }
}
registerNamedRoute(() => new StudySharePage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/StudySharePage", pageFullPath: "entry/src/main/ets/pages/StudySharePage", integratedHsp: "false", moduleType: "followWithHap" });
