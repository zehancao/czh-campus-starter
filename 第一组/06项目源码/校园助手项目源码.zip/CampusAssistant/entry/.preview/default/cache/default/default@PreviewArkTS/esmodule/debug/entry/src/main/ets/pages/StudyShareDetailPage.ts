if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface StudyShareDetailPage_Params {
    share?: StudyShareItem;
    isLoading?: boolean;
    errorMsg?: string;
    isMyShare?: boolean;
    shareId?: number;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import fileIo from "@ohos:file.fs";
import fileUri from "@ohos:file.fileuri";
import filePreview from "@hms:filemanagement.filepreview";
import http from "@ohos:net.http";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { StudyShareItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const PREVIEWABLE_TYPES: string[] = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'gif', 'webp'];
const MIME_MAP: Record<string, string> = {
    'pdf': 'application/pdf',
    'doc': 'application/msword',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'ppt': 'application/vnd.ms-powerpoint',
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'xls': 'application/vnd.ms-excel',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'png': 'image/png',
    'gif': 'image/gif',
    'webp': 'image/webp'
};
const FILE_TYPE_ICONS: Record<string, string> = {
    'pdf': '📄',
    'doc': '📝',
    'docx': '📝',
    'ppt': '📊',
    'pptx': '📊',
    'xls': '📈',
    'xlsx': '📈',
    'jpg': '🖼️',
    'jpeg': '🖼️',
    'png': '🖼️',
    'zip': '📦',
    'rar': '📦'
};
const CATEGORY_COLORS: Record<string, string> = {
    '课件': '#0288D1',
    '笔记': Theme.ocean,
    '真题': '#D97706',
    '作业': Theme.success,
    '其他': Theme.textSecondary
};
const CATEGORY_BG: Record<string, string> = {
    '课件': '#E0F0FF',
    '笔记': Theme.oceanLight,
    '真题': '#FFF9E6',
    '作业': Theme.successLight,
    '其他': '#F3F4F6'
};
class StudyShareDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__share = new ObservedPropertyObjectPU(new StudyShareItem(), this, "share");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.__isMyShare = new ObservedPropertySimplePU(false, this, "isMyShare");
        this.shareId = 0;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StudyShareDetailPage_Params) {
        if (params.share !== undefined) {
            this.share = params.share;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
        if (params.isMyShare !== undefined) {
            this.isMyShare = params.isMyShare;
        }
        if (params.shareId !== undefined) {
            this.shareId = params.shareId;
        }
    }
    updateStateVars(params: StudyShareDetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__share.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
        this.__isMyShare.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__share.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        this.__isMyShare.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __share: ObservedPropertyObjectPU<StudyShareItem>;
    get share() {
        return this.__share.get();
    }
    set share(newValue: StudyShareItem) {
        this.__share.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    private __isMyShare: ObservedPropertySimplePU<boolean>;
    get isMyShare() {
        return this.__isMyShare.get();
    }
    set isMyShare(newValue: boolean) {
        this.__isMyShare.set(newValue);
    }
    private shareId: number;
    aboutToAppear(): void {
        const params: Record<string, Object> = router.getParams() as Record<string, Object>;
        if (params !== undefined && params !== null) {
            const idObj: Object = params['id'];
            if (idObj !== undefined && idObj !== null) {
                this.shareId = parseInt(idObj as string, 10);
            }
        }
        if (this.shareId > 0) {
            this.loadDetail();
        }
        else {
            this.errorMsg = '参数错误';
            this.isLoading = false;
        }
    }
    private async loadDetail(): Promise<void> {
        this.isLoading = true;
        const result = await ApiService.getStudyShareDetail(this.shareId);
        if (result.code === 200 && result.data !== undefined) {
            const obj: Record<string, Object> = result.data as Record<string, Object>;
            this.share.id = (obj['id'] as number) ?? 0;
            this.share.userId = (obj['userId'] as number) ?? 0;
            this.share.uploaderName = (obj['uploaderName'] as string) ?? '';
            this.share.uploaderAvatar = (obj['uploaderAvatar'] as string) ?? '';
            this.share.title = (obj['title'] as string) ?? '';
            this.share.description = (obj['description'] as string) ?? '';
            this.share.courseName = (obj['courseName'] as string) ?? '';
            this.share.category = (obj['category'] as string) ?? '其他';
            this.share.fileUrl = (obj['fileUrl'] as string) ?? '';
            this.share.fileType = (obj['fileType'] as string) ?? '';
            this.share.fileSize = (obj['fileSize'] as number) ?? 0;
            this.share.coverImage = (obj['coverImage'] as string) ?? '';
            this.share.likeCount = (obj['likeCount'] as number) ?? 0;
            this.share.favoriteCount = (obj['favoriteCount'] as number) ?? 0;
            this.share.downloadCount = (obj['downloadCount'] as number) ?? 0;
            this.share.liked = (obj['liked'] as boolean) ?? false;
            this.share.favorited = (obj['favorited'] as boolean) ?? false;
            this.share.status = (obj['status'] as number) ?? 0;
            this.share.createTime = (obj['createTime'] as string) ?? '';
            const store: AppStore = AppStore.getInstance();
            if (store.isLoggedIn && store.userInfo.id === this.share.userId) {
                this.isMyShare = true;
            }
        }
        else {
            this.errorMsg = '加载失败';
        }
        this.isLoading = false;
    }
    private async toggleLike(): Promise<void> {
        const result = await ApiService.likeStudyShare(this.shareId);
        if (result.code === 200) {
            this.loadDetail();
        }
    }
    private async toggleFavorite(): Promise<void> {
        const result = await ApiService.favoriteStudyShare(this.shareId);
        if (result.code === 200) {
            this.loadDetail();
        }
    }
    private async doDownload(): Promise<void> {
        const result = await ApiService.downloadStudyShare(this.shareId);
        if (result.code === 200) {
            this.share.downloadCount = this.share.downloadCount + 1;
        }
        const store: AppStore = AppStore.getInstance();
        if (store.context === undefined) {
            promptAction.showToast({ message: '下载失败' });
            return;
        }
        const downloadDir: string = store.context.filesDir;
        const ext: string = this.share.fileType.length > 0 ? this.share.fileType : 'pdf';
        const fileName: string = `${this.share.title.replace(new RegExp('[\\\\/:*?\"<>|]', 'g'), '_')}.${ext}`;
        const destPath: string = `${downloadDir}/${fileName}`;
        const remoteUrl: string = `${ApiService.baseUrl}${this.share.fileUrl}`;
        const req: http.HttpRequest = http.createHttp();
        try {
            const response: http.HttpResponse = await req.request(remoteUrl, {
                method: http.RequestMethod.GET,
                header: { 'Authorization': `Bearer ${store.token}` }
            });
            if (response.responseCode === 200) {
                const resultData: ArrayBuffer = response.result as ArrayBuffer;
                const file: fileIo.File = fileIo.openSync(destPath, fileIo.OpenMode.READ_WRITE | fileIo.OpenMode.CREATE);
                fileIo.writeSync(file.fd, resultData);
                fileIo.closeSync(file);
                promptAction.showToast({ message: `已保存到 ${destPath}` });
            }
            else {
                promptAction.showToast({ message: '下载失败' });
            }
        }
        catch (e) {
            promptAction.showToast({ message: '下载失败' });
        }
        finally {
            req.destroy();
        }
    }
    private isPreviewable(): boolean {
        const ext: string = this.share.fileType.toLowerCase();
        for (let i = 0; i < PREVIEWABLE_TYPES.length; i++) {
            if (PREVIEWABLE_TYPES[i] === ext)
                return true;
        }
        return false;
    }
    private async doPreview(): Promise<void> {
        const ext: string = this.share.fileType.toLowerCase();
        if (!this.isPreviewable()) {
            promptAction.showToast({ message: '该格式不支持预览' });
            return;
        }
        const store: AppStore = AppStore.getInstance();
        if (store.context === undefined) {
            promptAction.showToast({ message: '预览失败' });
            return;
        }
        const cacheDir: string = store.context.cacheDir;
        const fileName: string = `preview_${this.shareId}.${ext}`;
        const localPath: string = `${cacheDir}/${fileName}`;
        try {
            if (fileIo.accessSync(localPath)) {
                fileIo.unlinkSync(localPath);
            }
        }
        catch (e) {
        }
        const remoteUrl: string = `${ApiService.baseUrl}${this.share.fileUrl}`;
        const req: http.HttpRequest = http.createHttp();
        try {
            const response: http.HttpResponse = await req.request(remoteUrl, {
                method: http.RequestMethod.GET,
                expectDataType: http.HttpDataType.ARRAY_BUFFER,
                header: {}
            });
            if (response.responseCode === 200) {
                const resultData: ArrayBuffer = response.result as ArrayBuffer;
                const file: fileIo.File = fileIo.openSync(localPath, fileIo.OpenMode.READ_WRITE | fileIo.OpenMode.CREATE);
                fileIo.writeSync(file.fd, resultData);
                fileIo.closeSync(file);
            }
            else {
                promptAction.showToast({ message: '下载文件失败' });
                return;
            }
        }
        catch (e) {
            promptAction.showToast({ message: '下载文件失败' });
            return;
        }
        finally {
            req.destroy();
        }
        if (ext === 'pdf') {
            router.pushUrl({
                url: 'pages/StudySharePreviewPage',
                params: {
                    'shareId': `${this.shareId}`,
                    'fileUrl': this.share.fileUrl,
                    'title': this.share.title
                } as Record<string, string>
            });
        }
        else {
            const uri: fileUri.FileUri = new fileUri.FileUri(localPath);
            const mime: string | undefined = MIME_MAP[ext];
            const mimeType: string = mime !== undefined ? mime : 'application/octet-stream';
            const fileInfo: filePreview.PreviewInfo = {
                title: this.share.title,
                uri: uri.toString(),
                mimeType: mimeType
            };
            try {
                filePreview.openPreview(store.context, fileInfo);
            }
            catch (e) {
                promptAction.showToast({ message: '预览失败，请下载后查看' });
            }
        }
    }
    private doReport(): void {
        AlertDialog.show({
            title: '举报',
            message: '确定要举报这份资料吗？',
            primaryButton: { value: '取消', action: () => { } },
            confirm: {
                value: '举报',
                fontColor: Theme.danger,
                action: () => { this.submitReport(); }
            }
        });
    }
    private async submitReport(): Promise<void> {
        const result = await ApiService.reportStudyShare(this.shareId);
        if (result.code === 200) {
            promptAction.showToast({ message: '已举报' });
            router.back();
        }
    }
    private deleteShare(): void {
        AlertDialog.show({
            title: '确认删除',
            message: '确定要删除这份资料吗？',
            primaryButton: { value: '取消', action: () => { } },
            confirm: {
                value: '删除',
                fontColor: Theme.danger,
                action: () => { this.doDelete(); }
            }
        });
    }
    private async doDelete(): Promise<void> {
        const result = await ApiService.deleteStudyShare(this.shareId);
        if (result.code === 200) {
            promptAction.showToast({ message: '已删除' });
            router.back();
        }
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0)
            return '';
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16)
            return t.substring(0, 16);
        return t;
    }
    private formatFileSize(bytes: number): string {
        if (bytes <= 0)
            return '';
        if (bytes < 1024)
            return `${bytes}B`;
        if (bytes < 1024 * 1024)
            return `${(bytes / 1024).toFixed(1)}KB`;
        return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
    }
    private getFileIcon(): string {
        const icon: string | undefined = FILE_TYPE_ICONS[this.share.fileType.toLowerCase()];
        return icon !== undefined ? icon : '📁';
    }
    private getCategoryColor(): string {
        const c: string | undefined = CATEGORY_COLORS[this.share.category];
        return c !== undefined ? c : Theme.textSecondary;
    }
    private getCategoryBg(): string {
        const b: string | undefined = CATEGORY_BG[this.share.category];
        return b !== undefined ? b : '#F3F4F6';
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(324:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '资料详情',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.isMyShare && !this.isLoading) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('删除');
                                            Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(327:11)", "entry");
                                            Text.fontSize(14);
                                            Text.fontColor(Theme.danger);
                                            Text.onClick(() => { this.deleteShare(); });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/StudyShareDetailPage.ets", line: 325, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '资料详情',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.isMyShare && !this.isLoading) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('删除');
                                                Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(327:11)", "entry");
                                                Text.fontSize(14);
                                                Text.fontColor(Theme.danger);
                                                Text.onClick(() => { this.deleteShare(); });
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '资料详情'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(332:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(333:11)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(338:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('😕');
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(339:11)", "entry");
                        Text.fontSize(48);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(340:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(345:9)", "entry");
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(346:11)", "entry");
                        Column.padding({ left: 12, right: 12, top: 8, bottom: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(347:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                        Column.borderRadius(Theme.cardRadius);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(348:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.share.uploaderName);
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(349:17)", "entry");
                        Text.fontSize(14);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(this.share.createTime));
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(353:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ left: 10 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(357:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.share.category);
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(358:17)", "entry");
                        Text.fontSize(11);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(this.getCategoryColor());
                        Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                        Text.borderRadius(10);
                        Text.backgroundColor(this.getCategoryBg());
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.share.title);
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(368:15)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.width('100%');
                        Text.margin({ top: 12 });
                        Text.lineHeight(26);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.share.courseName.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(377:17)", "entry");
                                    Row.margin({ top: 8 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('📚');
                                    Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(378:19)", "entry");
                                    Text.fontSize(14);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.share.courseName);
                                    Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(380:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.ocean);
                                    Text.margin({ left: 4 });
                                }, Text);
                                Text.pop();
                                Row.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Stack.create();
                        Stack.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(388:15)", "entry");
                        Stack.width('100%');
                        Stack.margin({ top: 12 });
                    }, Stack);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.share.coverImage.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Image.create(`${ApiService.baseUrl}${this.share.coverImage}`);
                                    Image.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(390:19)", "entry");
                                    Image.width('100%');
                                    Image.height(200);
                                    Image.borderRadius(Theme.radiusMd);
                                    Image.objectFit(ImageFit.Cover);
                                }, Image);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(396:19)", "entry");
                                    Column.width('100%');
                                    Column.height(120);
                                    Column.backgroundColor(Theme.bgInput);
                                    Column.borderRadius(Theme.radiusMd);
                                    Column.justifyContent(FlexAlign.Center);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.getFileIcon());
                                    Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(397:21)", "entry");
                                    Text.fontSize(40);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.share.fileType.toUpperCase());
                                    Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(399:21)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textSecondary);
                                    Text.margin({ top: 4 });
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(410:17)", "entry");
                        Row.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                        Row.borderRadius(4);
                        Row.backgroundColor('#00000080');
                        Row.position({ bottom: 8, right: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.getFileIcon());
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(411:19)", "entry");
                        Text.fontSize(12);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.share.fileType.toUpperCase());
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(413:19)", "entry");
                        Text.fontSize(10);
                        Text.fontColor('#FFFFFF');
                        Text.margin({ left: 2 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    Stack.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.share.description.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.share.description);
                                    Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(427:17)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textSecondary);
                                    Text.width('100%');
                                    Text.margin({ top: 12 });
                                    Text.lineHeight(22);
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(435:15)", "entry");
                        Row.margin({ top: 10 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatFileSize(this.share.fileSize));
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(436:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('·');
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(439:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ left: 6, right: 6 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.share.downloadCount}次下载`);
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(443:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(454:13)", "entry");
                        Blank.height(10);
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(456:13)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 2 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(457:15)", "entry");
                        Row.layoutWeight(1);
                        Row.justifyContent(FlexAlign.Center);
                        Row.height(48);
                        Row.backgroundColor('#FFFFFF');
                        Row.borderRadius(Theme.cardRadius);
                        Row.onClick(() => { this.toggleLike(); });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.share.liked ? '❤️' : '🤍');
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(458:17)", "entry");
                        Text.fontSize(20);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.share.likeCount}`);
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(459:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(this.share.liked ? Theme.danger : Theme.textTertiary);
                        Text.margin({ left: 6 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(471:15)", "entry");
                        Row.layoutWeight(1);
                        Row.justifyContent(FlexAlign.Center);
                        Row.height(48);
                        Row.backgroundColor('#FFFFFF');
                        Row.borderRadius(Theme.cardRadius);
                        Row.margin({ left: 6 });
                        Row.onClick(() => { this.toggleFavorite(); });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.share.favorited ? '⭐' : '☆');
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(472:17)", "entry");
                        Text.fontSize(20);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.share.favoriteCount}`);
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(473:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(this.share.favorited ? '#D97706' : Theme.textTertiary);
                        Text.margin({ left: 6 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(486:15)", "entry");
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                        Column.height(48);
                        Column.backgroundColor('#FFFFFF');
                        Column.borderRadius(Theme.cardRadius);
                        Column.margin({ left: 6 });
                        Column.enabled(this.isPreviewable());
                        Column.onClick(() => { this.doPreview(); });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('👁️');
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(487:17)", "entry");
                        Text.fontSize(20);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('预览');
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(488:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(this.isPreviewable() ? Theme.ocean : Theme.textDisabled);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(501:15)", "entry");
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                        Column.height(48);
                        Column.backgroundColor('#FFFFFF');
                        Column.borderRadius(Theme.cardRadius);
                        Column.margin({ left: 6 });
                        Column.onClick(() => { this.doDownload(); });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('📥');
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(502:17)", "entry");
                        Text.fontSize(20);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('下载');
                        Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(503:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.primary);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (!this.isMyShare) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('举报此资料');
                                    Text.debugLine("entry/src/main/ets/pages/StudyShareDetailPage.ets(519:15)", "entry");
                                    Text.fontSize(13);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.width('100%');
                                    Text.textAlign(TextAlign.Center);
                                    Text.margin({ top: 16 });
                                    Text.onClick(() => { this.doReport(); });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "StudyShareDetailPage";
    }
}
registerNamedRoute(() => new StudyShareDetailPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/StudyShareDetailPage", pageFullPath: "entry/src/main/ets/pages/StudyShareDetailPage", integratedHsp: "false", moduleType: "followWithHap" });
