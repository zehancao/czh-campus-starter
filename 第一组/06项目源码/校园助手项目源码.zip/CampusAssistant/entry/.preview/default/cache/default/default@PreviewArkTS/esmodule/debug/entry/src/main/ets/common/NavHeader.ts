if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface NavHeader_Params {
    title?: string;
    rightSlot?: () => void;
}
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
export class NavHeader extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__title = new SynchedPropertySimpleOneWayPU(params.title, this, "title");
        this.rightSlot = this.defaultSlot;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: NavHeader_Params) {
        if (params.title === undefined) {
            this.__title.set('');
        }
        if (params.rightSlot !== undefined) {
            this.rightSlot = params.rightSlot;
        }
    }
    updateStateVars(params: NavHeader_Params) {
        this.__title.reset(params.title);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__title.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__title.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __title: SynchedPropertySimpleOneWayPU<string>;
    get title() {
        return this.__title.get();
    }
    set title(newValue: string) {
        this.__title.set(newValue);
    }
    private __rightSlot;
    defaultSlot(parent = null): void {
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/NavHeader.ets(13:5)", "entry");
            Row.width('100%');
            Row.height(Theme.navHeight);
            Row.padding({ left: 12, right: 16 });
            Row.alignItems(VerticalAlign.Center);
            Row.backgroundColor(Theme.bgCard);
            Row.border({ width: { bottom: 0.5 }, color: Theme.border });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/NavHeader.ets(14:7)", "entry");
            Row.width(44);
            Row.height(44);
            Row.justifyContent(FlexAlign.Center);
            Row.alignItems(VerticalAlign.Center);
            Row.onClick(() => {
                this.getUIContext().getRouter().back();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777226, "type": 20000, params: [], "bundleName": "com.campus.assistant", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/common/NavHeader.ets(15:9)", "entry");
            Image.width(Theme.navBackSize);
            Image.height(Theme.navBackSize);
        }, Image);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.title);
            Text.debugLine("entry/src/main/ets/common/NavHeader.ets(27:7)", "entry");
            Text.fontSize(Theme.navTitleSize);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.rightSlot !== undefined) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/common/NavHeader.ets(35:9)", "entry");
                        Row.width(44);
                        Row.height(44);
                        Row.justifyContent(FlexAlign.End);
                        Row.alignItems(VerticalAlign.Center);
                    }, Row);
                    this.rightSlot.bind(this)();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/common/NavHeader.ets(43:9)", "entry");
                        Blank.width(44);
                    }, Blank);
                    Blank.pop();
                });
            }
        }, If);
        If.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
