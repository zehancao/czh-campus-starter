if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LostFoundDetailPage_Params {
    itemData?: LostFoundItem;
    images?: string[];
    isLoading?: boolean;
    isMyPost?: boolean;
    errorMsg?: string;
    lostFoundIdInput?: number;
}
interface ImagePreview_Params {
    images?: string[];
    startIndex?: number;
}
import router from "@ohos:router";
import http from "@ohos:net.http";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { LostFoundItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const STATUS_LABELS: string[] = ['进行中', '已找到/已归还'];
const STATUS_COLORS: string[] = [Theme.warning, Theme.success];
function splitImageString(imagesStr: string): string[] {
    if (imagesStr === null || imagesStr === undefined || imagesStr.length === 0) {
        return [];
    }
    const cleaned: string = imagesStr.replace('[', '').replace(']', '').replace(new RegExp('"', 'g'), '');
    if (cleaned.length === 0) {
        return [];
    }
    return cleaned.split(',');
}
class ImagePreview extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.images = [];
        this.startIndex = 0;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ImagePreview_Params) {
        if (params.images !== undefined) {
            this.images = params.images;
        }
        if (params.startIndex !== undefined) {
            this.startIndex = params.startIndex;
        }
    }
    updateStateVars(params: ImagePreview_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private images: string[];
    private startIndex: number;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.images.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(32:7)", "entry");
                        Column.width('100%');
                        Column.height(280);
                        Column.backgroundColor(Theme.bgInput);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('📷 暂无图片');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(33:9)", "entry");
                        Text.fontSize(32);
                        Text.fontColor(Theme.textDisabled);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Stack.create();
                        Stack.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(39:7)", "entry");
                    }, Stack);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Swiper.create();
                        Swiper.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(40:9)", "entry");
                        Swiper.width('100%');
                        Swiper.height(280);
                        Swiper.autoPlay(false);
                        Swiper.indicator(false);
                        Swiper.loop(false);
                        Swiper.onChange((index: number) => { this.startIndex = index; });
                    }, Swiper);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const img = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Image.create(ApiService.baseUrl + img);
                                Image.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(42:13)", "entry");
                                Image.width('100%');
                                Image.height(280);
                                Image.objectFit(ImageFit.Cover);
                            }, Image);
                        };
                        this.forEachUpdateFunction(elmtId, this.images, forEachItemGenFunction, (img: string) => img, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Swiper.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.images.length > 1) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create((this.startIndex + 1) + '/' + this.images.length);
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(55:11)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor('#FFFFFF');
                                    Text.backgroundColor('#00000066');
                                    Text.borderRadius(Theme.radiusMd);
                                    Text.padding({ left: 10, right: 10, top: 3, bottom: 3 });
                                    Text.position({ bottom: 12, right: 12 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Stack.pop();
                });
            }
        }, If);
        If.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class LostFoundDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__itemData = new ObservedPropertyObjectPU(new LostFoundItem(), this, "itemData");
        this.__images = new ObservedPropertyObjectPU([], this, "images");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isMyPost = new ObservedPropertySimplePU(false, this, "isMyPost");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.lostFoundIdInput = 0;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LostFoundDetailPage_Params) {
        if (params.itemData !== undefined) {
            this.itemData = params.itemData;
        }
        if (params.images !== undefined) {
            this.images = params.images;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isMyPost !== undefined) {
            this.isMyPost = params.isMyPost;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
        if (params.lostFoundIdInput !== undefined) {
            this.lostFoundIdInput = params.lostFoundIdInput;
        }
    }
    updateStateVars(params: LostFoundDetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__itemData.purgeDependencyOnElmtId(rmElmtId);
        this.__images.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isMyPost.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__itemData.aboutToBeDeleted();
        this.__images.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isMyPost.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __itemData: ObservedPropertyObjectPU<LostFoundItem>;
    get itemData() {
        return this.__itemData.get();
    }
    set itemData(newValue: LostFoundItem) {
        this.__itemData.set(newValue);
    }
    private __images: ObservedPropertyObjectPU<string[]>;
    get images() {
        return this.__images.get();
    }
    set images(newValue: string[]) {
        this.__images.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isMyPost: ObservedPropertySimplePU<boolean>;
    get isMyPost() {
        return this.__isMyPost.get();
    }
    set isMyPost(newValue: boolean) {
        this.__isMyPost.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    private lostFoundIdInput: number;
    aboutToAppear(): void {
        const params: Record<string, Object> = router.getParams() as Record<string, Object>;
        if (params !== undefined && params !== null) {
            const idObj: Object = params['id'];
            if (idObj !== undefined && idObj !== null) {
                this.lostFoundIdInput = parseInt(idObj as string, 10);
            }
        }
        if (this.lostFoundIdInput > 0) {
            this.loadDetail();
        }
        else {
            this.errorMsg = '参数错误';
            this.isLoading = false;
        }
    }
    private async loadDetail(): Promise<void> {
        this.isLoading = true;
        try {
            const result = await ApiService.request(http.RequestMethod.GET, '/api/lost-found/detail?id=' + this.lostFoundIdInput, undefined, false);
            if (result.code === 200 && result.data !== undefined) {
                const obj: Record<string, Object> = result.data as Record<string, Object>;
                const lf: LostFoundItem = new LostFoundItem();
                lf.id = (obj['id'] as number) ?? 0;
                lf.userId = (obj['userId'] as number) ?? 0;
                lf.userName = (obj['userName'] as string) ?? '';
                lf.type = (obj['type'] as number) ?? 1;
                lf.title = (obj['title'] as string) ?? '';
                lf.description = (obj['description'] as string) ?? '';
                const imgObj: Object = obj['images'];
                if (imgObj !== null && imgObj !== undefined) {
                    lf.images = imgObj as string;
                }
                else {
                    lf.images = '[]';
                }
                lf.locationDesc = (obj['locationDesc'] as string) ?? '';
                lf.category = (obj['category'] as string) ?? '';
                const phoneObj: Object = obj['contactPhone'];
                if (phoneObj !== null && phoneObj !== undefined) {
                    lf.contactPhone = phoneObj as string;
                }
                else {
                    lf.contactPhone = '';
                }
                lf.status = (obj['status'] as number) ?? 1;
                lf.createTime = (obj['createTime'] as string) ?? '';
                this.itemData = lf;
                this.images = splitImageString(lf.images);
                const store: AppStore = AppStore.getInstance();
                if (store.isLoggedIn && store.userInfo.id === lf.userId) {
                    this.isMyPost = true;
                }
            }
            else {
                this.errorMsg = result.msg || '加载失败';
            }
        }
        catch (err) {
            this.errorMsg = '网络错误';
        }
        this.isLoading = false;
    }
    private deletePost(): void {
        if (!this.isMyPost) {
            return;
        }
        AlertDialog.show({
            title: '确认删除',
            message: '确定要删除这条' + (this.itemData.type === 1 ? '寻物' : '招领') + '信息吗？此操作不可恢复。',
            primaryButton: {
                value: '取消',
                action: () => { }
            },
            confirm: {
                value: '删除',
                fontColor: Theme.danger,
                action: () => {
                    this.doDelete();
                }
            }
        });
    }
    private async doDelete(): Promise<void> {
        const result = await ApiService.deleteLostFound(this.itemData.id);
        if (result.code === 200) {
            promptAction.showToast({ message: '已删除' });
            router.back();
        }
        else {
            AlertDialog.show({
                message: result.msg || '删除失败',
                confirm: { value: '好的', action: () => { } }
            });
        }
    }
    private contactOwner(): void {
        const store: AppStore = AppStore.getInstance();
        if (!store.isLoggedIn) {
            AlertDialog.show({
                message: '请先登录后联系',
                confirm: { value: '好的', action: () => { } }
            });
            return;
        }
        AlertDialog.show({
            message: '联系 ' + this.itemData.userName + '：\n' + this.itemData.contactPhone,
            confirm: { value: '好的', action: () => { } }
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(193:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: this.itemData.type === 1 ? '寻物信息' : '招领信息',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.isMyPost && !this.isLoading) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('删除');
                                            Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(196:11)", "entry");
                                            Text.fontSize(14);
                                            Text.fontColor(Theme.danger);
                                            Text.onClick(() => { this.deletePost(); });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundDetailPage.ets", line: 194, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: this.itemData.type === 1 ? '寻物信息' : '招领信息',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.isMyPost && !this.isLoading) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('删除');
                                                Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(196:11)", "entry");
                                                Text.fontSize(14);
                                                Text.fontColor(Theme.danger);
                                                Text.onClick(() => { this.deletePost(); });
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: this.itemData.type === 1 ? '寻物信息' : '招领信息'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(201:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(202:11)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(207:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('😕');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(208:11)", "entry");
                        Text.fontSize(48);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(209:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('重试');
                        Button.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(210:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 20 });
                        Button.onClick(() => { this.loadDetail(); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(218:9)", "entry");
                        Scroll.layoutWeight(1);
                        Scroll.width('100%');
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(219:11)", "entry");
                    }, Column);
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new ImagePreview(this, { images: this.images, startIndex: 0 }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundDetailPage.ets", line: 220, col: 13 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        images: this.images,
                                        startIndex: 0
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "ImagePreview" });
                    }
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(222:13)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16, top: 12 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.type === 1 ? '🔍 寻物' : '📢 招领');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(223:15)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.secondary);
                        Text.backgroundColor(Theme.secondaryLight);
                        Text.borderRadius(Theme.radiusSm);
                        Text.padding({ left: 10, right: 10, top: 4, bottom: 4 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(228:15)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(STATUS_LABELS[Math.max(0, Math.min(this.itemData.status - 1, 1))]);
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(229:15)", "entry");
                        Text.fontSize(12);
                        Text.fontColor('#FFFFFF');
                        Text.backgroundColor(STATUS_COLORS[Math.max(0, Math.min(this.itemData.status - 1, 1))]);
                        Text.borderRadius(4);
                        Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.title);
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(239:13)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.width('100%');
                        Text.padding({ left: 16, right: 16 });
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(245:13)", "entry");
                        Divider.height(8);
                        Divider.color(Theme.bgPage);
                        Divider.width('100%');
                        Divider.margin({ top: 12 });
                    }, Divider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(246:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.itemData.category.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(248:17)", "entry");
                                    Row.width('100%');
                                    Row.padding({ top: 6, bottom: 6 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('物品分类');
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(249:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.width(80);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.itemData.category);
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(250:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textPrimary);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Blank.create();
                                    Blank.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(251:19)", "entry");
                                }, Blank);
                                Blank.pop();
                                Row.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.itemData.locationDesc.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(258:17)", "entry");
                                    Row.width('100%');
                                    Row.padding({ top: 6, bottom: 6 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('地    点');
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(259:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.width(80);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.itemData.locationDesc);
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(260:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textPrimary);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Blank.create();
                                    Blank.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(261:19)", "entry");
                                }, Blank);
                                Blank.pop();
                                Row.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(267:15)", "entry");
                        Row.width('100%');
                        Row.padding({ top: 6, bottom: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('发布者');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(268:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textTertiary);
                        Text.width(80);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.userName);
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(269:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(270:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(275:15)", "entry");
                        Row.width('100%');
                        Row.padding({ top: 6, bottom: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('发布时间');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(276:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textTertiary);
                        Text.width(80);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(this.itemData.createTime));
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(277:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(278:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(283:15)", "entry");
                        Divider.height(1);
                        Divider.color(Theme.border);
                        Divider.width('100%');
                        Divider.margin({ top: 6, bottom: 6 });
                    }, Divider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(285:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('详细描述');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(286:17)", "entry");
                        Text.fontSize(14);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(287:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.description.length > 0 ? this.itemData.description : '暂无描述');
                        Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(290:15)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.width('100%');
                        Text.margin({ top: 6 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(299:13)", "entry");
                        Divider.height(8);
                        Divider.color(Theme.bgPage);
                        Divider.width('100%');
                    }, Divider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.itemData.contactPhone.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(302:15)", "entry");
                                    Column.width('100%');
                                    Column.padding(16);
                                    Column.backgroundColor('#FFFFFF');
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(303:17)", "entry");
                                    Row.width('100%');
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('联系方式');
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(304:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontWeight(FontWeight.Medium);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Blank.create();
                                    Blank.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(305:19)", "entry");
                                }, Blank);
                                Blank.pop();
                                Row.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(308:17)", "entry");
                                    Row.width('100%');
                                    Row.margin({ top: 8 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('📞');
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(309:19)", "entry");
                                    Text.fontSize(20);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.itemData.contactPhone);
                                    Text.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(310:19)", "entry");
                                    Text.fontSize(16);
                                    Text.fontColor(Theme.secondary);
                                    Text.margin({ left: 8 });
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Blank.create();
                                    Blank.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(313:19)", "entry");
                                }, Blank);
                                Blank.pop();
                                Row.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(323:13)", "entry");
                        Divider.height(16);
                        Divider.color(Theme.bgPage);
                        Divider.width('100%');
                    }, Divider);
                    Column.pop();
                    Scroll.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(329:9)", "entry");
                        Row.width('100%');
                        Row.height(64);
                        Row.backgroundColor('#FFFFFF');
                        Row.shadow(ShadowStyle.sm);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('📞 联系 ' + (this.itemData.userName.length > 0 ? this.itemData.userName : '发布者'));
                        Button.debugLine("entry/src/main/ets/pages/LostFoundDetailPage.ets(330:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.borderRadius(Theme.buttonRadius);
                        Button.height(44);
                        Button.layoutWeight(1);
                        Button.margin({ left: 16, right: 16 });
                        Button.onClick(() => { this.contactOwner(); });
                    }, Button);
                    Button.pop();
                    Row.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0) {
            return '';
        }
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16) {
            return t.substring(0, 16);
        }
        return t;
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "LostFoundDetailPage";
    }
}
registerNamedRoute(() => new LostFoundDetailPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/LostFoundDetailPage", pageFullPath: "entry/src/main/ets/pages/LostFoundDetailPage", integratedHsp: "false", moduleType: "followWithHap" });
