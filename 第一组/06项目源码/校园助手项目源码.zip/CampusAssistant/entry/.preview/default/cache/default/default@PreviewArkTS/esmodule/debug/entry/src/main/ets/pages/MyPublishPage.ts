if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MyPublishPage_Params {
    products?: Product[];
    activities?: ClubActivityItem[];
    carpools?: CarpoolOrder[];
    confessionPosts?: ConfessionPost[];
    studyShares?: StudyShareItem[];
    isLoggedIn?: boolean;
    productsLoaded?: boolean;
    activitiesLoaded?: boolean;
    carpoolsLoaded?: boolean;
    confessionLoaded?: boolean;
    studyLoaded?: boolean;
    productsLoading?: boolean;
    activitiesLoading?: boolean;
    carpoolsLoading?: boolean;
    confessionLoading?: boolean;
    studyLoading?: boolean;
}
interface MyStudyShareCard_Params {
    item?: StudyShareItem;
    onTap?: () => void;
    onDelete?: () => void;
}
interface MyConfessionCard_Params {
    item?: ConfessionPost;
    onDelete?: () => void;
}
interface MyCarpoolCard_Params {
    item?: CarpoolOrder;
    onTap?: () => void;
    onDelete?: () => void;
}
interface MyActivityCard_Params {
    item?: ClubActivityItem;
    onTap?: () => void;
    onDelete?: () => void;
}
interface MyProductCard_Params {
    item?: Product;
    onTap?: () => void;
    onStatusChange?: (status: number) => void;
    onDelete?: () => void;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { Product, ClubActivityItem, CarpoolOrder, ConfessionPost, StudyShareItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const STATUS_LABELS: string[] = ['', '在售', '已售', '下架'];
const STATUS_COLORS: string[] = [Theme.bgCard, Theme.success, Theme.textSecondary, Theme.danger];
const CONDITION_LABELS: string[] = ['', '全新', '几乎全新', '轻微使用痕迹', '明显使用痕迹', '成色一般'];
const ACTIVITY_STATUS: string[] = ['', '报名中', '已满', '已结束'];
const ACTIVITY_STATUS_COLORS: string[] = [Theme.bgCard, Theme.success, Theme.warning, Theme.textTertiary];
const CARPOOL_STATUS: string[] = ['', '招募中', '已满员', '已取消'];
const CARPOOL_STATUS_COLORS: string[] = [Theme.bgCard, Theme.success, Theme.warning, Theme.danger];
class MyProductCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = new Product();
        this.onTap = undefined;
        this.onStatusChange = undefined;
        this.onDelete = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyProductCard_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.onTap !== undefined) {
            this.onTap = params.onTap;
        }
        if (params.onStatusChange !== undefined) {
            this.onStatusChange = params.onStatusChange;
        }
        if (params.onDelete !== undefined) {
            this.onDelete = params.onDelete;
        }
    }
    updateStateVars(params: MyProductCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: Product;
    private onTap?: () => void;
    private onStatusChange?: (status: number) => void;
    private onDelete?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(25:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(12);
            Row.margin({ bottom: 12 });
            Row.onClick(() => {
                if (this.onTap !== undefined) {
                    this.onTap();
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.images.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(ApiService.baseUrl + this.item.images[0]);
                        Image.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(27:9)", "entry");
                        Image.width(96);
                        Image.height(96);
                        Image.borderRadius(10);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(33:9)", "entry");
                        Column.width(96);
                        Column.height(96);
                        Column.backgroundColor(Theme.bgPage);
                        Column.borderRadius(10);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83D\uDCE6');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(34:11)", "entry");
                        Text.fontSize(34);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(44:7)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(45:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.title);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(46:11)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(52:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`\u00A5${this.item.price.toFixed(2)}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(53:11)", "entry");
            Text.fontSize(17);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.secondary);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${CONDITION_LABELS[Math.max(1, Math.min(this.item.conditionLevel, 5))]}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(60:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`浏览 ${this.item.viewCount} \u00B7 ${this.item.createTime}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(66:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(72:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(STATUS_LABELS[Math.max(0, Math.min(this.item.status, 3))]);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(73:11)", "entry");
            Text.fontSize(11);
            Text.fontColor('#FFFFFF');
            Text.backgroundColor(STATUS_COLORS[Math.max(0, Math.min(this.item.status, 3))]);
            Text.borderRadius(4);
            Text.padding({ left: 7, right: 7, top: 2, bottom: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(79:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.status === 1) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('下架');
                        Button.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(82:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.fontSize(11);
                        Button.fontColor(Theme.danger);
                        Button.backgroundColor(Theme.dangerLight);
                        Button.height(28);
                        Button.padding({ left: 10, right: 10 });
                        Button.onClick(() => {
                            if (this.onStatusChange !== undefined) {
                                this.onStatusChange(3);
                            }
                        });
                    }, Button);
                    Button.pop();
                });
            }
            else if (this.item.status === 3) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('上架');
                        Button.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(95:13)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.fontSize(11);
                        Button.fontColor(Theme.success);
                        Button.backgroundColor(Theme.successLight);
                        Button.height(28);
                        Button.padding({ left: 10, right: 10 });
                        Button.onClick(() => {
                            if (this.onStatusChange !== undefined) {
                                this.onStatusChange(1);
                            }
                        });
                    }, Button);
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('删除');
            Button.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(109:11)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(11);
            Button.fontColor(Theme.danger);
            Button.backgroundColor(Theme.dangerLight);
            Button.height(28);
            Button.padding({ left: 10, right: 10 });
            Button.margin({ left: 6 });
            Button.onClick(() => {
                if (this.onDelete !== undefined) {
                    this.onDelete();
                }
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class MyActivityCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = new ClubActivityItem();
        this.onTap = undefined;
        this.onDelete = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyActivityCard_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.onTap !== undefined) {
            this.onTap = params.onTap;
        }
        if (params.onDelete !== undefined) {
            this.onDelete = params.onDelete;
        }
    }
    updateStateVars(params: MyActivityCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: ClubActivityItem;
    private onTap?: () => void;
    private onDelete?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(150:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(12);
            Row.margin({ bottom: 12 });
            Row.onClick(() => {
                if (this.onTap !== undefined) {
                    this.onTap();
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.coverImage.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(ApiService.baseUrl + this.item.coverImage);
                        Image.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(152:9)", "entry");
                        Image.width(72);
                        Image.height(72);
                        Image.borderRadius(10);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(158:9)", "entry");
                        Column.width(72);
                        Column.height(72);
                        Column.backgroundColor(Theme.bgPage);
                        Column.borderRadius(10);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83C\uDF89');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(159:11)", "entry");
                        Text.fontSize(34);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(169:7)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(170:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.title);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(171:11)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('删除');
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(177:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.danger);
            Text.margin({ left: 8 });
            Text.onClick(() => {
                if (this.onDelete !== undefined) {
                    this.onDelete();
                }
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.item.club} \u00B7 ${this.item.venue}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(189:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 4 });
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.item.currentParticipants}/${this.item.maxParticipants}人 \u00B7 ${this.item.activityTime}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(197:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class MyCarpoolCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = new CarpoolOrder();
        this.onTap = undefined;
        this.onDelete = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyCarpoolCard_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.onTap !== undefined) {
            this.onTap = params.onTap;
        }
        if (params.onDelete !== undefined) {
            this.onDelete = params.onDelete;
        }
    }
    updateStateVars(params: MyCarpoolCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: CarpoolOrder;
    private onTap?: () => void;
    private onDelete?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(227:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(12);
            Row.margin({ bottom: 12 });
            Row.onClick(() => {
                if (this.onTap !== undefined) {
                    this.onTap();
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(228:7)", "entry");
            Column.width(72);
            Column.height(72);
            Column.backgroundColor(Theme.bgPage);
            Column.borderRadius(10);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('\uD83D\uDE97');
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(229:9)", "entry");
            Text.fontSize(34);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(238:7)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(239:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.departure);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(240:11)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(' \u2192 ');
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(245:11)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.destination);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(248:11)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('删除');
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(254:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.danger);
            Text.margin({ left: 8 });
            Text.onClick(() => {
                if (this.onDelete !== undefined) {
                    this.onDelete();
                }
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.item.departureTime} \u00B7 ${this.item.currentPassengers}/${this.item.maxPassengers}人`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(266:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.remark.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.item.remark);
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(273:11)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.width('100%');
                        Text.margin({ top: 2 });
                        Text.maxLines(1);
                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class MyConfessionCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = new ConfessionPost();
        this.onDelete = () => { };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyConfessionCard_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.onDelete !== undefined) {
            this.onDelete = params.onDelete;
        }
    }
    updateStateVars(params: MyConfessionCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: ConfessionPost;
    private onDelete: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(305:5)", "entry");
            Column.width('100%');
            Column.padding(12);
            Column.backgroundColor('#FFFFFF');
            Column.borderRadius(12);
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(306:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.category);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(307:9)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.primary);
            Text.backgroundColor(Theme.primaryLight);
            Text.borderRadius(4);
            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(313:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('删除');
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(314:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.danger);
            Text.onClick(() => { this.onDelete(); });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.content);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(321:7)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ top: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.images.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Flex.create({ wrap: FlexWrap.Wrap, justifyContent: FlexAlign.Start });
                        Flex.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(328:9)", "entry");
                        Flex.width('100%');
                        Flex.margin({ top: 8 });
                    }, Flex);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const imgUrl = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Image.create(ApiService.baseUrl + imgUrl);
                                Image.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(330:13)", "entry");
                                Image.width(this.item.images.length === 1 ? 200 : 100);
                                Image.height(this.item.images.length === 1 ? 200 : 100);
                                Image.borderRadius(6);
                                Image.objectFit(ImageFit.Cover);
                                Image.margin({ right: 4, bottom: 4 });
                            }, Image);
                        };
                        this.forEachUpdateFunction(elmtId, this.item.images, forEachItemGenFunction, (imgUrl: string, index: number) => `${index}`, true, true);
                    }, ForEach);
                    ForEach.pop();
                    Flex.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(342:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`\u2764 ${this.item.likeCount}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(343:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`\uD83D\uDCAC ${this.item.commentCount}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(346:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ left: 12 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class MyStudyShareCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = new StudyShareItem();
        this.onTap = undefined;
        this.onDelete = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyStudyShareCard_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.onTap !== undefined) {
            this.onTap = params.onTap;
        }
        if (params.onDelete !== undefined) {
            this.onDelete = params.onDelete;
        }
    }
    updateStateVars(params: MyStudyShareCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: StudyShareItem;
    private onTap?: () => void;
    private onDelete?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(369:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor('#FFFFFF');
            Row.borderRadius(12);
            Row.margin({ bottom: 12 });
            Row.onClick(() => {
                if (this.onTap !== undefined) {
                    this.onTap();
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(370:7)", "entry");
            Column.width(72);
            Column.height(72);
            Column.backgroundColor(Theme.bgPage);
            Column.borderRadius(10);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('\uD83D\uDCC4');
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(371:9)", "entry");
            Text.fontSize(34);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(380:7)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(381:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.title);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(382:11)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('删除');
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(388:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.danger);
            Text.margin({ left: 8 });
            Text.onClick(() => {
                if (this.onDelete !== undefined) {
                    this.onDelete();
                }
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.item.courseName} \u00B7 ${this.item.category}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(400:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 4 });
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(408:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`\u2764 ${this.item.likeCount}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(409:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`\u2B07 ${this.item.downloadCount}`);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(412:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ left: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(416:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.createTime);
            Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(417:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class MyPublishPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__products = new ObservedPropertyObjectPU([], this, "products");
        this.__activities = new ObservedPropertyObjectPU([], this, "activities");
        this.__carpools = new ObservedPropertyObjectPU([], this, "carpools");
        this.__confessionPosts = new ObservedPropertyObjectPU([], this, "confessionPosts");
        this.__studyShares = new ObservedPropertyObjectPU([], this, "studyShares");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.__productsLoaded = new ObservedPropertySimplePU(false, this, "productsLoaded");
        this.__activitiesLoaded = new ObservedPropertySimplePU(false, this, "activitiesLoaded");
        this.__carpoolsLoaded = new ObservedPropertySimplePU(false, this, "carpoolsLoaded");
        this.__confessionLoaded = new ObservedPropertySimplePU(false, this, "confessionLoaded");
        this.__studyLoaded = new ObservedPropertySimplePU(false, this, "studyLoaded");
        this.__productsLoading = new ObservedPropertySimplePU(true, this, "productsLoading");
        this.__activitiesLoading = new ObservedPropertySimplePU(false, this, "activitiesLoading");
        this.__carpoolsLoading = new ObservedPropertySimplePU(false, this, "carpoolsLoading");
        this.__confessionLoading = new ObservedPropertySimplePU(false, this, "confessionLoading");
        this.__studyLoading = new ObservedPropertySimplePU(false, this, "studyLoading");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyPublishPage_Params) {
        if (params.products !== undefined) {
            this.products = params.products;
        }
        if (params.activities !== undefined) {
            this.activities = params.activities;
        }
        if (params.carpools !== undefined) {
            this.carpools = params.carpools;
        }
        if (params.confessionPosts !== undefined) {
            this.confessionPosts = params.confessionPosts;
        }
        if (params.studyShares !== undefined) {
            this.studyShares = params.studyShares;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
        if (params.productsLoaded !== undefined) {
            this.productsLoaded = params.productsLoaded;
        }
        if (params.activitiesLoaded !== undefined) {
            this.activitiesLoaded = params.activitiesLoaded;
        }
        if (params.carpoolsLoaded !== undefined) {
            this.carpoolsLoaded = params.carpoolsLoaded;
        }
        if (params.confessionLoaded !== undefined) {
            this.confessionLoaded = params.confessionLoaded;
        }
        if (params.studyLoaded !== undefined) {
            this.studyLoaded = params.studyLoaded;
        }
        if (params.productsLoading !== undefined) {
            this.productsLoading = params.productsLoading;
        }
        if (params.activitiesLoading !== undefined) {
            this.activitiesLoading = params.activitiesLoading;
        }
        if (params.carpoolsLoading !== undefined) {
            this.carpoolsLoading = params.carpoolsLoading;
        }
        if (params.confessionLoading !== undefined) {
            this.confessionLoading = params.confessionLoading;
        }
        if (params.studyLoading !== undefined) {
            this.studyLoading = params.studyLoading;
        }
    }
    updateStateVars(params: MyPublishPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__products.purgeDependencyOnElmtId(rmElmtId);
        this.__activities.purgeDependencyOnElmtId(rmElmtId);
        this.__carpools.purgeDependencyOnElmtId(rmElmtId);
        this.__confessionPosts.purgeDependencyOnElmtId(rmElmtId);
        this.__studyShares.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
        this.__productsLoaded.purgeDependencyOnElmtId(rmElmtId);
        this.__activitiesLoaded.purgeDependencyOnElmtId(rmElmtId);
        this.__carpoolsLoaded.purgeDependencyOnElmtId(rmElmtId);
        this.__confessionLoaded.purgeDependencyOnElmtId(rmElmtId);
        this.__studyLoaded.purgeDependencyOnElmtId(rmElmtId);
        this.__productsLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__activitiesLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__carpoolsLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__confessionLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__studyLoading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__products.aboutToBeDeleted();
        this.__activities.aboutToBeDeleted();
        this.__carpools.aboutToBeDeleted();
        this.__confessionPosts.aboutToBeDeleted();
        this.__studyShares.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        this.__productsLoaded.aboutToBeDeleted();
        this.__activitiesLoaded.aboutToBeDeleted();
        this.__carpoolsLoaded.aboutToBeDeleted();
        this.__confessionLoaded.aboutToBeDeleted();
        this.__studyLoaded.aboutToBeDeleted();
        this.__productsLoading.aboutToBeDeleted();
        this.__activitiesLoading.aboutToBeDeleted();
        this.__carpoolsLoading.aboutToBeDeleted();
        this.__confessionLoading.aboutToBeDeleted();
        this.__studyLoading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __products: ObservedPropertyObjectPU<Product[]>;
    get products() {
        return this.__products.get();
    }
    set products(newValue: Product[]) {
        this.__products.set(newValue);
    }
    private __activities: ObservedPropertyObjectPU<ClubActivityItem[]>;
    get activities() {
        return this.__activities.get();
    }
    set activities(newValue: ClubActivityItem[]) {
        this.__activities.set(newValue);
    }
    private __carpools: ObservedPropertyObjectPU<CarpoolOrder[]>;
    get carpools() {
        return this.__carpools.get();
    }
    set carpools(newValue: CarpoolOrder[]) {
        this.__carpools.set(newValue);
    }
    private __confessionPosts: ObservedPropertyObjectPU<ConfessionPost[]>;
    get confessionPosts() {
        return this.__confessionPosts.get();
    }
    set confessionPosts(newValue: ConfessionPost[]) {
        this.__confessionPosts.set(newValue);
    }
    private __studyShares: ObservedPropertyObjectPU<StudyShareItem[]>;
    get studyShares() {
        return this.__studyShares.get();
    }
    set studyShares(newValue: StudyShareItem[]) {
        this.__studyShares.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    private __productsLoaded: ObservedPropertySimplePU<boolean>;
    get productsLoaded() {
        return this.__productsLoaded.get();
    }
    set productsLoaded(newValue: boolean) {
        this.__productsLoaded.set(newValue);
    }
    private __activitiesLoaded: ObservedPropertySimplePU<boolean>;
    get activitiesLoaded() {
        return this.__activitiesLoaded.get();
    }
    set activitiesLoaded(newValue: boolean) {
        this.__activitiesLoaded.set(newValue);
    }
    private __carpoolsLoaded: ObservedPropertySimplePU<boolean>;
    get carpoolsLoaded() {
        return this.__carpoolsLoaded.get();
    }
    set carpoolsLoaded(newValue: boolean) {
        this.__carpoolsLoaded.set(newValue);
    }
    private __confessionLoaded: ObservedPropertySimplePU<boolean>;
    get confessionLoaded() {
        return this.__confessionLoaded.get();
    }
    set confessionLoaded(newValue: boolean) {
        this.__confessionLoaded.set(newValue);
    }
    private __studyLoaded: ObservedPropertySimplePU<boolean>;
    get studyLoaded() {
        return this.__studyLoaded.get();
    }
    set studyLoaded(newValue: boolean) {
        this.__studyLoaded.set(newValue);
    }
    private __productsLoading: ObservedPropertySimplePU<boolean>;
    get productsLoading() {
        return this.__productsLoading.get();
    }
    set productsLoading(newValue: boolean) {
        this.__productsLoading.set(newValue);
    }
    private __activitiesLoading: ObservedPropertySimplePU<boolean>;
    get activitiesLoading() {
        return this.__activitiesLoading.get();
    }
    set activitiesLoading(newValue: boolean) {
        this.__activitiesLoading.set(newValue);
    }
    private __carpoolsLoading: ObservedPropertySimplePU<boolean>;
    get carpoolsLoading() {
        return this.__carpoolsLoading.get();
    }
    set carpoolsLoading(newValue: boolean) {
        this.__carpoolsLoading.set(newValue);
    }
    private __confessionLoading: ObservedPropertySimplePU<boolean>;
    get confessionLoading() {
        return this.__confessionLoading.get();
    }
    set confessionLoading(newValue: boolean) {
        this.__confessionLoading.set(newValue);
    }
    private __studyLoading: ObservedPropertySimplePU<boolean>;
    get studyLoading() {
        return this.__studyLoading.get();
    }
    set studyLoading(newValue: boolean) {
        this.__studyLoading.set(newValue);
    }
    aboutToAppear(): void {
        const store: AppStore = AppStore.getInstance();
        this.isLoggedIn = store.isLoggedIn;
        if (this.isLoggedIn) {
            this.loadTabData(0);
        }
        else {
            this.productsLoading = false;
        }
    }
    private async loadTabData(tabIndex: number): Promise<void> {
        if (tabIndex === 0 && !this.productsLoaded) {
            this.productsLoading = true;
            const result: ApiResult = await ApiService.getMyProducts();
            if (result.code === 200 && result.data !== undefined) {
                this.products = ApiService.parseProductList(result.data);
            }
            this.productsLoaded = true;
            this.productsLoading = false;
        }
        else if (tabIndex === 1 && !this.activitiesLoaded) {
            this.activitiesLoading = true;
            const result: ApiResult = await ApiService.getMyPublishedClubActivities();
            if (result.code === 200 && result.data !== undefined) {
                this.activities = ApiService.parseClubActivityList(result.data);
            }
            this.activitiesLoaded = true;
            this.activitiesLoading = false;
        }
        else if (tabIndex === 2 && !this.carpoolsLoaded) {
            this.carpoolsLoading = true;
            const result: ApiResult = await ApiService.getMyCarpoolOrders();
            if (result.code === 200 && result.data !== undefined) {
                this.carpools = ApiService.parseCarpoolOrders(result.data);
            }
            this.carpoolsLoaded = true;
            this.carpoolsLoading = false;
        }
        else if (tabIndex === 3 && !this.confessionLoaded) {
            this.confessionLoading = true;
            const result: ApiResult = await ApiService.getMyConfessionPosts();
            if (result.code === 200 && result.data !== undefined) {
                this.confessionPosts = ApiService.parseConfessionPostList(result.data);
            }
            this.confessionLoaded = true;
            this.confessionLoading = false;
        }
        else if (tabIndex === 4 && !this.studyLoaded) {
            this.studyLoading = true;
            const result: ApiResult = await ApiService.getMyStudyShares();
            if (result.code === 200 && result.data !== undefined) {
                this.studyShares = ApiService.parseStudyShareList(result.data);
            }
            this.studyLoaded = true;
            this.studyLoading = false;
        }
    }
    private confirmDeleteConfession(postId: number): void {
        AlertDialog.show({
            message: '确定删除这条帖子吗？',
            primaryButton: { value: '取消', action: () => { } },
            secondaryButton: { value: '删除', action: () => { this.doDeleteConfession(postId); } }
        });
    }
    private async doDeleteConfession(postId: number): Promise<void> {
        const result: ApiResult = await ApiService.deleteConfession(postId);
        if (result.code === 200) {
            this.confessionPosts = this.confessionPosts.filter((p: ConfessionPost) => p.id !== postId);
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    private confirmDeleteActivity(activityId: number): void {
        AlertDialog.show({
            message: '确定删除这个活动吗？',
            primaryButton: { value: '取消', action: () => { } },
            secondaryButton: { value: '删除', action: () => { this.doDeleteActivity(activityId); } }
        });
    }
    private async doDeleteActivity(activityId: number): Promise<void> {
        const result: ApiResult = await ApiService.deleteClubActivity(activityId);
        if (result.code === 200) {
            this.activities = this.activities.filter((a: ClubActivityItem) => a.id !== activityId);
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    private confirmDeleteCarpool(orderId: number): void {
        AlertDialog.show({
            message: '确定删除这条拼车信息吗？',
            primaryButton: { value: '取消', action: () => { } },
            secondaryButton: { value: '删除', action: () => { this.doDeleteCarpool(orderId); } }
        });
    }
    private async doDeleteCarpool(orderId: number): Promise<void> {
        const result: ApiResult = await ApiService.deleteCarpool(orderId);
        if (result.code === 200) {
            this.carpools = this.carpools.filter((c: CarpoolOrder) => c.id !== orderId);
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    private confirmDeleteStudyShare(shareId: number): void {
        AlertDialog.show({
            message: '确定删除这份资料吗？',
            primaryButton: { value: '取消', action: () => { } },
            secondaryButton: { value: '删除', action: () => { this.doDeleteStudyShare(shareId); } }
        });
    }
    private async doDeleteStudyShare(shareId: number): Promise<void> {
        const result: ApiResult = await ApiService.deleteStudyShare(shareId);
        if (result.code === 200) {
            this.studyShares = this.studyShares.filter((s: StudyShareItem) => s.id !== shareId);
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    private async changeStatus(product: Product, status: number): Promise<void> {
        const result: ApiResult = await ApiService.updateProductStatus(product.id, status);
        if (result.code === 200) {
            product.status = status;
            this.products = this.products.slice();
            this.getUIContext().getPromptAction().showToast({ message: status === 1 ? '已上架' : '已下架', duration: 1500 });
        }
        else {
            AlertDialog.show({
                message: result.msg || '操作失败',
                confirm: { value: '好的', action: () => { } }
            });
        }
    }
    private async deleteProduct(product: Product): Promise<void> {
        const result: ApiResult = await ApiService.deleteProduct(product.id);
        if (result.code === 200) {
            const idx: number = this.products.findIndex((p: Product) => p.id === product.id);
            if (idx >= 0) {
                this.products.splice(idx, 1);
                this.products = this.products.slice();
            }
            this.getUIContext().getPromptAction().showToast({ message: '已删除', duration: 1500 });
        }
        else {
            AlertDialog.show({
                message: result.msg || '删除失败',
                confirm: { value: '好的', action: () => { } }
            });
        }
    }
    private onTabChange(index: number): void {
        this.loadTabData(index);
    }
    productListBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.productsLoading && !this.productsLoaded) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(629:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(630:9)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.products.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(633:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83D\uDCE6');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(634:9)", "entry");
                        Text.fontSize(64);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('还没有发布商品');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(636:9)", "entry");
                        Text.fontSize(17);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Medium);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('去发布闲置物品赚取零花钱');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(641:9)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 6 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去发布');
                        Button.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(645:9)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 28 });
                        Button.onClick(() => {
                            router.pushUrl({ url: 'pages/PublishPage' });
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(658:7)", "entry");
                        Scroll.width('100%');
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(659:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(660:11)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16, bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`共 ${this.products.length} 件发布`);
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(661:13)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textSecondary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(664:13)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.productsLoading) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    LoadingProgress.create();
                                    LoadingProgress.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(666:15)", "entry");
                                    LoadingProgress.color(Theme.secondary);
                                    LoadingProgress.width(14);
                                    LoadingProgress.height(14);
                                }, LoadingProgress);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(675:11)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 12, right: 12, bottom: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    if (isInitialRender) {
                                        let componentCall = new MyProductCard(this, {
                                            item: item,
                                            onTap: () => {
                                                router.pushUrl({ url: 'pages/ProductDetailPage', params: { 'productId': item.id } as Record<string, Object> });
                                            },
                                            onStatusChange: (status: number) => this.changeStatus(item, status),
                                            onDelete: () => this.deleteProduct(item)
                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyPublishPage.ets", line: 677, col: 15 });
                                        ViewPU.create(componentCall);
                                        let paramsLambda = () => {
                                            return {
                                                item: item,
                                                onTap: () => {
                                                    router.pushUrl({ url: 'pages/ProductDetailPage', params: { 'productId': item.id } as Record<string, Object> });
                                                },
                                                onStatusChange: (status: number) => this.changeStatus(item, status),
                                                onDelete: () => this.deleteProduct(item)
                                            };
                                        };
                                        componentCall.paramsGenerator_ = paramsLambda;
                                    }
                                    else {
                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                    }
                                }, { name: "MyProductCard" });
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.products, forEachItemGenFunction, (item: Product) => item.id.toString(), false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
    }
    activityListBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.activitiesLoading && !this.activitiesLoaded) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(703:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(704:9)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.activities.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(707:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83C\uDF89');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(708:9)", "entry");
                        Text.fontSize(64);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('还没有发布活动');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(710:9)", "entry");
                        Text.fontSize(17);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Medium);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(720:7)", "entry");
                        Scroll.width('100%');
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(721:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.padding({ left: 12, right: 12, top: 8, bottom: 20 });
                        Column.justifyContent(FlexAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    if (isInitialRender) {
                                        let componentCall = new MyActivityCard(this, {
                                            item: item,
                                            onTap: () => {
                                                router.pushUrl({ url: 'pages/ClubActivityDetailPage', params: { 'id': item.id } as Record<string, Object> });
                                            },
                                            onDelete: () => { this.confirmDeleteActivity(item.id); }
                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyPublishPage.ets", line: 723, col: 13 });
                                        ViewPU.create(componentCall);
                                        let paramsLambda = () => {
                                            return {
                                                item: item,
                                                onTap: () => {
                                                    router.pushUrl({ url: 'pages/ClubActivityDetailPage', params: { 'id': item.id } as Record<string, Object> });
                                                },
                                                onDelete: () => { this.confirmDeleteActivity(item.id); }
                                            };
                                        };
                                        componentCall.paramsGenerator_ = paramsLambda;
                                    }
                                    else {
                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                    }
                                }, { name: "MyActivityCard" });
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.activities, forEachItemGenFunction, (item: ClubActivityItem) => `${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
    }
    carpoolListBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.carpoolsLoading && !this.carpoolsLoaded) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(746:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(747:9)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.carpools.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(750:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83D\uDE97');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(751:9)", "entry");
                        Text.fontSize(64);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('还没有发布拼车');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(753:9)", "entry");
                        Text.fontSize(17);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Medium);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(763:7)", "entry");
                        Scroll.width('100%');
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(764:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.padding({ left: 12, right: 12, top: 8, bottom: 20 });
                        Column.justifyContent(FlexAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    if (isInitialRender) {
                                        let componentCall = new MyCarpoolCard(this, {
                                            item: item,
                                            onTap: () => {
                                                router.pushUrl({ url: 'pages/CarpoolDetailPage', params: { 'id': `${item.id}` } as Record<string, string> });
                                            },
                                            onDelete: () => { this.confirmDeleteCarpool(item.id); }
                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyPublishPage.ets", line: 766, col: 13 });
                                        ViewPU.create(componentCall);
                                        let paramsLambda = () => {
                                            return {
                                                item: item,
                                                onTap: () => {
                                                    router.pushUrl({ url: 'pages/CarpoolDetailPage', params: { 'id': `${item.id}` } as Record<string, string> });
                                                },
                                                onDelete: () => { this.confirmDeleteCarpool(item.id); }
                                            };
                                        };
                                        componentCall.paramsGenerator_ = paramsLambda;
                                    }
                                    else {
                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                    }
                                }, { name: "MyCarpoolCard" });
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.carpools, forEachItemGenFunction, (item: CarpoolOrder) => `${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
    }
    confessionListBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.confessionLoading && !this.confessionLoaded) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(789:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(790:9)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.confessionPosts.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(793:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83D\uDC95');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(794:9)", "entry");
                        Text.fontSize(64);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('还没有发布表白墙');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(796:9)", "entry");
                        Text.fontSize(17);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Medium);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(806:7)", "entry");
                        Scroll.width('100%');
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(807:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.padding({ left: 12, right: 12, top: 8, bottom: 20 });
                        Column.justifyContent(FlexAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    if (isInitialRender) {
                                        let componentCall = new MyConfessionCard(this, {
                                            item: item,
                                            onDelete: () => { this.confirmDeleteConfession(item.id); }
                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyPublishPage.ets", line: 809, col: 13 });
                                        ViewPU.create(componentCall);
                                        let paramsLambda = () => {
                                            return {
                                                item: item,
                                                onDelete: () => { this.confirmDeleteConfession(item.id); }
                                            };
                                        };
                                        componentCall.paramsGenerator_ = paramsLambda;
                                    }
                                    else {
                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                    }
                                }, { name: "MyConfessionCard" });
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.confessionPosts, forEachItemGenFunction, (item: ConfessionPost) => `${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
    }
    studyShareListBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.studyLoading && !this.studyLoaded) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(829:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(830:9)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.studyShares.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(833:7)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83D\uDCC4');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(834:9)", "entry");
                        Text.fontSize(64);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('还没有发布资料');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(836:9)", "entry");
                        Text.fontSize(17);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Medium);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(846:7)", "entry");
                        Scroll.width('100%');
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(847:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.padding({ left: 12, right: 12, top: 8, bottom: 20 });
                        Column.justifyContent(FlexAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    if (isInitialRender) {
                                        let componentCall = new MyStudyShareCard(this, {
                                            item: item,
                                            onTap: () => {
                                                router.pushUrl({ url: 'pages/StudyShareDetailPage', params: { 'id': item.id } as Record<string, Object> });
                                            },
                                            onDelete: () => { this.confirmDeleteStudyShare(item.id); }
                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyPublishPage.ets", line: 849, col: 13 });
                                        ViewPU.create(componentCall);
                                        let paramsLambda = () => {
                                            return {
                                                item: item,
                                                onTap: () => {
                                                    router.pushUrl({ url: 'pages/StudyShareDetailPage', params: { 'id': item.id } as Record<string, Object> });
                                                },
                                                onDelete: () => { this.confirmDeleteStudyShare(item.id); }
                                            };
                                        };
                                        componentCall.paramsGenerator_ = paramsLambda;
                                    }
                                    else {
                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                    }
                                }, { name: "MyStudyShareCard" });
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.studyShares, forEachItemGenFunction, (item: StudyShareItem) => `${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(870:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '我的发布' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyPublishPage.ets", line: 871, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '我的发布'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '我的发布'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(874:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('\uD83D\uDD12');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(875:11)", "entry");
                        Text.fontSize(56);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录查看发布');
                        Text.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(877:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(881:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 24 });
                        Button.onClick(() => {
                            router.pushUrl({ url: 'pages/LoginPage' });
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.productsLoading && !this.productsLoaded) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(894:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(895:11)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Tabs.create({ barPosition: BarPosition.Start });
                        Tabs.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(903:9)", "entry");
                        Tabs.scrollable(true);
                        Tabs.barMode(BarMode.Scrollable);
                        Tabs.width('100%');
                        Tabs.layoutWeight(1);
                        Tabs.onChange((index: number) => {
                            this.onTabChange(index);
                        });
                    }, Tabs);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TabContent.create(() => {
                            this.productListBuilder.bind(this)();
                        });
                        TabContent.tabBar('商品');
                        TabContent.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(904:11)", "entry");
                    }, TabContent);
                    TabContent.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TabContent.create(() => {
                            this.activityListBuilder.bind(this)();
                        });
                        TabContent.tabBar('活动');
                        TabContent.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(909:11)", "entry");
                    }, TabContent);
                    TabContent.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TabContent.create(() => {
                            this.carpoolListBuilder.bind(this)();
                        });
                        TabContent.tabBar('拼车');
                        TabContent.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(914:11)", "entry");
                    }, TabContent);
                    TabContent.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TabContent.create(() => {
                            this.confessionListBuilder.bind(this)();
                        });
                        TabContent.tabBar('表白墙');
                        TabContent.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(919:11)", "entry");
                    }, TabContent);
                    TabContent.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TabContent.create(() => {
                            this.studyShareListBuilder.bind(this)();
                        });
                        TabContent.tabBar('资料');
                        TabContent.debugLine("entry/src/main/ets/pages/MyPublishPage.ets(924:11)", "entry");
                    }, TabContent);
                    TabContent.pop();
                    Tabs.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "MyPublishPage";
    }
}
registerNamedRoute(() => new MyPublishPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/MyPublishPage", pageFullPath: "entry/src/main/ets/pages/MyPublishPage", integratedHsp: "false", moduleType: "followWithHap" });
