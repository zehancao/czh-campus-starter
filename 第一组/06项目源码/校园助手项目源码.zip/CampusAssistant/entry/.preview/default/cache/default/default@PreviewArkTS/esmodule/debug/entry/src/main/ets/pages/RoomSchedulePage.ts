if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface RoomSchedulePage_Params {
    classroom?: string;
    selectedDayOfWeek?: number;
    schedules?: CourseSchedule[];
    isLoading?: boolean;
    errorMessage?: string;
}
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { CourseSchedule } from '../model/Models';
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const ROOM_DAY_LABELS: string[] = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
class RoomSchedulePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__classroom = new ObservedPropertySimplePU('', this, "classroom");
        this.__selectedDayOfWeek = new ObservedPropertySimplePU(1, this, "selectedDayOfWeek");
        this.__schedules = new ObservedPropertyObjectPU([], this, "schedules");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__errorMessage = new ObservedPropertySimplePU('', this, "errorMessage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: RoomSchedulePage_Params) {
        if (params.classroom !== undefined) {
            this.classroom = params.classroom;
        }
        if (params.selectedDayOfWeek !== undefined) {
            this.selectedDayOfWeek = params.selectedDayOfWeek;
        }
        if (params.schedules !== undefined) {
            this.schedules = params.schedules;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.errorMessage !== undefined) {
            this.errorMessage = params.errorMessage;
        }
    }
    updateStateVars(params: RoomSchedulePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__classroom.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDayOfWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__schedules.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMessage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__classroom.aboutToBeDeleted();
        this.__selectedDayOfWeek.aboutToBeDeleted();
        this.__schedules.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__errorMessage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __classroom: ObservedPropertySimplePU<string>;
    get classroom() {
        return this.__classroom.get();
    }
    set classroom(newValue: string) {
        this.__classroom.set(newValue);
    }
    private __selectedDayOfWeek: ObservedPropertySimplePU<number>;
    get selectedDayOfWeek() {
        return this.__selectedDayOfWeek.get();
    }
    set selectedDayOfWeek(newValue: number) {
        this.__selectedDayOfWeek.set(newValue);
    }
    private __schedules: ObservedPropertyObjectPU<CourseSchedule[]>;
    get schedules() {
        return this.__schedules.get();
    }
    set schedules(newValue: CourseSchedule[]) {
        this.__schedules.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __errorMessage: ObservedPropertySimplePU<string>;
    get errorMessage() {
        return this.__errorMessage.get();
    }
    set errorMessage(newValue: string) {
        this.__errorMessage.set(newValue);
    }
    aboutToAppear(): void {
        this.readParams();
        this.loadSchedule();
    }
    private readParams(): void {
        const paramsObj: Object | undefined = this.getUIContext().getRouter().getParams();
        if (paramsObj === undefined || paramsObj === null) {
            return;
        }
        const params: Record<string, Object> = paramsObj as Record<string, Object>;
        const classroomObj: Object = params['classroom'];
        if (classroomObj !== null && classroomObj !== undefined) {
            this.classroom = classroomObj as string;
        }
        const dayObj: Object = params['dayOfWeek'];
        if (dayObj !== null && dayObj !== undefined) {
            if (typeof dayObj === 'number') {
                const dayNum: number = dayObj as number;
                if (dayNum >= 1 && dayNum <= 7) {
                    this.selectedDayOfWeek = dayNum;
                }
            }
            else {
                const parsed: number = parseInt(dayObj as string);
                if (parsed >= 1 && parsed <= 7) {
                    this.selectedDayOfWeek = parsed;
                }
            }
        }
    }
    private async loadSchedule(): Promise<void> {
        if (this.classroom.length === 0) {
            this.errorMessage = '教室参数错误';
            return;
        }
        this.isLoading = true;
        this.errorMessage = '';
        this.schedules = [];
        try {
            const list: CourseSchedule[] = await ApiService.getRoomSchedule(this.classroom, this.selectedDayOfWeek);
            this.schedules = this.sortSchedules(list);
        }
        catch (_err) {
            this.schedules = [];
            this.errorMessage = '课表加载失败，请检查网络或后端服务';
        }
        finally {
            this.isLoading = false;
        }
    }
    private sortSchedules(list: CourseSchedule[]): CourseSchedule[] {
        const copied: CourseSchedule[] = [];
        for (let i = 0; i < list.length; i++) {
            copied.push(list[i]);
        }
        copied.sort((a: CourseSchedule, b: CourseSchedule) => {
            return a.startSection - b.startSection;
        });
        return copied;
    }
    private dayText(): string {
        return ROOM_DAY_LABELS[this.selectedDayOfWeek - 1];
    }
    private sectionRangeText(item: CourseSchedule): string {
        return `第${item.startSection}-${item.endSection}节`;
    }
    private timeRangeText(item: CourseSchedule): string {
        const startIndex: number = item.startSection - 1;
        const endIndex: number = item.endSection - 1;
        if (startIndex >= 0 && endIndex >= 0 && startIndex < Constants.SECTION_TIMES.length && endIndex < Constants.SECTION_TIMES.length) {
            return `${Constants.SECTION_TIMES[startIndex][0]}-${Constants.SECTION_TIMES[endIndex][1]}`;
        }
        return '';
    }
    private weekText(item: CourseSchedule): string {
        let text: string = `第${item.startWeek}-${item.endWeek}周`;
        if (item.weekParity === 'odd') {
            text += ' 单周';
        }
        if (item.weekParity === 'even') {
            text += ' 双周';
        }
        return text;
    }
    private teacherText(item: CourseSchedule): string {
        return item.teacherName.length > 0 ? item.teacherName : '教师未录入';
    }
    private showDayPicker(): void {
        let currentIdx: number = this.selectedDayOfWeek - 1;
        TextPickerDialog.show({
            range: ROOM_DAY_LABELS,
            selected: currentIdx,
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < ROOM_DAY_LABELS.length) {
                    this.selectedDayOfWeek = idx + 1;
                    this.loadSchedule();
                }
            }
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(127:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    // Keep custom header - has special elements (classroom title + day picker)
                    NavHeader(this, {
                        title: this.classroom.length > 0 ? this.classroom : '教室课表',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.dayText());
                                Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(130:9)", "entry");
                                Text.fontSize(14);
                                Text.fontWeight(FontWeight.Medium);
                                Text.fontColor(Theme.primary);
                                Text.padding({ left: 14, right: 14, top: 7, bottom: 7 });
                                Text.backgroundColor(Theme.primaryLight);
                                Text.borderRadius(Theme.radiusPill);
                                Text.onClick(() => { this.showDayPicker(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RoomSchedulePage.ets", line: 129, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: this.classroom.length > 0 ? this.classroom : '教室课表',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.dayText());
                                    Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(130:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontWeight(FontWeight.Medium);
                                    Text.fontColor(Theme.primary);
                                    Text.padding({ left: 14, right: 14, top: 7, bottom: 7 });
                                    Text.backgroundColor(Theme.primaryLight);
                                    Text.borderRadius(Theme.radiusPill);
                                    Text.onClick(() => { this.showDayPicker(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: this.classroom.length > 0 ? this.classroom : '教室课表'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(137:7)", "entry");
            Column.padding({ left: 18, right: 18, top: 16, bottom: 16 });
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.margin({ left: 16, right: 16, top: 4 });
            Column.shadow(ShadowStyle.nmRaised);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(138:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.dayText());
            Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(139:11)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(143:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`共 ${this.schedules.length} 节课`);
            Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(144:11)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('点击右上角星期可切换查看其它日期');
            Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(150:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
            Text.margin({ top: 6 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.errorMessage.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMessage);
                        Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(163:9)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.danger);
                        Text.width('100%');
                        Text.padding({ left: 16, right: 16, top: 10 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading && this.schedules.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(171:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(172:11)", "entry");
                        LoadingProgress.width(32);
                        LoadingProgress.height(32);
                        LoadingProgress.color(Theme.primary);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在加载教室课表');
                        Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(176:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.schedules.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(185:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('这一天没有课程安排');
                        Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(186:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('该教室当天可以灵活使用');
                        Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(189:11)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(198:9)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16, top: 14, bottom: 20 });
                        List.scrollBar(BarState.Off);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(200:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.CourseCard.bind(this)(item);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.schedules, forEachItemGenFunction, (item: CourseSchedule, index: number) => `${index}-${item.courseName}-${item.startSection}`, true, true);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    CourseCard(item: CourseSchedule, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(218:5)", "entry");
            Row.width('100%');
            Row.padding({ left: 16, right: 16, top: 14, bottom: 14 });
            Row.backgroundColor(Theme.bgCard);
            Row.borderRadius(20);
            Row.shadow(ShadowStyle.nmRaised);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(219:7)", "entry");
            Column.width(82);
            Column.padding({ left: 10, right: 8, top: 9, bottom: 9 });
            Column.backgroundColor(Theme.primaryLight);
            Column.borderRadius(16);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.sectionRangeText(item));
            Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(220:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.primary);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.timeRangeText(item));
            Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(224:9)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 5 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(235:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.courseName.length > 0 ? item.courseName : '课程名称未录入');
            Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(236:9)", "entry");
            Text.fontSize(17);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(244:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.teacherText(item));
            Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(245:11)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.weekText(item));
            Text.debugLine("entry/src/main/ets/pages/RoomSchedulePage.ets(248:11)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ left: 12 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "RoomSchedulePage";
    }
}
registerNamedRoute(() => new RoomSchedulePage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/RoomSchedulePage", pageFullPath: "entry/src/main/ets/pages/RoomSchedulePage", integratedHsp: "false", moduleType: "followWithHap" });
