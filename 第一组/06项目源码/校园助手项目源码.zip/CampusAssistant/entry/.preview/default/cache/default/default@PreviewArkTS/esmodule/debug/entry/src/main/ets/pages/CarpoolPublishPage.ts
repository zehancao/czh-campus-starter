if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CarpoolPublishPage_Params {
    departure?: string;
    destination?: string;
    departureDate?: string;
    departureHour?: string;
    departureMinute?: string;
    maxPassengers?: string;
    contactPhone?: string;
    remark?: string;
    isSubmitting?: boolean;
    hours?: string[];
    minutes?: string[];
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
class CarpoolPublishPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__departure = new ObservedPropertySimplePU('', this, "departure");
        this.__destination = new ObservedPropertySimplePU('', this, "destination");
        this.__departureDate = new ObservedPropertySimplePU('', this, "departureDate");
        this.__departureHour = new ObservedPropertySimplePU('08', this, "departureHour");
        this.__departureMinute = new ObservedPropertySimplePU('00', this, "departureMinute");
        this.__maxPassengers = new ObservedPropertySimplePU('4', this, "maxPassengers");
        this.__contactPhone = new ObservedPropertySimplePU('', this, "contactPhone");
        this.__remark = new ObservedPropertySimplePU('', this, "remark");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.hours = [];
        this.minutes = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CarpoolPublishPage_Params) {
        if (params.departure !== undefined) {
            this.departure = params.departure;
        }
        if (params.destination !== undefined) {
            this.destination = params.destination;
        }
        if (params.departureDate !== undefined) {
            this.departureDate = params.departureDate;
        }
        if (params.departureHour !== undefined) {
            this.departureHour = params.departureHour;
        }
        if (params.departureMinute !== undefined) {
            this.departureMinute = params.departureMinute;
        }
        if (params.maxPassengers !== undefined) {
            this.maxPassengers = params.maxPassengers;
        }
        if (params.contactPhone !== undefined) {
            this.contactPhone = params.contactPhone;
        }
        if (params.remark !== undefined) {
            this.remark = params.remark;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
        if (params.hours !== undefined) {
            this.hours = params.hours;
        }
        if (params.minutes !== undefined) {
            this.minutes = params.minutes;
        }
    }
    updateStateVars(params: CarpoolPublishPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__departure.purgeDependencyOnElmtId(rmElmtId);
        this.__destination.purgeDependencyOnElmtId(rmElmtId);
        this.__departureDate.purgeDependencyOnElmtId(rmElmtId);
        this.__departureHour.purgeDependencyOnElmtId(rmElmtId);
        this.__departureMinute.purgeDependencyOnElmtId(rmElmtId);
        this.__maxPassengers.purgeDependencyOnElmtId(rmElmtId);
        this.__contactPhone.purgeDependencyOnElmtId(rmElmtId);
        this.__remark.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__departure.aboutToBeDeleted();
        this.__destination.aboutToBeDeleted();
        this.__departureDate.aboutToBeDeleted();
        this.__departureHour.aboutToBeDeleted();
        this.__departureMinute.aboutToBeDeleted();
        this.__maxPassengers.aboutToBeDeleted();
        this.__contactPhone.aboutToBeDeleted();
        this.__remark.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __departure: ObservedPropertySimplePU<string>;
    get departure() {
        return this.__departure.get();
    }
    set departure(newValue: string) {
        this.__departure.set(newValue);
    }
    private __destination: ObservedPropertySimplePU<string>;
    get destination() {
        return this.__destination.get();
    }
    set destination(newValue: string) {
        this.__destination.set(newValue);
    }
    private __departureDate: ObservedPropertySimplePU<string>;
    get departureDate() {
        return this.__departureDate.get();
    }
    set departureDate(newValue: string) {
        this.__departureDate.set(newValue);
    }
    private __departureHour: ObservedPropertySimplePU<string>;
    get departureHour() {
        return this.__departureHour.get();
    }
    set departureHour(newValue: string) {
        this.__departureHour.set(newValue);
    }
    private __departureMinute: ObservedPropertySimplePU<string>;
    get departureMinute() {
        return this.__departureMinute.get();
    }
    set departureMinute(newValue: string) {
        this.__departureMinute.set(newValue);
    }
    private __maxPassengers: ObservedPropertySimplePU<string>;
    get maxPassengers() {
        return this.__maxPassengers.get();
    }
    set maxPassengers(newValue: string) {
        this.__maxPassengers.set(newValue);
    }
    private __contactPhone: ObservedPropertySimplePU<string>;
    get contactPhone() {
        return this.__contactPhone.get();
    }
    set contactPhone(newValue: string) {
        this.__contactPhone.set(newValue);
    }
    private __remark: ObservedPropertySimplePU<string>;
    get remark() {
        return this.__remark.get();
    }
    set remark(newValue: string) {
        this.__remark.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    private hours: string[];
    private minutes: string[];
    aboutToAppear(): void {
        for (let i = 0; i < 24; i++) {
            this.hours.push(i < 10 ? `0${i}` : `${i}`);
        }
        for (let i = 0; i < 60; i += 5) {
            this.minutes.push(i < 10 ? `0${i}` : `${i}`);
        }
    }
    private async doPublish(): Promise<void> {
        if (this.departure.length === 0) {
            this.showToast('请填写出发地');
            return;
        }
        if (this.destination.length === 0) {
            this.showToast('请填写目的地');
            return;
        }
        if (this.departureDate.length === 0) {
            this.showToast('请选择出发日期');
            return;
        }
        if (this.contactPhone.length === 0) {
            this.showToast('请填写联系电话');
            return;
        }
        if (this.contactPhone.length !== 11) {
            this.showToast('联系电话需为11位手机号');
            return;
        }
        this.isSubmitting = true;
        const departureTime: string = `${this.departureDate} ${this.departureHour}:${this.departureMinute}`;
        const maxP: number = parseInt(this.maxPassengers, 10);
        const params: Record<string, Object> = {
            'departure': this.departure,
            'destination': this.destination,
            'departureTime': departureTime,
            'maxPassengers': isNaN(maxP) ? 4 : maxP,
            'contactPhone': this.contactPhone,
            'remark': this.remark,
        };
        const result = await ApiService.publishCarpool(params);
        this.isSubmitting = false;
        if (result.code === 200) {
            this.showToast('发布成功');
            router.back();
        }
        else {
            this.showToast(`发布失败: ${result.msg}`);
        }
    }
    private showToast(msg: string): void {
        const ctx = this.getUIContext();
        ctx.getPromptAction().showToast({ message: msg, duration: 2000 });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(81:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '发布拼车' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CarpoolPublishPage.ets", line: 82, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '发布拼车'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '发布拼车'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(84:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(85:9)", "entry");
            Column.width('100%');
            Column.padding(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(86:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('出发地 *');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(87:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '如：北门', text: this.departure });
            TextInput.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(89:13)", "entry");
            TextInput.fontSize(14);
            TextInput.width('100%');
            TextInput.margin({ top: 4 });
            TextInput.onChange((value: string) => { this.departure = value; });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(95:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('目的地 *');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(96:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '如：火车站', text: this.destination });
            TextInput.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(98:13)", "entry");
            TextInput.fontSize(14);
            TextInput.width('100%');
            TextInput.margin({ top: 4 });
            TextInput.onChange((value: string) => { this.destination = value; });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(104:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('出发日期 *');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(105:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            DatePicker.create();
            DatePicker.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(107:13)", "entry");
            DatePicker.onChange((value: DatePickerResult) => {
                const y: number = value.year ?? 2026;
                const m: number = (value.month ?? 0) + 1;
                const d: number = value.day ?? 1;
                this.departureDate = `${y}-${m < 10 ? '0' + m : m}-${d < 10 ? '0' + d : d}`;
            });
            DatePicker.margin({ top: 4 });
        }, DatePicker);
        DatePicker.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(118:11)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(119:13)", "entry");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('时');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(120:15)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.hours, selected: 8 });
            TextPicker.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(122:15)", "entry");
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                if (typeof value === 'string') {
                    this.departureHour = value;
                }
            });
            TextPicker.height(120);
        }, TextPicker);
        TextPicker.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(132:13)", "entry");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('分');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(133:15)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextPicker.create({ range: this.minutes, selected: 0 });
            TextPicker.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(135:15)", "entry");
            TextPicker.onChange((value: string | string[], index: number | number[]) => {
                if (typeof value === 'string') {
                    this.departureMinute = value;
                }
            });
            TextPicker.height(120);
        }, TextPicker);
        TextPicker.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(147:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('最大乘客数（不含司机）');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(148:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '4', text: this.maxPassengers });
            TextInput.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(150:13)", "entry");
            TextInput.fontSize(14);
            TextInput.type(InputType.Number);
            TextInput.width('100%');
            TextInput.margin({ top: 4 });
            TextInput.onChange((value: string) => { this.maxPassengers = value; });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(156:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('联系电话');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(157:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入11位手机号', text: this.contactPhone });
            TextInput.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(159:13)", "entry");
            TextInput.fontSize(14);
            TextInput.type(InputType.PhoneNumber);
            TextInput.maxLength(11);
            TextInput.width('100%');
            TextInput.margin({ top: 4 });
            TextInput.onChange((value: string) => { this.contactPhone = value; });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(165:11)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('备注');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(166:13)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '如：AA、走高速、可放行李等', text: this.remark });
            TextInput.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(168:13)", "entry");
            TextInput.fontSize(14);
            TextInput.width('100%');
            TextInput.margin({ top: 4 });
            TextInput.onChange((value: string) => { this.remark = value; });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('发布拼车');
            Button.debugLine("entry/src/main/ets/pages/CarpoolPublishPage.ets(174:11)", "entry");
            Button.width('100%');
            Button.height(48);
            Button.type(ButtonType.Normal);
            Button.backgroundColor(Theme.primary);
            Button.fontColor('#FFFFFF');
            Button.borderRadius(Theme.radiusMd);
            Button.fontSize(16);
            Button.enabled(!this.isSubmitting);
            Button.onClick(() => { this.doPublish(); });
        }, Button);
        Button.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "CarpoolPublishPage";
    }
}
registerNamedRoute(() => new CarpoolPublishPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/CarpoolPublishPage", pageFullPath: "entry/src/main/ets/pages/CarpoolPublishPage", integratedHsp: "false", moduleType: "followWithHap" });
