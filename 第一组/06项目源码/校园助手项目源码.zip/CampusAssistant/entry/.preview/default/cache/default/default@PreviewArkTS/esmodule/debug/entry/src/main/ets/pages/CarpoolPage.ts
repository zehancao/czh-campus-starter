if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CarpoolPage_Params {
    orders?: CarpoolOrder[];
    activeTab?: number;
    isLoading?: boolean;
    currentPage?: number;
    hasMore?: boolean;
    isLoadingMore?: boolean;
    showMine?: boolean;
    searchDest?: string;
}
interface CarpoolCard_Params {
    itemData?: CarpoolOrder;
    onTapCallback?: () => void;
    onJoinCallback?: () => void;
    onCancelJoinCallback?: () => void;
    onDeleteCallback?: () => void;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { CarpoolOrder } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
const STATUS_TABS: string[] = ['全部', '招募中', '已满', '已出发'];
const STATUS_VALUES: number[] = [-1, 0, 1, 2];
const STATUS_COLORS: Record<string, string> = {
    '0': Theme.success,
    '1': Theme.warning,
    '2': Theme.primary,
    '3': Theme.textDisabled
};
const STATUS_BG: Record<string, string> = {
    '0': '#DCFCE7',
    '1': '#FEF3C7',
    '2': Theme.primaryLight,
    '3': '#F3F4F6'
};
const STATUS_LABELS: Record<string, string> = {
    '0': '招募中',
    '1': '已满',
    '2': '已出发',
    '3': '已取消'
};
const PAGE_SIZE: number = 20;
class CarpoolCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.itemData = new CarpoolOrder();
        this.onTapCallback = undefined;
        this.onJoinCallback = undefined;
        this.onCancelJoinCallback = undefined;
        this.onDeleteCallback = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CarpoolCard_Params) {
        if (params.itemData !== undefined) {
            this.itemData = params.itemData;
        }
        if (params.onTapCallback !== undefined) {
            this.onTapCallback = params.onTapCallback;
        }
        if (params.onJoinCallback !== undefined) {
            this.onJoinCallback = params.onJoinCallback;
        }
        if (params.onCancelJoinCallback !== undefined) {
            this.onCancelJoinCallback = params.onCancelJoinCallback;
        }
        if (params.onDeleteCallback !== undefined) {
            this.onDeleteCallback = params.onDeleteCallback;
        }
    }
    updateStateVars(params: CarpoolCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private itemData: CarpoolOrder;
    private onTapCallback?: () => void;
    private onJoinCallback?: () => void;
    private onCancelJoinCallback?: () => void;
    private onDeleteCallback?: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(39:5)", "entry");
            Column.width('100%');
            Column.padding(14);
            Column.backgroundColor('#FFFFFF');
            Column.borderRadius(Theme.cardRadius);
            Column.margin({ bottom: 10 });
            Column.shadow(ShadowStyle.sm);
            Column.onClick(() => {
                if (this.onTapCallback !== undefined) {
                    this.onTapCallback();
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(40:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.publisherName);
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(41:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.formatTime(this.itemData.createTime));
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(43:9)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(45:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (AppStore.getInstance().isLoggedIn && AppStore.getInstance().userInfo.id === this.itemData.userId) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('删除');
                        Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(47:11)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ right: 8 });
                        Text.onClick(() => {
                            if (this.onDeleteCallback !== undefined) {
                                this.onDeleteCallback();
                            }
                        });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(STATUS_LABELS[`${this.itemData.status}`] ?? '未知');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(56:9)", "entry");
            Text.fontSize(10);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(STATUS_COLORS[`${this.itemData.status}`] ?? Theme.textTertiary);
            Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
            Text.borderRadius(10);
            Text.backgroundColor(STATUS_BG[`${this.itemData.status}`] ?? '#F3F4F6');
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(65:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(66:9)", "entry");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.departure);
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(67:11)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textPrimary);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('出发');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(69:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(74:9)", "entry");
            Column.justifyContent(FlexAlign.Center);
            Column.width(40);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('→');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(75:11)", "entry");
            Text.fontSize(20);
            Text.fontColor(Theme.primary);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(80:9)", "entry");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemData.destination);
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(81:11)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textPrimary);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('到达');
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(83:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(91:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`🕐 ${this.formatTime(this.itemData.departureTime)}`);
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(92:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textSecondary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`👥 ${this.itemData.currentPassengers}/${this.itemData.maxPassengers}人`);
            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(94:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textSecondary);
            Text.margin({ left: 16 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.itemData.remark.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.itemData.remark);
                        Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(101:9)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.maxLines(2);
                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                        Text.width('100%');
                        Text.margin({ top: 6 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.itemData.status === 0 || this.itemData.status === 1) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(108:9)", "entry");
                        Row.width('100%');
                        Row.justifyContent(FlexAlign.End);
                        Row.margin({ top: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.itemData.joined) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('已加入-退出');
                                    Button.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(110:13)", "entry");
                                    Button.fontSize(12);
                                    Button.height(28);
                                    Button.type(ButtonType.Normal);
                                    Button.backgroundColor('#FEF3C7');
                                    Button.fontColor(Theme.warning);
                                    Button.borderRadius(14);
                                    Button.onClick(() => {
                                        if (this.onCancelJoinCallback !== undefined) {
                                            this.onCancelJoinCallback();
                                        }
                                    });
                                }, Button);
                                Button.pop();
                            });
                        }
                        else if (this.itemData.currentPassengers < this.itemData.maxPassengers) {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('加入拼车');
                                    Button.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(120:13)", "entry");
                                    Button.fontSize(12);
                                    Button.height(28);
                                    Button.type(ButtonType.Normal);
                                    Button.backgroundColor(Theme.primaryLight);
                                    Button.fontColor(Theme.primary);
                                    Button.borderRadius(14);
                                    Button.onClick(() => {
                                        if (this.onJoinCallback !== undefined) {
                                            this.onJoinCallback();
                                        }
                                    });
                                }, Button);
                                Button.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(2, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('已满员');
                                    Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(130:13)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textDisabled);
                                }, Text);
                                Text.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0)
            return '';
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16)
            return t.substring(0, 16);
        return t;
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class CarpoolPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__orders = new ObservedPropertyObjectPU([], this, "orders");
        this.__activeTab = new ObservedPropertySimplePU(0, this, "activeTab");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__currentPage = new ObservedPropertySimplePU(1, this, "currentPage");
        this.__hasMore = new ObservedPropertySimplePU(true, this, "hasMore");
        this.__isLoadingMore = new ObservedPropertySimplePU(false, this, "isLoadingMore");
        this.__showMine = new ObservedPropertySimplePU(false, this, "showMine");
        this.__searchDest = new ObservedPropertySimplePU('', this, "searchDest");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CarpoolPage_Params) {
        if (params.orders !== undefined) {
            this.orders = params.orders;
        }
        if (params.activeTab !== undefined) {
            this.activeTab = params.activeTab;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
        if (params.hasMore !== undefined) {
            this.hasMore = params.hasMore;
        }
        if (params.isLoadingMore !== undefined) {
            this.isLoadingMore = params.isLoadingMore;
        }
        if (params.showMine !== undefined) {
            this.showMine = params.showMine;
        }
        if (params.searchDest !== undefined) {
            this.searchDest = params.searchDest;
        }
    }
    updateStateVars(params: CarpoolPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__orders.purgeDependencyOnElmtId(rmElmtId);
        this.__activeTab.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
        this.__hasMore.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoadingMore.purgeDependencyOnElmtId(rmElmtId);
        this.__showMine.purgeDependencyOnElmtId(rmElmtId);
        this.__searchDest.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__orders.aboutToBeDeleted();
        this.__activeTab.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__currentPage.aboutToBeDeleted();
        this.__hasMore.aboutToBeDeleted();
        this.__isLoadingMore.aboutToBeDeleted();
        this.__showMine.aboutToBeDeleted();
        this.__searchDest.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __orders: ObservedPropertyObjectPU<CarpoolOrder[]>;
    get orders() {
        return this.__orders.get();
    }
    set orders(newValue: CarpoolOrder[]) {
        this.__orders.set(newValue);
    }
    private __activeTab: ObservedPropertySimplePU<number>;
    get activeTab() {
        return this.__activeTab.get();
    }
    set activeTab(newValue: number) {
        this.__activeTab.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __currentPage: ObservedPropertySimplePU<number>;
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: number) {
        this.__currentPage.set(newValue);
    }
    private __hasMore: ObservedPropertySimplePU<boolean>;
    get hasMore() {
        return this.__hasMore.get();
    }
    set hasMore(newValue: boolean) {
        this.__hasMore.set(newValue);
    }
    private __isLoadingMore: ObservedPropertySimplePU<boolean>;
    get isLoadingMore() {
        return this.__isLoadingMore.get();
    }
    set isLoadingMore(newValue: boolean) {
        this.__isLoadingMore.set(newValue);
    }
    private __showMine: ObservedPropertySimplePU<boolean>;
    get showMine() {
        return this.__showMine.get();
    }
    set showMine(newValue: boolean) {
        this.__showMine.set(newValue);
    }
    private __searchDest: ObservedPropertySimplePU<string>;
    get searchDest() {
        return this.__searchDest.get();
    }
    set searchDest(newValue: string) {
        this.__searchDest.set(newValue);
    }
    onPageShow(): void {
        if (this.showMine) {
            this.loadMyOrders();
        }
        else {
            this.refreshList();
        }
    }
    private async refreshList(): Promise<void> {
        this.isLoading = true;
        this.currentPage = 1;
        this.hasMore = true;
        const status: number = STATUS_VALUES[this.activeTab];
        const result = await ApiService.getCarpoolList(this.searchDest, status, 1, PAGE_SIZE);
        if (result.code === 200 && result.data !== undefined) {
            this.orders = ApiService.parseCarpoolOrders(result.data);
            this.hasMore = this.orders.length >= PAGE_SIZE;
        }
        else {
            this.orders = [];
            this.hasMore = false;
        }
        this.isLoading = false;
    }
    private async loadMore(): Promise<void> {
        if (this.isLoadingMore || !this.hasMore)
            return;
        this.isLoadingMore = true;
        this.currentPage = this.currentPage + 1;
        const status: number = STATUS_VALUES[this.activeTab];
        const result = await ApiService.getCarpoolList(this.searchDest, status, this.currentPage, PAGE_SIZE);
        if (result.code === 200 && result.data !== undefined) {
            const newItems: CarpoolOrder[] = ApiService.parseCarpoolOrders(result.data);
            for (let i = 0; i < newItems.length; i++) {
                this.orders.push(newItems[i]);
            }
            this.hasMore = newItems.length >= PAGE_SIZE;
        }
        else {
            this.hasMore = false;
        }
        this.isLoadingMore = false;
    }
    private async loadMyOrders(): Promise<void> {
        this.isLoading = true;
        const result = await ApiService.getMyCarpoolOrders();
        if (result.code === 200 && result.data !== undefined) {
            this.orders = ApiService.parseCarpoolOrders(result.data);
        }
        else {
            this.orders = [];
        }
        this.hasMore = false;
        this.isLoading = false;
    }
    private onTabChange(index: number): void {
        this.activeTab = index;
        this.showMine = false;
        this.refreshList();
    }
    private onToggleMine(): void {
        this.showMine = !this.showMine;
        if (this.showMine) {
            this.loadMyOrders();
        }
        else {
            this.refreshList();
        }
    }
    private doSearch(): void {
        if (this.showMine) {
            this.showMine = false;
        }
        this.refreshList();
    }
    private goToDetail(item: CarpoolOrder): void {
        router.pushUrl({
            url: 'pages/CarpoolDetailPage',
            params: { 'id': `${item.id}` } as Record<string, string>
        });
    }
    private goToPublish(): void {
        router.pushUrl({ url: 'pages/CarpoolPublishPage' });
    }
    private async joinOrder(item: CarpoolOrder): Promise<void> {
        const result = await ApiService.joinCarpool(item.id);
        if (result.code === 200) {
            if (this.showMine) {
                this.loadMyOrders();
            }
            else {
                this.refreshList();
            }
        }
    }
    private async cancelJoinOrder(item: CarpoolOrder): Promise<void> {
        const result = await ApiService.cancelJoinCarpool(item.id);
        if (result.code === 200) {
            if (this.showMine) {
                this.loadMyOrders();
            }
            else {
                this.refreshList();
            }
        }
    }
    private confirmDeleteCarpool(item: CarpoolOrder): void {
        AlertDialog.show({
            message: '确定删除这条拼车信息吗？',
            primaryButton: {
                value: '取消',
                action: () => { }
            },
            secondaryButton: {
                value: '删除',
                action: () => { this.doDeleteCarpool(item.id); }
            }
        });
    }
    private async doDeleteCarpool(orderId: number): Promise<void> {
        const result: ApiResult = await ApiService.deleteCarpool(orderId);
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
            if (this.showMine) {
                this.loadMyOrders();
            }
            else {
                this.refreshList();
            }
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(311:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '拼车',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create({ space: 8 });
                                Row.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(313:9)", "entry");
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.showMine) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('全部');
                                            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(315:13)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.primary);
                                            Text.onClick(() => { this.onToggleMine(); });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('我的');
                                            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(318:13)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textSecondary);
                                            Text.onClick(() => { this.onToggleMine(); });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                            }, If);
                            If.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('发布');
                                Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(321:11)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(Theme.primary);
                                Text.onClick(() => { this.goToPublish(); });
                            }, Text);
                            Text.pop();
                            Row.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CarpoolPage.ets", line: 312, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '拼车',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create({ space: 8 });
                                    Row.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(313:9)", "entry");
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.showMine) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('全部');
                                                Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(315:13)", "entry");
                                                Text.fontSize(13);
                                                Text.fontColor(Theme.primary);
                                                Text.onClick(() => { this.onToggleMine(); });
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('我的');
                                                Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(318:13)", "entry");
                                                Text.fontSize(13);
                                                Text.fontColor(Theme.textSecondary);
                                                Text.onClick(() => { this.onToggleMine(); });
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                }, If);
                                If.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('发布');
                                    Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(321:11)", "entry");
                                    Text.fontSize(13);
                                    Text.fontColor(Theme.primary);
                                    Text.onClick(() => { this.goToPublish(); });
                                }, Text);
                                Text.pop();
                                Row.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '拼车'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.showMine) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(327:9)", "entry");
                        Row.width('100%');
                        Row.backgroundColor('#FFFFFF');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const tab = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(329:13)", "entry");
                                Column.layoutWeight(1);
                                Column.alignItems(HorizontalAlign.Center);
                                Column.padding({ top: 4, bottom: 4 });
                                Column.onClick(() => { this.onTabChange(index); });
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(tab);
                                Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(330:15)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(this.activeTab === index ? Theme.primary : Theme.textSecondary);
                                Text.fontWeight(this.activeTab === index ? FontWeight.Medium : FontWeight.Regular);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Divider.create();
                                Divider.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(334:15)", "entry");
                                Divider.height(2);
                                Divider.width(24);
                                Divider.color(this.activeTab === index ? Theme.primary : 'transparent');
                                Divider.borderRadius(1);
                                Divider.margin({ top: 4 });
                            }, Divider);
                            Column.pop();
                        };
                        this.forEachUpdateFunction(elmtId, STATUS_TABS, forEachItemGenFunction, (tab: string) => tab, true, false);
                    }, ForEach);
                    ForEach.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(347:9)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16, top: 8, bottom: 8 });
                        Row.backgroundColor('#FFFFFF');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '搜索目的地...', text: this.searchDest });
                        TextInput.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(348:11)", "entry");
                        TextInput.fontSize(13);
                        TextInput.layoutWeight(1);
                        TextInput.height(36);
                        TextInput.borderRadius(18);
                        TextInput.backgroundColor('#F3F4F6');
                        TextInput.onChange((value: string) => { this.searchDest = value; });
                        TextInput.onSubmit(() => { this.doSearch(); });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('搜索');
                        Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(353:11)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.primary);
                        Text.margin({ left: 8 });
                        Text.onClick(() => { this.doSearch(); });
                    }, Text);
                    Text.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(360:7)", "entry");
            Divider.height(1);
            Divider.color(Theme.border);
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(363:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(364:11)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 0 });
                        List.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(368:9)", "entry");
                        List.layoutWeight(1);
                        List.edgeEffect(EdgeEffect.Spring);
                        List.padding({ left: 12, right: 12, top: 4, bottom: 20 });
                        List.onReachEnd(() => { this.loadMore(); });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.orders.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        {
                                            const itemCreation = (elmtId, isInitialRender) => {
                                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                ListItem.create(deepRenderFunction, true);
                                                if (!isInitialRender) {
                                                    ListItem.pop();
                                                }
                                                ViewStackProcessor.StopGetAccessRecording();
                                            };
                                            const itemCreation2 = (elmtId, isInitialRender) => {
                                                ListItem.create(deepRenderFunction, true);
                                                ListItem.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(371:15)", "entry");
                                            };
                                            const deepRenderFunction = (elmtId, isInitialRender) => {
                                                itemCreation(elmtId, isInitialRender);
                                                {
                                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                        if (isInitialRender) {
                                                            let componentCall = new CarpoolCard(this, {
                                                                itemData: item,
                                                                onTapCallback: () => this.goToDetail(item),
                                                                onJoinCallback: () => this.joinOrder(item),
                                                                onCancelJoinCallback: () => this.cancelJoinOrder(item),
                                                                onDeleteCallback: () => this.confirmDeleteCarpool(item)
                                                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CarpoolPage.ets", line: 372, col: 17 });
                                                            ViewPU.create(componentCall);
                                                            let paramsLambda = () => {
                                                                return {
                                                                    itemData: item,
                                                                    onTapCallback: () => this.goToDetail(item),
                                                                    onJoinCallback: () => this.joinOrder(item),
                                                                    onCancelJoinCallback: () => this.cancelJoinOrder(item),
                                                                    onDeleteCallback: () => this.confirmDeleteCarpool(item)
                                                                };
                                                            };
                                                            componentCall.paramsGenerator_ = paramsLambda;
                                                        }
                                                        else {
                                                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                                                        }
                                                    }, { name: "CarpoolCard" });
                                                }
                                                ListItem.pop();
                                            };
                                            this.observeComponentCreation2(itemCreation2, ListItem);
                                            ListItem.pop();
                                        }
                                    };
                                    this.forEachUpdateFunction(elmtId, this.orders, forEachItemGenFunction, (item: CarpoolOrder) => `${item.id}`, false, false);
                                }, ForEach);
                                ForEach.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                {
                                    const itemCreation = (elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        ListItem.create(deepRenderFunction, true);
                                        if (!isInitialRender) {
                                            ListItem.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    };
                                    const itemCreation2 = (elmtId, isInitialRender) => {
                                        ListItem.create(deepRenderFunction, true);
                                        ListItem.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(382:13)", "entry");
                                    };
                                    const deepRenderFunction = (elmtId, isInitialRender) => {
                                        itemCreation(elmtId, isInitialRender);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Column.create();
                                            Column.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(383:15)", "entry");
                                            Column.width('100%');
                                            Column.alignItems(HorizontalAlign.Center);
                                            Column.margin({ top: 40 });
                                        }, Column);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('🚗');
                                            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(384:17)", "entry");
                                            Text.fontSize(56);
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('暂无拼车信息');
                                            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(385:17)", "entry");
                                            Text.fontSize(15);
                                            Text.fontColor(Theme.textSecondary);
                                            Text.margin({ top: 8 });
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('点击右上角"发布"发起拼车吧');
                                            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(387:17)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.margin({ top: 4 });
                                        }, Text);
                                        Text.pop();
                                        Column.pop();
                                        ListItem.pop();
                                    };
                                    this.observeComponentCreation2(itemCreation2, ListItem);
                                    ListItem.pop();
                                }
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.hasMore && this.orders.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                {
                                    const itemCreation = (elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        ListItem.create(deepRenderFunction, true);
                                        if (!isInitialRender) {
                                            ListItem.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    };
                                    const itemCreation2 = (elmtId, isInitialRender) => {
                                        ListItem.create(deepRenderFunction, true);
                                        ListItem.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(395:13)", "entry");
                                    };
                                    const deepRenderFunction = (elmtId, isInitialRender) => {
                                        itemCreation(elmtId, isInitialRender);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Row.create();
                                            Row.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(396:15)", "entry");
                                            Row.width('100%');
                                            Row.justifyContent(FlexAlign.Center);
                                            Row.padding({ top: 12, bottom: 12 });
                                        }, Row);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            LoadingProgress.create();
                                            LoadingProgress.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(397:17)", "entry");
                                            LoadingProgress.width(20);
                                            LoadingProgress.height(20);
                                            LoadingProgress.color(Theme.primary);
                                        }, LoadingProgress);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('加载更多...');
                                            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(398:17)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.margin({ left: 8 });
                                        }, Text);
                                        Text.pop();
                                        Row.pop();
                                        ListItem.pop();
                                    };
                                    this.observeComponentCreation2(itemCreation2, ListItem);
                                    ListItem.pop();
                                }
                            });
                        }
                        else if (!this.hasMore && this.orders.length > 0) {
                            this.ifElseBranchUpdateFunction(1, () => {
                                {
                                    const itemCreation = (elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        ListItem.create(deepRenderFunction, true);
                                        if (!isInitialRender) {
                                            ListItem.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    };
                                    const itemCreation2 = (elmtId, isInitialRender) => {
                                        ListItem.create(deepRenderFunction, true);
                                        ListItem.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(403:13)", "entry");
                                    };
                                    const deepRenderFunction = (elmtId, isInitialRender) => {
                                        itemCreation(elmtId, isInitialRender);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('- 没有更多了 -');
                                            Text.debugLine("entry/src/main/ets/pages/CarpoolPage.ets(404:15)", "entry");
                                            Text.fontSize(12);
                                            Text.fontColor(Theme.textDisabled);
                                            Text.width('100%');
                                            Text.textAlign(TextAlign.Center);
                                            Text.padding({ top: 12, bottom: 12 });
                                        }, Text);
                                        Text.pop();
                                        ListItem.pop();
                                    };
                                    this.observeComponentCreation2(itemCreation2, ListItem);
                                    ListItem.pop();
                                }
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(2, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "CarpoolPage";
    }
}
registerNamedRoute(() => new CarpoolPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/CarpoolPage", pageFullPath: "entry/src/main/ets/pages/CarpoolPage", integratedHsp: "false", moduleType: "followWithHap" });
