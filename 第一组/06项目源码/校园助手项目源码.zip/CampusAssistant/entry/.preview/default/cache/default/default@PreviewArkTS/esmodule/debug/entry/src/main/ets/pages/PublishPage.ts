if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PublishPage_Params {
    categories?: ProductCategory[];
    selectedCategoryIndex?: number;
    selectedConditionIndex?: number;
    selectedLocationIndex?: number;
    titleInput?: string;
    descInput?: string;
    priceInput?: string;
    originalPriceInput?: string;
    locationInput?: string;
    imageUrlList?: string[];
    isLoggedIn?: boolean;
    isLoading?: boolean;
    isUploading?: boolean;
    isSubmitting?: boolean;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import type { ProductCategory } from '../model/Models';
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const CONDITION_OPTIONS: string[] = ['全新', '几乎全新', '轻微使用痕迹', '明显使用痕迹', '成色一般'];
const LOCATION_OPTIONS: string[] = ['一食堂', '二食堂', '图书馆', '宿舍区', '教学楼', '操场', '快递站', '校门口'];
class PublishPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__categories = new ObservedPropertyObjectPU([], this, "categories");
        this.__selectedCategoryIndex = new ObservedPropertySimplePU(0, this, "selectedCategoryIndex");
        this.__selectedConditionIndex = new ObservedPropertySimplePU(1, this, "selectedConditionIndex");
        this.__selectedLocationIndex = new ObservedPropertySimplePU(0, this, "selectedLocationIndex");
        this.__titleInput = new ObservedPropertySimplePU('', this, "titleInput");
        this.__descInput = new ObservedPropertySimplePU('', this, "descInput");
        this.__priceInput = new ObservedPropertySimplePU('', this, "priceInput");
        this.__originalPriceInput = new ObservedPropertySimplePU('', this, "originalPriceInput");
        this.__locationInput = new ObservedPropertySimplePU('', this, "locationInput");
        this.__imageUrlList = new ObservedPropertyObjectPU([], this, "imageUrlList");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isUploading = new ObservedPropertySimplePU(false, this, "isUploading");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PublishPage_Params) {
        if (params.categories !== undefined) {
            this.categories = params.categories;
        }
        if (params.selectedCategoryIndex !== undefined) {
            this.selectedCategoryIndex = params.selectedCategoryIndex;
        }
        if (params.selectedConditionIndex !== undefined) {
            this.selectedConditionIndex = params.selectedConditionIndex;
        }
        if (params.selectedLocationIndex !== undefined) {
            this.selectedLocationIndex = params.selectedLocationIndex;
        }
        if (params.titleInput !== undefined) {
            this.titleInput = params.titleInput;
        }
        if (params.descInput !== undefined) {
            this.descInput = params.descInput;
        }
        if (params.priceInput !== undefined) {
            this.priceInput = params.priceInput;
        }
        if (params.originalPriceInput !== undefined) {
            this.originalPriceInput = params.originalPriceInput;
        }
        if (params.locationInput !== undefined) {
            this.locationInput = params.locationInput;
        }
        if (params.imageUrlList !== undefined) {
            this.imageUrlList = params.imageUrlList;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isUploading !== undefined) {
            this.isUploading = params.isUploading;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
    }
    updateStateVars(params: PublishPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__categories.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedCategoryIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedConditionIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedLocationIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__titleInput.purgeDependencyOnElmtId(rmElmtId);
        this.__descInput.purgeDependencyOnElmtId(rmElmtId);
        this.__priceInput.purgeDependencyOnElmtId(rmElmtId);
        this.__originalPriceInput.purgeDependencyOnElmtId(rmElmtId);
        this.__locationInput.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUrlList.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isUploading.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__categories.aboutToBeDeleted();
        this.__selectedCategoryIndex.aboutToBeDeleted();
        this.__selectedConditionIndex.aboutToBeDeleted();
        this.__selectedLocationIndex.aboutToBeDeleted();
        this.__titleInput.aboutToBeDeleted();
        this.__descInput.aboutToBeDeleted();
        this.__priceInput.aboutToBeDeleted();
        this.__originalPriceInput.aboutToBeDeleted();
        this.__locationInput.aboutToBeDeleted();
        this.__imageUrlList.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isUploading.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __categories: ObservedPropertyObjectPU<ProductCategory[]>;
    get categories() {
        return this.__categories.get();
    }
    set categories(newValue: ProductCategory[]) {
        this.__categories.set(newValue);
    }
    private __selectedCategoryIndex: ObservedPropertySimplePU<number>;
    get selectedCategoryIndex() {
        return this.__selectedCategoryIndex.get();
    }
    set selectedCategoryIndex(newValue: number) {
        this.__selectedCategoryIndex.set(newValue);
    }
    private __selectedConditionIndex: ObservedPropertySimplePU<number>;
    get selectedConditionIndex() {
        return this.__selectedConditionIndex.get();
    }
    set selectedConditionIndex(newValue: number) {
        this.__selectedConditionIndex.set(newValue);
    }
    private __selectedLocationIndex: ObservedPropertySimplePU<number>;
    get selectedLocationIndex() {
        return this.__selectedLocationIndex.get();
    }
    set selectedLocationIndex(newValue: number) {
        this.__selectedLocationIndex.set(newValue);
    }
    private __titleInput: ObservedPropertySimplePU<string>;
    get titleInput() {
        return this.__titleInput.get();
    }
    set titleInput(newValue: string) {
        this.__titleInput.set(newValue);
    }
    private __descInput: ObservedPropertySimplePU<string>;
    get descInput() {
        return this.__descInput.get();
    }
    set descInput(newValue: string) {
        this.__descInput.set(newValue);
    }
    private __priceInput: ObservedPropertySimplePU<string>;
    get priceInput() {
        return this.__priceInput.get();
    }
    set priceInput(newValue: string) {
        this.__priceInput.set(newValue);
    }
    private __originalPriceInput: ObservedPropertySimplePU<string>;
    get originalPriceInput() {
        return this.__originalPriceInput.get();
    }
    set originalPriceInput(newValue: string) {
        this.__originalPriceInput.set(newValue);
    }
    private __locationInput: ObservedPropertySimplePU<string>;
    get locationInput() {
        return this.__locationInput.get();
    }
    set locationInput(newValue: string) {
        this.__locationInput.set(newValue);
    }
    private __imageUrlList: ObservedPropertyObjectPU<string[]>;
    get imageUrlList() {
        return this.__imageUrlList.get();
    }
    set imageUrlList(newValue: string[]) {
        this.__imageUrlList.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isUploading: ObservedPropertySimplePU<boolean>;
    get isUploading() {
        return this.__isUploading.get();
    }
    set isUploading(newValue: boolean) {
        this.__isUploading.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    aboutToAppear(): void {
        const store: AppStore = AppStore.getInstance();
        this.isLoggedIn = store.isLoggedIn;
        this.loadCategories();
    }
    private async loadCategories(): Promise<void> {
        const result = await ApiService.getProductCategories();
        if (result.code === 200 && result.data !== undefined) {
            this.categories = ApiService.parseProductCategoryList(result.data);
        }
        this.isLoading = false;
    }
    private parseMoney(text: string): number {
        const value: number = Number(text);
        if (isNaN(value)) {
            return -1;
        }
        return value;
    }
    private currentCategoryId(): number {
        if (this.categories.length === 0) {
            return 0;
        }
        const index: number = Math.max(0, Math.min(this.selectedCategoryIndex, this.categories.length - 1));
        return this.categories[index].id;
    }
    private currentLocation(): string {
        if (this.locationInput.trim().length > 0) {
            return this.locationInput.trim();
        }
        const index: number = Math.max(0, Math.min(this.selectedLocationIndex, LOCATION_OPTIONS.length - 1));
        return LOCATION_OPTIONS[index];
    }
    private canSubmitNow(): boolean {
        return this.titleInput.trim().length > 0 &&
            this.descInput.trim().length > 0 &&
            this.priceInput.trim().length > 0 &&
            this.currentCategoryId() > 0 &&
            !this.isSubmitting &&
            !this.isUploading;
    }
    private async pickImagesFromAlbum(): Promise<void> {
        if (this.imageUrlList.length >= 5) {
            AlertDialog.show({ message: '最多上传 5 张图片', confirm: { value: '知道了', action: () => { } } });
            return;
        }
        if (this.isUploading) {
            return;
        }
        this.isUploading = true;
        try {
            promptAction.showToast({ message: '正在打开相册', duration: 1200 });
            const uris: string[] = await ApiService.pickImages();
            const limit: number = Math.min(uris.length, 5 - this.imageUrlList.length);
            for (let i = 0; i < limit; i++) {
                const url: string = await ApiService.uploadImage(uris[i]);
                if (url.startsWith('ERROR:')) {
                    AlertDialog.show({ message: '图片上传失败，请重试', confirm: { value: '确定', action: () => { } } });
                }
                else {
                    this.imageUrlList.push(url);
                }
            }
        }
        catch (err) {
            AlertDialog.show({
                message: '相册无法打开，请用真机或模拟器运行',
                confirm: { value: '知道了', action: () => { } }
            });
        }
        finally {
            this.isUploading = false;
        }
    }
    private removeImageByIndex(index: number): void {
        const list: string[] = [];
        for (let i = 0; i < this.imageUrlList.length; i++) {
            if (i !== index) {
                list.push(this.imageUrlList[i]);
            }
        }
        this.imageUrlList = list;
    }
    private async submitPublish(): Promise<void> {
        if (!this.isLoggedIn) {
            AlertDialog.show({ message: '请先登录后再发布商品', confirm: { value: '去登录', action: () => { router.pushUrl({ url: 'pages/LoginPage' }); } } });
            return;
        }
        if (!this.canSubmitNow()) {
            AlertDialog.show({ message: '请把分类、标题、价格和描述填写完整', confirm: { value: '好的', action: () => { } } });
            return;
        }
        const price: number = this.parseMoney(this.priceInput.trim());
        const originalPrice: number = this.originalPriceInput.trim().length > 0 ? this.parseMoney(this.originalPriceInput.trim()) : 0;
        if (price <= 0) {
            AlertDialog.show({ message: '售价必须大于 0', confirm: { value: '好的', action: () => { } } });
            return;
        }
        if (originalPrice < 0) {
            AlertDialog.show({ message: '原价格式不正确', confirm: { value: '好的', action: () => { } } });
            return;
        }
        this.isSubmitting = true;
        const params: Record<string, Object> = {
            'categoryId': this.currentCategoryId(),
            'title': this.titleInput.trim(),
            'description': this.descInput.trim(),
            'price': price,
            'originalPrice': originalPrice,
            'conditionLevel': this.selectedConditionIndex + 1,
            'images': this.imageUrlList,
            'campusLocation': this.currentLocation()
        };
        const result = await ApiService.publishProduct(params);
        this.isSubmitting = false;
        if (result.code === 200) {
            promptAction.showToast({ message: '发布成功，等待审核', duration: 1800 });
            router.back();
        }
        else {
            AlertDialog.show({ title: '发布失败', message: result.msg || '请稍后重试', confirm: { value: '好的', action: () => { } } });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(160:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '发布商品',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.isSubmitting ? '提交中' : '发布');
                                Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(162:9)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(this.canSubmitNow() ? Theme.primary : Theme.textTertiary);
                                Text.onClick(() => { this.submitPublish(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/PublishPage.ets", line: 161, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '发布商品',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.isSubmitting ? '提交中' : '发布');
                                    Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(162:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(this.canSubmitNow() ? Theme.primary : Theme.textTertiary);
                                    Text.onClick(() => { this.submitPublish(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '发布商品'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(169:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/PublishPage.ets(170:11)", "entry");
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                        LoadingProgress.color(Theme.primary);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('加载发布信息中');
                        Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(171:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(174:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录');
                        Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(175:11)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('登录后才可以发布二手商品');
                        Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(176:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/PublishPage.ets(177:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.primary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 20 });
                        Button.onClick(() => { router.pushUrl({ url: 'pages/LoginPage' }); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/PublishPage.ets(185:9)", "entry");
                        Scroll.layoutWeight(1);
                        Scroll.backgroundColor(Theme.bgPage);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(186:11)", "entry");
                        Column.width('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(187:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('商品图片');
                        Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(188:15)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.width('100%');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/PublishPage.ets(189:15)", "entry");
                        Scroll.scrollable(ScrollDirection.Horizontal);
                        Scroll.scrollBar(BarState.Off);
                        Scroll.width('100%');
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/PublishPage.ets(190:17)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const url = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Stack.create({ alignContent: Alignment.TopEnd });
                                Stack.debugLine("entry/src/main/ets/pages/PublishPage.ets(192:21)", "entry");
                                Stack.width(82);
                                Stack.height(82);
                                Stack.margin({ right: 10, top: 10 });
                            }, Stack);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Image.create(ApiService.baseUrl + url);
                                Image.debugLine("entry/src/main/ets/pages/PublishPage.ets(193:23)", "entry");
                                Image.width(82);
                                Image.height(82);
                                Image.borderRadius(8);
                                Image.objectFit(ImageFit.Cover);
                            }, Image);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('×');
                                Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(195:23)", "entry");
                                Text.width(22);
                                Text.height(22);
                                Text.borderRadius(11);
                                Text.fontSize(16);
                                Text.fontColor('#FFFFFF');
                                Text.textAlign(TextAlign.Center);
                                Text.backgroundColor('#00000088');
                                Text.onClick(() => { this.removeImageByIndex(index); });
                            }, Text);
                            Text.pop();
                            Stack.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.imageUrlList, forEachItemGenFunction, (url: string) => url, true, false);
                    }, ForEach);
                    ForEach.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithChild();
                        Button.debugLine("entry/src/main/ets/pages/PublishPage.ets(202:19)", "entry");
                        Button.type(ButtonType.Normal);
                        Button.width(82);
                        Button.height(82);
                        Button.borderRadius(8);
                        Button.backgroundColor(Theme.primaryLight);
                        Button.margin({ top: 10 });
                        Button.onClick(() => { this.pickImagesFromAlbum(); });
                    }, Button);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(203:21)", "entry");
                        Column.width(82);
                        Column.height(82);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.isUploading ? '上传中' : '+');
                        Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(204:23)", "entry");
                        Text.fontSize(this.isUploading ? 14 : 28);
                        Text.fontColor(Theme.primary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.imageUrlList.length + '/5');
                        Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(205:23)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 2 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    Button.pop();
                    Row.pop();
                    Scroll.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(219:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                        Column.margin({ top: 8 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('商品分类');
                        Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(220:15)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.width('100%');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Flex.create({ wrap: FlexWrap.Wrap });
                        Flex.debugLine("entry/src/main/ets/pages/PublishPage.ets(221:15)", "entry");
                        Flex.width('100%');
                    }, Flex);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const item = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.name);
                                Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(223:19)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(this.selectedCategoryIndex === index ? '#FFFFFF' : Theme.textPrimary);
                                Text.backgroundColor(this.selectedCategoryIndex === index ? Theme.primary : Theme.bgPage);
                                Text.borderRadius(14);
                                Text.padding({ left: 12, right: 12, top: 6, bottom: 6 });
                                Text.margin({ right: 8, top: 10 });
                                Text.onClick(() => { this.selectedCategoryIndex = index; });
                            }, Text);
                            Text.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.categories, forEachItemGenFunction, (item: ProductCategory) => item.id.toString(), true, false);
                    }, ForEach);
                    ForEach.pop();
                    Flex.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(236:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                        Column.margin({ top: 8 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '商品标题，例如：二手高数教材', text: this.titleInput });
                        TextInput.debugLine("entry/src/main/ets/pages/PublishPage.ets(237:15)", "entry");
                        TextInput.height(46);
                        TextInput.fontSize(15);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(8);
                        TextInput.onChange((value: string) => { this.titleInput = value; });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/PublishPage.ets(240:15)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 10 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '售价', text: this.priceInput });
                        TextInput.debugLine("entry/src/main/ets/pages/PublishPage.ets(241:17)", "entry");
                        TextInput.height(46);
                        TextInput.fontSize(15);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(8);
                        TextInput.layoutWeight(1);
                        TextInput.onChange((value: string) => { this.priceInput = value; });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '原价，可不填', text: this.originalPriceInput });
                        TextInput.debugLine("entry/src/main/ets/pages/PublishPage.ets(244:17)", "entry");
                        TextInput.height(46);
                        TextInput.fontSize(15);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(8);
                        TextInput.layoutWeight(1);
                        TextInput.margin({ left: 10 });
                        TextInput.onChange((value: string) => { this.originalPriceInput = value; });
                    }, TextInput);
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextArea.create({ placeholder: '描述商品状态、购买时间、配件、交易说明等', text: this.descInput });
                        TextArea.debugLine("entry/src/main/ets/pages/PublishPage.ets(248:15)", "entry");
                        TextArea.height(132);
                        TextArea.fontSize(15);
                        TextArea.backgroundColor(Theme.bgInput);
                        TextArea.borderRadius(8);
                        TextArea.margin({ top: 10 });
                        TextArea.onChange((value: string) => { this.descInput = value; });
                    }, TextArea);
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(254:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                        Column.margin({ top: 8 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('成色');
                        Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(255:15)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.width('100%');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Flex.create({ wrap: FlexWrap.Wrap });
                        Flex.debugLine("entry/src/main/ets/pages/PublishPage.ets(256:15)", "entry");
                        Flex.width('100%');
                    }, Flex);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const name = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(name);
                                Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(258:19)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(this.selectedConditionIndex === index ? '#FFFFFF' : Theme.textPrimary);
                                Text.backgroundColor(this.selectedConditionIndex === index ? Theme.success : Theme.bgPage);
                                Text.borderRadius(14);
                                Text.padding({ left: 12, right: 12, top: 6, bottom: 6 });
                                Text.margin({ right: 8, top: 10 });
                                Text.onClick(() => { this.selectedConditionIndex = index; });
                            }, Text);
                            Text.pop();
                        };
                        this.forEachUpdateFunction(elmtId, CONDITION_OPTIONS, forEachItemGenFunction, (name: string) => name, true, false);
                    }, ForEach);
                    ForEach.pop();
                    Flex.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/PublishPage.ets(271:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                        Column.margin({ top: 8, bottom: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('交易地点');
                        Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(272:15)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.width('100%');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Flex.create({ wrap: FlexWrap.Wrap });
                        Flex.debugLine("entry/src/main/ets/pages/PublishPage.ets(273:15)", "entry");
                        Flex.width('100%');
                    }, Flex);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const name = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(name);
                                Text.debugLine("entry/src/main/ets/pages/PublishPage.ets(275:19)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(this.selectedLocationIndex === index && this.locationInput.length === 0 ? '#FFFFFF' : Theme.textPrimary);
                                Text.backgroundColor(this.selectedLocationIndex === index && this.locationInput.length === 0 ? Theme.primary : Theme.bgPage);
                                Text.borderRadius(14);
                                Text.padding({ left: 12, right: 12, top: 6, bottom: 6 });
                                Text.margin({ right: 8, top: 10 });
                                Text.onClick(() => {
                                    this.selectedLocationIndex = index;
                                    this.locationInput = '';
                                });
                            }, Text);
                            Text.pop();
                        };
                        this.forEachUpdateFunction(elmtId, LOCATION_OPTIONS, forEachItemGenFunction, (name: string) => name, true, false);
                    }, ForEach);
                    ForEach.pop();
                    Flex.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '也可以手动输入具体地点', text: this.locationInput });
                        TextInput.debugLine("entry/src/main/ets/pages/PublishPage.ets(288:15)", "entry");
                        TextInput.height(44);
                        TextInput.fontSize(14);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(8);
                        TextInput.margin({ top: 12 });
                        TextInput.onChange((value: string) => { this.locationInput = value; });
                    }, TextInput);
                    Column.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "PublishPage";
    }
}
registerNamedRoute(() => new PublishPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/PublishPage", pageFullPath: "entry/src/main/ets/pages/PublishPage", integratedHsp: "false", moduleType: "followWithHap" });
