if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ClubActivityListPage_Params {
    activities?: ClubActivityItem[];
    selectedClub?: string;
    selectedStatus?: number;
    showMine?: boolean;
    isRefreshing?: boolean;
    isLoading?: boolean;
    errorMessage?: string;
    currentPage?: number;
    hasMore?: boolean;
    isLoadingMore?: boolean;
    clubOptions?: string[];
    clubLabels?: string[];
    statusValues?: number[];
    statusLabels?: string[];
}
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { ClubActivityItem } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
const PAGE_SIZE: number = 20;
class ClubActivityListPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__activities = new ObservedPropertyObjectPU([], this, "activities");
        this.__selectedClub = new ObservedPropertySimplePU('', this, "selectedClub");
        this.__selectedStatus = new ObservedPropertySimplePU(1, this, "selectedStatus");
        this.__showMine = new ObservedPropertySimplePU(false, this, "showMine");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__errorMessage = new ObservedPropertySimplePU('', this, "errorMessage");
        this.__currentPage = new ObservedPropertySimplePU(1, this, "currentPage");
        this.__hasMore = new ObservedPropertySimplePU(true, this, "hasMore");
        this.__isLoadingMore = new ObservedPropertySimplePU(false, this, "isLoadingMore");
        this.clubOptions = ['', '篮球', '排球', '足球', '羽毛球', '乒乓球', '剧本杀', '桌游', '唱歌', '学习', '琴棋书画', '电竞', '户外', '聚餐'];
        this.clubLabels = ['全部', '篮球', '排球', '足球', '羽毛球', '乒乓球', '剧本杀', '桌游', '唱歌', '学习', '琴棋书画', '电竞', '户外', '聚餐'];
        this.statusValues = [0, 1, 2];
        this.statusLabels = ['全部', '报名中', '已满'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ClubActivityListPage_Params) {
        if (params.activities !== undefined) {
            this.activities = params.activities;
        }
        if (params.selectedClub !== undefined) {
            this.selectedClub = params.selectedClub;
        }
        if (params.selectedStatus !== undefined) {
            this.selectedStatus = params.selectedStatus;
        }
        if (params.showMine !== undefined) {
            this.showMine = params.showMine;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.errorMessage !== undefined) {
            this.errorMessage = params.errorMessage;
        }
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
        if (params.hasMore !== undefined) {
            this.hasMore = params.hasMore;
        }
        if (params.isLoadingMore !== undefined) {
            this.isLoadingMore = params.isLoadingMore;
        }
        if (params.clubOptions !== undefined) {
            this.clubOptions = params.clubOptions;
        }
        if (params.clubLabels !== undefined) {
            this.clubLabels = params.clubLabels;
        }
        if (params.statusValues !== undefined) {
            this.statusValues = params.statusValues;
        }
        if (params.statusLabels !== undefined) {
            this.statusLabels = params.statusLabels;
        }
    }
    updateStateVars(params: ClubActivityListPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__activities.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedClub.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedStatus.purgeDependencyOnElmtId(rmElmtId);
        this.__showMine.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMessage.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
        this.__hasMore.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoadingMore.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__activities.aboutToBeDeleted();
        this.__selectedClub.aboutToBeDeleted();
        this.__selectedStatus.aboutToBeDeleted();
        this.__showMine.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__errorMessage.aboutToBeDeleted();
        this.__currentPage.aboutToBeDeleted();
        this.__hasMore.aboutToBeDeleted();
        this.__isLoadingMore.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __activities: ObservedPropertyObjectPU<ClubActivityItem[]>;
    get activities() {
        return this.__activities.get();
    }
    set activities(newValue: ClubActivityItem[]) {
        this.__activities.set(newValue);
    }
    private __selectedClub: ObservedPropertySimplePU<string>;
    get selectedClub() {
        return this.__selectedClub.get();
    }
    set selectedClub(newValue: string) {
        this.__selectedClub.set(newValue);
    }
    private __selectedStatus: ObservedPropertySimplePU<number>;
    get selectedStatus() {
        return this.__selectedStatus.get();
    }
    set selectedStatus(newValue: number) {
        this.__selectedStatus.set(newValue);
    }
    private __showMine: ObservedPropertySimplePU<boolean>;
    get showMine() {
        return this.__showMine.get();
    }
    set showMine(newValue: boolean) {
        this.__showMine.set(newValue);
    }
    private __isRefreshing: ObservedPropertySimplePU<boolean>;
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue: boolean) {
        this.__isRefreshing.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __errorMessage: ObservedPropertySimplePU<string>;
    get errorMessage() {
        return this.__errorMessage.get();
    }
    set errorMessage(newValue: string) {
        this.__errorMessage.set(newValue);
    }
    private __currentPage: ObservedPropertySimplePU<number>;
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: number) {
        this.__currentPage.set(newValue);
    }
    private __hasMore: ObservedPropertySimplePU<boolean>;
    get hasMore() {
        return this.__hasMore.get();
    }
    set hasMore(newValue: boolean) {
        this.__hasMore.set(newValue);
    }
    private __isLoadingMore: ObservedPropertySimplePU<boolean>;
    get isLoadingMore() {
        return this.__isLoadingMore.get();
    }
    set isLoadingMore(newValue: boolean) {
        this.__isLoadingMore.set(newValue);
    }
    private clubOptions: string[];
    private clubLabels: string[];
    private statusValues: number[];
    private statusLabels: string[];
    aboutToAppear(): void {
        this.refreshActivities();
    }
    onPageShow(): void {
        this.refreshActivities();
    }
    private async refreshActivities(): Promise<void> {
        this.currentPage = 1;
        this.hasMore = true;
        this.isLoading = true;
        this.errorMessage = '';
        let result: ApiResult;
        if (this.showMine) {
            result = await ApiService.getMyClubActivities(this.currentPage, PAGE_SIZE);
        }
        else {
            result = await ApiService.getClubActivityList(this.selectedClub, this.selectedStatus, this.currentPage, PAGE_SIZE);
        }
        if (result.code === 200 && result.data !== undefined) {
            const arr: ClubActivityItem[] = this.parseActivityList(result.data);
            this.activities = arr;
            this.hasMore = arr.length >= PAGE_SIZE;
        }
        else {
            this.activities = [];
            this.hasMore = false;
            this.errorMessage = result.msg.length > 0 ? result.msg : '活动加载失败';
        }
        this.isLoading = false;
    }
    private async loadMore(): Promise<void> {
        if (this.isLoadingMore || !this.hasMore) {
            return;
        }
        this.isLoadingMore = true;
        this.currentPage = this.currentPage + 1;
        let result: ApiResult;
        if (this.showMine) {
            result = await ApiService.getMyClubActivities(this.currentPage, PAGE_SIZE);
        }
        else {
            result = await ApiService.getClubActivityList(this.selectedClub, this.selectedStatus, this.currentPage, PAGE_SIZE);
        }
        if (result.code === 200 && result.data !== undefined) {
            const newItems: ClubActivityItem[] = this.parseActivityList(result.data);
            const merged: ClubActivityItem[] = this.activities.concat(newItems);
            this.activities = merged;
            this.hasMore = newItems.length >= PAGE_SIZE;
        }
        this.isLoadingMore = false;
    }
    private async doRefresh(): Promise<void> {
        this.isRefreshing = true;
        await this.refreshActivities();
        this.isRefreshing = false;
    }
    private parseActivityList(data: Object): ClubActivityItem[] {
        const arr: Object[] = data as Object[];
        const list: ClubActivityItem[] = [];
        for (let i = 0; i < arr.length; i++) {
            const obj: Record<string, Object> = arr[i] as Record<string, Object>;
            const item: ClubActivityItem = this.parseActivity(obj);
            list.push(item);
        }
        return list;
    }
    private parseActivity(obj: Record<string, Object>): ClubActivityItem {
        const item: ClubActivityItem = new ClubActivityItem();
        item.id = (obj['id'] as number) ?? 0;
        item.userId = (obj['userId'] as number) ?? 0;
        item.userName = (obj['userName'] as string) ?? '';
        item.club = (obj['club'] as string) ?? '';
        item.title = (obj['title'] as string) ?? '';
        item.description = (obj['description'] as string) ?? '';
        item.venue = (obj['venue'] as string) ?? '';
        item.activityTime = (obj['activityTime'] as string) ?? '';
        item.maxParticipants = (obj['maxParticipants'] as number) ?? 20;
        item.currentParticipants = (obj['currentParticipants'] as number) ?? 0;
        item.status = (obj['status'] as number) ?? 1;
        item.createTime = (obj['createTime'] as string) ?? '';
        item.coverImage = (obj['coverImage'] as string) ?? '';
        item.registered = (obj['registered'] as boolean) ?? false;
        const namesObj: Object = obj['participantNames'];
        if (namesObj !== null && namesObj !== undefined) {
            item.participantNames = namesObj as string[];
        }
        return item;
    }
    private statusText(status: number): string {
        if (status === 1) {
            return '报名中';
        }
        if (status === 2) {
            return '已满';
        }
        return '未知';
    }
    private statusColor(status: number): string {
        if (status === 1) {
            return Theme.success;
        }
        if (status === 2) {
            return Theme.warning;
        }
        return Theme.textSecondary;
    }
    private statusBg(status: number): string {
        if (status === 1) {
            return Theme.successLight;
        }
        if (status === 2) {
            return Theme.warningLight;
        }
        return Theme.divider;
    }
    private formatTime(time: string): string {
        if (time.length >= 16) {
            return time.replace('T', ' ').substring(0, 16);
        }
        return time;
    }
    private pad2(value: number): string {
        return value < 10 ? `0${value}` : `${value}`;
    }
    private formatDate(date: Date): string {
        return `${date.getFullYear()}-${this.pad2(date.getMonth() + 1)}-${this.pad2(date.getDate())} ${this.pad2(date.getHours())}:${this.pad2(date.getMinutes())}`;
    }
    private deadlineTime(time: string): string {
        if (time.length < 16) {
            return '活动开始前1小时';
        }
        const date: Date = new Date(time);
        const timeMs: number = date.getTime();
        if (timeMs <= 0) {
            return '活动开始前1小时';
        }
        date.setHours(date.getHours() - 1);
        return this.formatDate(date);
    }
    private goDetail(item: ClubActivityItem): void {
        const params: Record<string, Object> = {
            'id': item.id
        } as Record<string, Object>;
        this.getUIContext().getRouter().pushUrl({
            url: 'pages/ClubActivityDetailPage',
            params: params
        });
    }
    private confirmDeleteActivity(item: ClubActivityItem): void {
        AlertDialog.show({
            message: '确定删除这个活动吗？',
            primaryButton: {
                value: '取消',
                action: () => { }
            },
            secondaryButton: {
                value: '删除',
                action: () => { this.doDeleteActivity(item.id); }
            }
        });
    }
    private async doDeleteActivity(activityId: number): Promise<void> {
        const result: ApiResult = await ApiService.deleteClubActivity(activityId);
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
            this.refreshActivities();
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(213:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '校园活动',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Button.createWithLabel('组局');
                                Button.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(215:9)", "entry");
                                Button.height(36);
                                Button.fontSize(14);
                                Button.fontColor(Color.White);
                                Button.backgroundColor(Theme.primary);
                                Button.borderRadius(18);
                                Button.padding({ left: 16, right: 16 });
                                Button.onClick(() => {
                                    this.getUIContext().getRouter().pushUrl({ url: 'pages/ClubActivityPublishPage' });
                                });
                            }, Button);
                            Button.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ClubActivityListPage.ets", line: 214, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '校园活动',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('组局');
                                    Button.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(215:9)", "entry");
                                    Button.height(36);
                                    Button.fontSize(14);
                                    Button.fontColor(Color.White);
                                    Button.backgroundColor(Theme.primary);
                                    Button.borderRadius(18);
                                    Button.padding({ left: 16, right: 16 });
                                    Button.onClick(() => {
                                        this.getUIContext().getRouter().pushUrl({ url: 'pages/ClubActivityPublishPage' });
                                    });
                                }, Button);
                                Button.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '校园活动'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(227:7)", "entry");
            Row.width('100%');
            Row.padding({ left: 16, right: 16, top: 12, bottom: 8 });
            Row.backgroundColor(Theme.bgCard);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('活动广场');
            Button.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(228:9)", "entry");
            Button.height(34);
            Button.fontSize(13);
            Button.fontColor(!this.showMine ? Color.White : Theme.textSecondary);
            Button.backgroundColor(!this.showMine ? Theme.primary : Theme.bgInput);
            Button.borderRadius(17);
            Button.onClick(() => {
                this.showMine = false;
                this.refreshActivities();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('我的报名');
            Button.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(238:9)", "entry");
            Button.height(34);
            Button.fontSize(13);
            Button.fontColor(this.showMine ? Color.White : Theme.textSecondary);
            Button.backgroundColor(this.showMine ? Theme.primary : Theme.bgInput);
            Button.borderRadius(17);
            Button.onClick(() => {
                this.showMine = true;
                this.refreshActivities();
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.showMine) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(254:9)", "entry");
                        Scroll.scrollable(ScrollDirection.Horizontal);
                        Scroll.scrollBar(BarState.Off);
                        Scroll.width('100%');
                        Scroll.height(44);
                        Scroll.backgroundColor(Theme.bgCard);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create({ space: 8 });
                        Row.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(255:11)", "entry");
                        Row.padding({ left: 16, right: 16 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const club = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.clubLabels[index]);
                                Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(257:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(this.selectedClub === club ? Color.White : Theme.textSecondary);
                                Text.padding({ left: 14, right: 14, top: 7, bottom: 7 });
                                Text.backgroundColor(this.selectedClub === club ? Theme.primary : Theme.bgInput);
                                Text.borderRadius(15);
                                Text.onClick(() => {
                                    this.selectedClub = club;
                                    this.refreshActivities();
                                });
                            }, Text);
                            Text.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.clubOptions, forEachItemGenFunction, (club: string, index: number) => `${index}-${club}`, true, true);
                    }, ForEach);
                    ForEach.pop();
                    Row.pop();
                    Scroll.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(277:9)", "entry");
                        Scroll.scrollable(ScrollDirection.Horizontal);
                        Scroll.scrollBar(BarState.Off);
                        Scroll.width('100%');
                        Scroll.height(44);
                        Scroll.backgroundColor(Theme.bgCard);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create({ space: 8 });
                        Row.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(278:11)", "entry");
                        Row.padding({ left: 16, right: 16 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const status = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.statusLabels[index]);
                                Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(280:15)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(this.selectedStatus === status ? Color.White : Theme.textSecondary);
                                Text.padding({ left: 14, right: 14, top: 7, bottom: 7 });
                                Text.backgroundColor(this.selectedStatus === status ? Theme.success : Theme.bgInput);
                                Text.borderRadius(15);
                                Text.onClick(() => {
                                    this.selectedStatus = status;
                                    this.refreshActivities();
                                });
                            }, Text);
                            Text.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.statusValues, forEachItemGenFunction, (status: number, index: number) => `${index}-${status}`, true, true);
                    }, ForEach);
                    ForEach.pop();
                    Row.pop();
                    Scroll.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Refresh.create({ refreshing: { value: this.isRefreshing, changeEvent: newValue => { this.isRefreshing = newValue; } } });
            Refresh.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(301:7)", "entry");
            Refresh.layoutWeight(1);
            Refresh.onRefreshing(() => {
                this.doRefresh();
            });
        }, Refresh);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading && this.activities.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(303:11)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(304:13)", "entry");
                        LoadingProgress.width(32);
                        LoadingProgress.height(32);
                        LoadingProgress.color(Theme.primary);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在加载活动');
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(308:13)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.activities.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(317:11)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMessage.length > 0 ? this.errorMessage : (this.showMine ? '还没有报名活动' : '暂无社团活动'));
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(318:13)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('刷新');
                        Button.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(321:13)", "entry");
                        Button.height(36);
                        Button.fontSize(14);
                        Button.fontColor(Color.White);
                        Button.backgroundColor(Theme.primary);
                        Button.borderRadius(18);
                        Button.margin({ top: 16 });
                        Button.onClick(() => {
                            this.refreshActivities();
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(336:11)", "entry");
                        List.width('100%');
                        List.height('100%');
                        List.padding({ left: 16, right: 16, top: 14, bottom: 24 });
                        List.scrollBar(BarState.Off);
                        List.onReachEnd(() => {
                            this.loadMore();
                        });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(338:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.ActivityCard.bind(this)(item);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.activities, forEachItemGenFunction, (item: ClubActivityItem) => `${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.hasMore && this.activities.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                {
                                    const itemCreation = (elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        ListItem.create(deepRenderFunction, true);
                                        if (!isInitialRender) {
                                            ListItem.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    };
                                    const itemCreation2 = (elmtId, isInitialRender) => {
                                        ListItem.create(deepRenderFunction, true);
                                        ListItem.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(343:15)", "entry");
                                    };
                                    const deepRenderFunction = (elmtId, isInitialRender) => {
                                        itemCreation(elmtId, isInitialRender);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Row.create();
                                            Row.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(344:17)", "entry");
                                            Row.width('100%');
                                            Row.justifyContent(FlexAlign.Center);
                                            Row.padding({ top: 12, bottom: 12 });
                                        }, Row);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            LoadingProgress.create();
                                            LoadingProgress.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(345:19)", "entry");
                                            LoadingProgress.width(20);
                                            LoadingProgress.height(20);
                                            LoadingProgress.color(Theme.primary);
                                        }, LoadingProgress);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('加载更多...');
                                            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(349:19)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.margin({ left: 8 });
                                        }, Text);
                                        Text.pop();
                                        Row.pop();
                                        ListItem.pop();
                                    };
                                    this.observeComponentCreation2(itemCreation2, ListItem);
                                    ListItem.pop();
                                }
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (!this.hasMore && this.activities.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                {
                                    const itemCreation = (elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        ListItem.create(deepRenderFunction, true);
                                        if (!isInitialRender) {
                                            ListItem.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    };
                                    const itemCreation2 = (elmtId, isInitialRender) => {
                                        ListItem.create(deepRenderFunction, true);
                                        ListItem.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(360:15)", "entry");
                                    };
                                    const deepRenderFunction = (elmtId, isInitialRender) => {
                                        itemCreation(elmtId, isInitialRender);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('- 没有更多了 -');
                                            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(361:17)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.width('100%');
                                            Text.textAlign(TextAlign.Center);
                                            Text.padding({ top: 12, bottom: 12 });
                                        }, Text);
                                        Text.pop();
                                        ListItem.pop();
                                    };
                                    this.observeComponentCreation2(itemCreation2, ListItem);
                                    ListItem.pop();
                                }
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Refresh.pop();
        Column.pop();
    }
    ActivityCard(item: ClubActivityItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(391:5)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(10);
            Column.shadow(ShadowStyle.sm);
            Column.onClick(() => {
                this.goDetail(item);
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.coverImage.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(`${ApiService.baseUrl}${item.coverImage}`);
                        Image.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(393:9)", "entry");
                        Image.width('100%');
                        Image.height(150);
                        Image.objectFit(ImageFit.Cover);
                        Image.borderRadius(10);
                        Image.margin({ bottom: 12 });
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(400:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.club);
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(401:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.primary);
            Text.padding({ left: 8, right: 8, top: 3, bottom: 3 });
            Text.backgroundColor(Theme.primaryLight);
            Text.borderRadius(4);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(407:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (AppStore.getInstance().isLoggedIn && AppStore.getInstance().userInfo.id === item.userId) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('删除');
                        Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(409:11)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ right: 8 });
                        Text.onClick(() => { this.confirmDeleteActivity(item); });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.statusText(item.status));
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(415:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(this.statusColor(item.status));
            Text.padding({ left: 8, right: 8, top: 3, bottom: 3 });
            Text.backgroundColor(this.statusBg(item.status));
            Text.borderRadius(4);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(424:7)", "entry");
            Text.fontSize(17);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
            Text.margin({ top: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.description.length > 0 ? item.description : '发布者暂未填写活动介绍');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(433:7)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textSecondary);
            Text.lineHeight(19);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
            Text.margin({ top: 6 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(442:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('地点');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(443:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width(42);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.venue);
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(447:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textPrimary);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(457:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 7 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('时间');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(458:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width(42);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.formatTime(item.activityTime));
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(462:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textPrimary);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(470:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 7 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('截止');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(471:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width(42);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.deadlineTime(item.activityTime));
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(475:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.warning);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(483:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 7 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('人数');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(484:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width(42);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${item.currentParticipants}/${item.maxParticipants}`);
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(488:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(item.currentParticipants >= item.maxParticipants ? Theme.warning : Theme.textPrimary);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('查看详情');
            Text.debugLine("entry/src/main/ets/pages/ClubActivityListPage.ets(492:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.primary);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "ClubActivityListPage";
    }
}
registerNamedRoute(() => new ClubActivityListPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/ClubActivityListPage", pageFullPath: "entry/src/main/ets/pages/ClubActivityListPage", integratedHsp: "false", moduleType: "followWithHap" });
