if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ConfessionPublishPage_Params {
    contentInput?: string;
    selectedCategory?: number;
    isAnonymous?: number;
    imageUriList?: string[];
    imageUrlList?: string[];
    isUploading?: boolean;
    isSubmitting?: boolean;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const CATEGORIES: string[] = ['表白', '树洞', '吐槽', '交友'];
const CATEGORY_COLORS: string[] = ['#DB2777', Theme.ocean, Theme.primary, '#7C3AED'];
class ConfessionPublishPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__contentInput = new ObservedPropertySimplePU('', this, "contentInput");
        this.__selectedCategory = new ObservedPropertySimplePU(1, this, "selectedCategory");
        this.__isAnonymous = new ObservedPropertySimplePU(0, this, "isAnonymous");
        this.__imageUriList = new ObservedPropertyObjectPU([], this, "imageUriList");
        this.__imageUrlList = new ObservedPropertyObjectPU([], this, "imageUrlList");
        this.__isUploading = new ObservedPropertySimplePU(false, this, "isUploading");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ConfessionPublishPage_Params) {
        if (params.contentInput !== undefined) {
            this.contentInput = params.contentInput;
        }
        if (params.selectedCategory !== undefined) {
            this.selectedCategory = params.selectedCategory;
        }
        if (params.isAnonymous !== undefined) {
            this.isAnonymous = params.isAnonymous;
        }
        if (params.imageUriList !== undefined) {
            this.imageUriList = params.imageUriList;
        }
        if (params.imageUrlList !== undefined) {
            this.imageUrlList = params.imageUrlList;
        }
        if (params.isUploading !== undefined) {
            this.isUploading = params.isUploading;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
    }
    updateStateVars(params: ConfessionPublishPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__contentInput.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedCategory.purgeDependencyOnElmtId(rmElmtId);
        this.__isAnonymous.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUriList.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUrlList.purgeDependencyOnElmtId(rmElmtId);
        this.__isUploading.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__contentInput.aboutToBeDeleted();
        this.__selectedCategory.aboutToBeDeleted();
        this.__isAnonymous.aboutToBeDeleted();
        this.__imageUriList.aboutToBeDeleted();
        this.__imageUrlList.aboutToBeDeleted();
        this.__isUploading.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __contentInput: ObservedPropertySimplePU<string>;
    get contentInput() {
        return this.__contentInput.get();
    }
    set contentInput(newValue: string) {
        this.__contentInput.set(newValue);
    }
    private __selectedCategory: ObservedPropertySimplePU<number>;
    get selectedCategory() {
        return this.__selectedCategory.get();
    }
    set selectedCategory(newValue: number) {
        this.__selectedCategory.set(newValue);
    }
    private __isAnonymous: ObservedPropertySimplePU<number>;
    get isAnonymous() {
        return this.__isAnonymous.get();
    }
    set isAnonymous(newValue: number) {
        this.__isAnonymous.set(newValue);
    }
    private __imageUriList: ObservedPropertyObjectPU<string[]>;
    get imageUriList() {
        return this.__imageUriList.get();
    }
    set imageUriList(newValue: string[]) {
        this.__imageUriList.set(newValue);
    }
    private __imageUrlList: ObservedPropertyObjectPU<string[]>;
    get imageUrlList() {
        return this.__imageUrlList.get();
    }
    set imageUrlList(newValue: string[]) {
        this.__imageUrlList.set(newValue);
    }
    private __isUploading: ObservedPropertySimplePU<boolean>;
    get isUploading() {
        return this.__isUploading.get();
    }
    set isUploading(newValue: boolean) {
        this.__isUploading.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    private async pickImagesFromAlbum(): Promise<void> {
        if (this.imageUrlList.length >= 5) {
            AlertDialog.show({
                message: '最多上传5张图片',
                confirm: { value: '知道了', action: () => { } }
            });
            return;
        }
        this.isUploading = true;
        const uris: string[] = await ApiService.pickImages();
        if (uris.length === 0) {
            this.isUploading = false;
            return;
        }
        const maxNew: number = 5 - this.imageUrlList.length;
        const toUpload: string[] = [];
        for (let i = 0; i < Math.min(uris.length, maxNew); i++) {
            toUpload.push(uris[i]);
        }
        for (let i = 0; i < toUpload.length; i++) {
            const url: string = await ApiService.uploadConfessionImage(toUpload[i]);
            if (url.startsWith('ERROR:')) {
                AlertDialog.show({
                    message: '图片上传失败，请重试',
                    confirm: { value: '确定', action: () => { } }
                });
            }
            else {
                this.imageUriList.push(toUpload[i]);
                this.imageUrlList.push(url);
            }
        }
        this.isUploading = false;
    }
    private removeImageByIndex(index: number): void {
        const newUris: string[] = [];
        const newUrls: string[] = [];
        for (let i = 0; i < this.imageUriList.length; i++) {
            if (i !== index) {
                newUris.push(this.imageUriList[i]);
                newUrls.push(this.imageUrlList[i]);
            }
        }
        this.imageUriList = newUris;
        this.imageUrlList = newUrls;
    }
    private async submitPublish(): Promise<void> {
        if (this.contentInput.trim().length === 0) {
            AlertDialog.show({
                message: '请输入内容',
                confirm: { value: '好的', action: () => { } }
            });
            return;
        }
        this.isSubmitting = true;
        const imgArr: string[] = [];
        for (let i = 0; i < this.imageUrlList.length; i++) {
            imgArr.push(this.imageUrlList[i]);
        }
        const params: Record<string, Object> = {
            'content': this.contentInput.trim(),
            'category': CATEGORIES[this.selectedCategory],
            'isAnonymous': this.isAnonymous,
            'images': JSON.stringify(imgArr)
        };
        const result = await ApiService.publishConfession(params);
        this.isSubmitting = false;
        if (result.code === 200) {
            promptAction.showToast({ message: '发布成功！' });
            router.back();
        }
        else {
            AlertDialog.show({
                title: '发布失败',
                message: result.msg || '请稍后重试',
                confirm: { value: '好的', action: () => { } }
            });
        }
    }
    private canSubmit(): boolean {
        return this.contentInput.trim().length > 0 && !this.isSubmitting;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(111:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '发布帖子',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(this.isSubmitting ? '发布中…' : '发布');
                                Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(113:9)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(this.canSubmit() ? Theme.primary : Theme.textDisabled);
                                Text.onClick(() => { this.submitPublish(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ConfessionPublishPage.ets", line: 112, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '发布帖子',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.isSubmitting ? '发布中…' : '发布');
                                    Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(113:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(this.canSubmit() ? Theme.primary : Theme.textDisabled);
                                    Text.onClick(() => { this.submitPublish(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '发布帖子'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(119:7)", "entry");
            Scroll.layoutWeight(1);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(120:9)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(121:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('分类');
            Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(122:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ bottom: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(129:13)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, idx: number) => {
                const cat = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(cat);
                    Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(131:17)", "entry");
                    Text.fontSize(13);
                    Text.fontColor(this.selectedCategory === idx ? '#FFFFFF' : CATEGORY_COLORS[idx]);
                    Text.backgroundColor(this.selectedCategory === idx ? CATEGORY_COLORS[idx] : '#FFFFFF');
                    Text.border({ width: 1, color: CATEGORY_COLORS[idx] });
                    Text.borderRadius(16);
                    Text.padding({ left: 16, right: 16, top: 6, bottom: 6 });
                    Text.margin({ right: 8 });
                    Text.onClick(() => { this.selectedCategory = idx; });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, CATEGORIES, forEachItemGenFunction, (cat: string) => cat, true, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(148:11)", "entry");
            Blank.height(10);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(150:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('内容');
            Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(151:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.margin({ bottom: 6 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({ placeholder: '说点什么吧...', text: this.contentInput });
            TextArea.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(157:13)", "entry");
            TextArea.width('100%');
            TextArea.height(150);
            TextArea.fontSize(15);
            TextArea.backgroundColor(Theme.bgInput);
            TextArea.borderRadius(8);
            TextArea.padding({ left: 12, right: 12 });
            TextArea.onChange((val: string) => { this.contentInput = val; });
        }, TextArea);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(170:11)", "entry");
            Blank.height(10);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(172:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(173:13)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('添加图片');
            Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(174:15)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`(${this.imageUrlList.length}/5)`);
            Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(177:15)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(181:15)", "entry");
        }, Blank);
        Blank.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(186:13)", "entry");
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.width('100%');
            Scroll.height(90);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(187:15)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, idx: number) => {
                const url = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Stack.create();
                    Stack.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(189:19)", "entry");
                    Stack.margin({ right: 8 });
                }, Stack);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(ApiService.baseUrl + url);
                    Image.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(190:21)", "entry");
                    Image.width(76);
                    Image.height(76);
                    Image.borderRadius(8);
                    Image.objectFit(ImageFit.Cover);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('×');
                    Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(192:21)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#FFFFFF');
                    Text.backgroundColor('#00000080');
                    Text.width(18);
                    Text.height(18);
                    Text.borderRadius(9);
                    Text.textAlign(TextAlign.Center);
                    Text.position({ top: -3, right: -3 });
                    Text.onClick(() => { this.removeImageByIndex(idx); });
                }, Text);
                Text.pop();
                Stack.pop();
            };
            this.forEachUpdateFunction(elmtId, this.imageUrlList, forEachItemGenFunction, (url: string) => url, true, false);
        }, ForEach);
        ForEach.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.imageUrlList.length < 5) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(204:19)", "entry");
                        Column.width(76);
                        Column.height(76);
                        Column.backgroundColor(Theme.bgInput);
                        Column.borderRadius(8);
                        Column.border({ width: 1, color: Theme.border, style: BorderStyle.Dashed });
                        Column.justifyContent(FlexAlign.Center);
                        Column.onClick(() => { this.pickImagesFromAlbum(); });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.isUploading) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    LoadingProgress.create();
                                    LoadingProgress.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(206:23)", "entry");
                                    LoadingProgress.color(Theme.primary);
                                    LoadingProgress.width(24);
                                    LoadingProgress.height(24);
                                }, LoadingProgress);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('+');
                                    Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(208:23)", "entry");
                                    Text.fontSize(28);
                                    Text.fontColor(Theme.textDisabled);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('上传');
                                    Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(209:23)", "entry");
                                    Text.fontSize(10);
                                    Text.fontColor(Theme.textDisabled);
                                    Text.margin({ top: 2 });
                                }, Text);
                                Text.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        Scroll.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(228:11)", "entry");
            Blank.height(10);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(230:11)", "entry");
            Column.width('100%');
            Column.padding({ left: 16, right: 16, top: 14, bottom: 14 });
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(231:13)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('匿名发布');
            Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(232:15)", "entry");
            Text.fontSize(15);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(235:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isAnonymous === 1 ? '🎭 匿名' : '😎 实名');
            Text.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(236:15)", "entry");
            Text.fontSize(13);
            Text.fontColor(this.isAnonymous === 1 ? Theme.ocean : Theme.textSecondary);
            Text.onClick(() => {
                this.isAnonymous = this.isAnonymous === 0 ? 1 : 0;
            });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(249:11)", "entry");
            Blank.height(24);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('发布帖子');
            Button.debugLine("entry/src/main/ets/pages/ConfessionPublishPage.ets(251:11)", "entry");
            Button.type(ButtonType.Capsule);
            Button.width('92%');
            Button.height(48);
            Button.backgroundColor(this.canSubmit() ? Theme.primary : Theme.textDisabled);
            Button.fontColor('#FFFFFF');
            Button.enabled(this.canSubmit());
            Button.onClick(() => { this.submitPublish(); });
        }, Button);
        Button.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "ConfessionPublishPage";
    }
}
registerNamedRoute(() => new ConfessionPublishPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/ConfessionPublishPage", pageFullPath: "entry/src/main/ets/pages/ConfessionPublishPage", integratedHsp: "false", moduleType: "followWithHap" });
