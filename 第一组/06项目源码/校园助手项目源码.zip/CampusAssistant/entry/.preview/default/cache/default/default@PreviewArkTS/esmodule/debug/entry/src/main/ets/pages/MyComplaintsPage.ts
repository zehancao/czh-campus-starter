if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MyComplaintsPage_Params {
    score?: number;
    myItems?: CItem[];
    agItems?: CItem[];
    loading?: boolean;
    dId?: number;
    dName?: string;
    pId?: number;
    dlgController?: CustomDialogController | null;
}
interface ComplaintDlg_Params {
    controller?: CustomDialogController;
    dName?: string;
    onSubmit?: (reason: string) => void;
    reason?: string;
}
interface CCard_Params {
    isMy?: boolean;
    who?: string;
    why?: string;
    stat?: number;
    when?: string;
}
interface CreditCard_Params {
    score?: number;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const STATUS: string[] = ['待处理', '已处理'];
interface CItem {
    id: number;
    cId: number;
    cName: string;
    dId: number;
    dName: string;
    why: string;
    stat: number;
    when: string;
}
class CreditCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.score = 100;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CreditCard_Params) {
        if (params.score !== undefined) {
            this.score = params.score;
        }
    }
    updateStateVars(params: CreditCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private score: number;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(26:5)", "entry");
            Row.width('100%');
            Row.height(110);
            Row.backgroundColor(this.score >= 90 ? Theme.success : this.score >= 80 ? Theme.warning : Theme.danger);
            Row.borderRadius(16);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(27:7)", "entry");
            Column.alignItems(HorizontalAlign.Center);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('信用分');
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(28:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textWhite);
            Text.opacity(0.85);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.score.toString());
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(29:9)", "entry");
            Text.fontSize(36);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textWhite);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.score >= 85 ? '可发布商品' : '信用分不足');
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(30:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textWhite);
            Text.opacity(0.9);
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(32:7)", "entry");
            Divider.vertical(true);
            Divider.height(50);
            Divider.color(Theme.textWhite);
            Divider.opacity(0.25);
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(33:7)", "entry");
            Column.alignItems(HorizontalAlign.Center);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('信用等级');
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(34:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textWhite);
            Text.opacity(0.85);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.getLevel());
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(35:9)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textWhite);
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    getLevel(): string { return this.score >= 90 ? '优秀' : this.score >= 80 ? '良好' : this.score >= 70 ? '一般' : '较差'; }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class CCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.isMy = false;
        this.who = '';
        this.why = '';
        this.stat = 0;
        this.when = '';
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CCard_Params) {
        if (params.isMy !== undefined) {
            this.isMy = params.isMy;
        }
        if (params.who !== undefined) {
            this.who = params.who;
        }
        if (params.why !== undefined) {
            this.why = params.why;
        }
        if (params.stat !== undefined) {
            this.stat = params.stat;
        }
        if (params.when !== undefined) {
            this.when = params.when;
        }
    }
    updateStateVars(params: CCard_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private isMy: boolean;
    private who: string;
    private why: string;
    private stat: number;
    private when: string;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(53:5)", "entry");
            Column.width('100%');
            Column.padding(14);
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(12);
            Column.margin({ bottom: 10 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(54:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isMy ? '⚖️' : '👤');
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(55:9)", "entry");
            Text.fontSize(22);
            Text.width(40);
            Text.height(40);
            Text.textAlign(TextAlign.Center);
            Text.backgroundColor(this.isMy ? Theme.secondaryLight : Theme.dangerLight);
            Text.borderRadius(20);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(57:9)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 10 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(58:11)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.who);
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(59:13)", "entry");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(60:13)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(STATUS[Math.max(0, Math.min(this.stat, 1))]);
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(61:13)", "entry");
            Text.fontSize(11);
            Text.fontColor(this.stat === 0 ? Theme.warning : Theme.success);
            Text.backgroundColor(this.stat === 0 ? Theme.warningLight : Theme.successLight);
            Text.borderRadius(4);
            Text.padding({ left: 7, right: 7, top: 2, bottom: 2 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isMy ? '被投诉人' : '投诉人');
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(66:11)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 2 });
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(69:7)", "entry");
            Divider.height(1);
            Divider.color(Theme.divider);
            Divider.margin({ top: 10, bottom: 10 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.why);
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(70:7)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textPrimary);
            Text.width('100%');
            Text.maxLines(5);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(71:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 6 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(71:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.fmt(this.when));
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(71:24)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    fmt(s: string): string {
        if (!s)
            return '';
        const t = s.replace('T', ' ');
        return t.length > 16 ? t.substring(0, 16) : t;
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
class ComplaintDlg extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = undefined;
        this.dName = '';
        this.onSubmit = undefined;
        this.__reason = new ObservedPropertySimplePU('', this, "reason");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ComplaintDlg_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.dName !== undefined) {
            this.dName = params.dName;
        }
        if (params.onSubmit !== undefined) {
            this.onSubmit = params.onSubmit;
        }
        if (params.reason !== undefined) {
            this.reason = params.reason;
        }
    }
    updateStateVars(params: ComplaintDlg_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__reason.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__reason.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller?: CustomDialogController;
    setController(ctr: CustomDialogController) {
        this.controller = ctr;
    }
    private dName: string;
    private onSubmit?: (reason: string) => void;
    private __reason: ObservedPropertySimplePU<string>;
    get reason() {
        return this.__reason.get();
    }
    set reason(newValue: string) {
        this.__reason.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(88:5)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20 });
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('投诉举报');
            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(89:7)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.dName.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('被投诉用户：' + this.dName);
                        Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(94:9)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({
                placeholder: '请详细描述投诉原因…',
                text: this.reason
            });
            TextArea.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(99:7)", "entry");
            TextArea.width('100%');
            TextArea.height(120);
            TextArea.fontSize(14);
            TextArea.backgroundColor(Theme.bgInput);
            TextArea.borderRadius(8);
            TextArea.padding(12);
            TextArea.margin({ top: 12 });
            TextArea.onChange((val: string) => { this.reason = val; });
        }, TextArea);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(109:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 16, bottom: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('取消');
            Button.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(110:9)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontColor(Theme.textSecondary);
            Button.backgroundColor(Theme.bgInput);
            Button.layoutWeight(1);
            Button.margin({ right: 8 });
            Button.onClick(() => { this.controller?.close(); });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('提交投诉');
            Button.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(116:9)", "entry");
            Button.type(ButtonType.Capsule);
            Button.backgroundColor(this.reason.trim().length >= 2 ? Theme.danger : Theme.textDisabled);
            Button.fontColor(Theme.textWhite);
            Button.layoutWeight(1);
            Button.margin({ left: 8 });
            Button.enabled(this.reason.trim().length >= 2);
            Button.onClick(() => {
                if (this.onSubmit !== undefined) {
                    this.onSubmit(this.reason.trim());
                }
                this.controller?.close();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class MyComplaintsPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__score = new ObservedPropertySimplePU(100, this, "score");
        this.__myItems = new ObservedPropertyObjectPU([], this, "myItems");
        this.__agItems = new ObservedPropertyObjectPU([], this, "agItems");
        this.__loading = new ObservedPropertySimplePU(true, this, "loading");
        this.dId = 0;
        this.dName = '';
        this.pId = 0;
        this.dlgController = null;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyComplaintsPage_Params) {
        if (params.score !== undefined) {
            this.score = params.score;
        }
        if (params.myItems !== undefined) {
            this.myItems = params.myItems;
        }
        if (params.agItems !== undefined) {
            this.agItems = params.agItems;
        }
        if (params.loading !== undefined) {
            this.loading = params.loading;
        }
        if (params.dId !== undefined) {
            this.dId = params.dId;
        }
        if (params.dName !== undefined) {
            this.dName = params.dName;
        }
        if (params.pId !== undefined) {
            this.pId = params.pId;
        }
        if (params.dlgController !== undefined) {
            this.dlgController = params.dlgController;
        }
    }
    updateStateVars(params: MyComplaintsPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__score.purgeDependencyOnElmtId(rmElmtId);
        this.__myItems.purgeDependencyOnElmtId(rmElmtId);
        this.__agItems.purgeDependencyOnElmtId(rmElmtId);
        this.__loading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__score.aboutToBeDeleted();
        this.__myItems.aboutToBeDeleted();
        this.__agItems.aboutToBeDeleted();
        this.__loading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __score: ObservedPropertySimplePU<number>;
    get score() {
        return this.__score.get();
    }
    set score(newValue: number) {
        this.__score.set(newValue);
    }
    private __myItems: ObservedPropertyObjectPU<CItem[]>;
    get myItems() {
        return this.__myItems.get();
    }
    set myItems(newValue: CItem[]) {
        this.__myItems.set(newValue);
    }
    private __agItems: ObservedPropertyObjectPU<CItem[]>;
    get agItems() {
        return this.__agItems.get();
    }
    set agItems(newValue: CItem[]) {
        this.__agItems.set(newValue);
    }
    private __loading: ObservedPropertySimplePU<boolean>;
    get loading() {
        return this.__loading.get();
    }
    set loading(newValue: boolean) {
        this.__loading.set(newValue);
    }
    private dId: number;
    private dName: string;
    private pId: number;
    aboutToAppear(): void {
        try {
            const p = router.getParams() as Record<string, Object>;
            if (p) {
                this.dId = p['defendantId'] !== undefined ? Number(p['defendantId']) : 0;
                this.dName = (p['defendantName'] as string) ?? '';
                this.pId = p['productId'] !== undefined ? Number(p['productId']) : 0;
            }
        }
        catch (e) { }
        if (!AppStore.getInstance().isLoggedIn) {
            this.loading = false;
            return;
        }
        this.loadAll();
    }
    async loadAll(): Promise<void> {
        this.loading = true;
        const sr = await ApiService.getCreditScore();
        if (sr.code === 200 && sr.data) {
            const d = sr.data as Record<string, Object>;
            this.score = (d['creditScore'] as number) ?? 100;
        }
        const me = AppStore.getInstance().userInfo.id;
        const lr = await ApiService.getMyComplaints();
        const a: CItem[] = [];
        const b: CItem[] = [];
        if (lr.code === 200 && lr.data) {
            for (const o of lr.data as Object[]) {
                const obj = o as Record<string, Object>;
                const c: CItem = {
                    id: (obj['id'] as number) ?? 0,
                    cId: (obj['complainantId'] as number) ?? 0,
                    cName: (obj['complainantName'] as string) ?? '',
                    dId: (obj['defendantId'] as number) ?? 0,
                    dName: (obj['defendantName'] as string) ?? '',
                    why: (obj['reason'] as string) ?? '',
                    stat: (obj['status'] as number) ?? 0,
                    when: (obj['createTime'] as string) ?? ''
                };
                if (c.cId === me)
                    a.push(c);
                if (c.dId === me)
                    b.push(c);
            }
        }
        this.myItems = a;
        this.agItems = b;
        this.loading = false;
        if (this.dId > 0)
            setTimeout(() => this.showDlg(), 150);
    }
    private dlgController: CustomDialogController | null;
    showDlg(): void {
        if (AppStore.getInstance().userInfo.id === this.dId) {
            AlertDialog.show({ message: '不能投诉自己', confirm: { value: '好的', action: () => { } } });
            return;
        }
        this.dlgController = new CustomDialogController({
            builder: () => {
                let jsDialog = new ComplaintDlg(this, {
                    dName: this.dName,
                    onSubmit: (reason: string) => this.doSubmit(reason)
                }, undefined, -1, () => { }, { page: "entry/src/main/ets/pages/MyComplaintsPage.ets", line: 197, col: 16 });
                jsDialog.setController(this.dlgController);
                ViewPU.create(jsDialog);
                let paramsLambda = () => {
                    return {
                        dName: this.dName,
                        onSubmit: (reason: string) => this.doSubmit(reason)
                    };
                };
                jsDialog.paramsGenerator_ = paramsLambda;
            },
            autoCancel: true,
            cancel: () => { this.dId = 0; this.dName = ''; this.pId = 0; },
            alignment: DialogAlignment.Bottom,
            customStyle: true
        }, this);
        this.dlgController.open();
    }
    async doSubmit(r: string): Promise<void> {
        const p: Record<string, Object> = { 'defendantId': this.dId, 'reason': r };
        if (this.pId > 0)
            p['productId'] = this.pId;
        const res = await ApiService.submitComplaint(p);
        if (res.code === 200) {
            promptAction.showToast({ message: '投诉已提交，等待管理员审核', duration: 2000 });
            this.dId = 0;
            this.dName = '';
            this.pId = 0;
            this.loadAll();
        }
        else {
            AlertDialog.show({ message: res.msg || '提交失败', confirm: { value: '好的', action: () => { } } });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(223:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
            Column.justifyContent(FlexAlign.Start);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    // 顶部导航栏 - custom header with count, keep it
                    NavHeader(this, {
                        title: '投诉与信用',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.myItems.length + this.agItems.length > 0) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('共' + (this.myItems.length + this.agItems.length) + '条');
                                            Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(227:11)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyComplaintsPage.ets", line: 225, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '投诉与信用',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.myItems.length + this.agItems.length > 0) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('共' + (this.myItems.length + this.agItems.length) + '条');
                                                Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(227:11)", "entry");
                                                Text.fontSize(13);
                                                Text.fontColor(Theme.textTertiary);
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '投诉与信用'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!AppStore.getInstance().isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(233:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('🔒');
                        Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(234:11)", "entry");
                        Text.fontSize(56);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录');
                        Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(236:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(240:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.secondary);
                        Button.fontColor(Theme.textWhite);
                        Button.margin({ top: 20 });
                        Button.onClick(() => {
                            router.pushUrl({ url: 'pages/LoginPage' });
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.loading) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(253:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(254:11)", "entry");
                        LoadingProgress.color(Theme.secondary);
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(263:9)", "entry");
                        Scroll.width('100%');
                        Scroll.layoutWeight(1);
                        Scroll.align(Alignment.Top);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(264:11)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 16, right: 16, top: 0 });
                        Column.justifyContent(FlexAlign.Start);
                        Column.alignItems(HorizontalAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        __Common__.create();
                        __Common__.margin({ bottom: 0 });
                    }, __Common__);
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new 
                                // 绿色信用卡片
                                CreditCard(this, { score: this.score }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyComplaintsPage.ets", line: 266, col: 13 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        score: this.score
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "CreditCard" });
                    }
                    __Common__.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 提示条，紧贴绿卡
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(270:13)", "entry");
                        // 提示条，紧贴绿卡
                        Row.width('100%');
                        // 提示条，紧贴绿卡
                        Row.margin({ top: 0, bottom: 12 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('⚠️');
                        Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(271:15)", "entry");
                        Text.fontSize(14);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('投诉经管理员审核通过后，被投诉人信用分 -5');
                        Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(273:15)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ left: 4 });
                    }, Text);
                    Text.pop();
                    // 提示条，紧贴绿卡
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 投诉内容卡片组
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(282:13)", "entry");
                        // 投诉内容卡片组
                        Column.width('100%');
                        // 投诉内容卡片组
                        Column.backgroundColor(Theme.bgCard);
                        // 投诉内容卡片组
                        Column.borderRadius(16);
                        // 投诉内容卡片组
                        Column.shadow(ShadowStyle.md);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(283:15)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16, top: 14, bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('📝 投诉内容');
                        Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(284:17)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(288:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.myItems.length + '条');
                        Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(289:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.myItems.length === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(297:17)", "entry");
                                    Column.width('100%');
                                    Column.padding({ top: 18, bottom: 18 });
                                    Column.backgroundColor(Theme.bgCard);
                                    Column.borderRadius(12);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('暂无投诉记录');
                                    Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(298:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textTertiary);
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                if (isInitialRender) {
                                                    let componentCall = new CCard(this, {
                                                        isMy: true,
                                                        who: item.dName,
                                                        why: item.why,
                                                        stat: item.stat,
                                                        when: item.when
                                                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyComplaintsPage.ets", line: 308, col: 19 });
                                                    ViewPU.create(componentCall);
                                                    let paramsLambda = () => {
                                                        return {
                                                            isMy: true,
                                                            who: item.dName,
                                                            why: item.why,
                                                            stat: item.stat,
                                                            when: item.when
                                                        };
                                                    };
                                                    componentCall.paramsGenerator_ = paramsLambda;
                                                }
                                                else {
                                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                                }
                                            }, { name: "CCard" });
                                        }
                                    };
                                    this.forEachUpdateFunction(elmtId, this.myItems, forEachItemGenFunction, (item: CItem) => 'm' + item.id, false, false);
                                }, ForEach);
                                ForEach.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    // 投诉内容卡片组
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 自己的被投诉记录卡片组
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(324:13)", "entry");
                        // 自己的被投诉记录卡片组
                        Column.width('100%');
                        // 自己的被投诉记录卡片组
                        Column.backgroundColor(Theme.bgCard);
                        // 自己的被投诉记录卡片组
                        Column.borderRadius(16);
                        // 自己的被投诉记录卡片组
                        Column.shadow(ShadowStyle.md);
                        // 自己的被投诉记录卡片组
                        Column.margin({ top: 12 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(325:15)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16, top: 14, bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('📋 自己的被投诉记录');
                        Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(326:17)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(330:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.agItems.length + '条');
                        Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(331:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.agItems.length === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(339:17)", "entry");
                                    Column.width('100%');
                                    Column.padding({ top: 18, bottom: 18 });
                                    Column.backgroundColor(Theme.bgCard);
                                    Column.borderRadius(12);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('没有被投诉记录');
                                    Text.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(340:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textTertiary);
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                if (isInitialRender) {
                                                    let componentCall = new CCard(this, {
                                                        isMy: false,
                                                        who: item.cName,
                                                        why: item.why,
                                                        stat: item.stat,
                                                        when: item.when
                                                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MyComplaintsPage.ets", line: 350, col: 19 });
                                                    ViewPU.create(componentCall);
                                                    let paramsLambda = () => {
                                                        return {
                                                            isMy: false,
                                                            who: item.cName,
                                                            why: item.why,
                                                            stat: item.stat,
                                                            when: item.when
                                                        };
                                                    };
                                                    componentCall.paramsGenerator_ = paramsLambda;
                                                }
                                                else {
                                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                                }
                                            }, { name: "CCard" });
                                        }
                                    };
                                    this.forEachUpdateFunction(elmtId, this.agItems, forEachItemGenFunction, (item: CItem) => 'a' + item.id, false, false);
                                }, ForEach);
                                ForEach.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    // 自己的被投诉记录卡片组
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/MyComplaintsPage.ets(366:13)", "entry");
                        Blank.height(24);
                    }, Blank);
                    Blank.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "MyComplaintsPage";
    }
}
registerNamedRoute(() => new MyComplaintsPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/MyComplaintsPage", pageFullPath: "entry/src/main/ets/pages/MyComplaintsPage", integratedHsp: "false", moduleType: "followWithHap" });
