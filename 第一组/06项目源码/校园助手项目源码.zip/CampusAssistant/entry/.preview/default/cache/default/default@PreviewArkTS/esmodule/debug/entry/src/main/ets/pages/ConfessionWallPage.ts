if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ConfessionWallPage_Params {
    posts?: ConfessionPost[];
    activeTab?: number;
    isLoading?: boolean;
    currentPage?: number;
    hasMore?: boolean;
    isLoadingMore?: boolean;
    showImagePreview?: boolean;
    previewImages?: string[];
    previewIndex?: number;
    expandedComments?: Record<string, boolean>;
    commentInputs?: Record<string, string>;
    showCommentInput?: boolean;
    commentingPostId?: number;
    commentList?: ConfessionComment[];
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { ConfessionPost, ConfessionComment } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
import { AvatarView } from "@normalized:N&&&entry/src/main/ets/common/AvatarView&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
const CATEGORY_TABS: string[] = ['全部', '表白', '树洞', '吐槽', '交友'];
const CATEGORY_COLORS: string[] = [Theme.ocean, '#DB2777', Theme.ocean, Theme.primary, '#7C3AED'];
const CATEGORY_BG_COLORS: string[] = [Theme.oceanLight, '#FCE7F3', Theme.oceanLight, Theme.primaryLight, '#F3E8FF'];
const PAGE_SIZE: number = 20;
class ConfessionWallPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__posts = new ObservedPropertyObjectPU([], this, "posts");
        this.__activeTab = new ObservedPropertySimplePU(0, this, "activeTab");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__currentPage = new ObservedPropertySimplePU(1, this, "currentPage");
        this.__hasMore = new ObservedPropertySimplePU(true, this, "hasMore");
        this.__isLoadingMore = new ObservedPropertySimplePU(false, this, "isLoadingMore");
        this.__showImagePreview = new ObservedPropertySimplePU(false, this, "showImagePreview");
        this.__previewImages = new ObservedPropertyObjectPU([], this, "previewImages");
        this.__previewIndex = new ObservedPropertySimplePU(0, this, "previewIndex");
        this.__expandedComments = new ObservedPropertyObjectPU({}, this, "expandedComments");
        this.__commentInputs = new ObservedPropertyObjectPU({}, this, "commentInputs");
        this.__showCommentInput = new ObservedPropertySimplePU(false, this, "showCommentInput");
        this.__commentingPostId = new ObservedPropertySimplePU(0, this, "commentingPostId");
        this.__commentList = new ObservedPropertyObjectPU([], this, "commentList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ConfessionWallPage_Params) {
        if (params.posts !== undefined) {
            this.posts = params.posts;
        }
        if (params.activeTab !== undefined) {
            this.activeTab = params.activeTab;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
        if (params.hasMore !== undefined) {
            this.hasMore = params.hasMore;
        }
        if (params.isLoadingMore !== undefined) {
            this.isLoadingMore = params.isLoadingMore;
        }
        if (params.showImagePreview !== undefined) {
            this.showImagePreview = params.showImagePreview;
        }
        if (params.previewImages !== undefined) {
            this.previewImages = params.previewImages;
        }
        if (params.previewIndex !== undefined) {
            this.previewIndex = params.previewIndex;
        }
        if (params.expandedComments !== undefined) {
            this.expandedComments = params.expandedComments;
        }
        if (params.commentInputs !== undefined) {
            this.commentInputs = params.commentInputs;
        }
        if (params.showCommentInput !== undefined) {
            this.showCommentInput = params.showCommentInput;
        }
        if (params.commentingPostId !== undefined) {
            this.commentingPostId = params.commentingPostId;
        }
        if (params.commentList !== undefined) {
            this.commentList = params.commentList;
        }
    }
    updateStateVars(params: ConfessionWallPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__posts.purgeDependencyOnElmtId(rmElmtId);
        this.__activeTab.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
        this.__hasMore.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoadingMore.purgeDependencyOnElmtId(rmElmtId);
        this.__showImagePreview.purgeDependencyOnElmtId(rmElmtId);
        this.__previewImages.purgeDependencyOnElmtId(rmElmtId);
        this.__previewIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__expandedComments.purgeDependencyOnElmtId(rmElmtId);
        this.__commentInputs.purgeDependencyOnElmtId(rmElmtId);
        this.__showCommentInput.purgeDependencyOnElmtId(rmElmtId);
        this.__commentingPostId.purgeDependencyOnElmtId(rmElmtId);
        this.__commentList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__posts.aboutToBeDeleted();
        this.__activeTab.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__currentPage.aboutToBeDeleted();
        this.__hasMore.aboutToBeDeleted();
        this.__isLoadingMore.aboutToBeDeleted();
        this.__showImagePreview.aboutToBeDeleted();
        this.__previewImages.aboutToBeDeleted();
        this.__previewIndex.aboutToBeDeleted();
        this.__expandedComments.aboutToBeDeleted();
        this.__commentInputs.aboutToBeDeleted();
        this.__showCommentInput.aboutToBeDeleted();
        this.__commentingPostId.aboutToBeDeleted();
        this.__commentList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __posts: ObservedPropertyObjectPU<ConfessionPost[]>;
    get posts() {
        return this.__posts.get();
    }
    set posts(newValue: ConfessionPost[]) {
        this.__posts.set(newValue);
    }
    private __activeTab: ObservedPropertySimplePU<number>;
    get activeTab() {
        return this.__activeTab.get();
    }
    set activeTab(newValue: number) {
        this.__activeTab.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __currentPage: ObservedPropertySimplePU<number>;
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: number) {
        this.__currentPage.set(newValue);
    }
    private __hasMore: ObservedPropertySimplePU<boolean>;
    get hasMore() {
        return this.__hasMore.get();
    }
    set hasMore(newValue: boolean) {
        this.__hasMore.set(newValue);
    }
    private __isLoadingMore: ObservedPropertySimplePU<boolean>;
    get isLoadingMore() {
        return this.__isLoadingMore.get();
    }
    set isLoadingMore(newValue: boolean) {
        this.__isLoadingMore.set(newValue);
    }
    private __showImagePreview: ObservedPropertySimplePU<boolean>;
    get showImagePreview() {
        return this.__showImagePreview.get();
    }
    set showImagePreview(newValue: boolean) {
        this.__showImagePreview.set(newValue);
    }
    private __previewImages: ObservedPropertyObjectPU<string[]>;
    get previewImages() {
        return this.__previewImages.get();
    }
    set previewImages(newValue: string[]) {
        this.__previewImages.set(newValue);
    }
    private __previewIndex: ObservedPropertySimplePU<number>;
    get previewIndex() {
        return this.__previewIndex.get();
    }
    set previewIndex(newValue: number) {
        this.__previewIndex.set(newValue);
    }
    private __expandedComments: ObservedPropertyObjectPU<Record<string, boolean>>;
    get expandedComments() {
        return this.__expandedComments.get();
    }
    set expandedComments(newValue: Record<string, boolean>) {
        this.__expandedComments.set(newValue);
    }
    private __commentInputs: ObservedPropertyObjectPU<Record<string, string>>;
    get commentInputs() {
        return this.__commentInputs.get();
    }
    set commentInputs(newValue: Record<string, string>) {
        this.__commentInputs.set(newValue);
    }
    private __showCommentInput: ObservedPropertySimplePU<boolean>;
    get showCommentInput() {
        return this.__showCommentInput.get();
    }
    set showCommentInput(newValue: boolean) {
        this.__showCommentInput.set(newValue);
    }
    private __commentingPostId: ObservedPropertySimplePU<number>;
    get commentingPostId() {
        return this.__commentingPostId.get();
    }
    set commentingPostId(newValue: number) {
        this.__commentingPostId.set(newValue);
    }
    private __commentList: ObservedPropertyObjectPU<ConfessionComment[]>;
    get commentList() {
        return this.__commentList.get();
    }
    set commentList(newValue: ConfessionComment[]) {
        this.__commentList.set(newValue);
    }
    onPageShow(): void {
        this.refreshList();
    }
    private async refreshList(): Promise<void> {
        this.isLoading = true;
        this.currentPage = 1;
        this.hasMore = true;
        const category: string = this.activeTab === 0 ? '' : CATEGORY_TABS[this.activeTab];
        const result = await ApiService.getConfessionList(category, 1, PAGE_SIZE);
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            this.posts = this.parsePosts(arr);
            this.hasMore = arr.length >= PAGE_SIZE;
        }
        else {
            this.posts = [];
            this.hasMore = false;
        }
        this.isLoading = false;
    }
    private async loadMore(): Promise<void> {
        if (this.isLoadingMore || !this.hasMore)
            return;
        this.isLoadingMore = true;
        this.currentPage = this.currentPage + 1;
        const category: string = this.activeTab === 0 ? '' : CATEGORY_TABS[this.activeTab];
        const result = await ApiService.getConfessionList(category, this.currentPage, PAGE_SIZE);
        if (result.code === 200 && result.data !== undefined) {
            const arr: Object[] = result.data as Object[];
            const newPosts: ConfessionPost[] = this.parsePosts(arr);
            for (let i = 0; i < newPosts.length; i++) {
                this.posts.push(newPosts[i]);
            }
            this.hasMore = arr.length >= PAGE_SIZE;
        }
        else {
            this.hasMore = false;
        }
        this.isLoadingMore = false;
    }
    private parsePosts(arr: Object[]): ConfessionPost[] {
        const list: ConfessionPost[] = [];
        for (let i = 0; i < arr.length; i++) {
            const obj: Record<string, Object> = arr[i] as Record<string, Object>;
            const item: ConfessionPost = new ConfessionPost();
            item.id = (obj['id'] as number) ?? 0;
            item.userId = (obj['userId'] as number) ?? 0;
            item.publisherName = (obj['publisherName'] as string) ?? '';
            item.publisherAvatar = (obj['publisherAvatar'] as string) ?? '';
            item.content = (obj['content'] as string) ?? '';
            const imgObj: Object = obj['images'];
            if (imgObj !== null && imgObj !== undefined) {
                const imgArr: Object[] = imgObj as Object[];
                item.images = [];
                for (let j = 0; j < imgArr.length; j++) {
                    item.images.push(imgArr[j] as string);
                }
            }
            item.category = (obj['category'] as string) ?? '树洞';
            item.isAnonymous = (obj['isAnonymous'] as number) ?? 0;
            item.likeCount = (obj['likeCount'] as number) ?? 0;
            item.commentCount = (obj['commentCount'] as number) ?? 0;
            item.liked = (obj['liked'] as boolean) ?? false;
            item.status = (obj['status'] as number) ?? 0;
            item.createTime = (obj['createTime'] as string) ?? '';
            list.push(item);
        }
        return list;
    }
    private onTabChange(index: number): void {
        this.activeTab = index;
        this.refreshList();
    }
    private goToPublish(): void {
        router.pushUrl({ url: 'pages/ConfessionPublishPage' });
    }
    private async toggleLike(item: ConfessionPost): Promise<void> {
        const result = await ApiService.likeConfession(item.id);
        if (result.code === 200) {
            this.refreshList();
        }
    }
    private confirmDelete(item: ConfessionPost): void {
        AlertDialog.show({
            message: '确定删除这条帖子吗？',
            primaryButton: {
                value: '取消',
                action: () => { }
            },
            secondaryButton: {
                value: '删除',
                action: () => { this.doDeleteConfession(item.id); }
            }
        });
    }
    private async doDeleteConfession(postId: number): Promise<void> {
        const result = await ApiService.deleteConfession(postId);
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '删除成功', duration: 1500 });
            this.refreshList();
        }
        else {
            const msg: string = result.msg ?? '删除失败';
            this.getUIContext().getPromptAction().showToast({ message: msg, duration: 2000 });
        }
    }
    private openImagePreview(images: string[], index: number): void {
        this.previewImages = images;
        this.previewIndex = index;
        this.showImagePreview = true;
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0)
            return '';
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16)
            return t.substring(0, 16);
        return t;
    }
    private getCategoryIndex(category: string): number {
        if (category === '表白')
            return 1;
        if (category === '树洞')
            return 2;
        if (category === '吐槽')
            return 3;
        if (category === '交友')
            return 4;
        return 0;
    }
    private getRelativeTime(timeStr: string): string {
        if (timeStr.length === 0)
            return '';
        const t: string = timeStr.replace('T', ' ');
        const timestamp: number = Date.parse(t);
        if (isNaN(timestamp))
            return t;
        const diff: number = Date.now() - timestamp;
        const minutes: number = Math.floor(diff / 60000);
        if (minutes < 1)
            return '刚刚';
        if (minutes < 60)
            return `${minutes}分钟前`;
        const hours: number = Math.floor(minutes / 60);
        if (hours < 24)
            return `${hours}小时前`;
        const days: number = Math.floor(hours / 24);
        if (days < 7)
            return `${days}天前`;
        return this.formatTime(timeStr);
    }
    private async loadComments(postId: number): Promise<void> {
        const result = await ApiService.getConfessionDetail(postId);
        if (result.code === 200 && result.data !== undefined) {
            const obj: Record<string, Object> = result.data as Record<string, Object>;
            const commentsObj: Object = obj['comments'];
            if (commentsObj !== null && commentsObj !== undefined) {
                const arr: Object[] = commentsObj as Object[];
                this.commentList = [];
                for (let i = 0; i < arr.length; i++) {
                    const c: Record<string, Object> = arr[i] as Record<string, Object>;
                    const comment: ConfessionComment = new ConfessionComment();
                    comment.id = (c['id'] as number) ?? 0;
                    comment.userId = (c['userId'] as number) ?? 0;
                    comment.nickname = (c['nickname'] as string) ?? '';
                    comment.avatar = (c['avatar'] as string) ?? '';
                    comment.content = (c['content'] as string) ?? '';
                    comment.isAnonymous = (c['isAnonymous'] as number) ?? 0;
                    comment.createTime = (c['createTime'] as string) ?? '';
                    this.commentList.push(comment);
                }
            }
        }
    }
    private async openCommentInput(postId: number): Promise<void> {
        this.commentingPostId = postId;
        this.showCommentInput = true;
        await this.loadComments(postId);
    }
    private async submitComment(): Promise<void> {
        const inputKey: string = `post_${this.commentingPostId}`;
        const content: string = this.commentInputs[inputKey] ?? '';
        if (content.trim().length === 0) {
            this.getUIContext().getPromptAction().showToast({ message: '请输入评论内容', duration: 2000 });
            return;
        }
        const result = await ApiService.commentConfession(this.commentingPostId, content.trim(), 0);
        if (result.code === 200) {
            this.commentInputs[inputKey] = '';
            this.showCommentInput = false;
            this.getUIContext().getPromptAction().showToast({ message: '评论成功', duration: 1500 });
            this.refreshList();
        }
        else {
            this.getUIContext().getPromptAction().showToast({ message: '评论失败', duration: 2000 });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(229:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(230:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '表白墙',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('发布');
                                Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(232:11)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(Theme.primary);
                                Text.onClick(() => { this.goToPublish(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ConfessionWallPage.ets", line: 231, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '表白墙',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('发布');
                                    Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(232:11)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.primary);
                                    Text.onClick(() => { this.goToPublish(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '表白墙'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(235:9)", "entry");
            Row.width('100%');
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const tab = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(237:13)", "entry");
                    Column.layoutWeight(1);
                    Column.alignItems(HorizontalAlign.Center);
                    Column.padding({ top: 4, bottom: 4 });
                    Column.onClick(() => { this.onTabChange(index); });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(tab);
                    Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(238:15)", "entry");
                    Text.fontSize(14);
                    Text.fontColor(this.activeTab === index ? CATEGORY_COLORS[index] : Theme.textSecondary);
                    Text.fontWeight(this.activeTab === index ? FontWeight.Medium : FontWeight.Regular);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(242:15)", "entry");
                    Divider.height(2);
                    Divider.width(24);
                    Divider.color(this.activeTab === index ? CATEGORY_COLORS[index] : 'transparent');
                    Divider.borderRadius(1);
                    Divider.margin({ top: 4 });
                }, Divider);
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, CATEGORY_TABS, forEachItemGenFunction, (tab: string) => tab, true, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(258:9)", "entry");
            Divider.height(1);
            Divider.color(Theme.border);
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(261:11)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(262:13)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 0 });
                        List.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(267:11)", "entry");
                        List.layoutWeight(1);
                        List.edgeEffect(EdgeEffect.Spring);
                        List.padding({ left: 0, right: 0, top: 0, bottom: 20 });
                        List.onReachEnd(() => { this.loadMore(); });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(269:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.PostCard.bind(this)(item);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.posts, forEachItemGenFunction, (item: ConfessionPost) => `${item.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.posts.length === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                {
                                    const itemCreation = (elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        ListItem.create(deepRenderFunction, true);
                                        if (!isInitialRender) {
                                            ListItem.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    };
                                    const itemCreation2 = (elmtId, isInitialRender) => {
                                        ListItem.create(deepRenderFunction, true);
                                        ListItem.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(275:15)", "entry");
                                    };
                                    const deepRenderFunction = (elmtId, isInitialRender) => {
                                        itemCreation(elmtId, isInitialRender);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Column.create();
                                            Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(276:17)", "entry");
                                            Column.width('100%');
                                            Column.alignItems(HorizontalAlign.Center);
                                            Column.margin({ top: 40 });
                                        }, Column);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('💌');
                                            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(277:19)", "entry");
                                            Text.fontSize(56);
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('暂无帖子');
                                            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(278:19)", "entry");
                                            Text.fontSize(15);
                                            Text.fontColor(Theme.textSecondary);
                                            Text.margin({ top: 8 });
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('点击右上角"发布"说点什么吧');
                                            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(280:19)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.margin({ top: 4 });
                                        }, Text);
                                        Text.pop();
                                        Column.pop();
                                        ListItem.pop();
                                    };
                                    this.observeComponentCreation2(itemCreation2, ListItem);
                                    ListItem.pop();
                                }
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    {
                        const itemCreation = (elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            ListItem.create(deepRenderFunction, true);
                            if (!isInitialRender) {
                                ListItem.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        };
                        const itemCreation2 = (elmtId, isInitialRender) => {
                            ListItem.create(deepRenderFunction, true);
                            ListItem.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(289:13)", "entry");
                        };
                        const deepRenderFunction = (elmtId, isInitialRender) => {
                            itemCreation(elmtId, isInitialRender);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(290:15)", "entry");
                                Column.width('100%');
                                Column.padding({ top: 12, bottom: 12 });
                                Column.alignItems(HorizontalAlign.Center);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.isLoadingMore) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Row.create();
                                            Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(292:19)", "entry");
                                            Row.justifyContent(FlexAlign.Center);
                                        }, Row);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            LoadingProgress.create();
                                            LoadingProgress.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(293:21)", "entry");
                                            LoadingProgress.width(20);
                                            LoadingProgress.height(20);
                                            LoadingProgress.color(Theme.primary);
                                        }, LoadingProgress);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('加载更多...');
                                            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(294:21)", "entry");
                                            Text.fontSize(13);
                                            Text.fontColor(Theme.textTertiary);
                                            Text.margin({ left: 8 });
                                        }, Text);
                                        Text.pop();
                                        Row.pop();
                                    });
                                }
                                else if (!this.hasMore && this.posts.length > 0) {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('- 没有更多了 -');
                                            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(299:19)", "entry");
                                            Text.fontSize(12);
                                            Text.fontColor(Theme.textDisabled);
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(2, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                            Column.pop();
                            ListItem.pop();
                        };
                        this.observeComponentCreation2(itemCreation2, ListItem);
                        ListItem.pop();
                    }
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showImagePreview) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.ImagePreviewOverlay.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showCommentInput) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.CommentInputOverlay.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    PostCard(item: ConfessionPost, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(330:5)", "entry");
            Column.width('100%');
            Column.padding({ left: 14, right: 14, top: 14, bottom: 14 });
            Column.backgroundColor('#FFFFFF');
            Column.margin({ bottom: 1 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(331:7)", "entry");
            Row.width('100%');
            Row.alignItems(VerticalAlign.Top);
        }, Row);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new AvatarView(this, { avatar: item.isAnonymous === 1 ? '' : item.publisherAvatar, name: item.publisherName, avatarSize: 36 }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ConfessionWallPage.ets", line: 332, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            avatar: item.isAnonymous === 1 ? '' : item.publisherAvatar,
                            name: item.publisherName,
                            avatarSize: 36
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        avatar: item.isAnonymous === 1 ? '' : item.publisherAvatar, name: item.publisherName
                    });
                }
            }, { name: "AvatarView" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(333:9)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 10 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.isAnonymous === 1 ? '匿名用户' : item.publisherName);
            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(334:11)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(338:11)", "entry");
            Row.margin({ top: 2 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.getRelativeTime(item.createTime));
            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(339:13)", "entry");
            Text.fontSize(11);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.category);
            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(342:13)", "entry");
            Text.fontSize(9);
            Text.fontColor(CATEGORY_COLORS[this.getCategoryIndex(item.category)]);
            Text.padding({ left: 4, right: 4, top: 1, bottom: 1 });
            Text.borderRadius(6);
            Text.backgroundColor(CATEGORY_BG_COLORS[this.getCategoryIndex(item.category)]);
            Text.margin({ left: 6 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (AppStore.getInstance().isLoggedIn && AppStore.getInstance().userInfo.id === item.userId) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(355:11)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('删除');
                        Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(356:11)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.onClick(() => { this.confirmDelete(item); });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.content.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(item.content);
                        Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(366:9)", "entry");
                        Text.fontSize(15);
                        Text.fontColor(Theme.textPrimary);
                        Text.width('100%');
                        Text.margin({ top: 10 });
                        Text.lineHeight(22);
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.images.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.ImageGrid.bind(this)(item.images);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(378:7)", "entry");
            Row.margin({ top: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(379:9)", "entry");
            Row.onClick(() => { this.toggleLike(item); });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.liked ? '❤️' : '🤍');
            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(380:11)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${item.likeCount}`);
            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(382:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(item.liked ? Theme.danger : Theme.textTertiary);
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(389:9)", "entry");
            Row.margin({ left: 24 });
            Row.onClick(() => { this.openCommentInput(item.id); });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('💬');
            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(390:11)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${item.commentCount}`);
            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(392:11)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
        Column.pop();
    }
    ImageGrid(images: string[], parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (images.length === 1) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(`${ApiService.baseUrl}${images[0]}`);
                        Image.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(411:7)", "entry");
                        Image.width(200);
                        Image.height(200);
                        Image.borderRadius(8);
                        Image.objectFit(ImageFit.Cover);
                        Image.margin({ top: 10 });
                        Image.onClick(() => { this.openImagePreview(images, 0); });
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Flex.create({ wrap: FlexWrap.Wrap, justifyContent: FlexAlign.Start });
                        Flex.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(419:7)", "entry");
                        Flex.margin({ top: 10 });
                    }, Flex);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const img = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Image.create(`${ApiService.baseUrl}${img}`);
                                Image.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(421:11)", "entry");
                                Image.width((AppStorage.get<number>('screenWidth') ?? 360) / 3 - 20);
                                Image.height((AppStorage.get<number>('screenWidth') ?? 360) / 3 - 20);
                                Image.borderRadius(6);
                                Image.objectFit(ImageFit.Cover);
                                Image.margin({ top: 4, right: 4 });
                                Image.onClick(() => { this.openImagePreview(images, index); });
                            }, Image);
                        };
                        this.forEachUpdateFunction(elmtId, images, forEachItemGenFunction, (img: string, index: number) => `${index}-${img}`, true, true);
                    }, ForEach);
                    ForEach.pop();
                    Flex.pop();
                });
            }
        }, If);
        If.pop();
    }
    ImagePreviewOverlay(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(436:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#000000');
            Column.position({ x: 0, y: 0 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(437:7)", "entry");
            Row.width('100%');
            Row.height(56);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('✕');
            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(438:9)", "entry");
            Text.fontSize(22);
            Text.fontColor('#FFFFFF');
            Text.margin({ left: 16 });
            Text.onClick(() => { this.showImagePreview = false; });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(443:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.previewIndex + 1}/${this.previewImages.length}`);
            Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(444:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#FFFFFF');
            Text.margin({ right: 16 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Swiper.create();
            Swiper.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(452:7)", "entry");
            Swiper.index(this.previewIndex);
            Swiper.layoutWeight(1);
            Swiper.indicator(false);
            Swiper.onChange((index: number) => { this.previewIndex = index; });
        }, Swiper);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const img = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(`${ApiService.baseUrl}${img}`);
                    Image.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(454:11)", "entry");
                    Image.width('100%');
                    Image.objectFit(ImageFit.Contain);
                }, Image);
            };
            this.forEachUpdateFunction(elmtId, this.previewImages, forEachItemGenFunction, (img: string, index: number) => `${index}`, false, true);
        }, ForEach);
        ForEach.pop();
        Swiper.pop();
        Column.pop();
    }
    CommentInputOverlay(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(472:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('rgba(0,0,0,0.3)');
            Column.position({ x: 0, y: 0 });
            Column.onClick(() => { this.showCommentInput = false; });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(473:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(475:7)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.commentList.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(477:11)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 14, right: 14, top: 10, bottom: 10 });
                        Column.backgroundColor(Theme.bgPage);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const c = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(479:15)", "entry");
                                Row.width('100%');
                                Row.padding({ top: 6, bottom: 6 });
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(c.isAnonymous === 1 ? '匿名' : c.nickname);
                                Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(480:17)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(Theme.primary);
                                Text.fontWeight(FontWeight.Medium);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(': ');
                                Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(484:17)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(Theme.textTertiary);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(c.content);
                                Text.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(487:17)", "entry");
                                Text.fontSize(13);
                                Text.fontColor(Theme.textPrimary);
                                Text.layoutWeight(1);
                            }, Text);
                            Text.pop();
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.commentList, forEachItemGenFunction, (c: ConfessionComment) => `${c.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(501:9)", "entry");
            Row.width('100%');
            Row.padding({ left: 12, right: 12, top: 8, bottom: 8 });
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '写评论...', text: { value: this.commentInputs[`post_${this.commentingPostId}`], changeEvent: newValue => { this.commentInputs[`post_${this.commentingPostId}`] = newValue; } } });
            TextInput.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(502:11)", "entry");
            TextInput.layoutWeight(1);
            TextInput.height(36);
            TextInput.borderRadius(18);
            TextInput.backgroundColor('#F5F5F5');
            TextInput.padding({ left: 14, right: 14 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('发送');
            Button.debugLine("entry/src/main/ets/pages/ConfessionWallPage.ets(509:11)", "entry");
            Button.height(32);
            Button.fontSize(13);
            Button.backgroundColor(Theme.primary);
            Button.fontColor('#FFFFFF');
            Button.borderRadius(16);
            Button.margin({ left: 8 });
            Button.onClick(() => { this.submitComment(); });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "ConfessionWallPage";
    }
}
registerNamedRoute(() => new ConfessionWallPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/ConfessionWallPage", pageFullPath: "entry/src/main/ets/pages/ConfessionWallPage", integratedHsp: "false", moduleType: "followWithHap" });
