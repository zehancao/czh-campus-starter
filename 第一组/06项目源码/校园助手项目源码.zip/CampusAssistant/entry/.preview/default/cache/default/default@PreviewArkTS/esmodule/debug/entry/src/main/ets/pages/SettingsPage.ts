if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SettingsPage_Params {
    feedbackContent?: string;
    contactInfo?: string;
    sending?: boolean;
}
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
class SettingsPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__feedbackContent = new ObservedPropertySimplePU('', this, "feedbackContent");
        this.__contactInfo = new ObservedPropertySimplePU('', this, "contactInfo");
        this.__sending = new ObservedPropertySimplePU(false, this, "sending");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SettingsPage_Params) {
        if (params.feedbackContent !== undefined) {
            this.feedbackContent = params.feedbackContent;
        }
        if (params.contactInfo !== undefined) {
            this.contactInfo = params.contactInfo;
        }
        if (params.sending !== undefined) {
            this.sending = params.sending;
        }
    }
    updateStateVars(params: SettingsPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__feedbackContent.purgeDependencyOnElmtId(rmElmtId);
        this.__contactInfo.purgeDependencyOnElmtId(rmElmtId);
        this.__sending.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__feedbackContent.aboutToBeDeleted();
        this.__contactInfo.aboutToBeDeleted();
        this.__sending.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __feedbackContent: ObservedPropertySimplePU<string>;
    get feedbackContent() {
        return this.__feedbackContent.get();
    }
    set feedbackContent(newValue: string) {
        this.__feedbackContent.set(newValue);
    }
    private __contactInfo: ObservedPropertySimplePU<string>;
    get contactInfo() {
        return this.__contactInfo.get();
    }
    set contactInfo(newValue: string) {
        this.__contactInfo.set(newValue);
    }
    private __sending: ObservedPropertySimplePU<boolean>;
    get sending() {
        return this.__sending.get();
    }
    set sending(newValue: boolean) {
        this.__sending.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(15:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '联系我们' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/SettingsPage.ets", line: 16, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '联系我们'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '联系我们'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(18:7)", "entry");
            Column.width('90%');
            Column.padding(16);
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.margin({ top: 12 });
            Column.shadow(ShadowStyle.sm);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('您的反馈对我们非常重要');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(19:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ bottom: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '联系方式（选填，方便我们回复您）', text: this.contactInfo });
            TextInput.debugLine("entry/src/main/ets/pages/SettingsPage.ets(24:9)", "entry");
            TextInput.type(InputType.Normal);
            TextInput.height(44);
            TextInput.fontSize(14);
            TextInput.backgroundColor(Theme.bgInput);
            TextInput.borderRadius(Theme.radiusSm);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((value: string) => { this.contactInfo = value; });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({ placeholder: '请输入您的反馈或建议...', text: this.feedbackContent });
            TextArea.debugLine("entry/src/main/ets/pages/SettingsPage.ets(33:9)", "entry");
            TextArea.height(160);
            TextArea.fontSize(14);
            TextArea.backgroundColor(Theme.bgInput);
            TextArea.borderRadius(Theme.radiusSm);
            TextArea.padding(12);
            TextArea.margin({ top: 12 });
            TextArea.onChange((value: string) => { this.feedbackContent = value; });
        }, TextArea);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.sending ? '发送中...' : '提交反馈');
            Button.debugLine("entry/src/main/ets/pages/SettingsPage.ets(42:9)", "entry");
            Button.width('100%');
            Button.height(44);
            Button.fontSize(16);
            Button.fontColor(Color.White);
            Button.backgroundColor(this.sending ? Theme.textDisabled : Theme.primary);
            Button.borderRadius(Theme.buttonRadius);
            Button.margin({ top: 20 });
            Button.enabled(!this.sending && this.feedbackContent.length > 0);
            Button.onClick(() => { this.submitFeedback(); });
        }, Button);
        Button.pop();
        Column.pop();
        Column.pop();
    }
    async submitFeedback(): Promise<void> {
        this.sending = true;
        const store = AppStore.getInstance();
        const userName: string = store.userInfo.name.length > 0 ? store.userInfo.name : '匿名用户';
        const result: ApiResult = await ApiService.submitFeedback(userName, this.contactInfo, this.feedbackContent);
        this.sending = false;
        if (result.code === 200) {
            this.feedbackContent = '';
            this.contactInfo = '';
            AlertDialog.show({ message: '感谢您的反馈，我们会尽快处理！' });
        }
        else {
            AlertDialog.show({ message: result.msg });
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "SettingsPage";
    }
}
registerNamedRoute(() => new SettingsPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/SettingsPage", pageFullPath: "entry/src/main/ets/pages/SettingsPage", integratedHsp: "false", moduleType: "followWithHap" });
