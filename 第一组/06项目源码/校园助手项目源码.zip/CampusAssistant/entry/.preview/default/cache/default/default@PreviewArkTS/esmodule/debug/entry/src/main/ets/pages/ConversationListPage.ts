if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ConversationListPage_Params {
    conversations?: Conversation[];
    onlineUserIds?: number[];
    keyword?: string;
    isLoggedIn?: boolean;
    isLoading?: boolean;
    errorMsg?: string;
    hasLoadedOnce?: boolean;
    wsCallback?: MessageCallback | null;
    refreshTimer?: number;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { Conversation, ChatMessage } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { WebSocketService } from "@normalized:N&&&entry/src/main/ets/service/WebSocketService&";
import type { WsMessage, MessageCallback } from "@normalized:N&&&entry/src/main/ets/service/WebSocketService&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
class ConversationListPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__conversations = new ObservedPropertyObjectPU([], this, "conversations");
        this.__onlineUserIds = new ObservedPropertyObjectPU([], this, "onlineUserIds");
        this.__keyword = new ObservedPropertySimplePU('', this, "keyword");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.hasLoadedOnce = false;
        this.wsCallback = null;
        this.refreshTimer = -1;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ConversationListPage_Params) {
        if (params.conversations !== undefined) {
            this.conversations = params.conversations;
        }
        if (params.onlineUserIds !== undefined) {
            this.onlineUserIds = params.onlineUserIds;
        }
        if (params.keyword !== undefined) {
            this.keyword = params.keyword;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
        if (params.hasLoadedOnce !== undefined) {
            this.hasLoadedOnce = params.hasLoadedOnce;
        }
        if (params.wsCallback !== undefined) {
            this.wsCallback = params.wsCallback;
        }
        if (params.refreshTimer !== undefined) {
            this.refreshTimer = params.refreshTimer;
        }
    }
    updateStateVars(params: ConversationListPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__conversations.purgeDependencyOnElmtId(rmElmtId);
        this.__onlineUserIds.purgeDependencyOnElmtId(rmElmtId);
        this.__keyword.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__conversations.aboutToBeDeleted();
        this.__onlineUserIds.aboutToBeDeleted();
        this.__keyword.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __conversations: ObservedPropertyObjectPU<Conversation[]>;
    get conversations() {
        return this.__conversations.get();
    }
    set conversations(newValue: Conversation[]) {
        this.__conversations.set(newValue);
    }
    private __onlineUserIds: ObservedPropertyObjectPU<number[]>;
    get onlineUserIds() {
        return this.__onlineUserIds.get();
    }
    set onlineUserIds(newValue: number[]) {
        this.__onlineUserIds.set(newValue);
    }
    private __keyword: ObservedPropertySimplePU<string>;
    get keyword() {
        return this.__keyword.get();
    }
    set keyword(newValue: string) {
        this.__keyword.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    private hasLoadedOnce: boolean;
    private wsCallback: MessageCallback | null;
    private refreshTimer: number;
    aboutToAppear(): void {
        const store: AppStore = AppStore.getInstance();
        this.isLoggedIn = store.isLoggedIn;
        if (this.isLoggedIn) {
            this.registerWsCallback();
            WebSocketService.getInstance().connect();
            this.loadData();
            this.startPolling();
        }
        else {
            this.isLoading = false;
        }
    }
    aboutToDisappear(): void {
        if (this.wsCallback !== null) {
            WebSocketService.getInstance().removeMessageCallback(this.wsCallback);
            this.wsCallback = null;
        }
        this.stopPolling();
    }
    onPageShow(): void {
        if (this.hasLoadedOnce && this.isLoggedIn) {
            this.loadData(false);
        }
    }
    private startPolling(): void {
        this.stopPolling();
        this.refreshTimer = setInterval(() => {
            if (this.isLoggedIn && WebSocketService.getInstance().connectionState !== 'connected') {
                this.loadData(false);
            }
        }, 3000) as number;
    }
    private stopPolling(): void {
        if (this.refreshTimer !== -1) {
            clearInterval(this.refreshTimer);
            this.refreshTimer = -1;
        }
    }
    private async loadData(showLoading: boolean = true): Promise<void> {
        if (showLoading || !this.hasLoadedOnce) {
            this.isLoading = true;
        }
        if (showLoading) {
            this.errorMsg = '';
        }
        const result = await ApiService.getConversations();
        if (result.code === 200 && result.data !== undefined) {
            this.conversations = ApiService.parseConversationList(result.data);
            this.errorMsg = '';
        }
        else if (showLoading) {
            this.errorMsg = result.msg || '会话加载失败';
        }
        const onlineResult = await ApiService.getOnlineUsers();
        if (onlineResult.code === 200 && onlineResult.data !== undefined) {
            this.onlineUserIds = onlineResult.data as number[];
        }
        this.hasLoadedOnce = true;
        this.isLoading = false;
    }
    private registerWsCallback(): void {
        if (this.wsCallback !== null) {
            return;
        }
        this.wsCallback = (msg: WsMessage) => {
            this.handleWsMessage(msg);
        };
        WebSocketService.getInstance().onMessage(this.wsCallback);
    }
    private handleWsMessage(msg: WsMessage): void {
        if (msg.type === 'user_status') {
            const data: Record<string, Object> = msg.data as Record<string, Object>;
            const uid: number = (data['userId'] as number) ?? 0;
            const online: boolean = (data['online'] as boolean) ?? false;
            this.updateOnlineUser(uid, online);
            return;
        }
        if (msg.type === 'online_users_loaded') {
            this.refreshOnlineUsersFromSocket();
            return;
        }
        if (msg.type === 'connection_state') {
            const data: Record<string, Object> = msg.data as Record<string, Object>;
            const state: string = (data['state'] as string) ?? '';
            if (state === 'connected') {
                this.loadData(false);
            }
            return;
        }
        if (msg.type === 'message') {
            const item: ChatMessage = this.parseWsChatMessage(msg.data);
            this.updateConversationByMessage(item);
            return;
        }
        if (msg.type === 'unread_update') {
            this.loadData(false);
        }
    }
    private parseWsChatMessage(data: Object): ChatMessage {
        const obj: Record<string, Object> = data as Record<string, Object>;
        const item: ChatMessage = new ChatMessage();
        item.id = (obj['id'] as number) ?? 0;
        item.conversationId = (obj['conversationId'] as number) ?? 0;
        item.senderId = (obj['senderId'] as number) ?? 0;
        item.content = (obj['content'] as string) ?? '';
        item.msgType = (obj['msgType'] as string) ?? 'text';
        item.createTime = (obj['createTime'] as string) ?? '';
        item.isMine = item.senderId === AppStore.getInstance().userInfo.id;
        return item;
    }
    private updateOnlineUser(userId: number, online: boolean): void {
        if (userId <= 0) {
            return;
        }
        const next: number[] = [];
        let exists: boolean = false;
        for (let i = 0; i < this.onlineUserIds.length; i++) {
            if (this.onlineUserIds[i] === userId) {
                exists = true;
                if (online) {
                    next.push(this.onlineUserIds[i]);
                }
            }
            else {
                next.push(this.onlineUserIds[i]);
            }
        }
        if (online && !exists) {
            next.push(userId);
        }
        this.onlineUserIds = next;
    }
    private refreshOnlineUsersFromSocket(): void {
        const next: number[] = [];
        for (let i = 0; i < this.conversations.length; i++) {
            const userId: number = this.conversations[i].otherUserId;
            if (WebSocketService.getInstance().isUserOnline(userId)) {
                next.push(userId);
            }
        }
        this.onlineUserIds = next;
    }
    private updateConversationByMessage(message: ChatMessage): void {
        if (message.conversationId <= 0) {
            return;
        }
        const next: Conversation[] = [];
        let found: boolean = false;
        for (let i = 0; i < this.conversations.length; i++) {
            const source: Conversation = this.conversations[i];
            if (source.id === message.conversationId) {
                const updated: Conversation = new Conversation();
                updated.id = source.id;
                updated.otherUserId = source.otherUserId;
                updated.otherUserName = source.otherUserName;
                updated.otherUserAvatar = source.otherUserAvatar;
                updated.lastMessage = this.messagePreviewByType(message.msgType, message.content);
                updated.lastTime = message.createTime;
                updated.unreadCount = message.isMine ? source.unreadCount : source.unreadCount + 1;
                updated.productId = source.productId;
                next.unshift(updated);
                found = true;
            }
            else {
                next.push(source);
            }
        }
        if (found) {
            this.conversations = next;
        }
        else {
            this.loadData(false);
        }
    }
    private isOnline(userId: number): boolean {
        for (let i = 0; i < this.onlineUserIds.length; i++) {
            if (this.onlineUserIds[i] === userId) {
                return true;
            }
        }
        return false;
    }
    private shouldShow(item: Conversation): boolean {
        const key: string = this.keyword.trim();
        if (key.length === 0) {
            return true;
        }
        return item.otherUserName.indexOf(key) >= 0 || item.lastMessage.indexOf(key) >= 0;
    }
    private messagePreviewByType(msgType: string, content: string): string {
        if (msgType === 'image') {
            return '[图片]';
        }
        if (msgType === 'product') {
            return '[商品卡片]';
        }
        return content;
    }
    private formatTime(text: string): string {
        if (text.length === 0) {
            return '';
        }
        const value: string = text.replace('T', ' ');
        if (value.length >= 16) {
            return value.substring(5, 16);
        }
        return value;
    }
    private previewText(item: Conversation): string {
        if (item.lastMessage.length === 0) {
            return '暂无消息';
        }
        return item.lastMessage;
    }
    private markConversationReadLocally(conversationId: number): void {
        const nextList: Conversation[] = [];
        for (let i = 0; i < this.conversations.length; i++) {
            const source: Conversation = this.conversations[i];
            if (source.id === conversationId) {
                const updated: Conversation = new Conversation();
                updated.id = source.id;
                updated.otherUserId = source.otherUserId;
                updated.otherUserName = source.otherUserName;
                updated.otherUserAvatar = source.otherUserAvatar;
                updated.lastMessage = source.lastMessage;
                updated.lastTime = source.lastTime;
                updated.unreadCount = 0;
                updated.productId = source.productId;
                nextList.push(updated);
            }
            else {
                nextList.push(source);
            }
        }
        this.conversations = nextList;
    }
    private goChat(item: Conversation): void {
        this.markConversationReadLocally(item.id);
        router.pushUrl({
            url: 'pages/ChatPage',
            params: {
                'conversationId': item.id.toString(),
                'otherUserId': item.otherUserId.toString(),
                'otherUserName': item.otherUserName,
                'productId': item.productId.toString()
            } as Record<string, string>
        });
    }
    ConversationCell(item: Conversation, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.shouldShow(item)) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(287:7)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 16, right: 16, top: 14, bottom: 14 });
                        Row.backgroundColor('#FFFFFF');
                        Row.onClick(() => { this.goChat(item); });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Stack.create({ alignContent: Alignment.BottomEnd });
                        Stack.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(288:9)", "entry");
                        Stack.width(50);
                        Stack.height(50);
                    }, Stack);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(item.otherUserName.length > 0 ? item.otherUserName.substring(0, 1) : '聊');
                        Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(289:11)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor('#FFFFFF');
                        Text.width(48);
                        Text.height(48);
                        Text.borderRadius(24);
                        Text.textAlign(TextAlign.Center);
                        Text.backgroundColor(Theme.primary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.isOnline(item.otherUserId)) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('');
                                    Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(295:13)", "entry");
                                    Text.width(11);
                                    Text.height(11);
                                    Text.borderRadius(6);
                                    Text.backgroundColor(Theme.success);
                                    Text.border({ width: 2, color: '#FFFFFF' });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Stack.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(302:9)", "entry");
                        Column.layoutWeight(1);
                        Column.margin({ left: 12 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(303:11)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(item.otherUserName.length > 0 ? item.otherUserName : '用户');
                        Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(304:13)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.maxLines(1);
                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                        Text.layoutWeight(1);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(item.lastTime));
                        Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(308:13)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(311:11)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.previewText(item));
                        Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(312:13)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(item.unreadCount > 0 ? Theme.textPrimary : Theme.textTertiary);
                        Text.maxLines(1);
                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                        Text.layoutWeight(1);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (item.unreadCount > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(item.unreadCount > 99 ? '99+' : item.unreadCount.toString());
                                    Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(317:15)", "entry");
                                    Text.fontSize(11);
                                    Text.fontColor('#FFFFFF');
                                    Text.textAlign(TextAlign.Center);
                                    Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                                    Text.borderRadius(10);
                                    Text.backgroundColor(Theme.danger);
                                    Text.margin({ left: 8 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Row.pop();
                    Column.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(334:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#FFFFFF');
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '会话',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create('刷新');
                                Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(336:9)", "entry");
                                Text.fontSize(14);
                                Text.fontColor(Theme.primary);
                                Text.onClick(() => { this.loadData(); });
                            }, Text);
                            Text.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ConversationListPage.ets", line: 335, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '会话',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('刷新');
                                    Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(336:9)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.primary);
                                    Text.onClick(() => { this.loadData(); });
                                }, Text);
                                Text.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '会话'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(340:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先登录');
                        Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(341:11)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('登录后可以查看买卖双方的会话');
                        Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(342:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('去登录');
                        Button.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(343:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.primary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 20 });
                        Button.onClick(() => { router.pushUrl({ url: 'pages/LoginPage' }); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else if (this.isLoading) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(349:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(350:11)", "entry");
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                        LoadingProgress.color(Theme.primary);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在加载会话');
                        Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(351:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(354:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(355:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('重试');
                        Button.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(356:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.backgroundColor(Theme.primary);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ top: 18 });
                        Button.onClick(() => { this.loadData(); });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(362:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Start);
                        Column.backgroundColor('#FFFFFF');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '搜索联系人或消息', text: this.keyword });
                        TextInput.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(363:11)", "entry");
                        TextInput.height(40);
                        TextInput.fontSize(14);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(20);
                        TextInput.margin({ left: 16, right: 16, top: 12, bottom: 12 });
                        TextInput.onChange((value: string) => { this.keyword = value; });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.conversations.length === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(369:13)", "entry");
                                    Column.width('100%');
                                    Column.padding({ top: 40, left: 16, right: 16 });
                                    Column.alignItems(HorizontalAlign.Center);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('暂无会话');
                                    Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(370:15)", "entry");
                                    Text.fontSize(18);
                                    Text.fontWeight(FontWeight.Medium);
                                    Text.fontColor(Theme.textPrimary);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('从商品详情页联系卖家后，会话会显示在这里');
                                    Text.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(371:15)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textSecondary);
                                    Text.margin({ top: 8 });
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    List.create();
                                    List.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(377:13)", "entry");
                                    List.width('100%');
                                    List.layoutWeight(1);
                                    List.backgroundColor('#FFFFFF');
                                }, List);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        {
                                            const itemCreation = (elmtId, isInitialRender) => {
                                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                ListItem.create(deepRenderFunction, true);
                                                if (!isInitialRender) {
                                                    ListItem.pop();
                                                }
                                                ViewStackProcessor.StopGetAccessRecording();
                                            };
                                            const itemCreation2 = (elmtId, isInitialRender) => {
                                                ListItem.create(deepRenderFunction, true);
                                                ListItem.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(379:17)", "entry");
                                            };
                                            const deepRenderFunction = (elmtId, isInitialRender) => {
                                                itemCreation(elmtId, isInitialRender);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Column.create();
                                                    Column.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(380:19)", "entry");
                                                    Column.width('100%');
                                                }, Column);
                                                this.ConversationCell.bind(this)(item);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Divider.create();
                                                    Divider.debugLine("entry/src/main/ets/pages/ConversationListPage.ets(382:21)", "entry");
                                                    Divider.height(1);
                                                    Divider.color(Theme.divider);
                                                    Divider.margin({ left: 78 });
                                                }, Divider);
                                                Column.pop();
                                                ListItem.pop();
                                            };
                                            this.observeComponentCreation2(itemCreation2, ListItem);
                                            ListItem.pop();
                                        }
                                    };
                                    this.forEachUpdateFunction(elmtId, this.conversations, forEachItemGenFunction, (item: Conversation) => `${item.id}-${item.lastTime}-${item.unreadCount}-${item.lastMessage}`, false, false);
                                }, ForEach);
                                ForEach.pop();
                                List.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "ConversationListPage";
    }
}
registerNamedRoute(() => new ConversationListPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/ConversationListPage", pageFullPath: "entry/src/main/ets/pages/ConversationListPage", integratedHsp: "false", moduleType: "followWithHap" });
