if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface EmptyRoomPage_Params {
    buildings?: string[];
    selectedBuilding?: string;
    selectedDayOfWeek?: number;
    selectedStartSection?: number;
    selectedEndSection?: number;
    selectedWeek?: number;
    rooms?: EmptyRoom[];
    isLoading?: boolean;
    hasSearched?: boolean;
    errorMessage?: string;
}
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { EmptyRoom, Semester } from '../model/Models';
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/Constants&";
import { calcSemesterWeek } from "@normalized:N&&&entry/src/main/ets/common/utils&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const DAY_LABELS: string[] = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
const WEEK_LABELS: string[] = [
    '不限周次', '第1周', '第2周', '第3周', '第4周', '第5周', '第6周', '第7周', '第8周', '第9周',
    '第10周', '第11周', '第12周', '第13周', '第14周', '第15周', '第16周', '第17周', '第18周', '第19周', '第20周'
];
class EmptyRoomPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__buildings = new ObservedPropertyObjectPU([], this, "buildings");
        this.__selectedBuilding = new ObservedPropertySimplePU('', this, "selectedBuilding");
        this.__selectedDayOfWeek = new ObservedPropertySimplePU(1, this, "selectedDayOfWeek");
        this.__selectedStartSection = new ObservedPropertySimplePU(1, this, "selectedStartSection");
        this.__selectedEndSection = new ObservedPropertySimplePU(2, this, "selectedEndSection");
        this.__selectedWeek = new ObservedPropertySimplePU(0, this, "selectedWeek");
        this.__rooms = new ObservedPropertyObjectPU([], this, "rooms");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__hasSearched = new ObservedPropertySimplePU(false, this, "hasSearched");
        this.__errorMessage = new ObservedPropertySimplePU('', this, "errorMessage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: EmptyRoomPage_Params) {
        if (params.buildings !== undefined) {
            this.buildings = params.buildings;
        }
        if (params.selectedBuilding !== undefined) {
            this.selectedBuilding = params.selectedBuilding;
        }
        if (params.selectedDayOfWeek !== undefined) {
            this.selectedDayOfWeek = params.selectedDayOfWeek;
        }
        if (params.selectedStartSection !== undefined) {
            this.selectedStartSection = params.selectedStartSection;
        }
        if (params.selectedEndSection !== undefined) {
            this.selectedEndSection = params.selectedEndSection;
        }
        if (params.selectedWeek !== undefined) {
            this.selectedWeek = params.selectedWeek;
        }
        if (params.rooms !== undefined) {
            this.rooms = params.rooms;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.hasSearched !== undefined) {
            this.hasSearched = params.hasSearched;
        }
        if (params.errorMessage !== undefined) {
            this.errorMessage = params.errorMessage;
        }
    }
    updateStateVars(params: EmptyRoomPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__buildings.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedBuilding.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDayOfWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedStartSection.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedEndSection.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__rooms.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__hasSearched.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMessage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__buildings.aboutToBeDeleted();
        this.__selectedBuilding.aboutToBeDeleted();
        this.__selectedDayOfWeek.aboutToBeDeleted();
        this.__selectedStartSection.aboutToBeDeleted();
        this.__selectedEndSection.aboutToBeDeleted();
        this.__selectedWeek.aboutToBeDeleted();
        this.__rooms.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__hasSearched.aboutToBeDeleted();
        this.__errorMessage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __buildings: ObservedPropertyObjectPU<string[]>;
    get buildings() {
        return this.__buildings.get();
    }
    set buildings(newValue: string[]) {
        this.__buildings.set(newValue);
    }
    private __selectedBuilding: ObservedPropertySimplePU<string>;
    get selectedBuilding() {
        return this.__selectedBuilding.get();
    }
    set selectedBuilding(newValue: string) {
        this.__selectedBuilding.set(newValue);
    }
    private __selectedDayOfWeek: ObservedPropertySimplePU<number>;
    get selectedDayOfWeek() {
        return this.__selectedDayOfWeek.get();
    }
    set selectedDayOfWeek(newValue: number) {
        this.__selectedDayOfWeek.set(newValue);
    }
    private __selectedStartSection: ObservedPropertySimplePU<number>;
    get selectedStartSection() {
        return this.__selectedStartSection.get();
    }
    set selectedStartSection(newValue: number) {
        this.__selectedStartSection.set(newValue);
    }
    private __selectedEndSection: ObservedPropertySimplePU<number>;
    get selectedEndSection() {
        return this.__selectedEndSection.get();
    }
    set selectedEndSection(newValue: number) {
        this.__selectedEndSection.set(newValue);
    }
    private __selectedWeek: ObservedPropertySimplePU<number>;
    get selectedWeek() {
        return this.__selectedWeek.get();
    }
    set selectedWeek(newValue: number) {
        this.__selectedWeek.set(newValue);
    }
    private __rooms: ObservedPropertyObjectPU<EmptyRoom[]>;
    get rooms() {
        return this.__rooms.get();
    }
    set rooms(newValue: EmptyRoom[]) {
        this.__rooms.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __hasSearched: ObservedPropertySimplePU<boolean>;
    get hasSearched() {
        return this.__hasSearched.get();
    }
    set hasSearched(newValue: boolean) {
        this.__hasSearched.set(newValue);
    }
    private __errorMessage: ObservedPropertySimplePU<string>;
    get errorMessage() {
        return this.__errorMessage.get();
    }
    set errorMessage(newValue: string) {
        this.__errorMessage.set(newValue);
    }
    aboutToAppear(): void {
        this.initPage();
    }
    private async initPage(): Promise<void> {
        this.selectedDayOfWeek = this.todayDayOfWeek();
        await this.loadCurrentWeek();
        await this.loadBuildings();
        await this.searchRooms();
    }
    private todayDayOfWeek(): number {
        const day: number = new Date().getDay();
        return day === 0 ? 7 : day;
    }
    private async loadBuildings(): Promise<void> {
        try {
            this.buildings = await ApiService.getBuildings();
        }
        catch (_err) {
            this.buildings = [];
        }
    }
    private async loadCurrentWeek(): Promise<void> {
        try {
            const result: ApiResult = await ApiService.getCurrentSemester();
            if (result.code === 200 && result.data !== undefined) {
                const semester: Semester = ApiService.parseSemester(result.data);
                this.selectedWeek = calcSemesterWeek(semester.startDate, semester.weekCount);
                return;
            }
        }
        catch (_err) {
        }
        this.selectedWeek = 1;
    }
    private sectionText(section: number): string {
        if (section >= 1 && section <= Constants.SECTION_TIMES.length) {
            const time: string[] = Constants.SECTION_TIMES[section - 1];
            return `第${section}节 ${time[0]}-${time[1]}`;
        }
        return `第${section}节`;
    }
    private selectedBuildingText(): string {
        return this.selectedBuilding.length > 0 ? this.selectedBuilding : '全部教学楼';
    }
    private selectedDayText(): string {
        return DAY_LABELS[this.selectedDayOfWeek - 1];
    }
    private selectedWeekText(): string {
        return this.selectedWeek > 0 ? `第${this.selectedWeek}周` : '不限周次';
    }
    private sectionRangeText(): string {
        if (this.selectedStartSection === this.selectedEndSection) {
            return this.sectionText(this.selectedStartSection);
        }
        return `第${this.selectedStartSection}-${this.selectedEndSection}节`;
    }
    private filterValueText(type: number): string {
        if (type === 1) {
            return this.selectedBuildingText();
        }
        if (type === 2) {
            return this.selectedDayText();
        }
        if (type === 3) {
            return this.sectionText(this.selectedStartSection);
        }
        if (type === 4) {
            return this.sectionText(this.selectedEndSection);
        }
        if (type === 5) {
            return this.selectedWeekText();
        }
        return '';
    }
    private projectorText(room: EmptyRoom): string {
        return room.hasProjector === 1 ? '有投影' : '无投影';
    }
    private acText(room: EmptyRoom): string {
        return room.hasAc === 1 ? '有空调' : '无空调';
    }
    private roomTitle(room: EmptyRoom): string {
        return room.roomNo;
    }
    private roomKey(room: EmptyRoom): string {
        if (room.id > 0) {
            return `${room.id}`;
        }
        return `${room.building}-${room.roomNo}`;
    }
    private resetSearchResult(): void {
        this.rooms = [];
        this.hasSearched = false;
        this.errorMessage = '';
    }
    private async searchRooms(): Promise<void> {
        if (this.selectedDayOfWeek <= 0 || this.selectedStartSection <= 0 || this.selectedEndSection <= 0) {
            this.errorMessage = '请选择星期和节次';
            return;
        }
        if (this.selectedEndSection < this.selectedStartSection) {
            this.errorMessage = '结束节次不能早于开始节次';
            return;
        }
        this.isLoading = true;
        this.errorMessage = '';
        this.hasSearched = true;
        this.rooms = [];
        try {
            let result: EmptyRoom[] = await ApiService.getEmptyRooms(this.selectedBuilding, this.selectedDayOfWeek, this.selectedStartSection, this.selectedWeek);
            for (let section = this.selectedStartSection + 1; section <= this.selectedEndSection; section++) {
                const sectionRooms: EmptyRoom[] = await ApiService.getEmptyRooms(this.selectedBuilding, this.selectedDayOfWeek, section, this.selectedWeek);
                const keys: string[] = [];
                for (let i = 0; i < sectionRooms.length; i++) {
                    keys.push(this.roomKey(sectionRooms[i]));
                }
                const next: EmptyRoom[] = [];
                for (let i = 0; i < result.length; i++) {
                    if (keys.indexOf(this.roomKey(result[i])) >= 0) {
                        next.push(result[i]);
                    }
                }
                result = next;
                if (result.length === 0) {
                    break;
                }
            }
            this.rooms = result;
        }
        catch (_err) {
            this.rooms = [];
            this.errorMessage = '空教室加载失败，请检查网络或后端服务';
        }
        finally {
            this.isLoading = false;
        }
    }
    private showBuildingPicker(): void {
        const options: string[] = ['全部教学楼'];
        for (let i = 0; i < this.buildings.length; i++) {
            options.push(this.buildings[i]);
        }
        let currentIdx: number = this.selectedBuilding.length > 0 ? options.indexOf(this.selectedBuilding) : 0;
        if (currentIdx < 0) {
            currentIdx = 0;
        }
        TextPickerDialog.show({
            range: options,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.selectedBuilding = idx === 0 ? '' : options[idx];
                    this.resetSearchResult();
                }
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.selectedBuilding = idx === 0 ? '' : options[idx];
                    this.resetSearchResult();
                }
            }
        });
    }
    private showDayPicker(): void {
        let currentIdx: number = this.selectedDayOfWeek - 1;
        TextPickerDialog.show({
            range: DAY_LABELS,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < DAY_LABELS.length) {
                    this.selectedDayOfWeek = idx + 1;
                    this.resetSearchResult();
                }
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < DAY_LABELS.length) {
                    this.selectedDayOfWeek = idx + 1;
                    this.resetSearchResult();
                }
            }
        });
    }
    private showStartSectionPicker(): void {
        const options: string[] = [];
        for (let i = 1; i <= Constants.SECTION_TIMES.length; i++) {
            options.push(this.sectionText(i));
        }
        let currentIdx: number = this.selectedStartSection - 1;
        TextPickerDialog.show({
            range: options,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.selectedStartSection = idx + 1;
                    if (this.selectedEndSection < this.selectedStartSection) {
                        this.selectedEndSection = this.selectedStartSection;
                    }
                    this.resetSearchResult();
                }
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.selectedStartSection = idx + 1;
                    if (this.selectedEndSection < this.selectedStartSection) {
                        this.selectedEndSection = this.selectedStartSection;
                    }
                    this.resetSearchResult();
                }
            }
        });
    }
    private showEndSectionPicker(): void {
        const options: string[] = [];
        for (let i = 1; i <= Constants.SECTION_TIMES.length; i++) {
            options.push(this.sectionText(i));
        }
        let currentIdx: number = this.selectedEndSection - 1;
        TextPickerDialog.show({
            range: options,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.selectedEndSection = idx + 1;
                    if (this.selectedEndSection < this.selectedStartSection) {
                        this.selectedStartSection = this.selectedEndSection;
                    }
                    this.resetSearchResult();
                }
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < options.length) {
                    this.selectedEndSection = idx + 1;
                    if (this.selectedEndSection < this.selectedStartSection) {
                        this.selectedStartSection = this.selectedEndSection;
                    }
                    this.resetSearchResult();
                }
            }
        });
    }
    private showWeekPicker(): void {
        let currentIdx: number = this.selectedWeek;
        TextPickerDialog.show({
            range: WEEK_LABELS,
            selected: currentIdx,
            onChange: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < WEEK_LABELS.length) {
                    this.selectedWeek = idx;
                    this.resetSearchResult();
                }
            },
            onAccept: (value: TextPickerResult) => {
                const idx: number = value.index as number;
                if (idx >= 0 && idx < WEEK_LABELS.length) {
                    this.selectedWeek = idx;
                    this.resetSearchResult();
                }
            }
        });
    }
    private goSchedule(room: EmptyRoom): void {
        this.getUIContext().getRouter().pushUrl({
            url: 'pages/RoomSchedulePage',
            params: {
                'classroom': this.roomTitle(room),
                'dayOfWeek': `${this.selectedDayOfWeek}`
            } as Record<string, string>
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(335:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '空教室查询' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/EmptyRoomPage.ets", line: 336, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '空教室查询'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '空教室查询'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(338:7)", "entry");
            Column.padding({ left: 16, right: 16, top: 16, bottom: 16 });
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(Theme.cardRadius);
            Column.shadow(ShadowStyle.nmRaisedLg);
            Column.margin({ left: 16, right: 16, top: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(339:9)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('查找空教室');
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(340:11)", "entry");
            Text.fontSize(Theme.fsTitle);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(344:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.selectedWeekText());
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(345:11)", "entry");
            Text.fontSize(Theme.fsCaption);
            Text.fontColor(Theme.primary);
            Text.padding({ left: 10, right: 10, top: 5, bottom: 5 });
            Text.backgroundColor(Theme.primaryLight);
            Text.borderRadius(Theme.chipRadius);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(355:9)", "entry");
            Row.width('100%');
        }, Row);
        this.FilterItem.bind(this)('教学楼', 1);
        this.FilterItem.bind(this)('星期', 2);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(361:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.FilterItem.bind(this)('开始节次', 3);
        this.FilterItem.bind(this)('结束节次', 4);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(368:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.FilterItem.bind(this)('周次', 5);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.isLoading ? '查询中...' : '查询空教室');
            Button.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(374:9)", "entry");
            Button.width('100%');
            Button.height(44);
            Button.fontSize(16);
            Button.fontWeight(FontWeight.Medium);
            Button.fontColor(Color.White);
            Button.backgroundColor(Theme.primary);
            Button.borderRadius(Theme.radiusPill);
            Button.shadow(ShadowStyle.sm);
            Button.enabled(!this.isLoading);
            Button.margin({ top: 14 });
            Button.onClick(() => {
                this.searchRooms();
            });
        }, Button);
        Button.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.errorMessage.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMessage);
                        Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(396:9)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.danger);
                        Text.width('100%');
                        Text.padding({ left: 16, right: 16, top: 10 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(403:7)", "entry");
            Row.width('100%');
            Row.padding({ left: 18, right: 18, top: 16, bottom: 10 });
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(404:9)", "entry");
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.hasSearched ? `共 ${this.rooms.length} 间空教室` : '请选择条件后查询');
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(405:11)", "entry");
            Text.fontSize(Theme.fsBody);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.selectedDayText()} · ${this.sectionRangeText()}`);
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(409:11)", "entry");
            Text.fontSize(Theme.fsCaption);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(415:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.selectedBuildingText());
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(416:9)", "entry");
            Text.fontSize(Theme.fsCaption);
            Text.fontColor(Theme.textSecondary);
            Text.padding({ left: 10, right: 10, top: 5, bottom: 5 });
            Text.backgroundColor(Theme.bgInput);
            Text.borderRadius(Theme.chipRadius);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading && this.rooms.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(428:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(429:11)", "entry");
                        LoadingProgress.width(32);
                        LoadingProgress.height(32);
                        LoadingProgress.color(Theme.primary);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在查询空教室');
                        Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(433:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.rooms.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(442:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.hasSearched ? '当前条件下没有空教室' : '请选择条件后查询');
                        Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(443:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.hasSearched ? '可以换一个教学楼、周次或节次再试' : '教学楼和周次可以不选');
                        Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(446:11)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(455:9)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16, bottom: 18 });
                        List.scrollBar(BarState.Off);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const room = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(457:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.RoomCard.bind(this)(room);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.rooms, forEachItemGenFunction, (room: EmptyRoom) => `${room.id}-${room.building}-${room.roomNo}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    FilterItem(label: string, type: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(475:5)", "entry");
            Column.layoutWeight(1);
            Column.height(56);
            Column.padding({ left: 12, right: 12, top: 8, bottom: 7 });
            Column.backgroundColor(Theme.bgInput);
            Column.borderRadius(18);
            Column.onClick(() => {
                if (type === 1) {
                    this.showBuildingPicker();
                }
                if (type === 2) {
                    this.showDayPicker();
                }
                if (type === 3) {
                    this.showStartSectionPicker();
                }
                if (type === 4) {
                    this.showEndSectionPicker();
                }
                if (type === 5) {
                    this.showWeekPicker();
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(476:7)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textTertiary);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(480:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 5 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.filterValueText(type));
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(481:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textPrimary);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(487:9)", "entry");
            Text.fontSize(13);
            Text.fontColor(Theme.textDisabled);
            Text.margin({ left: 6 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    RoomCard(room: EmptyRoom, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(521:5)", "entry");
            Column.width('100%');
            Column.padding({ left: 18, right: 18, top: 15, bottom: 15 });
            Column.backgroundColor(Theme.bgCard);
            Column.borderRadius(20);
            Column.shadow(ShadowStyle.nmRaised);
            Column.onClick(() => {
                this.goSchedule(room);
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(522:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(523:9)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.roomTitle(room));
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(524:11)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(room.type.length > 0 ? room.type : '普通教室');
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(528:11)", "entry");
            Text.fontSize(Theme.fsCaption);
            Text.fontColor(Theme.textSecondary);
            Text.margin({ top: 5 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('看课表');
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(536:9)", "entry");
            Text.fontSize(Theme.fsCaption);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Theme.primary);
            Text.padding({ left: 14, right: 14, top: 7, bottom: 7 });
            Text.backgroundColor(Theme.primaryLight);
            Text.borderRadius(Theme.radiusPill);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(546:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 12 });
        }, Row);
        this.Tag.bind(this)(`容量 ${room.capacity}`);
        this.Tag.bind(this)(this.projectorText(room));
        this.Tag.bind(this)(this.acText(room));
        Row.pop();
        Column.pop();
    }
    Tag(text: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(text);
            Text.debugLine("entry/src/main/ets/pages/EmptyRoomPage.ets(566:5)", "entry");
            Text.fontSize(12);
            Text.fontColor(Theme.textSecondary);
            Text.padding({ left: 10, right: 10, top: 5, bottom: 5 });
            Text.backgroundColor(Theme.bgInput);
            Text.borderRadius(Theme.chipRadius);
        }, Text);
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "EmptyRoomPage";
    }
}
registerNamedRoute(() => new EmptyRoomPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/EmptyRoomPage", pageFullPath: "entry/src/main/ets/pages/EmptyRoomPage", integratedHsp: "false", moduleType: "followWithHap" });
