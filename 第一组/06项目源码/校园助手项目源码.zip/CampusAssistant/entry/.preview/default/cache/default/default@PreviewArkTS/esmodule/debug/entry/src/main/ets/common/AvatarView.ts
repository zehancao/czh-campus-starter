if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AvatarView_Params {
    avatar?: string;
    name?: string;
    avatarSize?: number;
}
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
export class AvatarView extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__avatar = new SynchedPropertySimpleOneWayPU(params.avatar, this, "avatar");
        this.__name = new SynchedPropertySimpleOneWayPU(params.name, this, "name");
        this.avatarSize = 40;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AvatarView_Params) {
        if (params.avatar === undefined) {
            this.__avatar.set('');
        }
        if (params.name === undefined) {
            this.__name.set('');
        }
        if (params.avatarSize !== undefined) {
            this.avatarSize = params.avatarSize;
        }
    }
    updateStateVars(params: AvatarView_Params) {
        this.__avatar.reset(params.avatar);
        this.__name.reset(params.name);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__avatar.purgeDependencyOnElmtId(rmElmtId);
        this.__name.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__avatar.aboutToBeDeleted();
        this.__name.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __avatar: SynchedPropertySimpleOneWayPU<string>;
    get avatar() {
        return this.__avatar.get();
    }
    set avatar(newValue: string) {
        this.__avatar.set(newValue);
    }
    private __name: SynchedPropertySimpleOneWayPU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private avatarSize: number;
    private isImageUrl(url: string): boolean {
        return url.startsWith('/') || url.startsWith('http') || url.startsWith('https');
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isImageUrl(this.avatar)) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.avatar.startsWith('/') ? `${ApiService.baseUrl}${this.avatar}` : this.avatar);
                        Image.debugLine("entry/src/main/ets/common/AvatarView.ets(16:7)", "entry");
                        Image.width(this.avatarSize);
                        Image.height(this.avatarSize);
                        Image.borderRadius(this.avatarSize / 2);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else if (this.avatar.length > 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.avatar);
                        Text.debugLine("entry/src/main/ets/common/AvatarView.ets(22:7)", "entry");
                        Text.fontSize(this.avatarSize * 0.5);
                        Text.fontColor(Color.White);
                        Text.textAlign(TextAlign.Center);
                        Text.width(this.avatarSize);
                        Text.height(this.avatarSize);
                        Text.borderRadius(this.avatarSize / 2);
                        Text.backgroundColor(Theme.primary);
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.name.length > 0 ? this.name[0] : 'U');
                        Text.debugLine("entry/src/main/ets/common/AvatarView.ets(31:7)", "entry");
                        Text.fontSize(this.avatarSize * 0.5);
                        Text.fontColor(Color.White);
                        Text.textAlign(TextAlign.Center);
                        Text.width(this.avatarSize);
                        Text.height(this.avatarSize);
                        Text.borderRadius(this.avatarSize / 2);
                        Text.backgroundColor(Theme.primary);
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
}
