if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginPage_Params {
    studentId?: string;
    password?: string;
    isLoading?: boolean;
    errorMsg?: string;
}
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import type { ApiResult } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__studentId = new ObservedPropertySimplePU('', this, "studentId");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginPage_Params) {
        if (params.studentId !== undefined) {
            this.studentId = params.studentId;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
    }
    updateStateVars(params: LoginPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__studentId.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__studentId.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __studentId: ObservedPropertySimplePU<string>;
    get studentId() {
        return this.__studentId.get();
    }
    set studentId(newValue: string) {
        this.__studentId.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(14:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgCard);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/LoginPage.ets(15:7)", "entry");
            Blank.height(80);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('校园π');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(17:7)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Theme.textPrimary);
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Campus π');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(23:7)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textTertiary);
            Text.margin({ bottom: 60 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(28:7)", "entry");
            Column.width('85%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/LoginPage.ets(29:9)", "entry");
            Stack.width('100%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(30:11)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入学号', text: this.studentId });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(34:11)", "entry");
            TextInput.type(InputType.Normal);
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.backgroundColor('#FFFFFF');
            TextInput.borderRadius(28);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.margin({ right: 4, bottom: 4 });
            TextInput.onChange((value: string) => {
                this.studentId = value;
                this.errorMsg = '';
            });
        }, TextInput);
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/LoginPage.ets(57:9)", "entry");
            Blank.height(16);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/LoginPage.ets(59:9)", "entry");
            Stack.width('100%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(60:11)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入密码', text: this.password });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(64:11)", "entry");
            TextInput.type(InputType.Password);
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.fontSize(16);
            TextInput.placeholderColor(Theme.textDisabled);
            TextInput.backgroundColor('#FFFFFF');
            TextInput.borderRadius(28);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.margin({ right: 4, bottom: 4 });
            TextInput.onChange((value: string) => {
                this.password = value;
                this.errorMsg = '';
            });
        }, TextInput);
        Stack.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(90:9)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.danger);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/LoginPage.ets(96:7)", "entry");
            Blank.height(32);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.TopStart });
            Stack.debugLine("entry/src/main/ets/pages/LoginPage.ets(98:7)", "entry");
            Stack.width('85%');
            Stack.height(52);
            Stack.borderRadius(28);
            Stack.linearGradient({
                direction: GradientDirection.RightBottom,
                colors: [['#FFFFFF', 0.0], ['#D0D5DD', 1.0]]
            });
            Stack.clip(false);
            Stack.shadow({ radius: 16, color: '#ABB3C0', offsetX: 0, offsetY: 4 });
            Stack.enabled(!this.isLoading);
            Stack.onClick(() => {
                this.handleLogin();
            });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(99:9)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#C8CFDA');
            Column.borderRadius(28);
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(103:9)", "entry");
            Column.width('100%');
            Column.height(48);
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
            Column.borderRadius(28);
            Column.backgroundColor('#FFFFFF');
            Column.margin({ right: 4, bottom: 4 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('登 录');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(104:11)", "entry");
            Text.fontSize(18);
            Text.fontColor(Theme.textPrimary);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        Column.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/LoginPage.ets(129:7)", "entry");
            Blank.height(24);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(131:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('还没有账号？');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(132:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.textTertiary);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('立即注册');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(135:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Theme.primary);
            Text.fontWeight(FontWeight.Medium);
            Text.onClick(() => {
                this.getUIContext().getRouter().pushUrl({ url: 'pages/RegisterPage' });
            });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    private async handleLogin(): Promise<void> {
        if (this.studentId.length === 0) {
            this.errorMsg = '请输入学号';
            return;
        }
        if (this.password.length === 0) {
            this.errorMsg = '请输入密码';
            return;
        }
        this.isLoading = true;
        const result: ApiResult = await ApiService.login(this.studentId, this.password);
        this.isLoading = false;
        if (result.code === 200) {
            this.getUIContext().getPromptAction().showToast({ message: '登录成功' });
            AppStore.getInstance().pendingTab = 0;
            this.getUIContext().getRouter().replaceUrl({ url: 'pages/MainPage' });
        }
        else {
            this.errorMsg = result.msg.length > 0 ? result.msg : '登录失败';
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "LoginPage";
    }
}
registerNamedRoute(() => new LoginPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/LoginPage", pageFullPath: "entry/src/main/ets/pages/LoginPage", integratedHsp: "false", moduleType: "followWithHap" });
