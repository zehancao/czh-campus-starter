if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SafetyReportDetailPage_Params {
    report?: SafetyReport;
    isLoading?: boolean;
    handleRemark?: string;
    selectedStatus?: number;
    reportId?: number;
}
import router from "@ohos:router";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { SafetyReport } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const STATUS_LABELS: Record<string, string> = {
    '0': '待处理',
    '1': '处理中',
    '2': '已解决',
    '3': '误报'
};
const STATUS_COLORS: Record<string, string> = {
    '0': Theme.danger,
    '1': Theme.warning,
    '2': Theme.success,
    '3': Theme.textDisabled
};
const TYPE_ICONS: Record<string, string> = {
    '人身安全': '🚨',
    '财物丢失': '💰',
    '火情': '🔥',
    '医疗': '🏥',
    '其他': '⚠️'
};
class SafetyReportDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__report = new ObservedPropertyObjectPU(new SafetyReport(), this, "report");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__handleRemark = new ObservedPropertySimplePU('', this, "handleRemark");
        this.__selectedStatus = new ObservedPropertySimplePU(1, this, "selectedStatus");
        this.reportId = 0;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SafetyReportDetailPage_Params) {
        if (params.report !== undefined) {
            this.report = params.report;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.handleRemark !== undefined) {
            this.handleRemark = params.handleRemark;
        }
        if (params.selectedStatus !== undefined) {
            this.selectedStatus = params.selectedStatus;
        }
        if (params.reportId !== undefined) {
            this.reportId = params.reportId;
        }
    }
    updateStateVars(params: SafetyReportDetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__report.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__handleRemark.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedStatus.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__report.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__handleRemark.aboutToBeDeleted();
        this.__selectedStatus.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __report: ObservedPropertyObjectPU<SafetyReport>;
    get report() {
        return this.__report.get();
    }
    set report(newValue: SafetyReport) {
        this.__report.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __handleRemark: ObservedPropertySimplePU<string>;
    get handleRemark() {
        return this.__handleRemark.get();
    }
    set handleRemark(newValue: string) {
        this.__handleRemark.set(newValue);
    }
    private __selectedStatus: ObservedPropertySimplePU<number>;
    get selectedStatus() {
        return this.__selectedStatus.get();
    }
    set selectedStatus(newValue: number) {
        this.__selectedStatus.set(newValue);
    }
    private reportId: number;
    aboutToAppear(): void {
        const params: Record<string, string> = router.getParams() as Record<string, string>;
        if (params !== null && params !== undefined && params['id'] !== undefined) {
            this.reportId = parseInt(params['id'], 10);
        }
        this.loadDetail();
    }
    private async loadDetail(): Promise<void> {
        this.isLoading = true;
        const result = await ApiService.getSafetyDetail(this.reportId);
        if (result.code === 200 && result.data !== undefined) {
            const obj: Record<string, Object> = result.data as Record<string, Object>;
            this.report = new SafetyReport();
            this.report.id = (obj['id'] as number) ?? 0;
            this.report.userId = (obj['userId'] as number) ?? 0;
            this.report.reporterName = (obj['reporterName'] as string) ?? '';
            this.report.reporterPhone = (obj['reporterPhone'] as string) ?? '';
            this.report.type = (obj['type'] as string) ?? '';
            this.report.location = (obj['location'] as string) ?? '';
            this.report.description = (obj['description'] as string) ?? '';
            const imgObj: Object = obj['images'];
            if (imgObj !== null && imgObj !== undefined) {
                const imgArr: Object[] = imgObj as Object[];
                this.report.images = [];
                for (let j = 0; j < imgArr.length; j++) {
                    this.report.images.push(imgArr[j] as string);
                }
            }
            this.report.status = (obj['status'] as number) ?? 0;
            this.report.handlerId = (obj['handlerId'] as number) ?? 0;
            this.report.handlerName = (obj['handlerName'] as string) ?? '';
            this.report.handleRemark = (obj['handleRemark'] as string) ?? '';
            this.report.createTime = (obj['createTime'] as string) ?? '';
            this.report.handleTime = (obj['handleTime'] as string) ?? '';
        }
        this.isLoading = false;
    }
    private async doHandle(): Promise<void> {
        const result = await ApiService.handleSafetyReport(this.reportId, this.selectedStatus, this.handleRemark);
        if (result.code === 200) {
            this.loadDetail();
        }
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0)
            return '';
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16)
            return t.substring(0, 16);
        return t;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(91:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, { title: '求助详情' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/SafetyReportDetailPage.ets", line: 92, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '求助详情'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '求助详情'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(95:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(96:11)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(100:9)", "entry");
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(101:11)", "entry");
                        Column.width('100%');
                        Column.padding({ left: 16, right: 16, top: 8, bottom: 20 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(102:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                        Column.borderRadius(Theme.cardRadius);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(103:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(TYPE_ICONS[this.report.type] ?? '⚠️');
                        Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(104:17)", "entry");
                        Text.fontSize(24);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.report.type);
                        Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(105:17)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textPrimary);
                        Text.fontWeight(FontWeight.Bold);
                        Text.margin({ left: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(108:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(STATUS_LABELS[`${this.report.status}`] ?? '未知');
                        Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(109:17)", "entry");
                        Text.fontSize(12);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(STATUS_COLORS[`${this.report.status}`] ?? Theme.textTertiary);
                        Text.padding({ left: 10, right: 10, top: 3, bottom: 3 });
                        Text.borderRadius(10);
                        Text.backgroundColor('#F3F4F6');
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.report.location.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(119:17)", "entry");
                                    Row.width('100%');
                                    Row.margin({ top: 12 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('📍');
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(120:19)", "entry");
                                    Text.fontSize(14);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.report.location);
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(121:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textSecondary);
                                    Text.margin({ left: 4 });
                                }, Text);
                                Text.pop();
                                Row.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.report.description.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(128:17)", "entry");
                                    Column.width('100%');
                                    Column.margin({ top: 12 });
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('情况描述');
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(129:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.width('100%');
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.report.description);
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(131:19)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textPrimary);
                                    Text.margin({ top: 4 });
                                    Text.width('100%');
                                    Text.lineHeight(22);
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.report.images.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(139:17)", "entry");
                                    Row.width('100%');
                                    Row.margin({ top: 12 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = (_item, index: number) => {
                                        const img = _item;
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Image.create(`${ApiService.baseUrl}${img}`);
                                            Image.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(141:21)", "entry");
                                            Image.width(80);
                                            Image.height(80);
                                            Image.borderRadius(8);
                                            Image.objectFit(ImageFit.Cover);
                                            Image.margin({ right: 6 });
                                        }, Image);
                                    };
                                    this.forEachUpdateFunction(elmtId, this.report.images, forEachItemGenFunction, (img: string, index: number) => `${index}`, true, true);
                                }, ForEach);
                                ForEach.pop();
                                Row.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(149:15)", "entry");
                        Divider.margin({ top: 12, bottom: 12 });
                        Divider.color(Theme.border);
                    }, Divider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(151:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('报告人：');
                        Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(152:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.report.reporterName);
                        Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(154:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.report.reporterPhone.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.report.reporterPhone);
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(157:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.primary);
                                    Text.margin({ left: 8 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(163:15)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 6 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('报告时间：');
                        Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(164:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(this.report.createTime));
                        Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(166:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.report.status > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(177:15)", "entry");
                                    Column.width('100%');
                                    Column.padding(16);
                                    Column.backgroundColor('#FFFFFF');
                                    Column.borderRadius(Theme.cardRadius);
                                    Column.margin({ top: 10 });
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('处理信息');
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(178:17)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textPrimary);
                                    Text.fontWeight(FontWeight.Medium);
                                    Text.width('100%');
                                    Text.margin({ bottom: 8 });
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(182:17)", "entry");
                                    Row.width('100%');
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('处理人：');
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(183:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textTertiary);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.report.handlerName);
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(185:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textPrimary);
                                }, Text);
                                Text.pop();
                                Row.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(190:17)", "entry");
                                    Row.width('100%');
                                    Row.margin({ top: 6 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('处理时间：');
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(191:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textTertiary);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.formatTime(this.report.handleTime));
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(193:19)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(Theme.textPrimary);
                                }, Text);
                                Text.pop();
                                Row.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.report.handleRemark.length > 0) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Column.create();
                                                Column.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(199:19)", "entry");
                                                Column.width('100%');
                                                Column.margin({ top: 6 });
                                            }, Column);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('处理备注：');
                                                Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(200:21)", "entry");
                                                Text.fontSize(12);
                                                Text.fontColor(Theme.textTertiary);
                                                Text.width('100%');
                                            }, Text);
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create(this.report.handleRemark);
                                                Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(202:21)", "entry");
                                                Text.fontSize(13);
                                                Text.fontColor(Theme.textPrimary);
                                                Text.margin({ top: 2 });
                                                Text.width('100%');
                                            }, Text);
                                            Text.pop();
                                            Column.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.report.status === 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(216:15)", "entry");
                                    Column.width('100%');
                                    Column.padding(16);
                                    Column.backgroundColor('#FFFFFF');
                                    Column.borderRadius(Theme.cardRadius);
                                    Column.margin({ top: 10 });
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('处理此求助');
                                    Text.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(217:17)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Theme.textPrimary);
                                    Text.fontWeight(FontWeight.Medium);
                                    Text.width('100%');
                                    Text.margin({ bottom: 8 });
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create({ space: 8 });
                                    Row.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(221:17)", "entry");
                                    Row.width('100%');
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('处理中');
                                    Button.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(222:19)", "entry");
                                    Button.fontSize(12);
                                    Button.height(32);
                                    Button.type(ButtonType.Normal);
                                    Button.backgroundColor(this.selectedStatus === 1 ? Theme.warning : '#F3F4F6');
                                    Button.fontColor(this.selectedStatus === 1 ? '#FFFFFF' : Theme.textSecondary);
                                    Button.borderRadius(16);
                                    Button.onClick(() => { this.selectedStatus = 1; });
                                }, Button);
                                Button.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('已解决');
                                    Button.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(229:19)", "entry");
                                    Button.fontSize(12);
                                    Button.height(32);
                                    Button.type(ButtonType.Normal);
                                    Button.backgroundColor(this.selectedStatus === 2 ? Theme.success : '#F3F4F6');
                                    Button.fontColor(this.selectedStatus === 2 ? '#FFFFFF' : Theme.textSecondary);
                                    Button.borderRadius(16);
                                    Button.onClick(() => { this.selectedStatus = 2; });
                                }, Button);
                                Button.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('误报');
                                    Button.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(236:19)", "entry");
                                    Button.fontSize(12);
                                    Button.height(32);
                                    Button.type(ButtonType.Normal);
                                    Button.backgroundColor(this.selectedStatus === 3 ? Theme.textDisabled : '#F3F4F6');
                                    Button.fontColor(this.selectedStatus === 3 ? '#FFFFFF' : Theme.textSecondary);
                                    Button.borderRadius(16);
                                    Button.onClick(() => { this.selectedStatus = 3; });
                                }, Button);
                                Button.pop();
                                Row.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    TextInput.create({ placeholder: '处理备注（可选）', text: this.handleRemark });
                                    TextInput.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(245:17)", "entry");
                                    TextInput.fontSize(13);
                                    TextInput.width('100%');
                                    TextInput.height(40);
                                    TextInput.margin({ top: 8 });
                                    TextInput.backgroundColor('#F3F4F6');
                                    TextInput.borderRadius(8);
                                    TextInput.onChange((value: string) => { this.handleRemark = value; });
                                }, TextInput);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('提交处理');
                                    Button.debugLine("entry/src/main/ets/pages/SafetyReportDetailPage.ets(250:17)", "entry");
                                    Button.width('100%');
                                    Button.height(40);
                                    Button.type(ButtonType.Normal);
                                    Button.backgroundColor(Theme.primary);
                                    Button.fontColor('#FFFFFF');
                                    Button.borderRadius(Theme.radiusMd);
                                    Button.fontSize(14);
                                    Button.margin({ top: 8 });
                                    Button.onClick(() => { this.doHandle(); });
                                }, Button);
                                Button.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "SafetyReportDetailPage";
    }
}
registerNamedRoute(() => new SafetyReportDetailPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/SafetyReportDetailPage", pageFullPath: "entry/src/main/ets/pages/SafetyReportDetailPage", integratedHsp: "false", moduleType: "followWithHap" });
