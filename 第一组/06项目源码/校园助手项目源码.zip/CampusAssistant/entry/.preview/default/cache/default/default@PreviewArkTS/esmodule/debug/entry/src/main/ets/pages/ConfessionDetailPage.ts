if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ConfessionDetailPage_Params {
    post?: ConfessionPost;
    comments?: ConfessionComment[];
    images?: string[];
    isLoading?: boolean;
    isMyPost?: boolean;
    errorMsg?: string;
    commentInput?: string;
    commentAnonymous?: number;
    isSubmitting?: boolean;
    swiperIndex?: number;
    postId?: number;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/service/ApiService&";
import { AppStore } from "@normalized:N&&&entry/src/main/ets/service/AppStore&";
import { ConfessionPost, ConfessionComment } from "@normalized:N&&&entry/src/main/ets/model/Models&";
import { Theme, ShadowStyle } from "@normalized:N&&&entry/src/main/ets/common/Theme&";
import { NavHeader } from "@normalized:N&&&entry/src/main/ets/common/NavHeader&";
const CATEGORY_COLORS: Record<string, string> = {
    '表白': '#DB2777',
    '树洞': Theme.ocean,
    '吐槽': Theme.primary,
    '交友': '#7C3AED'
};
const CATEGORY_BG: Record<string, string> = {
    '表白': '#FCE7F3',
    '树洞': Theme.oceanLight,
    '吐槽': Theme.primaryLight,
    '交友': '#F3E8FF'
};
function splitImageString(imagesStr: string): string[] {
    if (imagesStr === null || imagesStr === undefined || imagesStr.length === 0)
        return [];
    const cleaned: string = imagesStr.replace('[', '').replace(']', '').replace(new RegExp('"', 'g'), '');
    if (cleaned.length === 0)
        return [];
    return cleaned.split(',');
}
class ConfessionDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__post = new ObservedPropertyObjectPU(new ConfessionPost(), this, "post");
        this.__comments = new ObservedPropertyObjectPU([], this, "comments");
        this.__images = new ObservedPropertyObjectPU([], this, "images");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isMyPost = new ObservedPropertySimplePU(false, this, "isMyPost");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.__commentInput = new ObservedPropertySimplePU('', this, "commentInput");
        this.__commentAnonymous = new ObservedPropertySimplePU(0, this, "commentAnonymous");
        this.__isSubmitting = new ObservedPropertySimplePU(false, this, "isSubmitting");
        this.__swiperIndex = new ObservedPropertySimplePU(0, this, "swiperIndex");
        this.postId = 0;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ConfessionDetailPage_Params) {
        if (params.post !== undefined) {
            this.post = params.post;
        }
        if (params.comments !== undefined) {
            this.comments = params.comments;
        }
        if (params.images !== undefined) {
            this.images = params.images;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isMyPost !== undefined) {
            this.isMyPost = params.isMyPost;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
        if (params.commentInput !== undefined) {
            this.commentInput = params.commentInput;
        }
        if (params.commentAnonymous !== undefined) {
            this.commentAnonymous = params.commentAnonymous;
        }
        if (params.isSubmitting !== undefined) {
            this.isSubmitting = params.isSubmitting;
        }
        if (params.swiperIndex !== undefined) {
            this.swiperIndex = params.swiperIndex;
        }
        if (params.postId !== undefined) {
            this.postId = params.postId;
        }
    }
    updateStateVars(params: ConfessionDetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__post.purgeDependencyOnElmtId(rmElmtId);
        this.__comments.purgeDependencyOnElmtId(rmElmtId);
        this.__images.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isMyPost.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
        this.__commentInput.purgeDependencyOnElmtId(rmElmtId);
        this.__commentAnonymous.purgeDependencyOnElmtId(rmElmtId);
        this.__isSubmitting.purgeDependencyOnElmtId(rmElmtId);
        this.__swiperIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__post.aboutToBeDeleted();
        this.__comments.aboutToBeDeleted();
        this.__images.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isMyPost.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        this.__commentInput.aboutToBeDeleted();
        this.__commentAnonymous.aboutToBeDeleted();
        this.__isSubmitting.aboutToBeDeleted();
        this.__swiperIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __post: ObservedPropertyObjectPU<ConfessionPost>;
    get post() {
        return this.__post.get();
    }
    set post(newValue: ConfessionPost) {
        this.__post.set(newValue);
    }
    private __comments: ObservedPropertyObjectPU<ConfessionComment[]>;
    get comments() {
        return this.__comments.get();
    }
    set comments(newValue: ConfessionComment[]) {
        this.__comments.set(newValue);
    }
    private __images: ObservedPropertyObjectPU<string[]>;
    get images() {
        return this.__images.get();
    }
    set images(newValue: string[]) {
        this.__images.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isMyPost: ObservedPropertySimplePU<boolean>;
    get isMyPost() {
        return this.__isMyPost.get();
    }
    set isMyPost(newValue: boolean) {
        this.__isMyPost.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    private __commentInput: ObservedPropertySimplePU<string>;
    get commentInput() {
        return this.__commentInput.get();
    }
    set commentInput(newValue: string) {
        this.__commentInput.set(newValue);
    }
    private __commentAnonymous: ObservedPropertySimplePU<number>;
    get commentAnonymous() {
        return this.__commentAnonymous.get();
    }
    set commentAnonymous(newValue: number) {
        this.__commentAnonymous.set(newValue);
    }
    private __isSubmitting: ObservedPropertySimplePU<boolean>;
    get isSubmitting() {
        return this.__isSubmitting.get();
    }
    set isSubmitting(newValue: boolean) {
        this.__isSubmitting.set(newValue);
    }
    private __swiperIndex: ObservedPropertySimplePU<number>;
    get swiperIndex() {
        return this.__swiperIndex.get();
    }
    set swiperIndex(newValue: number) {
        this.__swiperIndex.set(newValue);
    }
    private postId: number;
    aboutToAppear(): void {
        const params: Record<string, Object> = router.getParams() as Record<string, Object>;
        if (params !== undefined && params !== null) {
            const idObj: Object = params['id'];
            if (idObj !== undefined && idObj !== null) {
                this.postId = parseInt(idObj as string, 10);
            }
        }
        if (this.postId > 0) {
            this.loadDetail();
        }
        else {
            this.errorMsg = '参数错误';
            this.isLoading = false;
        }
    }
    private async loadDetail(): Promise<void> {
        this.isLoading = true;
        const result = await ApiService.getConfessionDetail(this.postId);
        if (result.code === 200 && result.data !== undefined) {
            const obj: Record<string, Object> = result.data as Record<string, Object>;
            this.post.id = (obj['id'] as number) ?? 0;
            this.post.userId = (obj['userId'] as number) ?? 0;
            this.post.publisherName = (obj['publisherName'] as string) ?? '';
            this.post.publisherAvatar = (obj['publisherAvatar'] as string) ?? '';
            this.post.content = (obj['content'] as string) ?? '';
            const imgObj: Object = obj['images'];
            if (imgObj !== null && imgObj !== undefined) {
                const imgArr: Object[] = imgObj as Object[];
                this.post.images = [];
                for (let j = 0; j < imgArr.length; j++) {
                    this.post.images.push(imgArr[j] as string);
                }
            }
            this.post.category = (obj['category'] as string) ?? '树洞';
            this.post.isAnonymous = (obj['isAnonymous'] as number) ?? 0;
            this.post.likeCount = (obj['likeCount'] as number) ?? 0;
            this.post.commentCount = (obj['commentCount'] as number) ?? 0;
            this.post.liked = (obj['liked'] as boolean) ?? false;
            this.post.status = (obj['status'] as number) ?? 0;
            this.post.createTime = (obj['createTime'] as string) ?? '';
            this.images = this.post.images;
            const commentsObj: Object = obj['comments'];
            if (commentsObj !== null && commentsObj !== undefined) {
                const arr: Object[] = commentsObj as Object[];
                this.comments = [];
                for (let i = 0; i < arr.length; i++) {
                    const c: Record<string, Object> = arr[i] as Record<string, Object>;
                    const comment: ConfessionComment = new ConfessionComment();
                    comment.id = (c['id'] as number) ?? 0;
                    comment.userId = (c['userId'] as number) ?? 0;
                    comment.nickname = (c['nickname'] as string) ?? '';
                    comment.avatar = (c['avatar'] as string) ?? '';
                    comment.content = (c['content'] as string) ?? '';
                    comment.isAnonymous = (c['isAnonymous'] as number) ?? 0;
                    comment.createTime = (c['createTime'] as string) ?? '';
                    this.comments.push(comment);
                }
            }
            const store: AppStore = AppStore.getInstance();
            if (store.isLoggedIn && store.userInfo.id === this.post.userId) {
                this.isMyPost = true;
            }
        }
        else {
            this.errorMsg = '加载失败';
        }
        this.isLoading = false;
    }
    private async toggleLike(): Promise<void> {
        const result = await ApiService.likeConfession(this.postId);
        if (result.code === 200) {
            this.loadDetail();
        }
    }
    private async submitComment(): Promise<void> {
        if (this.commentInput.trim().length === 0)
            return;
        this.isSubmitting = true;
        const result = await ApiService.commentConfession(this.postId, this.commentInput.trim(), this.commentAnonymous);
        this.isSubmitting = false;
        if (result.code === 200) {
            this.commentInput = '';
            promptAction.showToast({ message: '评论成功' });
            this.loadDetail();
        }
        else {
            promptAction.showToast({ message: '评论失败' });
        }
    }
    private deletePost(): void {
        AlertDialog.show({
            title: '确认删除',
            message: '确定要删除这条帖子吗？',
            primaryButton: { value: '取消', action: () => { } },
            confirm: {
                value: '删除',
                fontColor: Theme.danger,
                action: () => { this.doDelete(); }
            }
        });
    }
    private async doDelete(): Promise<void> {
        const result = await ApiService.deleteConfession(this.postId);
        if (result.code === 200) {
            promptAction.showToast({ message: '已删除' });
            router.back();
        }
    }
    private formatTime(timeStr: string): string {
        if (timeStr.length === 0)
            return '';
        const t: string = timeStr.replace('T', ' ');
        if (t.length > 16)
            return t.substring(0, 16);
        return t;
    }
    private getCategoryColor(): string {
        const c: string | undefined = CATEGORY_COLORS[this.post.category];
        return c !== undefined ? c : Theme.ocean;
    }
    private getCategoryBg(): string {
        const b: string | undefined = CATEGORY_BG[this.post.category];
        return b !== undefined ? b : Theme.oceanLight;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(176:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Theme.bgPage);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavHeader(this, {
                        title: '帖子详情',
                        rightSlot: () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                If.create();
                                if (this.isMyPost && !this.isLoading) {
                                    this.ifElseBranchUpdateFunction(0, () => {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('删除');
                                            Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(179:11)", "entry");
                                            Text.fontSize(14);
                                            Text.fontColor(Theme.danger);
                                            Text.onClick(() => { this.deletePost(); });
                                        }, Text);
                                        Text.pop();
                                    });
                                }
                                else {
                                    this.ifElseBranchUpdateFunction(1, () => {
                                    });
                                }
                            }, If);
                            If.pop();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ConfessionDetailPage.ets", line: 177, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '帖子详情',
                            rightSlot: () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.isMyPost && !this.isLoading) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('删除');
                                                Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(179:11)", "entry");
                                                Text.fontSize(14);
                                                Text.fontColor(Theme.danger);
                                                Text.onClick(() => { this.deletePost(); });
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '帖子详情'
                    });
                }
            }, { name: "NavHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(184:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(185:11)", "entry");
                        LoadingProgress.color(Theme.primary);
                        LoadingProgress.width(36);
                        LoadingProgress.height(36);
                    }, LoadingProgress);
                    Column.pop();
                });
            }
            else if (this.errorMsg.length > 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(190:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('😕');
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(191:11)", "entry");
                        Text.fontSize(48);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(192:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textSecondary);
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(197:9)", "entry");
                        Scroll.layoutWeight(1);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(198:11)", "entry");
                        Column.padding({ left: 12, right: 12, top: 8, bottom: 80 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(199:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                        Column.borderRadius(Theme.cardRadius);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(200:15)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.post.publisherName);
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(201:17)", "entry");
                        Text.fontSize(14);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(this.post.createTime));
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(205:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ left: 10 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(209:17)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.post.category);
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(210:17)", "entry");
                        Text.fontSize(11);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(this.getCategoryColor());
                        Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                        Text.borderRadius(10);
                        Text.backgroundColor(this.getCategoryBg());
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.post.content);
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(220:15)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Theme.textPrimary);
                        Text.width('100%');
                        Text.margin({ top: 12 });
                        Text.lineHeight(24);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.images.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.images.length === 1) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Image.create(`${ApiService.baseUrl}${this.images[0]}`);
                                                Image.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(229:19)", "entry");
                                                Image.width('100%');
                                                Image.height(220);
                                                Image.borderRadius(Theme.radiusMd);
                                                Image.objectFit(ImageFit.Cover);
                                                Image.margin({ top: 12 });
                                            }, Image);
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Stack.create();
                                                Stack.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(236:19)", "entry");
                                                Stack.width('100%');
                                                Stack.height(220);
                                                Stack.margin({ top: 12 });
                                            }, Stack);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Swiper.create();
                                                Swiper.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(237:21)", "entry");
                                                Swiper.width('100%');
                                                Swiper.height(220);
                                                Swiper.autoPlay(false);
                                                Swiper.indicator(false);
                                                Swiper.loop(false);
                                                Swiper.onChange((index: number) => { this.swiperIndex = index; });
                                            }, Swiper);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                ForEach.create();
                                                const forEachItemGenFunction = _item => {
                                                    const img = _item;
                                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                        Image.create(`${ApiService.baseUrl}${img}`);
                                                        Image.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(239:25)", "entry");
                                                        Image.width('100%');
                                                        Image.height(220);
                                                        Image.objectFit(ImageFit.Cover);
                                                        Image.borderRadius(Theme.radiusMd);
                                                    }, Image);
                                                };
                                                this.forEachUpdateFunction(elmtId, this.images, forEachItemGenFunction, (img: string) => img, false, false);
                                            }, ForEach);
                                            ForEach.pop();
                                            Swiper.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                If.create();
                                                if (this.images.length > 1) {
                                                    this.ifElseBranchUpdateFunction(0, () => {
                                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                            Text.create(`${this.swiperIndex + 1}/${this.images.length}`);
                                                            Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(254:23)", "entry");
                                                            Text.fontSize(12);
                                                            Text.fontColor('#FFFFFF');
                                                            Text.backgroundColor('#00000066');
                                                            Text.borderRadius(Theme.radiusSm);
                                                            Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                                                            Text.position({ bottom: 8, right: 8 });
                                                        }, Text);
                                                        Text.pop();
                                                    });
                                                }
                                                else {
                                                    this.ifElseBranchUpdateFunction(1, () => {
                                                    });
                                                }
                                            }, If);
                                            If.pop();
                                            Stack.pop();
                                        });
                                    }
                                }, If);
                                If.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(268:15)", "entry");
                        Row.margin({ top: 14 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(269:17)", "entry");
                        Row.onClick(() => { this.toggleLike(); });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.post.liked ? '❤️' : '🤍');
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(270:19)", "entry");
                        Text.fontSize(16);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.post.likeCount}`);
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(271:19)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(this.post.liked ? Theme.danger : Theme.textTertiary);
                        Text.margin({ left: 4 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(278:17)", "entry");
                        Row.margin({ left: 24 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('💬');
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(279:19)", "entry");
                        Text.fontSize(16);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.post.commentCount}`);
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(280:19)", "entry");
                        Text.fontSize(13);
                        Text.fontColor(Theme.textTertiary);
                        Text.margin({ left: 4 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    Row.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(294:13)", "entry");
                        Divider.height(8);
                        Divider.color(Theme.bgPage);
                        Divider.width('100%');
                    }, Divider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(296:13)", "entry");
                        Column.width('100%');
                        Column.padding(16);
                        Column.backgroundColor('#FFFFFF');
                        Column.borderRadius(Theme.cardRadius);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`评论 (${this.comments.length})`);
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(297:15)", "entry");
                        Text.fontSize(15);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Theme.textPrimary);
                        Text.width('100%');
                        Text.margin({ bottom: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.comments.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const item = _item;
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Row.create();
                                            Row.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(306:19)", "entry");
                                            Row.width('100%');
                                            Row.padding({ top: 10, bottom: 10 });
                                            Row.alignItems(VerticalAlign.Top);
                                        }, Row);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Column.create();
                                            Column.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(307:21)", "entry");
                                            Column.layoutWeight(1);
                                            Column.alignItems(HorizontalAlign.Start);
                                        }, Column);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(item.nickname);
                                            Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(308:23)", "entry");
                                            Text.fontSize(13);
                                            Text.fontWeight(FontWeight.Medium);
                                            Text.fontColor(Theme.textPrimary);
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(item.content);
                                            Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(312:23)", "entry");
                                            Text.fontSize(14);
                                            Text.fontColor(Theme.textSecondary);
                                            Text.margin({ top: 4 });
                                            Text.width('100%');
                                        }, Text);
                                        Text.pop();
                                        Column.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(this.formatTime(item.createTime));
                                            Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(321:21)", "entry");
                                            Text.fontSize(11);
                                            Text.fontColor(Theme.textTertiary);
                                        }, Text);
                                        Text.pop();
                                        Row.pop();
                                    };
                                    this.forEachUpdateFunction(elmtId, this.comments, forEachItemGenFunction, (item: ConfessionComment) => `${item.id}`, false, false);
                                }, ForEach);
                                ForEach.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('暂无评论，来说点什么吧~');
                                    Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(330:17)", "entry");
                                    Text.fontSize(13);
                                    Text.fontColor(Theme.textTertiary);
                                    Text.width('100%');
                                    Text.textAlign(TextAlign.Center);
                                    Text.margin({ top: 20, bottom: 20 });
                                }, Text);
                                Text.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                    Column.pop();
                    Scroll.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(348:9)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 12, right: 12, top: 8, bottom: 8 });
                        Row.backgroundColor('#FFFFFF');
                        Row.shadow(ShadowStyle.md);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(349:11)", "entry");
                        Row.layoutWeight(1);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '写评论...', text: this.commentInput });
                        TextInput.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(350:13)", "entry");
                        TextInput.layoutWeight(1);
                        TextInput.height(40);
                        TextInput.fontSize(14);
                        TextInput.backgroundColor(Theme.bgInput);
                        TextInput.borderRadius(20);
                        TextInput.padding({ left: 16, right: 16 });
                        TextInput.onChange((val: string) => { this.commentInput = val; });
                    }, TextInput);
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.commentAnonymous === 1 ? '🎭' : '😎');
                        Text.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(361:11)", "entry");
                        Text.fontSize(20);
                        Text.margin({ left: 8 });
                        Text.onClick(() => {
                            this.commentAnonymous = this.commentAnonymous === 0 ? 1 : 0;
                        });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('发送');
                        Button.debugLine("entry/src/main/ets/pages/ConfessionDetailPage.ets(368:11)", "entry");
                        Button.type(ButtonType.Capsule);
                        Button.height(36);
                        Button.fontSize(13);
                        Button.backgroundColor(this.commentInput.trim().length > 0 ? Theme.primary : Theme.textDisabled);
                        Button.fontColor('#FFFFFF');
                        Button.margin({ left: 8 });
                        Button.enabled(this.commentInput.trim().length > 0 && !this.isSubmitting);
                        Button.onClick(() => { this.submitComment(); });
                    }, Button);
                    Button.pop();
                    Row.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    public resetStateVarsOnReuse(params: Object): void {
    }
    static getEntryName(): string {
        return "ConfessionDetailPage";
    }
}
registerNamedRoute(() => new ConfessionDetailPage(undefined, {}), "", { bundleName: "com.campus.assistant", moduleName: "entry", pagePath: "pages/ConfessionDetailPage", pageFullPath: "entry/src/main/ets/pages/ConfessionDetailPage", integratedHsp: "false", moduleType: "followWithHap" });
